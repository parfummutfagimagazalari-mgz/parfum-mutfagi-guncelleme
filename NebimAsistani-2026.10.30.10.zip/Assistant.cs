// =====================================================================================
// Nebim Asistanı — Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.
// Tasarım ve geliştirme: Ahmet Aksoy. Fikri ve ticari haklar Ahmet Aksoy'a aittir.
// Ahmet Aksoy'un yazılı izni olmadan değiştirilemez, kopyalanamaz, çoğaltılamaz,
// dağıtılamaz, satılamaz ve ticari olarak kullanılamaz. Ayrıntı: LISANS.txt
// =====================================================================================
// Nebim V3 STORE / ERP — Mahmutbey Şubesi (PM3401) Canlı Yol Gösterici Asistan Omurgası (v5.0)
// Ortam: C# 5 / .NET Framework 4.0 (csc.exe uyumlu)
// Mimari Temel: MerkezAtlasKesif.cs v4.6 + Mahmutbey Şubesi (PM3401, ekranlar.json ve 9 Mağaza Karosu)
// 1. [OPT-11] ÖN PLAN, SİMGE DURUMU, SESSION-ID DOĞRULAMASI VE KASA (NebimV3POS) KALKANI
// 2. [OPT-12] EKRANLAR.JSON MAĞAZA KATALOĞU + KENDİ KENDİNİ İYİLEŞTİREN CANLI REHBER
// 3. [OPT-13] GÜVENLİ VE DOĞRULAMALI "ARA…" KUTUSU PROTOKOLÜ + NEBİMYARDIMCI KUYRUK KÖPRÜSÜ
// 4. [OPT-14] RDP-DOSTU ÇERÇEVE ÇİZİMİ + YUVARLATILMIŞ KÖŞELİ CANLI MAKİNE EKRANI (Daktilo/Flaşörlü)
// 5. [OPT-15] MAHMUTBEY (PM3401) 9 MAĞAZA KAROSU, KARO AYARLARI SEKMESİ VE MAĞAZA HAREKET ÖZETİ
// =====================================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using System.Windows.Forms;

[assembly: System.Reflection.AssemblyTitle("Nebim Asistanı — Mahmutbey Şubesi (PM3401)")]
[assembly: System.Reflection.AssemblyProduct("Nebim Asistanı")]
[assembly: System.Reflection.AssemblyCompany("Ahmet Aksoy")]
[assembly: System.Reflection.AssemblyCopyright("Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.")]
[assembly: System.Reflection.AssemblyTrademark("Nebim Asistanı — Ahmet Aksoy")]

public class SubeAyar
{
    public string Kod = "PM3401";
    public string Ad = "Mahmutbey";
    public string Sunucu = "172.22.16.98";
    public bool Mcp = true;

    public static SubeAyar Parse(string text)
    {
        SubeAyar s = new SubeAyar();
        if (string.IsNullOrWhiteSpace(text)) return s;
        try
        {
            Dictionary<string, object> d = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(text.TrimStart('\uFEFF'));
            object v;
            if (d.TryGetValue("kod", out v) && v != null && Regex.IsMatch(Convert.ToString(v), "^[A-Za-z]{2}[0-9]{3,5}$"))
                s.Kod = Convert.ToString(v).ToUpperInvariant();
            if (d.TryGetValue("ad", out v) && v != null && Convert.ToString(v).Trim().Length > 0)
                s.Ad = Convert.ToString(v).Trim();
            if (d.TryGetValue("sunucu", out v) && v != null && Convert.ToString(v).Trim().Length > 0)
                s.Sunucu = Convert.ToString(v).Trim();
            if (d.TryGetValue("mcp", out v) && v is bool)
                s.Mcp = (bool)v;
        }
        catch { }
        return s;
    }

    public static string Save(string path, string kod, string ad, SubeAyar mevcut)
    {
        kod = (kod ?? "").Trim().ToUpperInvariant();
        ad = (ad ?? "").Trim();
        if (!Regex.IsMatch(kod, "^[A-Z]{2}[0-9]{3,5}$")) return "Şube kodu iki harf ve 3-5 rakam olmalı (örn. PM3402).";
        if (ad.Length < 2 || ad.Length > 40) return "Şube adı 2-40 karakter olmalı.";
        JavaScriptSerializer js = new JavaScriptSerializer();
        Dictionary<string, object> d = null;
        try
        {
            if (File.Exists(path))
                d = js.Deserialize<Dictionary<string, object>>(File.ReadAllText(path, Encoding.UTF8).TrimStart('\uFEFF'));
        }
        catch { d = null; }
        if (d == null) d = new Dictionary<string, object> { { "sunucu", mevcut.Sunucu }, { "mcp", mevcut.Mcp } };
        d["kod"] = kod;
        d["ad"] = ad;
        d["degisti"] = DateTime.Now.ToString("s");
        try
        {
            string tmp = path + ".yaz";
            File.WriteAllText(tmp, js.Serialize(d), new UTF8Encoding(false));
            if (File.Exists(path)) File.Replace(tmp, path, null);
            else File.Move(tmp, path);
        }
        catch (Exception e) { return "Kaydedilemedi: " + e.Message; }
        return null;
    }

    public static SubeAyar Load(string path)
    {
        try { return File.Exists(path) ? Parse(File.ReadAllText(path, Encoding.UTF8)) : new SubeAyar(); }
        catch { return new SubeAyar(); }
    }
}

public class NebimScreen
{
    public string Id;
    public string Ad;
    public string Grup;
    public string Yol;
    public string Tur;
    public string Onay;
    public string Etiket = "";
    public int Sira = 1;
    public string[] Anahtar = new string[0];
    public string[] Adimlar = new string[0];
    public override string ToString()
    {
        return Etiket + Ad + (Tur == "kayit" ? "  · kayıt" : Tur == "okuma" ? "  · bakış" : "  · öğrenildi");
    }
}

public class MerkezSalesSummary
{
    public bool ok;
    public bool hasSales;
    public double netSales;
    public double cashSales;
    public double cardSales;
    public int transactionCount;
    public double itemQuantity;
    public string sourceReport;
    public string updatedAt;
    public string dateKey;
    public string detailNote;
}

public class AtlasItem
{
    public string ekranId;
    public string kategori;
    public string baslik;
    public string menuYolu;
    public string bolge;
    public string controlType;
    public string automationId;
    public string className;
    public int sol;
    public int ust;
    public int sira;
    public string araMetni;
    public string ilkVeriAlani;
    public bool dogrulandi;
    public List<string> anahtarKelimeler;
    public List<string> rehberAdimlari;
}

public class GuidedStep
{
    public int stepNo;
    public string fieldName;
    public string instruction;
    public bool isActionStep;
    public bool completed;
    public AutomationElement element;
    public System.Windows.Rect lastRect;
    public int rdpSol;
    public int rdpUst;
    public int rdpGenislik;
    public int rdpYukseklik;
    public string initialValue;
}

public class Assistant
{
    public const string Surum = "5.0";
    private const int MaxDepth = 9;
    private const int ChildLimit = 140;

    public static string ServiceRoot
    {
        get { return Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..")); }
    }

    public static string SubeDosyasi
    {
        get { return Path.Combine(ServiceRoot, "sube.json"); }
    }

    public static SubeAyar Sube = SubeAyar.Load(SubeDosyasi);
    private static Process mcpServiceProcess;

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int dx;
        public int dy;
        public uint mouseData;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)]
        public MOUSEINPUT mi;
        [FieldOffset(0)]
        public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public InputUnion u;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct LASTINPUTINFO
    {
        public uint cbSize;
        public uint dwTime;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

    [DllImport("user32.dll")]
    private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();

    [StructLayout(LayoutKind.Sequential)]
    public struct WIN32_RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hWnd, StringBuilder lpClassName, int nMaxCount);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out WIN32_RECT lpRect);

    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool EnumChildWindows(IntPtr hWndParent, EnumWindowsProc lpEnumFunc, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    private const int SW_SHOWMAXIMIZED = 3;
    private const int SW_MINIMIZE = 6;
    private const int SW_RESTORE = 9;

    private const uint KEYEVENTF_KEYUP = 0x0002;
    private const uint KEYEVENTF_UNICODE = 0x0004;
    private const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    private const uint MOUSEEVENTF_LEFTUP = 0x0004;

    private const ushort VK_BACK = 0x08;
    private const ushort VK_TAB = 0x09;
    private const ushort VK_RETURN = 0x0D;
    private const ushort VK_CONTROL = 0x11;
    private const ushort VK_ESCAPE = 0x1B;
    private const ushort VK_SPACE = 0x20;
    private const ushort VK_DOWN = 0x28;
    private const ushort VK_DELETE = 0x2E;
    private const ushort VK_A = 0x41;
    private const ushort VK_C = 0x43;
    private const ushort VK_V = 0x56;
    private const ushort VK_F4 = 0x73;
    private const ushort VK_F5 = 0x74;

    public static readonly Dictionary<string, AtlasItem> Atlas = new Dictionary<string, AtlasItem>(StringComparer.OrdinalIgnoreCase);
    public static readonly List<AtlasItem> SolMenuCatalog = new List<AtlasItem>();
    public static readonly Dictionary<string, string> LearnedQueryToMenu = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
    public static readonly Dictionary<string, int> ScreenUsageCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
    public static string LastRequestedQuery = "";
    public static int LastRequestedTileIdx = -1;
    public static string LastAssistantOpenedScreen = "";
    public static DateTime LastRequestTime = DateTime.MinValue;
    public static string LastRecordedUsageScreen = "";
    private static DateTime StartupRemoteBinaryTime = DateTime.MinValue;

    private static readonly HashSet<string> SkipNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        "Close", "Minimize", "Maximize", "Restore", "Kapat", "Küçült", "Ekranı Kapla",
        "Ara…", "Ara", "Ara...", "Sistem", "System", "Expand", "Expand Collapse", "Expand collapse button",
        "Butonları konfigüre et!", "Standart Sürüm", "Soldaki Sütun", "Sağdaki Sütun",
        "Veri Paneli", "Başlık Paneli", "Footer Panel", "Tıkla", "Aç", "Application",
        "Ribbon Display Options", "lc", "dataLayoutControl1", "Görünüm", "Font",
        "Touch/fare modu", "Pin", "Auto Hide", "Yatay Kaydırma Çubuğu", "Dikey Kaydırma Çubuğu",
        "Horizontal ScrollBar", "Vertical ScrollBar", "Üstteki Çizgi", "Alttaki Çizgi",
        "Üstteki Sayfa", "Alttaki Sayfa", "Pozisyon", "Back by small amount", "Forward by small amount",
        "Back by large amount", "Forward by large amount", "System Menu Bar", "Statik",
        "Sağdaki Sayfa", "Soldaki Sayfa", "Ellipsis", "Error Text", "Zorunlu",
        "Filtreler", "Filtre", "Ve", "Veya", "Seçim", "Kriter", "Kriterler", "Eşittir", "İçerir", "Grup"
    };

    // =====================================================================================
    // ÖZ-TEST (--self-test) VE GERİYE DÖNÜK UYUMLULUK YARDIMCILARI
    // =====================================================================================
    public static string Norm(string s)
    {
        StringBuilder sb = new StringBuilder();
        foreach (char ch in (s ?? "").Trim())
        {
            char c = ch;
            switch (c)
            {
                case 'İ': case 'I': case 'ı': c = 'i'; break;
                case 'Ş': case 'ş': c = 's'; break;
                case 'Ğ': case 'ğ': c = 'g'; break;
                case 'Ü': case 'ü': c = 'u'; break;
                case 'Ö': case 'ö': c = 'o'; break;
                case 'Ç': case 'ç': c = 'c'; break;
                case 'â': c = 'a'; break;
                case 'î': c = 'i'; break;
                case 'û': c = 'u'; break;
                default: c = char.ToLowerInvariant(c); break;
            }
            sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
        }
        return " " + string.Join(" ", sb.ToString().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)) + " ";
    }

    private static readonly HashSet<string> StopWords = new HashSet<string>
    {
        "ac", "acar", "acin", "ekran", "ekrani", "ekranini", "ekranina", "menu", "menusu", "menuyu",
        "nebim", "lutfen", "bana", "icin", "nerede", "nasil", "istiyorum", "goster", "bir", "bu",
        "ve", "ile", "yapacagim", "yapmak", "yap", "yapalim", "nereden", "hangi", "ekranda", "bakmak",
        "bakacagim", "olan", "gerek", "lazim"
    };

    public static int Lev(string a, string b)
    {
        int n = a.Length, m = b.Length;
        if (n == 0) return m;
        if (m == 0) return n;
        int[,] d = new int[n + 1, m + 1];
        for (int i = 0; i <= n; i++) d[i, 0] = i;
        for (int j = 0; j <= m; j++) d[0, j] = j;
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                int cost = a[i - 1] == b[j - 1] ? 0 : 1;
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1])
                    d[i, j] = Math.Min(d[i, j], d[i - 2, j - 2] + 1);
            }
        }
        return d[n, m];
    }

    private static List<string> QueryTokens(string query)
    {
        List<string> tokens = new List<string>();
        foreach (string t in Norm(query).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            if (t.Length >= 2 && !StopWords.Contains(t)) tokens.Add(t);
        return tokens;
    }

    private static double TokenScore(string t, string hay, string[] words)
    {
        if (hay.Contains(" " + t)) return 1.0;
        if (t.Length >= 3 && hay.Contains(t)) return 0.8;
        if (t.Length < 4) return 0;
        double best = 0;
        int allow = t.Length >= 7 ? 2 : 1;
        foreach (string w in words)
        {
            if (w.Length < 3) continue;
            if (Math.Abs(w.Length - t.Length) <= allow)
            {
                int d = Lev(t, w);
                if (d <= allow)
                {
                    double s = 0.85 - 0.15 * (d - 1);
                    if (s > best) best = s;
                }
            }
            for (int len = t.Length - 1; len <= t.Length + 1; len++)
            {
                if (len < 3 || len >= w.Length) continue;
                int d = Lev(t, w.Substring(0, len));
                if (d <= allow && 0.6 > best) best = 0.6;
            }
            if (t.Length > w.Length && w.Length >= 4)
            {
                int d = Lev(t.Substring(0, w.Length), w);
                if (d == 0 && 0.6 > best) best = 0.6;
            }
        }
        return best;
    }

    private static double Score(NebimScreen sc, string query, List<string> tokens, out int matched)
    {
        matched = 0;
        string q = Norm(query);
        string hay = Norm(sc.Ad + " " + string.Join(" ", sc.Anahtar ?? new string[0]));
        string[] words = hay.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        double score = 0;
        foreach (string t in tokens)
        {
            double s = TokenScore(t, hay, words);
            if (s > 0) matched++;
            score += s;
        }
        if (sc.Anahtar != null)
        {
            foreach (string p in sc.Anahtar)
            {
                string np = Norm(p);
                if (np.Trim().Length > 0 && q.Contains(np)) score += 3;
            }
        }
        string nad = Norm(sc.Ad);
        if (nad == q) score += 10;
        else if (q.Trim().Length >= 4 && nad.Contains(q)) score += 2;
        if (score > 0) score -= 0.02 * nad.Trim().Split(' ').Length;
        return score;
    }

    public static List<NebimScreen> Match(IList<NebimScreen> list, string query)
    {
        List<string> tokens = QueryTokens(query);
        List<NebimScreen> result = new List<NebimScreen>();
        if (tokens.Count == 0) return result;
        string q = Norm(query);
        foreach (NebimScreen sc in list)
            if (Norm(sc.Ad) == q) { result.Add(sc); return result; }
        double best = 0;
        Dictionary<NebimScreen, double> scores = new Dictionary<NebimScreen, double>();
        foreach (NebimScreen sc in list)
        {
            int m;
            double s = Score(sc, query, tokens, out m);
            scores[sc] = s;
            if (s > best) best = s;
        }
        if (best < 0.6) return result;
        foreach (NebimScreen sc in list)
            if (scores[sc] >= best - 0.001) result.Add(sc);
        return result;
    }

    public static bool IsRemoteTitle(string title)
    {
        if (string.IsNullOrEmpty(title)) return false;
        string t = title.ToLower(new CultureInfo("tr-TR"));
        string srv = (Sube.Sunucu ?? "").ToLower(new CultureInfo("tr-TR"));
        return t.Contains("nebim") || t.Contains("172.22.16.98") || t.Contains("istgbzpmdsql") || (srv.Length > 0 && t.Contains(srv)) || title.Contains(" - ");
    }

    public static string Intent(string text)
    {
        string s = (text ?? "").Trim().ToLower(new CultureInfo("tr-TR"));
        switch (s)
        {
            case "satış": case "satis": case "satış raporu": return "satis";
            case "stok": case "stok raporu": return "stok";
            case "sayım": case "sayim": return "sayim";
            case "transfer": case "stok transferi": return "transfer";
            case "kampanya": case "personel": case "masraf": return s;
            case "kapanış": case "kapanis": return "kapanis";
            case "devam": case "geri": return s;
            case "durum": case "yenile": case "kaldığım yer": return "durum";
            default: return "";
        }
    }

    public static double ParseNumber(string v)
    {
        string s = (v ?? "").Replace("₺", "").Replace("TL", "").Replace("tl", "").Replace(" ", "").Replace("\u00a0", "").Trim();
        if (s.Length == 0) return double.NaN;
        if (s.Contains(",")) { s = s.Replace(".", "").Replace(",", "."); }
        else if (Regex.IsMatch(s, @"^-?\d{1,3}(\.\d{3})+$")) s = s.Replace(".", "");
        double d;
        return double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d) ? d : double.NaN;
    }

    public static string[] Quoted(string text)
    {
        List<string> l = new List<string>();
        foreach (Match m in Regex.Matches(text ?? "", "[\"“”«]([^\"“”«»]{2,60})[\"“”»]"))
        {
            string v = m.Groups[1].Value.Trim();
            if (v.Length >= 2 && !l.Contains(v)) l.Add(v);
        }
        return l.ToArray();
    }

    private static int RunSelfTest()
    {
        if (Intent(" SATIŞ ") != "satis" || Intent("stok transferi") != "transfer" || Intent("şunu sil") != "" || Intent("panele aktar") != "") return 1;
        if (Norm("Ürün Girişi!") != " urun girisi ") return 3;
        NebimScreen t1 = new NebimScreen { Id = "a", Ad = "Mağaza Sayım Fişi", Anahtar = new string[] { "sayim", "sayim fisi" } };
        NebimScreen t2 = new NebimScreen { Id = "b", Ad = "Envanter ve Sayım Fark Raporu", Anahtar = new string[] { "sayim farki" } };
        NebimScreen t3 = new NebimScreen { Id = "c", Ad = "Mağazaya Gelen İrsaliyeyi Onayla - Fiş Bazında", Anahtar = new string[] { "mal kabul", "urun girisi" } };
        NebimScreen t4 = new NebimScreen { Id = "d", Ad = "Mağaza Hareket Özeti", Anahtar = new string[] { "ciro", "gunsonu", "kasa" } };
        List<NebimScreen> tl = new List<NebimScreen> { t1, t2, t3, t4 };
        if (Match(tl, "sayım")[0] != t1 || Match(tl, "sayım farkı")[0] != t2 || Match(tl, "merhaba").Count != 0 || Match(tl, "Envanter ve Sayım Fark Raporu").Count != 1) return 4;
        if (Match(tl, "sayın fişi")[0] != t1 || Match(tl, "mal kabl")[0] != t3 || Match(tl, "gün sonu")[0] != t4 || Match(tl, "cirro")[0] != t4 || Match(tl, "irsalye onay")[0] != t3) return 6;
        if (Lev("sayim", "sayin") != 1 || Lev("kabul", "kabl") != 1) return 7;
        if (Math.Abs(ParseNumber("12.345,67") - 12345.67) > 0.001 || Math.Abs(ParseNumber("1.234") - 1234) > 0.001 || !double.IsNaN(ParseNumber(""))) return 8;
        if (Math.Abs(ParseNumber("-194.300,00") + 194300) > 0.001 || Math.Abs(ParseNumber("9.900,00") - 9900) > 0.001 || Math.Abs(ParseNumber("₺5.700,00") - 5700) > 0.001) return 21;
        SubeAyar sb1 = SubeAyar.Parse("{\"kod\":\"pm3402\",\"ad\":\"Bakırköy\",\"mcp\":false,\"sunucu\":\"10.0.0.5\"}");
        if (sb1.Kod != "PM3402" || sb1.Ad != "Bakırköy" || sb1.Mcp || sb1.Sunucu != "10.0.0.5") return 22;
        SubeAyar sb2 = SubeAyar.Parse("bozuk {");
        if (sb2.Kod != "PM3401" || !sb2.Mcp) return 23;
        SubeAyar sb3 = SubeAyar.Parse("{\"kod\":\"../x\"}");
        if (sb3.Kod != "PM3401") return 24;
        if (!IsRemoteTitle("PM - 172.22.16.98 - Uzak Masaüstü Bağlantısı") || IsRemoteTitle("Not Defteri")) return 25;
        CultureInfo trT0 = new CultureInfo("tr-TR");
        Func<string, string> bas = x => trT0.TextInfo.ToTitleCase(x.ToLower(trT0));
        if (bas("SİPARİŞ VER") != "Sipariş Ver" || bas("Merkeze iadeler") != "Merkeze İadeler" || bas("Ürün iade al") != "Ürün İade Al" || bas("Stok sayımı yap") != "Stok Sayımı Yap" || bas("Şirkete para gönder") != "Şirkete Para Gönder") return 29;
        string tf = Path.Combine(Path.GetTempPath(), "nebim-sube-test-" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            File.WriteAllText(tf, "{\"kod\":\"PM3402\",\"ad\":\"Eski\",\"mcp\":false,\"merkez\":{\"etkin\":false,\"port\":3443}}", new UTF8Encoding(false));
            if (SubeAyar.Save(tf, "pm3403", "Bakırköy", new SubeAyar()) != null) return 26;
            SubeAyar y2 = SubeAyar.Load(tf);
            string raw2 = File.ReadAllText(tf, Encoding.UTF8);
            if (y2.Kod != "PM3403" || y2.Ad != "Bakırköy" || y2.Mcp || !raw2.Contains("merkez") || !raw2.Contains("3443")) return 27;
            if (SubeAyar.Save(tf, "X1", "Ad", new SubeAyar()) == null || SubeAyar.Save(tf, "PM3404", "A", new SubeAyar()) == null) return 28;
        }
        finally { try { File.Delete(tf); } catch { } }
        if (Quoted("Alttaki \"Çalıştır\" düğmesi ve “Zorunlu Filtreler”").Length != 2) return 9;
        if (!IsRemoteTitle("172.22.16.98 - Uzak Masaüstü Bağlantısı") || !IsRemoteTitle("Nebim - 172.22.16.98 - Remote Desktop Connection") || IsRemoteTitle("Uzak Masaüstü Bağlantısı") || IsRemoteTitle("")) return 2;
        return 0;
    }

    public static void StartMcpServiceIfNeeded()
    {
        try
        {
            if (!Sube.Mcp) return;
            if (mcpServiceProcess != null && !mcpServiceProcess.HasExited) return;
            try
            {
                foreach (string p in Directory.GetFiles(@"\\.\pipe\"))
                {
                    if (Path.GetFileName(p).StartsWith("NebimMCP-", StringComparison.OrdinalIgnoreCase))
                        return;
                }
            }
            catch { }
            try
            {
                FileInfo f = new FileInfo(Path.Combine(ServiceRoot, "state", "service-status.json"));
                if (f.Exists && (DateTime.Now - f.LastWriteTime).TotalSeconds < 75) return;
            }
            catch { }

            string node = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "nodejs", "node.exe");
            string svcScript = Path.Combine(ServiceRoot, "src", "service.mjs");
            string cfgFile = Path.Combine(ServiceRoot, "config.json");
            if (!File.Exists(node) || !File.Exists(svcScript)) return;

            ProcessStartInfo info = new ProcessStartInfo(node, "\"" + svcScript + "\" \"" + cfgFile + "\"")
            {
                WorkingDirectory = ServiceRoot,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            mcpServiceProcess = Process.Start(info);
        }
        catch { }
    }

    [STAThread]
    public static int Main(string[] args)
    {
        if (args != null && args.Length == 1 && args[0] == "--self-test")
        {
            return RunSelfTest();
        }

        try { SetProcessDPIAware(); } catch { }

        bool created;
        using (Mutex mutex = new Mutex(true, "Local\\NebimFloatingAssistantV1", out created))
        {
            if (!created)
            {
                try
                {
                    using (EventWaitHandle signal = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\NebimAssistantShowV1"))
                    {
                        signal.Set();
                    }
                }
                catch { }
                return 0;
            }

            Sube = SubeAyar.Load(SubeDosyasi);
            RecordInitialRemoteBinaryTimestamp();
            LoadStoreCatalogFromEkranlarJson();
            LoadUserMemory();
            EnrichAllAtlasItemsWithGuideMetadata();
            LoadExistingGuideCatalogOverrides();

            AutomationElement erpWin = FindErpWindow();
            IntPtr rdpWin = FindRdpClientWindow();
            string winTitle = erpWin != null ? SafeGetName(erpWin) : (rdpWin != IntPtr.Zero ? "Uzak Masaüstü (Nebim V3 STORE)" : "Nebim V3 STORE (" + Sube.Kod + ")");

            SaveGuideCatalogJson(winTitle);
            LogLine("=== Nebim Asistanı (" + Sube.Ad + " - " + Sube.Kod + ") v5.0 Başlatıldı | Pencere: " + winTitle + " | Mağaza Kataloğu: " + SolMenuCatalog.Count + " ekran ===");

            if (args != null && args.Length > 0 && string.Equals(args[0], "--sadece-atlas", StringComparison.OrdinalIgnoreCase))
            {
                return 0;
            }

            string initialAutoOpenMenu = "";
            if (args != null && args.Length >= 2 && string.Equals(args[0], "--ac", StringComparison.OrdinalIgnoreCase))
            {
                initialAutoOpenMenu = args[1];
            }
            else if (args != null && args.Length >= 1 && string.Equals(args[0], "--canli-test", StringComparison.OrdinalIgnoreCase))
            {
                initialAutoOpenMenu = args.Length >= 2 ? args[1] : "Mağaza Sayım Fişi";
            }

            StartMcpServiceIfNeeded();
            MinimizeOwnConsoleAndFocusErp(erpWin);

            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new RehberKontrolMerkezi(initialAutoOpenMenu));
        }
        return 0;
    }

    public static void MinimizeOwnConsoleAndFocusErp(AutomationElement erpWin)
    {
        try
        {
            IntPtr cw = GetConsoleWindow();
            if (cw != IntPtr.Zero)
            {
                ShowWindow(cw, SW_MINIMIZE);
            }
        }
        catch { }

        try
        {
            if (erpWin == null) erpWin = FindErpWindow();
            if (erpWin != null && !IsPosForeground())
            {
                IntPtr hErp = new IntPtr(erpWin.Current.NativeWindowHandle);
                if (hErp != IntPtr.Zero)
                {
                    if (IsIconic(hErp)) ShowWindow(hErp, SW_RESTORE);
                    BringWindowToFrontSafe(hErp);
                }
            }
        }
        catch { }
    }

    public static void LogLine(string message)
    {
        string line = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "] " + message;
        try { Console.WriteLine(line); } catch { }
        try
        {
            string logPath = Path.Combine(ResolveOutputDir(), "mahmutbey-rehber-log.txt");
            File.AppendAllText(logPath, line + Environment.NewLine, new UTF8Encoding(false));
        }
        catch { }
    }

    private static void RecordInitialRemoteBinaryTimestamp()
    {
        try
        {
            string exePath = Application.ExecutablePath;
            if (File.Exists(exePath))
            {
                StartupRemoteBinaryTime = File.GetLastWriteTimeUtc(exePath);
            }
        }
        catch { }
    }

    public static bool CheckIfRemoteBinaryUpdated()
    {
        return false;
    }

    public static string NormTr(string s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        StringBuilder sb = new StringBuilder(s.Length);
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            switch (c)
            {
                case 'I': case 'İ': case 'ı': case 'i': sb.Append('i'); break;
                case 'Ş': case 'ş': sb.Append('s'); break;
                case 'Ğ': case 'ğ': sb.Append('g'); break;
                case 'Ü': case 'ü': sb.Append('u'); break;
                case 'Ö': case 'ö': sb.Append('o'); break;
                case 'Ç': case 'ç': sb.Append('c'); break;
                default: sb.Append(char.ToLowerInvariant(c)); break;
            }
        }
        return sb.ToString().Trim();
    }

    public static int GetScreenUsageCount(string baslik)
    {
        if (string.IsNullOrEmpty(baslik)) return 0;
        int c;
        if (ScreenUsageCounts.TryGetValue(baslik.Trim(), out c)) return c;
        return 0;
    }

    public static bool IsLearnedFavoriteScreen(string baslik)
    {
        if (string.IsNullOrEmpty(baslik)) return false;
        if (GetScreenUsageCount(baslik) >= 2) return true;
        foreach (string v in LearnedQueryToMenu.Values)
        {
            if (string.Equals(v, baslik, StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    public static void AddLearnedMenuToStoreAtlas(string kategori, string baslik, string[] anahtarlar)
    {
        if (string.IsNullOrEmpty(baslik) || SkipNames.Contains(baslik)) return;
        foreach (AtlasItem existing in Atlas.Values)
        {
            if (existing.bolge == "SOL_MENU" && string.Equals(existing.baslik, baslik, StringComparison.OrdinalIgnoreCase))
            {
                if (existing.anahtarKelimeler == null) existing.anahtarKelimeler = new List<string>();
                if (anahtarlar != null)
                {
                    for (int i = 0; i < anahtarlar.Length; i++)
                    {
                        if (!string.IsNullOrEmpty(anahtarlar[i]) && !existing.anahtarKelimeler.Contains(anahtarlar[i]))
                        {
                            existing.anahtarKelimeler.Add(anahtarlar[i]);
                        }
                    }
                }
                return;
            }
        }
        string kat = string.IsNullOrEmpty(kategori) ? "Öğrenilen Mağaza Ekranları" : kategori;
        AtlasItem it = new AtlasItem();
        it.ekranId = "ogr:" + baslik;
        it.kategori = kat;
        it.baslik = baslik;
        it.menuYolu = kat + " → " + baslik;
        it.bolge = "SOL_MENU";
        it.controlType = "TreeItem";
        it.automationId = it.ekranId;
        it.className = "LearnedStoreScreen";
        it.sira = 1;
        it.araMetni = BuildSearchBoxQuery(baslik);
        it.ilkVeriAlani = InferFirstInputField(kat, baslik, it.menuYolu);
        it.anahtarKelimeler = new List<string> { NormTr(baslik) };
        if (anahtarlar != null)
        {
            for (int i = 0; i < anahtarlar.Length; i++)
            {
                if (!string.IsNullOrEmpty(anahtarlar[i]) && !it.anahtarKelimeler.Contains(anahtarlar[i]))
                {
                    it.anahtarKelimeler.Add(anahtarlar[i]);
                }
            }
        }
        it.rehberAdimlari = BuildDefaultGuideSteps(kat, baslik, it.ilkVeriAlani);
        Atlas["SOL_MENU|" + kat + "|" + baslik] = it;
    }

    public static void LoadUserMemory()
    {
        try
        {
            string outDir = ResolveOutputDir();
            string learnedPath = Path.Combine(outDir, "ogrenilen-ekranlar.json");
            if (File.Exists(learnedPath))
            {
                try
                {
                    string rawL = File.ReadAllText(learnedPath, Encoding.UTF8);
                    MatchCollection mc = Regex.Matches(rawL, "\"ad\"\\s*:\\s*\"([^\"]+)\"[\\s\\S]*?\"sayac\"\\s*:\\s*(\\d+)");
                    foreach (Match m in mc)
                    {
                        string ad = JsonUnescape(m.Groups[1].Value.Trim());
                        int cnt = 0;
                        int.TryParse(m.Groups[2].Value, out cnt);
                        if (ad.Length > 0 && cnt > 0)
                        {
                            int cur;
                            if (!ScreenUsageCounts.TryGetValue(ad, out cur) || cnt > cur)
                            {
                                ScreenUsageCounts[ad] = cnt;
                            }
                        }
                    }
                }
                catch { }
            }

            string[] memFiles = new string[]
            {
                Path.Combine(outDir, "kullanici-hafiza.json"),
                Path.Combine(outDir, "merkez-kesif", "kullanici-hafiza.json")
            };
            for (int f = 0; f < memFiles.Length; f++)
            {
                string mp = memFiles[f];
                if (string.IsNullOrEmpty(mp) || !File.Exists(mp)) continue;
                try
                {
                    string rawM = File.ReadAllText(mp, Encoding.UTF8);
                    MatchCollection mcMap = Regex.Matches(rawM, "\\{\"sorgu\":\"(.*?)\",\"hedef\":\"(.*?)\"\\}");
                    foreach (Match m in mcMap)
                    {
                        string q = JsonUnescape(m.Groups[1].Value).Trim();
                        string h = JsonUnescape(m.Groups[2].Value).Trim();
                        if (q.Length > 0 && h.Length > 0)
                        {
                            LearnedQueryToMenu[NormTr(q)] = h;
                            AddLearnedMenuToStoreAtlas("Öğrenilen Mağaza Ekranları", h, new string[] { NormTr(q) });
                        }
                    }

                    MatchCollection mcCnt = Regex.Matches(rawM, "\\{\"ekran\":\"(.*?)\",\"sayac\":(\\d+)\\}");
                    foreach (Match m in mcCnt)
                    {
                        string ek = JsonUnescape(m.Groups[1].Value).Trim();
                        int cnt = 0;
                        int.TryParse(m.Groups[2].Value, out cnt);
                        if (ek.Length > 0 && cnt > 0)
                        {
                            int cur;
                            if (!ScreenUsageCounts.TryGetValue(ek, out cur) || cnt > cur)
                            {
                                ScreenUsageCounts[ek] = cnt;
                            }
                            AddLearnedMenuToStoreAtlas("Öğrenilen Mağaza Ekranları", ek, null);
                        }
                    }
                }
                catch { }
            }
        }
        catch { }
    }

    public static void SaveUserMemory()
    {
        try
        {
            string outDir = ResolveOutputDir();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"guncelleme\": \"" + JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) + "\",");
            sb.AppendLine("  \"eslesmeler\": [");
            int idx = 0;
            foreach (KeyValuePair<string, string> kv in LearnedQueryToMenu)
            {
                idx++;
                string comma = idx < LearnedQueryToMenu.Count ? "," : "";
                sb.AppendLine("    {\"sorgu\":\"" + JsonEscape(kv.Key) + "\",\"hedef\":\"" + JsonEscape(kv.Value) + "\"}" + comma);
            }
            sb.AppendLine("  ],");
            sb.AppendLine("  \"sayaclar\": [");
            idx = 0;
            foreach (KeyValuePair<string, int> kv in ScreenUsageCounts)
            {
                idx++;
                string comma = idx < ScreenUsageCounts.Count ? "," : "";
                sb.AppendLine("    {\"ekran\":\"" + JsonEscape(kv.Key) + "\",\"sayac\":" + kv.Value + "}" + comma);
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");

            AtomicWriteText(Path.Combine(outDir, "kullanici-hafiza.json"), sb.ToString());
        }
        catch { }
    }

    private static void SortAtlasListByUsage(List<AtlasItem> list)
    {
        if (list == null || list.Count <= 1) return;
        list.Sort(delegate(AtlasItem a, AtlasItem b)
        {
            int ca = GetScreenUsageCount(a.baslik);
            int cb = GetScreenUsageCount(b.baslik);
            if (ca != cb) return cb.CompareTo(ca);
            return string.Compare(a.baslik, b.baslik, StringComparison.OrdinalIgnoreCase);
        });
    }

    public static List<AtlasItem> FilterMenusByQuery(string rawQuery, int maxResults)
    {
        List<AtlasItem> exactList = new List<AtlasItem>();
        List<AtlasItem> startsList = new List<AtlasItem>();
        List<AtlasItem> containsList = new List<AtlasItem>();
        List<AtlasItem> tokenList = new List<AtlasItem>();

        string qClean = (rawQuery ?? "").Trim();
        if (qClean.StartsWith("⭐ ")) qClean = qClean.Substring(2).Trim();
        string qNorm = NormTr(qClean);
        if (qNorm.Length == 0)
        {
            List<AtlasItem> allSorted = new List<AtlasItem>(SolMenuCatalog);
            SortAtlasListByUsage(allSorted);
            for (int i = 0; i < allSorted.Count && exactList.Count < maxResults; i++)
            {
                exactList.Add(allSorted[i]);
            }
            return exactList;
        }

        string[] tokens = qNorm.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        HashSet<string> seenTitles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        string learnedTarget;
        if (LearnedQueryToMenu.TryGetValue(qNorm, out learnedTarget) && !string.IsNullOrEmpty(learnedTarget))
        {
            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                AtlasItem lit = SolMenuCatalog[i];
                if (lit != null && string.Equals(lit.baslik, learnedTarget, StringComparison.OrdinalIgnoreCase))
                {
                    if (seenTitles.Add(lit.baslik)) exactList.Add(lit);
                    break;
                }
            }
        }

        for (int i = 0; i < SolMenuCatalog.Count; i++)
        {
            AtlasItem it = SolMenuCatalog[i];
            if (it == null || string.IsNullOrEmpty(it.baslik)) continue;
            if (!seenTitles.Add(it.baslik)) continue;

            string bNorm = NormTr(it.baslik);
            string aNorm = NormTr(it.araMetni);
            string kNorm = NormTr(it.kategori);
            string yNorm = NormTr(it.menuYolu);
            string idNorm = NormTr(it.ekranId);
            string kwNorm = (it.anahtarKelimeler != null && it.anahtarKelimeler.Count > 0)
                ? NormTr(string.Join(" ", it.anahtarKelimeler.ToArray()))
                : "";

            if (bNorm == qNorm || aNorm == qNorm || idNorm == qNorm)
            {
                exactList.Add(it);
            }
            else if (bNorm.StartsWith(qNorm, StringComparison.Ordinal) || aNorm.StartsWith(qNorm, StringComparison.Ordinal))
            {
                startsList.Add(it);
            }
            else if (bNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0 ||
                     aNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0 ||
                     kwNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0)
            {
                containsList.Add(it);
            }
            else if (tokens.Length > 0)
            {
                bool allTokensMatch = true;
                string combined = bNorm + " " + kNorm + " " + yNorm + " " + kwNorm;
                for (int t = 0; t < tokens.Length; t++)
                {
                    if (combined.IndexOf(tokens[t], StringComparison.Ordinal) < 0)
                    {
                        allTokensMatch = false;
                        break;
                    }
                }
                if (allTokensMatch)
                {
                    tokenList.Add(it);
                }
            }
        }

        SortAtlasListByUsage(startsList);
        SortAtlasListByUsage(containsList);
        SortAtlasListByUsage(tokenList);

        List<AtlasItem> merged = new List<AtlasItem>();
        for (int i = 0; i < exactList.Count && merged.Count < maxResults; i++) merged.Add(exactList[i]);
        for (int i = 0; i < startsList.Count && merged.Count < maxResults; i++) merged.Add(startsList[i]);
        for (int i = 0; i < containsList.Count && merged.Count < maxResults; i++) merged.Add(containsList[i]);
        for (int i = 0; i < tokenList.Count && merged.Count < maxResults; i++) merged.Add(tokenList[i]);
        return merged;
    }

    public static string ResolveBestMenuQuery(string rawInput, out AtlasItem matchedCatalogItem)
    {
        matchedCatalogItem = null;
        string cleaned = (rawInput ?? "").Trim();
        if (cleaned.StartsWith("⭐ ")) cleaned = cleaned.Substring(2).Trim();
        int bracketIdx = cleaned.LastIndexOf("  [");
        if (bracketIdx > 0) cleaned = cleaned.Substring(0, bracketIdx).Trim();
        if (cleaned.Length == 0) return "";

        string qNorm = NormTr(cleaned);
        string learnedTarget;
        if (LearnedQueryToMenu.TryGetValue(qNorm, out learnedTarget) && !string.IsNullOrEmpty(learnedTarget))
        {
            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                if (string.Equals(SolMenuCatalog[i].baslik, learnedTarget, StringComparison.OrdinalIgnoreCase))
                {
                    matchedCatalogItem = SolMenuCatalog[i];
                    return !string.IsNullOrEmpty(matchedCatalogItem.araMetni)
                        ? matchedCatalogItem.araMetni
                        : BuildSearchBoxQuery(matchedCatalogItem.baslik);
                }
            }
            return BuildSearchBoxQuery(learnedTarget);
        }

        List<AtlasItem> matches = FilterMenusByQuery(cleaned, 5);
        if (matches.Count > 0)
        {
            AtlasItem top = matches[0];
            string bNorm = NormTr(top.baslik);
            string aNorm = NormTr(top.araMetni);
            string kwNorm = (top.anahtarKelimeler != null && top.anahtarKelimeler.Count > 0)
                ? NormTr(string.Join(" ", top.anahtarKelimeler.ToArray()))
                : "";
            if (bNorm == qNorm || aNorm == qNorm ||
                bNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0 ||
                aNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0 ||
                qNorm.IndexOf(bNorm, StringComparison.Ordinal) >= 0 ||
                (kwNorm.Length > 0 && kwNorm.IndexOf(qNorm, StringComparison.Ordinal) >= 0))
            {
                matchedCatalogItem = top;
                if (!string.IsNullOrEmpty(matchedCatalogItem.araMetni))
                {
                    return matchedCatalogItem.araMetni;
                }
                return BuildSearchBoxQuery(matchedCatalogItem.baslik);
            }
        }
        return BuildSearchBoxQuery(cleaned);
    }

    public static void LoadStoreCatalogFromEkranlarJson()
    {
        Atlas.Clear();
        JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 4 * 1024 * 1024 };

        string[] candidatePaths = new string[]
        {
            Path.Combine(ResolveOutputDir(), "ekranlar.json"),
            Path.Combine(ServiceRoot, "sunucu-yardimci", "ekranlar.json")
        };

        string loadedPath = null;
        for (int p = 0; p < candidatePaths.Length; p++)
        {
            if (File.Exists(candidatePaths[p]))
            {
                loadedPath = candidatePaths[p];
                break;
            }
        }

        if (loadedPath != null)
        {
            try
            {
                string raw = File.ReadAllText(loadedPath, Encoding.UTF8).TrimStart('\uFEFF');
                Dictionary<string, object> doc = js.Deserialize<Dictionary<string, object>>(raw);
                if (doc != null && doc.ContainsKey("ekranlar") && doc["ekranlar"] is System.Collections.IEnumerable)
                {
                    foreach (object o in (System.Collections.IEnumerable)doc["ekranlar"])
                    {
                        Dictionary<string, object> d = o as Dictionary<string, object>;
                        if (d == null) continue;

                        string id = d.ContainsKey("id") && d["id"] != null ? Convert.ToString(d["id"]).Trim() : "";
                        string ad = d.ContainsKey("ad") && d["ad"] != null ? Convert.ToString(d["ad"]).Trim() : "";
                        string grup = d.ContainsKey("grup") && d["grup"] != null ? Convert.ToString(d["grup"]).Trim() : "Mağaza İşlemleri";
                        string yol = d.ContainsKey("yol") && d["yol"] != null ? Convert.ToString(d["yol"]).Trim() : ad;
                        int sira = 1;
                        if (d.ContainsKey("sira") && d["sira"] != null)
                        {
                            try { sira = Math.Max(1, Convert.ToInt32(d["sira"])); } catch { sira = 1; }
                        }

                        if (ad.Length == 0) continue;

                        AtlasItem it = new AtlasItem();
                        it.ekranId = id.Length > 0 ? id : NormTr(ad).Replace(" ", "-");
                        it.kategori = grup;
                        it.baslik = ad;
                        it.menuYolu = yol;
                        it.bolge = "SOL_MENU";
                        it.controlType = "TreeItem";
                        it.automationId = it.ekranId;
                        it.className = "NebimStoreScreen";
                        it.sira = sira;
                        it.araMetni = BuildSearchBoxQuery(ad);
                        it.anahtarKelimeler = new List<string>();
                        if (d.ContainsKey("anahtar") && d["anahtar"] is System.Collections.IEnumerable)
                        {
                            foreach (object kObj in (System.Collections.IEnumerable)d["anahtar"])
                            {
                                string kw = Convert.ToString(kObj ?? "").Trim();
                                if (kw.Length > 0) it.anahtarKelimeler.Add(kw);
                            }
                        }

                        it.rehberAdimlari = new List<string>();
                        if (d.ContainsKey("adimlar") && d["adimlar"] is System.Collections.IEnumerable)
                        {
                            int stepNum = 1;
                            foreach (object stObj in (System.Collections.IEnumerable)d["adimlar"])
                            {
                                string st = Convert.ToString(stObj ?? "").Trim();
                                if (st.Length > 0)
                                {
                                    it.rehberAdimlari.Add(stepNum + ". " + st);
                                    stepNum++;
                                }
                            }
                        }

                        string[] quotedFields = Quoted(string.Join(" ", it.rehberAdimlari.ToArray()));
                        it.ilkVeriAlani = (quotedFields.Length > 0)
                            ? quotedFields[0]
                            : InferFirstInputField(it.kategori, it.baslik, it.menuYolu);

                        string key = "SOL_MENU|" + it.kategori + "|" + it.baslik;
                        Atlas[key] = it;
                    }
                }
            }
            catch (Exception ex)
            {
                LogLine("[KATALOG] ekranlar.json okuma uyarısı: " + ex.Message);
            }
        }

        // Öğrenilen ekranları da (ogrenilen-ekranlar.json) mağaza kataloğuna dahil et
        try
        {
            string learnedPath = Path.Combine(ResolveOutputDir(), "ogrenilen-ekranlar.json");
            if (File.Exists(learnedPath))
            {
                string rawL = File.ReadAllText(learnedPath, Encoding.UTF8).TrimStart('\uFEFF');
                Dictionary<string, object> ld = js.Deserialize<Dictionary<string, object>>(rawL);
                if (ld != null && ld.ContainsKey("ekranlar") && ld["ekranlar"] is System.Collections.IEnumerable)
                {
                    foreach (object o in (System.Collections.IEnumerable)ld["ekranlar"])
                    {
                        Dictionary<string, object> d = o as Dictionary<string, object>;
                        if (d == null) continue;
                        string ad = d.ContainsKey("ad") && d["ad"] != null ? Convert.ToString(d["ad"]).Trim() : "";
                        if (ad.Length < 4 || SkipNames.Contains(ad) ||
                            ad.IndexOf("EmptySpace", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("LayoutControl", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Satır ", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("[", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("]", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.StartsWith("tcg", StringComparison.OrdinalIgnoreCase) ||
                            ad.StartsWith("tbc", StringComparison.OrdinalIgnoreCase) ||
                            ad.StartsWith("lcg", StringComparison.OrdinalIgnoreCase) ||
                            ad.IndexOf("Error Text", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Zorunlu", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Quick Access", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Caption Bar", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Ribbon", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("15:0", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("MainView", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("MainGroup", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            ad.IndexOf("Filter control", StringComparison.OrdinalIgnoreCase) >= 0) continue;

                        bool alreadyIn = false;
                        foreach (AtlasItem exIt in Atlas.Values)
                        {
                            if (string.Equals(exIt.baslik, ad, StringComparison.OrdinalIgnoreCase))
                            {
                                alreadyIn = true;
                                break;
                            }
                        }
                        if (alreadyIn) continue;

                        AtlasItem it = new AtlasItem();
                        it.ekranId = "ogr:" + ad;
                        it.kategori = "Öğrenilen Mağaza Ekranları";
                        it.baslik = ad;
                        it.menuYolu = "Nebim V3 STORE → " + ad;
                        it.bolge = "SOL_MENU";
                        it.controlType = "TreeItem";
                        it.automationId = it.ekranId;
                        it.className = "LearnedStoreScreen";
                        it.sira = 1;
                        it.araMetni = BuildSearchBoxQuery(ad);
                        it.ilkVeriAlani = InferFirstInputField(it.kategori, it.baslik, it.menuYolu);
                        it.anahtarKelimeler = new List<string> { NormTr(ad) };
                        it.rehberAdimlari = BuildDefaultGuideSteps(it.kategori, it.baslik, it.ilkVeriAlani);
                        Atlas["SOL_MENU|" + it.kategori + "|" + it.baslik] = it;
                    }
                }
            }
        }
        catch { }

        // Merkez ERP rehber kataloğunu da (merkez-rehber-katalog.json) ortak çapraz atlas olarak birleştir
        try
        {
            string[] merkezCatPaths = new string[]
            {
                Path.Combine(ResolveOutputDir(), "merkez-rehber-katalog.json"),
                Path.Combine(ResolveOutputDir(), "merkez-kesif", "merkez-rehber-katalog.json")
            };
            for (int mcIdx = 0; mcIdx < merkezCatPaths.Length; mcIdx++)
            {
                string mcp = merkezCatPaths[mcIdx];
                if (!File.Exists(mcp)) continue;
                string rawMc = File.ReadAllText(mcp, Encoding.UTF8);
                MatchCollection mItems = Regex.Matches(rawMc, "\"kategori\"\\s*:\\s*\"([^\"]+)\"[^\\}]*?\"baslik\"\\s*:\\s*\"([^\"]+)\"[^\\}]*?\"ilkVeriAlani\"\\s*:\\s*\"([^\"]*)\"");
                foreach (Match m in mItems)
                {
                    string kat = JsonUnescape(m.Groups[1].Value.Trim());
                    string bas = JsonUnescape(m.Groups[2].Value.Trim());
                    string ilk = JsonUnescape(m.Groups[3].Value.Trim());
                    if (bas.Length < 4 || SkipNames.Contains(bas)) continue;
                    string key = "SOL_MENU|" + kat + "|" + bas;
                    if (!Atlas.ContainsKey(key))
                    {
                        AtlasItem it = new AtlasItem();
                        it.ekranId = NormTr(bas).Replace(" ", "-");
                        it.kategori = kat;
                        it.baslik = bas;
                        it.menuYolu = kat + " → " + bas;
                        it.bolge = "SOL_MENU";
                        it.controlType = "TreeItem";
                        it.automationId = it.ekranId;
                        it.className = "NebimErpCrossScreen";
                        it.sira = 1;
                        it.araMetni = BuildSearchBoxQuery(bas);
                        it.ilkVeriAlani = !string.IsNullOrEmpty(ilk) ? ilk : InferFirstInputField(kat, bas, it.menuYolu);
                        it.anahtarKelimeler = new List<string> { NormTr(bas) };
                        it.rehberAdimlari = BuildDefaultGuideSteps(kat, bas, it.ilkVeriAlani);
                        Atlas[key] = it;
                    }
                }
                break;
            }
        }
        catch { }

        // Mal Kabul ve alt klasörlerdeki ek onay ekranlarını da mağaza kataloğuna ekle
        string[][] extraStoreMenus = new string[][]
        {
            new string[] { "Stok giriş/transfer", "İade Gelen Ürünleri Onayla (Onl.Bayi) - Fiş Bazında", "gelen urunler|gelen urunleri onayla|iade gelen|mal kabul" },
            new string[] { "Stok giriş/transfer", "İade Gelen Ürünleri Onayla (Onl.Bayi) - Ürün Detaylı", "gelen urunler|iade gelen urun detayli|mal kabul urun detayli" },
            new string[] { "Stok giriş/transfer", "Diğer Ofisten Yapılan Transferi Onayla - Fiş Bazında", "gelen urunler|diger ofisten|transfer onayla" },
            new string[] { "Stok giriş/transfer", "Diğer Ofisten Yapılan Transferi Onayla - Ürün Detaylı", "gelen urunler|diger ofisten urun detayli" }
        };
        for (int e = 0; e < extraStoreMenus.Length; e++)
        {
            string kat = extraStoreMenus[e][0];
            string ad = extraStoreMenus[e][1];
            string[] kws = extraStoreMenus[e][2].Split('|');
            string key = "SOL_MENU|" + kat + "|" + ad;
            if (!Atlas.ContainsKey(key))
            {
                AtlasItem it = new AtlasItem();
                it.ekranId = NormTr(ad).Replace(" ", "-");
                it.kategori = kat;
                it.baslik = ad;
                it.menuYolu = kat + " → " + ad;
                it.bolge = "SOL_MENU";
                it.controlType = "TreeItem";
                it.automationId = it.ekranId;
                it.className = "NebimStoreScreen";
                it.sira = 1;
                it.araMetni = BuildSearchBoxQuery(ad);
                it.ilkVeriAlani = InferFirstInputField(kat, ad, it.menuYolu);
                it.anahtarKelimeler = new List<string>(kws);
                it.rehberAdimlari = BuildDefaultGuideSteps(kat, ad, it.ilkVeriAlani);
                Atlas[key] = it;
            }
        }
    }

    public static void EnrichAllAtlasItemsWithGuideMetadata()
    {
        SolMenuCatalog.Clear();
        foreach (AtlasItem it in Atlas.Values)
        {
            if (it.bolge == "SOL_MENU")
            {
                if (it.sira < 1) it.sira = 1;
                if (string.IsNullOrEmpty(it.araMetni))
                {
                    it.araMetni = BuildSearchBoxQuery(it.baslik);
                }
                if (string.IsNullOrEmpty(it.ilkVeriAlani))
                {
                    it.ilkVeriAlani = InferFirstInputField(it.kategori, it.baslik, it.menuYolu);
                }
                if (it.rehberAdimlari == null || it.rehberAdimlari.Count == 0)
                {
                    it.rehberAdimlari = BuildDefaultGuideSteps(it.kategori, it.baslik, it.ilkVeriAlani);
                }
                SolMenuCatalog.Add(it);
            }
        }

        SolMenuCatalog.Sort(delegate(AtlasItem a, AtlasItem b)
        {
            int c = string.Compare(a.kategori, b.kategori, StringComparison.OrdinalIgnoreCase);
            return c != 0 ? c : string.Compare(a.baslik, b.baslik, StringComparison.OrdinalIgnoreCase);
        });
    }

    private static void LoadExistingGuideCatalogOverrides()
    {
        try
        {
            string[] catPaths = new string[]
            {
                Path.Combine(ResolveOutputDir(), "nebim-bilgi-cozum-kutuphanesi.json"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nebim-bilgi-cozum-kutuphanesi.json"),
                Path.Combine(ResolveOutputDir(), "mahmutbey-rehber-katalog.json")
            };
            JavaScriptSerializer js = new JavaScriptSerializer();
            js.MaxJsonLength = 32 * 1024 * 1024;
            for (int pIdx = 0; pIdx < catPaths.Length; pIdx++)
            {
                string path = catPaths[pIdx];
                if (!File.Exists(path)) continue;
                try
                {
                    string raw = File.ReadAllText(path, Encoding.UTF8).TrimStart('\uFEFF');
                    Dictionary<string, object> root = js.Deserialize<Dictionary<string, object>>(raw);
                    if (root != null && root.ContainsKey("menuler") && root["menuler"] is System.Collections.IEnumerable)
                    {
                        foreach (object o in (System.Collections.IEnumerable)root["menuler"])
                        {
                            Dictionary<string, object> m = o as Dictionary<string, object>;
                            if (m == null) continue;
                            string kat = m.ContainsKey("kategori") ? Convert.ToString(m["kategori"]).Trim() : "";
                            string bas = m.ContainsKey("baslik") ? Convert.ToString(m["baslik"]).Trim() : "";
                            string ara = m.ContainsKey("araMetni") ? Convert.ToString(m["araMetni"]).Trim() : "";
                            string ilk = m.ContainsKey("ilkVeriAlani") ? Convert.ToString(m["ilkVeriAlani"]).Trim() : "";
                            bool verified = m.ContainsKey("dogrulandi") && Convert.ToBoolean(m["dogrulandi"]);
                            if (bas.Length < 2) continue;

                            AtlasItem item = null;
                            string key = "SOL_MENU|" + kat + "|" + bas;
                            if (!Atlas.TryGetValue(key, out item) || item == null)
                            {
                                foreach (AtlasItem cand in Atlas.Values)
                                {
                                    if (cand.bolge == "SOL_MENU" && string.Equals(cand.baslik, bas, StringComparison.OrdinalIgnoreCase))
                                    {
                                        item = cand;
                                        break;
                                    }
                                }
                            }
                            if (item != null)
                            {
                                if (ara.Length > 0) item.araMetni = ara;
                                if (ilk.Length > 0) item.ilkVeriAlani = ilk;
                                if (verified) item.dogrulandi = true;
                                if (m.ContainsKey("rehberAdimlari") && m["rehberAdimlari"] is System.Collections.IEnumerable)
                                {
                                    List<string> steps = new List<string>();
                                    foreach (object so in (System.Collections.IEnumerable)m["rehberAdimlari"])
                                    {
                                        string st = Convert.ToString(so ?? "").Trim();
                                        if (st.Length > 0) steps.Add(st);
                                    }
                                    if (steps.Count >= 3) item.rehberAdimlari = steps;
                                }
                            }
                        }
                        break;
                    }
                }
                catch { }
            }
        }
        catch { }
    }

    public static string BuildSearchBoxQuery(string baslik)
    {
        string s = (baslik ?? "").Trim();
        int gt = s.IndexOf('>');
        if (gt >= 0)
        {
            string left = s.Substring(0, gt).Trim();
            string right = s.Substring(gt + 1).Trim();
            s = right.Length >= left.Length ? right : left;
        }
        return s;
    }

    public static string InferFirstInputField(string kategori, string baslik, string menuYolu)
    {
        string b = (baslik ?? "").ToLowerInvariant();
        string k = (kategori ?? "").ToLowerInvariant();

        if (b.Contains("hareket özeti") || b.Contains("ciro") || b.Contains("rapor") || b.Contains("listesi") || b.Contains("analiz") || b.Contains("ekstre"))
            return "Zorunlu Filtreler (Tarih / Depo)";
        if (b.Contains("envanter sorgula") || b.Contains("ürün sorgula") || b.Contains("barkod"))
            return "Ürün Kodu / Barkod";
        if (b.Contains("sayım"))
            return "Depo Kodu / Barkod (Dosyadan Al)";
        if (b.Contains("irsaliyeyi onayla"))
            return "Onay Bekleyen İrsaliye Seçimi";
        if (b.Contains("masraf"))
            return "Masraf Türü / Tutar";
        if (b.Contains("nakit çıkış") || b.Contains("banka"))
            return "Merkez Banka Hesabı / Tutar";
        if (b.Contains("verilen sipariş") || b.Contains("eksik ürün siparişi"))
            return "Depo / Ürün Kodu ve Miktar";
        if (b.Contains("merkeze iade") || b.Contains("sevk") || b.Contains("transfer"))
            return "Hedef Depo / Ürün Kodu";
        if (b.Contains("satış sorumlusu"))
            return "Satış Sorumlusu Kodu / Adı Soyadı";
        if (k.Contains("rapor"))
            return "Başlangıç Tarihi";
        return "Kod / Arama Alanı";
    }

    public static List<string> BuildDefaultGuideSteps(string kategori, string baslik, string firstField)
    {
        List<string> steps = new List<string>();
        string b = (baslik ?? "").ToLowerInvariant();
        string bNorm = NormTr(baslik ?? "");

        if (bNorm.Contains("satis sorumlusu") && !bNorm.Contains("rapor"))
        {
            steps.Add("1. Ekran Açılışı ve Seçim: Sol üst 'Ara...' kutusundan \"Satış Sorumlusu\" ekranı açılır; listeden işlem yapılacak personel satırına çift tıklayın veya yeni eklemek için üstteki \"+\" (Yeni) düğmesine basın.");
            steps.Add("2. Pasife Alma (Bağlantı İhlali Çözümü): Geçmiş faturalarda hareketi olan satış sorumlusu silinemez (\"Fatura Satır Tablosu İle Bağlantı İhlali\" verir). Silmek yerine kartın altındaki \"Perakende Satış Yapar\" (ve varsa \"Toptan Satış Yapar\") kutucuğunun işaretini kaldırın.");
            steps.Add("3. Yeni Kayıt İse Zorunlu Alanlar: Yeni personel açıyorsanız \"Satış Sorumlusu Kodu\", \"Adı\", \"Soyadı\" alanlarını doldurun ve \"Perakende Satış Yapar\" kutucuğunu işaretleyin.");
            steps.Add("4. Son İşlem (Kaydet): Kartın üst şeridindeki \"Kaydet\" (disket simgesi) düğmesine siz basın.");
            steps.Add("5. Netice Kontrolü: Ana listede ilgili personelin \"Perakende Satış Yapar\" sütunundaki işaretin kalktığını (veya yeni personelin listeye eklendiğini) doğrulayın; artık POS kasada aktif listeye gelmez.");
            return steps;
        }

        if (bNorm.Contains("gelen irsaliyeyi onayla") || bNorm.Contains("transferi onayla") || bNorm.Contains("iade gelen urunleri onayla"))
        {
            steps.Add("1. Ekran Açılışı ve Filtre: \"" + baslik + "\" ekranı açıldığında üst filtre/liste alanında bekleyen sevkiyat irsaliyelerini görüntülemek için \"İleri >\" veya \"Listele / Çalıştır\" adımına geçin.");
            steps.Add("2. İrsaliye Seçimi: Merkezden veya diğer mağazadan gelen onay bekleyen irsaliye satırını listeden seçin (kutucuğunu işaretleyin).");
            steps.Add("3. Ürün ve Miktar Kontrolü: Ürün detaylı onay ekranındaysanız fiziki koliden çıkan barkodları okutun veya satır adetlerinin irsaliye ile birebir tuttuğunu kontrol edin.");
            steps.Add("4. Son İşlem (Onayla / Tamamla): Alt veya üst bardaki \"İleri >\" / \"Onayla\" / \"Kaydet\" düğmesine basarak mal kabul işlemini tamamlayın.");
            steps.Add("5. Netice Kontrolü: İrsaliyenin bekleyen listesinden düştüğünü ve ürünlerin mağaza (" + Sube.Kod + ") envanterine eklendiğini \"Ürün Envanter Sorgula\" ekranından doğrulayın.");
            return steps;
        }

        if (bNorm.Contains("sayim fisi") || bNorm == "sayim" || bNorm.Contains("sayim esitleme"))
        {
            steps.Add("1. Ekran Açılışı ve İlk Odak: \"" + baslik + "\" açıldığında ilk veri alanı olan \"Depo Kodu\" (" + Sube.Kod + ") ve \"İşlem Tarihi\" alanlarını kontrol edip Tab ile geçin.");
            steps.Add("2. Açıklama ve Belge Bilgisi: \"Açıklama\" alanına sayım bilgisini (örn. Genel Sayım / Reyon Sayımı) yazın ve \"Satırlar\" sekmesine geçin.");
            steps.Add("3. Satır / Barkod Girişi: Ürün barkodlarını el terminali/barkod okuyucu ile tek tek okutun veya toplu metin dosyası varsa üst şeritten \"Dosyadan Al\" ile aktarın.");
            steps.Add("4. Son İşlem (Kaydet): Satır toplamlarını kontrol ettikten sonra üst şeritteki \"Kaydet\" (disket) düğmesine siz basın.");
            steps.Add("5. Netice Kontrolü: Sayım fiş numarasının oluştuğunu ve \"Envanter ve Sayım Fark Raporu\" ekranında sayım farklarının listelendiğini teyit edin.");
            return steps;
        }

        if (bNorm.Contains("masraf") && !bNorm.Contains("rapor"))
        {
            steps.Add("1. Ekran Açılışı ve Belge Bilgisi: \"" + baslik + "\" açıldığında \"Fatura/Belge Ref. Numarası\" ve \"Belge Tarihi\" alanlarını girip Tab tuşuna basın.");
            steps.Add("2. Cari / Tedarikçi Seçimi: \"Cari Hesap / Tedarikçi\" veya masraf cari kodunu seçin.");
            steps.Add("3. Masraf Kalemi ve Tutar: \"Satırlar\" sekmesinde yapılan giderin masraf kartını, açıklamasını, KDV oranını ve tutarını girin.");
            steps.Add("4. Son İşlem (Kaydet): Bilgileri kontrol ettikten sonra üst şeritteki \"Kaydet\" düğmesine siz basın.");
            steps.Add("5. Netice Kontrolü: Masraf fişinin kaydedildiğini ve \"Mağaza Hareket Özeti\" ekranında günün masraf çıkışlarına yansıdığını doğrulayın.");
            return steps;
        }

        if (bNorm.Contains("nakit cikis") && !bNorm.Contains("yapmayan"))
        {
            steps.Add("1. Ekran Açılışı ve Banka/IBAN Seçimi: \"Merkezin Banka Hesabına Nakit Çıkışı\" ekranında merkez banka hesabını / \"IBAN Numarası\" alanını seçin.");
            steps.Add("2. Belge ve Tarih Bilgisi: \"Belge Numarası\" (dekont/makbuz no) ve \"Belge Tarihi\" alanlarını kontrol edin.");
            steps.Add("3. Tutar ve Açıklama Girişi: Kasadan bankaya yatırılan net nakit \"Tutar\" bilgisini ve açıklamasını girin.");
            steps.Add("4. Son İşlem (Kaydet): Üst şeritteki \"Kaydet\" (disket) düğmesine basarak nakit çıkış fişini tamamlayın.");
            steps.Add("5. Netice Kontrolü: Fiş numarasının oluştuğunu ve mağaza nakit kasa bakiyesinden yatırılan tutarın düştüğünü \"Mağaza Hareket Özeti\"nden doğrulayın.");
            return steps;
        }

        steps.Add("1. Ekran Açılışı ve İlk Odak: \"" + firstField + "\" alanına veriyi girin ve Enter/Tab tuşuna basın.");

        if (b.Contains("rapor") || b.Contains("analiz") || b.Contains("ekstre") || b.Contains("listesi") || b.Contains("sorgula") || b.Contains("özeti"))
        {
            steps.Add("2. Zorunlu Filtre Kontrolü: \"Zorunlu Filtreler\" bölümündeki Başlangıç/Bitiş Tarihi ve Mağaza/Depo (" + Sube.Kod + ") kriterlerini kontrol edin (FilterControl satırlarına kısayol göndermeyin).");
            steps.Add("3. Ek Seçenekler: Raporun özet/detay veya envanter dahil kutucuklarını ihtiyacınıza göre işaretleyin.");
            steps.Add("4. Son İşlem (Çalıştır): Sağ alttaki veya üst şeritteki \"Çalıştır (F5)\" düğmesine siz basın.");
            steps.Add("5. Netice Kontrolü: Rapor tablosunun ekrana geldiğini, alt barda \"Kayıt 1 / N\" oluştuğunu ve \"Genel Toplam\" satırındaki tutar/miktar sonuçlarını doğrulayın.");
        }
        else if (b.Contains("sipariş") || b.Contains("irsaliye") || b.Contains("fatura") || b.Contains("fiş") || b.Contains("sayım") || b.Contains("transfer") || b.Contains("iade") || b.Contains("sevk"))
        {
            steps.Add("2. Başlık ve Depo Bilgileri: Gönderen/Alan Depo (" + Sube.Kod + "), işlem tarihi ve varsa karşı depo/cari alanlarını seçin.");
            steps.Add("3. Satır / Kalem Girişi: \"Satırlar\" sekmesinde \"Barkod / Madde Kodu\" okutun ve \"Miktar\" bilgisini girin.");
            steps.Add("4. Son İşlem (Kaydet): Satır toplamlarını kontrol ettikten sonra üstteki \"Kaydet\" (disket) düğmesine siz basın (Asistan Nebim'e veri yazmaz).");
            steps.Add("5. Netice Kontrolü: Fiş/Belge numarasının otomatik üretildiğini ve işlemin ilgili kontrol listesine/envantere yansıdığını doğrulayın.");
        }
        else
        {
            steps.Add("2. Kart / Tanım Alanları: Açılan ekrandaki zorunlu kod, açıklama ve parametre alanlarını eksiksiz doldurun.");
            steps.Add("3. Durum / Yetki Seçenekleri: Kaydın aktif/pasif veya şube yetki kutucuklarını kontrol edin.");
            steps.Add("4. Son İşlem (Kaydet / Çalıştır): İşlemi tamamlamak için üst şeritteki \"Kaydet\" veya \"Çalıştır\" düğmesine siz basın.");
            steps.Add("5. Netice Kontrolü: Uyarı mesajı çıkmadan kaydın tamamlandığını ve listede güncel haliyle göründüğünü doğrulayın.");
        }

        return steps;
    }

    // =====================================================================================
    // [OPT-13] GÜVENLİ VE DOĞRULAMALI "ARA…" KUTUSU PROTOKOLÜ (OpenScreenViaSearchBox)
    // =====================================================================================
    public static uint GetUserIdleTimeMs()
    {
        try
        {
            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(typeof(LASTINPUTINFO));
            if (GetLastInputInfo(ref lii))
            {
                uint nowTicks = (uint)Environment.TickCount;
                return nowTicks >= lii.dwTime ? (nowTicks - lii.dwTime) : 2000;
            }
        }
        catch { }
        return 2000;
    }

    private static bool IsPollutedUiControlName(string s)
    {
        if (string.IsNullOrEmpty(s)) return true;
        string t = s.Trim();
        if (t.Length < 3 || SkipNames.Contains(t)) return true;
        if (t.IndexOf("EmptySpace", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("LayoutControl", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Satır ", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("[", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("]", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.StartsWith("tcg", StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("tbc", StringComparison.OrdinalIgnoreCase) ||
            t.StartsWith("lcg", StringComparison.OrdinalIgnoreCase) ||
            t.IndexOf("Error Text", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Zorunlu", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Quick Access", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Caption Bar", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Ribbon", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("15:0", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("MainView", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("MainGroup", StringComparison.OrdinalIgnoreCase) >= 0 ||
            t.IndexOf("Filter control", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            return true;
        }
        return false;
    }

    public static void ResolveCrossAtlasForActiveErp(AutomationElement erpWin, ref string resolvedTitle, ref string query, ref int sira)
    {
        try
        {
            string wName = erpWin != null ? SafeGetName(erpWin) : "";
            bool isStore = wName.IndexOf("STORE", StringComparison.OrdinalIgnoreCase) >= 0;
            string[][] pairs = new string[][]
            {
                new string[] { "Mağaza Siparişleri", "Verilen Siparişler" },
                new string[] { "Personel Masraf Faturası", "Mağaza Masraf Girişi" },
                new string[] { "Peşin Masraf Faturası (Kasa)", "Mağaza Masraf Girişi" },
                new string[] { "Ofis ve Mağaza Depoları Sayım Fişi", "Mağaza Sayım Fişi" },
                new string[] { "Ürün Envanter Raporu", "Ürün Envanter Sorgula" },
                new string[] { "İade Gelen Ürünleri Onayla (Onl.Bayi) - Fiş Bazında", "Mağazaya Gelen İrsaliyeyi Onayla - Ürün Detaylı" },
                new string[] { "Diğer Ofisten Yapılan Transferi Onayla - Fiş Bazında", "Mağazaya Gelen İrsaliyeyi Onayla - Fiş Bazında" },
                new string[] { "Ofis Depoları Arası Transfer", "Merkeze İade" },
                new string[] { "Günlük Nakit Kasa Akışı", "Merkezin Banka Hesabına Nakit Çıkış" },
                new string[] { "Perakende Satış Fişlerinde Düzenlemeler", "Perakende Satışlar Listesi" }
            };
            string rtNorm = NormTr(resolvedTitle);
            for (int i = 0; i < pairs.Length; i++)
            {
                if (isStore && NormTr(pairs[i][0]) == rtNorm)
                {
                    LogLine("[MAHMUTBEY ÇAPRAZ-HARİTA] Aktif pencere STORE -> Merkez '" + resolvedTitle + "' yerine Mağaza '" + pairs[i][1] + "' eşlendi.");
                    resolvedTitle = pairs[i][1];
                    query = pairs[i][1];
                    return;
                }
                else if (!isStore && wName.IndexOf("ERP", StringComparison.OrdinalIgnoreCase) >= 0 && NormTr(pairs[i][1]) == rtNorm)
                {
                    LogLine("[MAHMUTBEY ÇAPRAZ-HARİTA] Aktif pencere ERP -> Mağaza '" + resolvedTitle + "' yerine Merkez '" + pairs[i][0] + "' eşlendi.");
                    resolvedTitle = pairs[i][0];
                    query = pairs[i][0];
                    return;
                }
            }
        }
        catch { }
    }

    public static bool OpenScreenViaSearchBox(AutomationElement erpWin, string menuTitleOrQuery, int sira, bool initiatedByButtonClick, out string statusMessage)
    {
        statusMessage = "";
        AtlasItem matchedItem;
        string query = ResolveBestMenuQuery(menuTitleOrQuery, out matchedItem);
        string resolvedTitle = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.baslik)) ? matchedItem.baslik : menuTitleOrQuery;
        int effectiveSira = sira > 1 ? sira : ((matchedItem != null && matchedItem.sira > 1) ? matchedItem.sira : 1);

        LogLine("[MAHMUTBEY ARA-AÇ] İstek alındı: '" + menuTitleOrQuery + "' -> Çözümlenen: '" + resolvedTitle + "' (Ara='" + query + "', sıra=" + effectiveSira + ")");

        if (query.Length < 2)
        {
            statusMessage = "Aranacak mağaza ekranı adı en az 2 karakter olmalıdır.";
            return false;
        }

        if (!initiatedByButtonClick)
        {
            for (int waitInput = 0; waitInput < 4; waitInput++)
            {
                if (IsPosForeground())
                {
                    statusMessage = "POS (Kasa) ekranı önde olduğu için işlem duraklatıldı.";
                    LogLine("[MAHMUTBEY ARA-AÇ] İptal: " + statusMessage);
                    return false;
                }
                if (GetUserIdleTimeMs() >= 1200) break;
                Thread.Sleep(150);
            }
        }

        if (IsPosForeground())
        {
            statusMessage = "POS (Kasa) ekranı önde olduğu için işlem duraklatıldı.";
            LogLine("[MAHMUTBEY ARA-AÇ] İptal: " + statusMessage);
            return false;
        }

        if (erpWin == null)
        {
            erpWin = FindErpWindow();
            if (erpWin == null)
            {
                IntPtr rdpHwnd = FindRdpClientWindow();
                return OpenScreenViaNebimYardimciQueue(rdpHwnd, resolvedTitle, query, effectiveSira, matchedItem, out statusMessage);
            }
        }

        ResolveCrossAtlasForActiveErp(erpWin, ref resolvedTitle, ref query, ref effectiveSira);
        MinimizeOwnConsoleAndFocusErp(erpWin);

        IntPtr mainHandle = new IntPtr(erpWin.Current.NativeWindowHandle);
        string titleBefore = GetActiveScreenName(erpWin);

        if (MatchesScreenTitle(titleBefore, resolvedTitle) || MatchesScreenTitle(titleBefore, query))
        {
            BringWindowToFrontSafe(mainHandle);
            statusMessage = "✅ '" + resolvedTitle + "' ekranı zaten açık ve aktif.";
            LogLine("[MAHMUTBEY ARA-AÇ] Zaten aktif ekran: " + titleBefore);
            return true;
        }

        AutomationElement existingChild;
        if (IsScreenOpen(erpWin, resolvedTitle, out existingChild) || IsScreenOpen(erpWin, query, out existingChild))
        {
            BringWindowToFrontSafe(mainHandle);
            if (existingChild != null)
            {
                try { existingChild.SetFocus(); } catch { }
                System.Windows.Rect rc = SafeGetRect(existingChild);
                if (!rc.IsEmpty && rc.Width > 40 && rc.Height > 40)
                {
                    ClickAt((int)(rc.Left + Math.Min(120, rc.Width / 2)), (int)(rc.Top + 14));
                    Thread.Sleep(200);
                }
            }
            string nowActive = GetActiveScreenName(erpWin);
            if (MatchesScreenTitle(nowActive, resolvedTitle) || MatchesScreenTitle(nowActive, query))
            {
                statusMessage = "✅ '" + resolvedTitle + "' ekranı açıktı; öne getirildi.";
                LogLine("[MAHMUTBEY ARA-AÇ] Açık MDI penceresi öne getirildi: " + nowActive);
                return true;
            }
        }

        AutomationElement searchBox = FindSearchBoxDeep(erpWin);
        System.Windows.Rect wrMain = SafeGetRect(erpWin);
        int baseClickX = (!wrMain.IsEmpty && wrMain.Width > 300) ? (int)(wrMain.Left + 75) : 75;
        int baseClickY = (!wrMain.IsEmpty && wrMain.Height > 300) ? (int)(wrMain.Top + 158) : 158;
        if (searchBox != null)
        {
            System.Windows.Rect boxRect = SafeGetRect(searchBox);
            if (!boxRect.IsEmpty && boxRect.Width > 20 && boxRect.Height > 8)
            {
                baseClickX = (int)(boxRect.Left + Math.Min(65, boxRect.Width / 2));
                baseClickY = (int)(boxRect.Top + boxRect.Height / 2);
            }
        }

        int initialSira = effectiveSira < 1 ? 1 : (effectiveSira > 8 ? 8 : effectiveSira);
        if (initialSira == 1 && string.Equals(query, "Satış Sorumlusu", StringComparison.OrdinalIgnoreCase))
        {
            initialSira = 4;
        }
        List<int> trySiras = new List<int> { initialSira };
        for (int cand = 1; cand <= 4; cand++)
        {
            if (!trySiras.Contains(cand)) trySiras.Add(cand);
        }

        for (int attemptIdx = 0; attemptIdx < trySiras.Count; attemptIdx++)
        {
            int curSira = trySiras[attemptIdx];
            if (IsPosForeground())
            {
                statusMessage = "POS (Kasa) ekranı öne geçtiği için arama durduruldu.";
                return false;
            }

            AutomationElement focusedEdit = null;
            if (searchBox != null)
            {
                if (!FocusSearchBox(searchBox, mainHandle, out focusedEdit))
                {
                    BringWindowToFrontSafe(mainHandle);
                    ClickAt(baseClickX, baseClickY);
                    Thread.Sleep(150);
                }
            }
            else
            {
                BringWindowToFrontSafe(mainHandle);
                ClickAt(baseClickX, baseClickY);
                Thread.Sleep(160);
            }

            SendKeyDownUp(VK_CONTROL, false);
            PressKey(VK_A);
            SendKeyDownUp(VK_CONTROL, true);
            Thread.Sleep(45);
            PressKey(VK_DELETE);
            PressKey(VK_BACK);
            Thread.Sleep(80);

            LogLine("[MAHMUTBEY ARA-AÇ] 'Ara…' kutusuna yazılıyor: \"" + query + "\" (Sıra=" + curSira + ", Deneme=" + (attemptIdx + 1) + ")");
            try
            {
                Clipboard.SetText(query);
                Thread.Sleep(45);
                SendKeyDownUp(VK_CONTROL, false);
                PressKey(VK_V);
                SendKeyDownUp(VK_CONTROL, true);
            }
            catch
            {
                TypeUnicodeText(query);
            }
            Thread.Sleep(500);

            if (IsPosForeground())
            {
                statusMessage = "POS (Kasa) ekranı öne geçtiği için ekran açma durduruldu.";
                return false;
            }

            for (int k = 0; k < curSira; k++)
            {
                PressKey(VK_DOWN);
                Thread.Sleep(140);
            }
            Thread.Sleep(80);

            int popX = baseClickX + 18;
            int popY = baseClickY + 41 + (curSira - 1) * 20;
            ClickAt(popX, popY);
            Thread.Sleep(65);
            ClickAt(popX, popY);
            Thread.Sleep(120);
            string activeAfterClick = GetActiveScreenName(erpWin);
            if (string.IsNullOrEmpty(activeAfterClick) || string.Equals(activeAfterClick, titleBefore, StringComparison.OrdinalIgnoreCase))
            {
                PressKey(VK_RETURN);
            }

            string openedWrongTitle = "";
            for (int i = 0; i < 18; i++)
            {
                Thread.Sleep(250);
                string activeNow = GetActiveScreenName(erpWin);
                if (activeNow.Length > 0 && !string.Equals(activeNow, titleBefore, StringComparison.OrdinalIgnoreCase))
                {
                    string verifyReason;
                    if (CrossVerifyLocalOpenedScreen(erpWin, resolvedTitle, query, matchedItem, activeNow, out verifyReason))
                    {
                        statusMessage = "✅ '" + activeNow + "' mağaza ekranı açıldı [✓ Harita Çapraz Test Doğrulandı].";
                        LogLine("[MAHMUTBEY ARA-AÇ] BAŞARILI & ÇAPRAZ TEST DOĞRULANDI: Açılan='" + activeNow + "' (" + verifyReason + ")");
                        return true;
                    }
                    else
                    {
                        openedWrongTitle = activeNow;
                        LogLine("[MAHMUTBEY ARA-AÇ] ÇAPRAZ TEST RED: Açılan='" + activeNow + "' != Hedef='" + resolvedTitle + "' (" + verifyReason + ")");
                        break;
                    }
                }
            }

            if (!string.IsNullOrEmpty(openedWrongTitle))
            {
                CloseChildWindowUia(erpWin, openedWrongTitle);
                Thread.Sleep(220);
                continue;
            }
            break;
        }

        statusMessage = "ℹ️ '" + query + "' Ara kutusuna yazıldı; ekran yükleniyor veya listeden seçim bekliyor.";
        return false;
    }

    public static void CloseChildWindowUia(AutomationElement erpWin, string wrongTitle)
    {
        if (erpWin == null || string.IsNullOrEmpty(wrongTitle)) return;
        try
        {
            AutomationElement childWin;
            if (IsScreenOpen(erpWin, wrongTitle, out childWin) && childWin != null && !Automation.Compare(childWin, erpWin))
            {
                object wp;
                if (childWin.TryGetCurrentPattern(WindowPattern.Pattern, out wp))
                {
                    ((WindowPattern)wp).Close();
                    LogLine("[MAHMUTBEY ÇAPRAZ-TEST] Yanlış açılan '" + wrongTitle + "' penceresi otomatik kapatıldı.");
                }
            }
        }
        catch { }
    }

    public static bool CrossVerifyLocalOpenedScreen(
        AutomationElement erpWin,
        string expectedTitle,
        string searchText,
        AtlasItem matchedItem,
        string openedTitle,
        out string reason)
    {
        reason = "";
        string candNorm = NormTr(openedTitle);
        string expNorm = NormTr(expectedTitle);
        string searchNorm = NormTr(searchText);
        if (candNorm.Length == 0)
        {
            reason = "Açılan ekran başlığı boş";
            return false;
        }

        string[] conflictWords = new string[] { "kontrol listesi", "raporu", "sihirbazi", "duzelt", "kapama" };
        for (int i = 0; i < conflictWords.Length; i++)
        {
            string cw = conflictWords[i];
            if (candNorm.Contains(cw) && !expNorm.Contains(cw) && !searchNorm.Contains(cw))
            {
                reason = "Zıt alt-ekran türü ('" + cw + "')";
                return false;
            }
        }
        if (expNorm.Contains("fis bazinda") && candNorm.Contains("urun detayli"))
        {
            reason = "Fiş Bazında yerine Ürün Detaylı açıldı";
            return false;
        }
        if (expNorm.Contains("urun detayli") && candNorm.Contains("fis bazinda"))
        {
            reason = "Ürün Detaylı yerine Fiş Bazında açıldı";
            return false;
        }

        if (MatchesScreenTitle(openedTitle, expectedTitle) || MatchesScreenTitle(openedTitle, searchText))
        {
            reason = "Ekran başlığı harita ile birebir uyumlu";
            return true;
        }

        string[] expTokens = expNorm.Split(new char[] { ' ', '-', '/', '(', ')', '.' }, StringSplitOptions.RemoveEmptyEntries);
        int sigCount = 0;
        int matchCount = 0;
        for (int i = 0; i < expTokens.Length; i++)
        {
            string tk = expTokens[i];
            if (tk.Length < 3 || tk == "ve" || tk == "ile" || tk == "icin") continue;
            sigCount++;
            if (candNorm.Contains(tk)) matchCount++;
        }
        if (sigCount > 0 && matchCount * 2 >= sigCount)
        {
            reason = "Kelime örtüşmesi (" + matchCount + "/" + sigCount + ") doğrulandı";
            return true;
        }

        reason = "Harita çapraz test uyuşmazlığı ('" + openedTitle + "' != '" + expectedTitle + "')";
        return false;
    }

    // =====================================================================================
    // UZAK MASAÜSTÜ (mstsc.exe) ÜZERİNDEN DOĞRUDAN "ARA…" KUTUSU VE ÇERÇEVE KÖPRÜSÜ
    // =====================================================================================
    public static IntPtr FindRdpClientWindow()
    {
        try
        {
            string[] rdpProcNames = new string[] { "mstsc", "msrdc" };
            for (int pIdx = 0; pIdx < rdpProcNames.Length; pIdx++)
            {
                Process[] procs = Process.GetProcessesByName(rdpProcNames[pIdx]);
                for (int i = 0; i < procs.Length; i++)
                {
                    try
                    {
                        if (procs[i].MainWindowHandle != IntPtr.Zero)
                        {
                            return procs[i].MainWindowHandle;
                        }
                    }
                    catch { }
                    finally { try { procs[i].Dispose(); } catch { } }
                }
            }

            IntPtr found = IntPtr.Zero;
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam)
            {
                if (!IsWindowVisible(hWnd)) return true;
                StringBuilder sbClass = new StringBuilder(128);
                GetClassName(hWnd, sbClass, 128);
                string cls = sbClass.ToString();
                if (cls.IndexOf("TscShellContainerClass", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    found = hWnd;
                    return false;
                }
                return true;
            }, IntPtr.Zero);
            return found;
        }
        catch { }
        return IntPtr.Zero;
    }

    public static System.Windows.Rect GetRdpCanvasRect(IntPtr rdpHwnd)
    {
        if (rdpHwnd == IntPtr.Zero) return System.Windows.Rect.Empty;
        try
        {
            IntPtr bestChild = IntPtr.Zero;
            int bestArea = 0;

            EnumChildWindows(rdpHwnd, delegate(IntPtr child, IntPtr lParam)
            {
                if (!IsWindowVisible(child)) return true;
                StringBuilder sbCls = new StringBuilder(128);
                GetClassName(child, sbCls, 128);
                string cls = sbCls.ToString();
                if (cls.IndexOf("OPWindowClass", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("IHWindowClass", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("UIMainClass", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    WIN32_RECT cr;
                    if (GetWindowRect(child, out cr))
                    {
                        int w = cr.Right - cr.Left;
                        int h = cr.Bottom - cr.Top;
                        if (w * h > bestArea && w > 400 && h > 300)
                        {
                            bestArea = w * h;
                            bestChild = child;
                        }
                    }
                }
                return true;
            }, IntPtr.Zero);

            WIN32_RECT r;
            if (bestChild != IntPtr.Zero && GetWindowRect(bestChild, out r))
            {
                return new System.Windows.Rect(r.Left, r.Top, r.Right - r.Left, r.Bottom - r.Top);
            }
            if (GetWindowRect(rdpHwnd, out r))
            {
                return new System.Windows.Rect(r.Left, r.Top, r.Right - r.Left, r.Bottom - r.Top);
            }
        }
        catch { }
        return System.Windows.Rect.Empty;
    }

    public static string LastVerifiedRdpScreen = "";
    public static List<GuidedStep> LastVerifiedRdpSteps = new List<GuidedStep>();
    public static int RdpVerifiedGraceTicks = 0;
    public static bool LastRdpFrameActive = false;

    public static void SendRdpFrameQueueCommand(string islem, GuidedStep step, int totalSteps)
    {
        try
        {
            string outDir = ResolveOutputDir();
            string kuyrukDir = Path.Combine(outDir, "kuyruk");
            if (!Directory.Exists(kuyrukDir)) return;

            string reqId = DateTime.Now.ToString("yyyyMMddHHmmss") + "-frm" + Guid.NewGuid().ToString("N").Substring(0, 4);
            string tmpPath = Path.Combine(kuyrukDir, "istek-" + reqId + ".tmp");
            string reqPath = Path.Combine(kuyrukDir, "istek-" + reqId + ".json");
            string resPath = Path.Combine(kuyrukDir, "sonuc-" + reqId + ".json");

            StringBuilder sb = new StringBuilder();
            sb.Append("{");
            sb.Append("\"id\":\"").Append(JsonEscape(reqId)).Append("\",");
            sb.Append("\"zaman\":\"").Append(JsonEscape(DateTime.Now.ToString("s"))).Append("\",");
            sb.Append("\"islem\":\"").Append(JsonEscape(islem)).Append("\"");
            if (step != null)
            {
                string rozet = "ADIM " + step.stepNo + "/" + Math.Max(1, totalSteps) + ": " + step.fieldName;
                sb.Append(",\"rozet\":\"").Append(JsonEscape(rozet)).Append("\",\"etiket\":\"").Append(JsonEscape(rozet)).Append("\"");
                sb.Append(",\"sol\":").Append(step.rdpSol);
                sb.Append(",\"ust\":").Append(step.rdpUst);
                sb.Append(",\"genislik\":").Append(step.rdpGenislik);
                sb.Append(",\"yukseklik\":").Append(step.rdpYukseklik);
                sb.Append(",\"aksiyonMu\":").Append(step.isActionStep ? "true" : "false");
            }
            sb.Append("}");

            File.WriteAllText(tmpPath, sb.ToString(), new UTF8Encoding(false));
            if (File.Exists(reqPath)) File.Delete(reqPath);
            File.Move(tmpPath, reqPath);

            ThreadPool.QueueUserWorkItem(delegate
            {
                for (int i = 0; i < 15; i++)
                {
                    Thread.Sleep(100);
                    try
                    {
                        if (File.Exists(resPath))
                        {
                            File.Delete(resPath);
                            break;
                        }
                    }
                    catch { }
                }
            });
        }
        catch { }
    }

    public static bool IsRdpBridgeFreshNow()
    {
        try
        {
            string durumPath = Path.Combine(ResolveOutputDir(), "yardimci-durum.json");
            if (!File.Exists(durumPath)) return false;
            double ageSec = Math.Abs((DateTime.UtcNow - File.GetLastWriteTimeUtc(durumPath)).TotalSeconds);
            return ageSec <= 180.0;
        }
        catch
        {
            return false;
        }
    }

    public static bool OpenScreenDirectlyInRdpWindow(
        IntPtr rdpHwnd,
        string baslik,
        string araMetni,
        string kategori,
        int sira,
        string ilkVeriAlani,
        AtlasItem matchedItem,
        out string statusMessage)
    {
        statusMessage = "";
        try
        {
            if (rdpHwnd == IntPtr.Zero) rdpHwnd = FindRdpClientWindow();
            if (rdpHwnd == IntPtr.Zero)
            {
                statusMessage = "⚠️ Uzak Masaüstü (RDP) veya Nebim V3 STORE penceresi bulunamadı.";
                LogLine("[MAHMUTBEY DOĞRUDAN-RDP] Hata: " + statusMessage);
                return false;
            }
            if (IsPosForeground())
            {
                statusMessage = "POS (Kasa) ekranı önde olduğu için işlem duraklatıldı.";
                return false;
            }
            if (IsIconic(rdpHwnd))
            {
                ShowWindow(rdpHwnd, SW_SHOWMAXIMIZED);
                Thread.Sleep(240);
            }
            BringWindowToFrontSafe(rdpHwnd);
            Thread.Sleep(180);

            System.Windows.Rect rdpCanvas = GetRdpCanvasRect(rdpHwnd);
            if (rdpCanvas.IsEmpty || rdpCanvas.Width < 400 || rdpCanvas.Height < 300)
            {
                WIN32_RECT wr;
                if (GetWindowRect(rdpHwnd, out wr))
                {
                    rdpCanvas = new System.Windows.Rect(wr.Left, wr.Top, wr.Right - wr.Left, wr.Bottom - wr.Top);
                }
            }
            if (rdpCanvas.IsEmpty || rdpCanvas.Width < 300)
            {
                statusMessage = "⚠️ RDP pencere boyutları okunamadı.";
                return false;
            }

            double scaleX = rdpCanvas.Width / 1920.0;
            double scaleY = rdpCanvas.Height / 1080.0;
            if (Math.Abs(scaleX - 1.0) < 0.08) scaleX = 1.0;
            if (Math.Abs(scaleY - 1.0) < 0.08) scaleY = 1.0;

            int searchX = (int)(rdpCanvas.Left + 75.0 * scaleX);
            int searchY = (int)(rdpCanvas.Top + 158.0 * scaleY);

            LogLine("[MAHMUTBEY DOĞRUDAN-RDP] 'Ara...' kutusuna tıklanıyor: (" + searchX + "," + searchY + ") | Hedef='" + baslik + "', Ara='" + araMetni + "', Sıra=" + sira);
            ClickAt(searchX, searchY);
            Thread.Sleep(150);

            SendKeyDownUp(VK_CONTROL, false);
            PressKey(VK_A);
            SendKeyDownUp(VK_CONTROL, true);
            Thread.Sleep(45);
            PressKey(VK_DELETE);
            PressKey(VK_BACK);
            Thread.Sleep(85);

            if (IsPosForeground())
            {
                statusMessage = "POS (Kasa) ekranı öne geçtiği için işlem durduruldu.";
                return false;
            }

            bool pastedViaClipboard = false;
            try
            {
                Clipboard.SetText(araMetni);
                Thread.Sleep(50);
                SendKeyDownUp(VK_CONTROL, false);
                PressKey(VK_V);
                SendKeyDownUp(VK_CONTROL, true);
                pastedViaClipboard = true;
            }
            catch
            {
                TypeUnicodeText(araMetni);
            }
            Thread.Sleep(520);

            int downCount = sira < 1 ? 1 : (sira > 10 ? 10 : sira);
            if (downCount == 1 && string.Equals(araMetni, "Satış Sorumlusu", StringComparison.OrdinalIgnoreCase))
            {
                downCount = 4;
            }
            for (int k = 0; k < downCount; k++)
            {
                PressKey(VK_DOWN);
                Thread.Sleep(140);
            }
            Thread.Sleep(80);
            int popX = searchX + (int)(18.0 * scaleX);
            int popY = searchY + (int)((41 + (downCount - 1) * 20) * scaleY);
            ClickAt(popX, popY);
            Thread.Sleep(65);
            ClickAt(popX, popY);
            Thread.Sleep(90);
            PressKey(VK_RETURN);
            LogLine("[MAHMUTBEY DOĞRUDAN-RDP] Açılır listeden Aşağı Ok x" + downCount + " + Çift Tık (" + popX + "," + popY + ") + Enter ile seçildi | pano=" + pastedViaClipboard);
            Thread.Sleep(450);

            LastVerifiedRdpScreen = baslik;
            LastVerifiedRdpSteps.Clear();
            LastRdpFrameActive = false;
            RdpVerifiedGraceTicks = 45;

            string firstField = !string.IsNullOrEmpty(ilkVeriAlani) ? ilkVeriAlani : InferFirstInputField(kategori, baslik, baslik);

            GuidedStep gs1 = new GuidedStep();
            gs1.stepNo = 1;
            gs1.fieldName = firstField;
            gs1.isActionStep = false;
            gs1.completed = false;
            gs1.lastRect = System.Windows.Rect.Empty;
            gs1.instruction = "1. İlk Veri Alanı: \"" + firstField + "\" alanına bilgiyi girin ve Enter/Tab tuşuna basın.";
            LastVerifiedRdpSteps.Add(gs1);

            GuidedStep gs2 = new GuidedStep();
            gs2.stepNo = 2;
            gs2.fieldName = "Filtre / Detay Alanları";
            gs2.isActionStep = false;
            gs2.completed = false;
            gs2.lastRect = System.Windows.Rect.Empty;
            gs2.instruction = "2. Veri Alanı: Ekrandaki zorunlu alanları ve tarih/depo/miktar bilgilerini kontrol edin.";
            LastVerifiedRdpSteps.Add(gs2);

            GuidedStep gs3 = new GuidedStep();
            gs3.stepNo = 3;
            gs3.fieldName = "Çalıştır / Kaydet";
            gs3.isActionStep = true;
            gs3.completed = false;
            gs3.lastRect = System.Windows.Rect.Empty;
            gs3.instruction = "3. Son Adım: Verileri kontrol ettikten sonra \"Çalıştır / Kaydet\" düğmesine siz basın.";
            LastVerifiedRdpSteps.Add(gs3);

            if (CanliMakineEkranPanel.ActiveInstance != null)
            {
                CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                    "▶ ADIM 1/3: " + firstField,
                    "1. İlk Veri Alanı: \"" + firstField + "\" alanına bilgiyi girin ve Enter/Tab tuşuna basın.",
                    "✅ '" + baslik + "' ekranı RDP üzerinden açıldı.");
            }

            statusMessage = "✅ '" + baslik + "' ekranı RDP üzerinden açıldı. İlk alan: " + firstField;
            LogLine("[MAHMUTBEY DOĞRUDAN-RDP] BAŞARILI: '" + baslik + "' açıldı.");
            return true;
        }
        catch (Exception ex)
        {
            statusMessage = "❌ Doğrudan RDP menü açma hatası: " + ex.Message;
            return false;
        }
    }

    public static bool OpenScreenViaNebimYardimciQueue(IntPtr rdpHwnd, string resolvedTitle, string query, int sira, AtlasItem matchedItem, out string statusMessage)
    {
        statusMessage = "";
        LastVerifiedRdpScreen = "";
        LastVerifiedRdpSteps.Clear();
        LastRdpFrameActive = false;

        try
        {
            string baslik = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.baslik)) ? matchedItem.baslik : resolvedTitle;
            string ekranId = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.ekranId)) ? matchedItem.ekranId : NormTr(baslik).Replace(" ", "-");
            string araMetni = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.araMetni)) ? matchedItem.araMetni : query;
            string kategori = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.kategori)) ? matchedItem.kategori : "";
            string menuYolu = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.menuYolu)) ? matchedItem.menuYolu : "";
            string ilkVeriAlani = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.ilkVeriAlani))
                ? matchedItem.ilkVeriAlani
                : InferFirstInputField(kategori, baslik, baslik);
            int effectiveSira = sira > 1 ? sira : ((matchedItem != null && matchedItem.sira > 1) ? matchedItem.sira : 1);

            if (!IsRdpBridgeFreshNow())
            {
                LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] NebimYardimci nabzı güncel değil -> Beklemeden Doğrudan RDP Pencere Otomasyonuna geçiliyor: '" + baslik + "'");
                return OpenScreenDirectlyInRdpWindow(rdpHwnd, baslik, araMetni, kategori, effectiveSira, ilkVeriAlani, matchedItem, out statusMessage);
            }

            string outDir = ResolveOutputDir();
            string kuyrukDir = Path.Combine(outDir, "kuyruk");
            Directory.CreateDirectory(kuyrukDir);

            string reqId = DateTime.Now.ToString("yyyyMMddHHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6);
            string tmpPath = Path.Combine(kuyrukDir, "istek-" + reqId + ".tmp");
            string reqPath = Path.Combine(kuyrukDir, "istek-" + reqId + ".json");
            string resPath = Path.Combine(kuyrukDir, "sonuc-" + reqId + ".json");

            StringBuilder sbReq = new StringBuilder();
            sbReq.Append("{");
            sbReq.Append("\"id\":\"").Append(JsonEscape(reqId)).Append("\",");
            sbReq.Append("\"zaman\":\"").Append(JsonEscape(DateTime.Now.ToString("s"))).Append("\",");
            sbReq.Append("\"islem\":\"merkez-ekran-ac\",");
            sbReq.Append("\"ekran\":\"").Append(JsonEscape(ekranId)).Append("\",");
            sbReq.Append("\"ad\":\"").Append(JsonEscape(baslik)).Append("\",");
            sbReq.Append("\"baslik\":\"").Append(JsonEscape(baslik)).Append("\",");
            sbReq.Append("\"araMetni\":\"").Append(JsonEscape(araMetni)).Append("\",");
            sbReq.Append("\"kategori\":\"").Append(JsonEscape(kategori)).Append("\",");
            sbReq.Append("\"menuYolu\":\"").Append(JsonEscape(menuYolu)).Append("\",");
            sbReq.Append("\"ilkVeriAlani\":\"").Append(JsonEscape(ilkVeriAlani)).Append("\",");
            sbReq.Append("\"sira\":").Append(effectiveSira);
            sbReq.Append("}");

            File.WriteAllText(tmpPath, sbReq.ToString(), new UTF8Encoding(false));
            if (File.Exists(reqPath)) File.Delete(reqPath);
            File.Move(tmpPath, reqPath);

            LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] İstek gönderildi (id=" + reqId + "): ekran='" + ekranId + "', baslik='" + baslik + "'");

            if (rdpHwnd != IntPtr.Zero)
            {
                if (IsIconic(rdpHwnd))
                {
                    ShowWindow(rdpHwnd, SW_SHOWMAXIMIZED);
                    Thread.Sleep(80);
                }
                BringWindowToFrontSafe(rdpHwnd);
            }

            if (CanliMakineEkranPanel.ActiveInstance != null)
            {
                CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                    "⚡ EYLEM 1/4: Mağaza RDP Köprüsü Tetiklendi",
                    "Hedef: '" + baslik + "' (" + (kategori.Length > 0 ? kategori : Sube.Ad) + ") ekranı için NebimYardimci'ya komut iletildi.",
                    "⏳ [1/4] RDP penceresi odaklandı; Nebim V3 STORE 'Ara...' kutusuna hazırlık yapılıyor...");
            }

            string rawRes = "";
            int lastPhaseShown = 1;
            bool pickedUpByHelper = false;
            Stopwatch swWait = Stopwatch.StartNew();
            while (swWait.ElapsedMilliseconds < 24000)
            {
                Thread.Sleep(40);
                long elMs = swWait.ElapsedMilliseconds;
                if (!pickedUpByHelper && !File.Exists(reqPath))
                {
                    pickedUpByHelper = true;
                }
                if (!pickedUpByHelper && elMs >= 6500)
                {
                    break;
                }
                if (CanliMakineEkranPanel.ActiveInstance != null)
                {
                    if (elMs >= 350 && lastPhaseShown < 2)
                    {
                        lastPhaseShown = 2;
                        CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                            "⌨ EYLEM 2/4: 'Ara...' Kutusuna Yazılıyor",
                            "'Ara...' kutusuna '" + araMetni + "' yazılıyor ve açılır liste filtreleniyor...",
                            "⏳ [2/4] Mağaza sol menüsü filtreleniyor (" + (elMs / 1000.0).ToString("0.0", CultureInfo.InvariantCulture) + " sn)...");
                    }
                    else if (elMs >= 1150 && lastPhaseShown < 3)
                    {
                        lastPhaseShown = 3;
                        CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                            "🔍 EYLEM 3/4: Mağaza Ekranı Seçildi & Açılıyor",
                            "Açılır listeden '" + baslik + "' seçildi; ekranın açılması bekleniyor...",
                            "⏳ [3/4] Nebim V3 STORE ekran yüklemesi bekleniyor (" + (elMs / 1000.0).ToString("0.0", CultureInfo.InvariantCulture) + " sn)...");
                    }
                    else if (elMs >= 2400 && lastPhaseShown < 4)
                    {
                        lastPhaseShown = 4;
                        CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                            "🎯 EYLEM 4/4: İlk Veri Giriş Alanı Taranıyor",
                            "Orta çalışma alanında ('" + ilkVeriAlani + "') kontrol koordinatı doğrulanıyor ve odaklanıyor...",
                            "⏳ [4/4] Gerçek UIA koordinatı ve otomatik odaklama bekleniyor...");
                    }
                    CanliMakineEkranPanel.ActiveInstance.StepAnimationNow();
                }
                Application.DoEvents();
                if (!File.Exists(resPath)) continue;

                for (int retry = 0; retry < 5; retry++)
                {
                    try
                    {
                        rawRes = File.ReadAllText(resPath, Encoding.UTF8);
                        File.Delete(resPath);
                        break;
                    }
                    catch
                    {
                        Thread.Sleep(80);
                    }
                }
                if (rawRes.Length > 0) break;
            }

            if (string.IsNullOrEmpty(rawRes))
            {
                try { if (File.Exists(reqPath)) File.Delete(reqPath); } catch { }
                if (!pickedUpByHelper)
                {
                    LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] NebimYardimci çalışmıyor (alındıMı=False) -> Doğrudan RDP Pencere Otomasyonuna geçiliyor: '" + baslik + "'");
                    return OpenScreenDirectlyInRdpWindow(rdpHwnd, baslik, araMetni, kategori, effectiveSira, ilkVeriAlani, matchedItem, out statusMessage);
                }
                statusMessage = "⏳ '" + baslik + "' ekranı RDP içinde açılıyor...";
                LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] NebimYardimci isteği aldı (alındıMı=True); çift işlem oluşmaması için doğrudan RDP tıklaması atlandı: '" + baslik + "'");
                return false;
            }

            LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] NebimYardimci yanıtı alındı: " + rawRes);

            bool ekranAcildi = Regex.IsMatch(rawRes, "\"ekranAcildi\"\\s*:\\s*true", RegexOptions.IgnoreCase) ||
                               Regex.IsMatch(rawRes, "\"ok\"\\s*:\\s*true", RegexOptions.IgnoreCase);
            bool rdpCerceveAktif = Regex.IsMatch(rawRes, "\"rdpCerceveAktif\"\\s*:\\s*true", RegexOptions.IgnoreCase);
            string acilanEkran = ExtractJsonStringField(rawRes, "acilanEkran");
            if (string.IsNullOrEmpty(acilanEkran)) acilanEkran = ExtractJsonStringField(rawRes, "baslik");
            string ilkAlanAdi = ExtractJsonStringField(rawRes, "ilkAlanAdi");
            string mesaj = ExtractJsonStringField(rawRes, "mesaj");
            string caprazTest = ExtractJsonStringField(rawRes, "caprazTest");
            string caprazTestDetay = ExtractJsonStringField(rawRes, "caprazTestDetay");

            int alanSol = ExtractJsonIntField(rawRes, "alanSol", 0);
            int alanUst = ExtractJsonIntField(rawRes, "alanUst", 0);
            int alanGenislik = ExtractJsonIntField(rawRes, "alanGenislik", 0);
            int alanYukseklik = ExtractJsonIntField(rawRes, "alanYukseklik", 0);
            int relLeft = ExtractJsonIntField(rawRes, "relLeft", 0);
            int relTop = ExtractJsonIntField(rawRes, "relTop", 0);
            int erpGenislik = ExtractJsonIntField(rawRes, "erpGenislik", 1920);
            int erpYukseklik = ExtractJsonIntField(rawRes, "erpYukseklik", 1040);

            if (!ekranAcildi)
            {
                if (!string.IsNullOrEmpty(mesaj) &&
                    (mesaj.IndexOf("bulunamadı", StringComparison.OrdinalIgnoreCase) >= 0 ||
                     mesaj.IndexOf("açık değil", StringComparison.OrdinalIgnoreCase) >= 0))
                {
                    return OpenScreenDirectlyInRdpWindow(rdpHwnd, baslik, araMetni, kategori, effectiveSira, ilkVeriAlani, matchedItem, out statusMessage);
                }
                LastVerifiedRdpScreen = "";
                LastVerifiedRdpSteps.Clear();
                LastRdpFrameActive = false;
                statusMessage = !string.IsNullOrEmpty(mesaj) ? ("⚠️ " + mesaj) : ("⚠️ Ekran henüz açılmadı: '" + baslik + "'");
                return false;
            }

            LastVerifiedRdpScreen = !string.IsNullOrEmpty(acilanEkran) ? acilanEkran : baslik;
            LastRdpFrameActive = rdpCerceveAktif;
            RdpVerifiedGraceTicks = 18;

            System.Windows.Rect rdpCanvas = rdpHwnd != IntPtr.Zero ? GetRdpCanvasRect(rdpHwnd) : System.Windows.Rect.Empty;
            double scaleX = 1.0;
            double scaleY = 1.0;
            if (!rdpCanvas.IsEmpty && rdpCanvas.Width > 300 && erpGenislik > 300)
            {
                scaleX = rdpCanvas.Width / (double)erpGenislik;
                if (Math.Abs(scaleX - 1.0) < 0.08) scaleX = 1.0;
            }
            if (!rdpCanvas.IsEmpty && rdpCanvas.Height > 300 && erpYukseklik > 300)
            {
                scaleY = rdpCanvas.Height / (double)erpYukseklik;
                if (Math.Abs(scaleY - 1.0) < 0.08) scaleY = 1.0;
            }

            double canvasLeft = !rdpCanvas.IsEmpty ? rdpCanvas.Left : 0;
            double canvasTop = !rdpCanvas.IsEmpty ? rdpCanvas.Top : 0;

            MatchCollection stepMatches = Regex.Matches(
                rawRes,
                "\\{\"ad\":\"(.*?)\",\"sol\":(-?\\d+),\"ust\":(-?\\d+),\"genislik\":(-?\\d+),\"yukseklik\":(-?\\d+),\"relLeft\":(-?\\d+),\"relTop\":(-?\\d+),\"aksiyonMu\":(true|false)(?:,\"automationId\":\"[^\"]*\")?\\}");

            if (stepMatches != null && stepMatches.Count > 0)
            {
                for (int i = 0; i < stepMatches.Count; i++)
                {
                    Match sm = stepMatches[i];
                    string sAd = JsonUnescape(sm.Groups[1].Value);
                    int sSol = int.Parse(sm.Groups[2].Value);
                    int sUst = int.Parse(sm.Groups[3].Value);
                    int sW = int.Parse(sm.Groups[4].Value);
                    int sH = int.Parse(sm.Groups[5].Value);
                    int sRelL = int.Parse(sm.Groups[6].Value);
                    int sRelT = int.Parse(sm.Groups[7].Value);
                    bool sAct = string.Equals(sm.Groups[8].Value, "true", StringComparison.OrdinalIgnoreCase);

                    GuidedStep gs = new GuidedStep();
                    gs.stepNo = LastVerifiedRdpSteps.Count + 1;
                    gs.fieldName = sAd;
                    gs.isActionStep = sAct;
                    gs.completed = false;
                    gs.rdpSol = sSol;
                    gs.rdpUst = sUst;
                    gs.rdpGenislik = sW;
                    gs.rdpYukseklik = sH;

                    if (sW > 30 && sH >= 16 && sRelL > 320 && (sRelT > 145 || sAct))
                    {
                        gs.lastRect = new System.Windows.Rect(
                            canvasLeft + sRelL * scaleX,
                            canvasTop + sRelT * scaleY,
                            Math.Max(40.0, sW * scaleX),
                            Math.Max(20.0, sH * scaleY));
                    }
                    else
                    {
                        gs.lastRect = System.Windows.Rect.Empty;
                    }

                    if (sAct)
                    {
                        gs.instruction = gs.stepNo + ". Son Adım: Verileri kontrol ettikten sonra \"" + sAd + "\" düğmesine siz basın.";
                    }
                    else if (gs.stepNo == 1)
                    {
                        gs.instruction = "1. İlk Veri Alanı (UIA Doğrulandı & Odaklandı): \"" + sAd + "\" alanına doğrudan klavyeden yazın ve Enter/Tab tuşuna basın.";
                    }
                    else
                    {
                        gs.instruction = gs.stepNo + ". Veri Alanı: \"" + sAd + "\" bilgisini kontrol edin / doldurun.";
                    }
                    LastVerifiedRdpSteps.Add(gs);
                }
            }

            if (LastVerifiedRdpSteps.Count == 0 && alanGenislik > 30 && alanYukseklik >= 16 && relLeft > 320 && relTop > 145)
            {
                string fName = !string.IsNullOrEmpty(ilkAlanAdi) ? ilkAlanAdi : ilkVeriAlani;
                GuidedStep gs1 = new GuidedStep();
                gs1.stepNo = 1;
                gs1.fieldName = fName;
                gs1.isActionStep = false;
                gs1.completed = false;
                gs1.rdpSol = alanSol;
                gs1.rdpUst = alanUst;
                gs1.rdpGenislik = alanGenislik;
                gs1.rdpYukseklik = alanYukseklik;
                gs1.lastRect = new System.Windows.Rect(
                    canvasLeft + relLeft * scaleX,
                    canvasTop + relTop * scaleY,
                    Math.Max(40.0, alanGenislik * scaleX),
                    Math.Max(20.0, alanYukseklik * scaleY));
                gs1.instruction = "1. İlk Veri Alanı (UIA Doğrulandı & Odaklandı): \"" + fName + "\" alanına doğrudan klavyeden yazın ve Enter/Tab tuşuna basın.";
                LastVerifiedRdpSteps.Add(gs1);
            }

            if (LastVerifiedRdpSteps.Count == 0 && matchedItem != null && matchedItem.rehberAdimlari != null && matchedItem.rehberAdimlari.Count > 0)
            {
                for (int i = 0; i < matchedItem.rehberAdimlari.Count; i++)
                {
                    GuidedStep gs = new GuidedStep();
                    gs.stepNo = i + 1;
                    gs.fieldName = (i == 0) ? ilkVeriAlani : ("Adım " + (i + 1));
                    gs.instruction = matchedItem.rehberAdimlari[i];
                    gs.isActionStep = (i == matchedItem.rehberAdimlari.Count - 1);
                    gs.lastRect = System.Windows.Rect.Empty;
                    LastVerifiedRdpSteps.Add(gs);
                }
            }

            statusMessage = !string.IsNullOrEmpty(mesaj)
                ? mesaj
                : ("✅ '" + LastVerifiedRdpScreen + "' açıldı.");
            if (string.Equals(caprazTest, "DOGRULANDI", StringComparison.OrdinalIgnoreCase) &&
                statusMessage.IndexOf("Çapraz Test", StringComparison.OrdinalIgnoreCase) < 0)
            {
                statusMessage += " [✓ Harita Çapraz Test Doğrulandı]";
            }
            return true;
        }
        catch (Exception ex)
        {
            LastVerifiedRdpScreen = "";
            LastVerifiedRdpSteps.Clear();
            LastRdpFrameActive = false;
            statusMessage = "❌ NebimYardimci kuyruk iletişim hatası: " + ex.Message;
            LogLine("[MAHMUTBEY KUYRUK-KÖPRÜ] Hata: " + ex.Message);
            return false;
        }
    }

    private static string ExtractJsonStringField(string json, string key)
    {
        if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(key)) return "";
        Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"");
        return m.Success ? JsonUnescape(m.Groups[1].Value) : "";
    }

    private static int ExtractJsonIntField(string json, string key, int defVal)
    {
        if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(key)) return defVal;
        Match m = Regex.Match(json, "\"" + Regex.Escape(key) + "\"\\s*:\\s*(-?\\d+)");
        int v;
        if (m.Success && int.TryParse(m.Groups[1].Value, out v)) return v;
        return defVal;
    }

    public static AutomationElement FindSearchBoxDeep(AutomationElement erpWin)
    {
        if (erpWin == null) return null;

        try
        {
            AutomationElement nav = erpWin.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.AutomationIdProperty, "MenuNavBar"));
            if (nav == null)
            {
                AutomationElementCollection topCh = erpWin.FindAll(TreeScope.Children, Condition.TrueCondition);
                if (topCh != null)
                {
                    foreach (AutomationElement c in topCh)
                    {
                        nav = c.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.AutomationIdProperty, "MenuNavBar"));
                        if (nav != null) break;
                    }
                }
            }

            if (nav != null)
            {
                AutomationElement combo = FindFirstChildByControlType(nav, ControlType.ComboBox);
                if (combo != null)
                {
                    try
                    {
                        AutomationElement innerEdit = combo.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Edit));
                        if (innerEdit != null) return innerEdit;
                    }
                    catch { }
                    return combo;
                }

                AutomationElement navEdit = FindEditInLeftTopRecursive(nav, 0);
                if (navEdit != null) return navEdit;
            }
        }
        catch { }

        return FindEditInLeftTopRecursive(erpWin, 0);
    }

    private static AutomationElement FindFirstChildByControlType(AutomationElement parent, ControlType targetType)
    {
        if (parent == null) return null;
        try
        {
            TreeWalker walker = TreeWalker.ControlViewWalker;
            AutomationElement c = walker.GetFirstChild(parent);
            int guard = 0;
            while (c != null && ++guard < 60)
            {
                if (SafeGetControlType(c) == targetType) return c;
                c = walker.GetNextSibling(c);
            }
        }
        catch { }
        return null;
    }

    private static AutomationElement FindEditInLeftTopRecursive(AutomationElement parent, int depth)
    {
        if (parent == null || depth > 6) return null;
        AutomationElementCollection ch = null;
        try { ch = parent.FindAll(TreeScope.Children, Condition.TrueCondition); } catch { return null; }
        if (ch == null) return null;

        int count = 0;
        AutomationElement comboFallback = null;
        foreach (AutomationElement c in ch)
        {
            if (++count > 60) break;
            System.Windows.Rect r = SafeGetRect(c);
            if (r.IsEmpty || r.Width <= 1 || r.Height <= 1) continue;
            if (r.Left > 340) continue;

            ControlType ct = SafeGetControlType(c);
            if (ct == ControlType.Edit && r.Left >= 0 && r.Left <= 320 && r.Top >= 60 && r.Top <= 250)
            {
                return c;
            }
            if (ct == ControlType.ComboBox && r.Left >= 0 && r.Left <= 320 && r.Top >= 60 && r.Top <= 250)
            {
                comboFallback = c;
            }

            if (r.Top <= 260)
            {
                AutomationElement sub = FindEditInLeftTopRecursive(c, depth + 1);
                if (sub != null) return sub;
            }
        }
        return comboFallback;
    }

    private static bool IsSearchBoxFocused(AutomationElement box, out AutomationElement focusedEl)
    {
        focusedEl = box;
        if (box == null) return false;
        try
        {
            AutomationElement f = AutomationElement.FocusedElement;
            if (f == null) return false;
            focusedEl = f;
            if (Automation.Compare(f, box)) return true;
            if (SafeGetControlType(f) != ControlType.Edit && SafeGetControlType(f) != ControlType.ComboBox) return false;

            System.Windows.Rect a = SafeGetRect(f);
            System.Windows.Rect b = SafeGetRect(box);
            return !a.IsEmpty && !b.IsEmpty && Math.Abs(a.Left - b.Left) < 25 && Math.Abs(a.Top - b.Top) < 16;
        }
        catch { return false; }
    }

    private static bool FocusSearchBox(AutomationElement box, IntPtr mainH, out AutomationElement focusedEdit)
    {
        focusedEdit = box;
        for (int k = 0; k < 4; k++)
        {
            BringWindowToFrontSafe(mainH);
            Thread.Sleep(110);
            try { box.SetFocus(); } catch { }
            Thread.Sleep(150);

            uint pid;
            GetWindowThreadProcessId(GetForegroundWindow(), out pid);
            int boxPid = 0;
            try { boxPid = box.Current.ProcessId; } catch { }

            if (IsSearchBoxFocused(box, out focusedEdit) && (boxPid == 0 || (int)pid == boxPid))
            {
                return true;
            }

            System.Windows.Rect r = SafeGetRect(box);
            if (!r.IsEmpty && r.Width > 4)
            {
                int clickX = (int)(r.Left + Math.Min(55.0, r.Width / 2.0));
                int clickY = (int)(r.Top + r.Height / 2.0);
                ClickAt(clickX, clickY);
                Thread.Sleep(200);
                if (IsSearchBoxFocused(box, out focusedEdit))
                {
                    return true;
                }
            }
        }
        return false;
    }

    private static bool IsSearchPopupShown(AutomationElement erpWin, IntPtr mainH)
    {
        try
        {
            IntPtr fg = GetForegroundWindow();
            uint pid;
            GetWindowThreadProcessId(fg, out pid);
            return fg != mainH && (int)pid == erpWin.Current.ProcessId;
        }
        catch { return false; }
    }

    public static void BringWindowToFrontSafe(IntPtr hWnd)
    {
        if (hWnd == IntPtr.Zero || IsPosForeground()) return;
        try
        {
            if (IsIconic(hWnd))
            {
                ShowWindow(hWnd, SW_RESTORE);
                Thread.Sleep(120);
            }
            IntPtr fg = GetForegroundWindow();
            uint pid;
            uint fgThread = GetWindowThreadProcessId(fg, out pid);
            uint myThread = GetCurrentThreadId();
            bool attached = fgThread != 0 && fgThread != myThread && AttachThreadInput(fgThread, myThread, true);
            try { SetForegroundWindow(hWnd); }
            finally { if (attached) AttachThreadInput(fgThread, myThread, false); }
        }
        catch { }
    }

    // =====================================================================================
    // [OPT-12] AÇIK EKRAN TARAMA VE KENDİ KENDİNİ İYİLEŞTİREN KATALOG MOTORU (SELF-HEALING)
    // =====================================================================================
    public static List<AutomationElement> GetAllOpenScreenWindows(AutomationElement erpWin)
    {
        List<AutomationElement> list = new List<AutomationElement>();
        if (erpWin == null) return list;

        AutomationElementCollection ch1 = null;
        try { ch1 = erpWin.FindAll(TreeScope.Children, Condition.TrueCondition); } catch { return list; }
        if (ch1 == null) return list;

        int c1Count = 0;
        foreach (AutomationElement c1 in ch1)
        {
            if (++c1Count > 50) break;
            ControlType ct1 = SafeGetControlType(c1);
            string aid1 = SafeGetAutomationId(c1);
            string nm1 = SafeGetName(c1);

            if (string.Equals(aid1, "MenuNavBar", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(aid1, "RibbonControl", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(aid1, "RibbonStatusBar", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(nm1, "The Ribbon", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(nm1, "Status Bar", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            if (ct1 == ControlType.Window)
            {
                list.Add(c1);
                continue;
            }

            if (ct1 == ControlType.Pane || SafeGetClass(c1).IndexOf("MDICLIENT", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                AutomationElementCollection ch2 = null;
                try { ch2 = c1.FindAll(TreeScope.Children, Condition.TrueCondition); } catch { }
                if (ch2 != null)
                {
                    int c2Count = 0;
                    foreach (AutomationElement c2 in ch2)
                    {
                        if (++c2Count > 50) break;
                        if (SafeGetControlType(c2) == ControlType.Window)
                        {
                            list.Add(c2);
                        }
                    }
                }
            }
        }
        return list;
    }

    public static string GetActiveScreenName(AutomationElement erpWin)
    {
        if (erpWin == null) return "";
        string title = SafeGetName(erpWin);
        string stripped = StripNebimTitle(title);
        if (stripped.Length > 0) return stripped;

        List<AutomationElement> wins = GetAllOpenScreenWindows(erpWin);
        for (int i = 0; i < wins.Count; i++)
        {
            if (!SafeIsOffscreen(wins[i]))
            {
                string wn = StripNebimTitle(SafeGetName(wins[i]));
                if (wn.Length > 0) return wn;
            }
        }
        if (wins.Count > 0)
        {
            return StripNebimTitle(SafeGetName(wins[0]));
        }
        return "";
    }

    public static AutomationElement GetActiveScreenElement(AutomationElement erpWin, string activeName)
    {
        if (erpWin == null) return null;
        if (string.IsNullOrEmpty(activeName)) activeName = GetActiveScreenName(erpWin);

        List<AutomationElement> wins = GetAllOpenScreenWindows(erpWin);

        if (!string.IsNullOrEmpty(activeName))
        {
            for (int i = 0; i < wins.Count; i++)
            {
                string nm = StripNebimTitle(SafeGetName(wins[i]));
                if (MatchesScreenTitle(nm, activeName))
                {
                    return wins[i];
                }
            }
        }

        if (wins.Count == 1 && !SafeIsOffscreen(wins[0]))
        {
            return wins[0];
        }

        return erpWin;
    }

    public static bool IsScreenOpen(AutomationElement erpWin, string targetName, out AutomationElement childWin)
    {
        childWin = null;
        if (erpWin == null || string.IsNullOrEmpty(targetName)) return false;

        string mainTitle = SafeGetName(erpWin);
        string stripped = StripNebimTitle(mainTitle);

        List<AutomationElement> wins = GetAllOpenScreenWindows(erpWin);
        for (int i = 0; i < wins.Count; i++)
        {
            string cn = StripNebimTitle(SafeGetName(wins[i]));
            if (MatchesScreenTitle(cn, targetName))
            {
                childWin = wins[i];
                return true;
            }
        }

        return MatchesScreenTitle(stripped, targetName);
    }

    private static bool MatchesScreenTitle(string candidate, string target)
    {
        candidate = (candidate ?? "").Trim();
        target = (target ?? "").Trim();
        if (candidate.Length == 0 || target.Length == 0) return false;
        if (string.Equals(candidate, target, StringComparison.OrdinalIgnoreCase)) return true;
        if (candidate.StartsWith(target + " - ", StringComparison.OrdinalIgnoreCase)) return true;
        if (candidate.StartsWith(target + " (", StringComparison.OrdinalIgnoreCase)) return true;
        if (target.StartsWith(candidate + " - ", StringComparison.OrdinalIgnoreCase)) return true;
        if (candidate.IndexOf(target, StringComparison.OrdinalIgnoreCase) >= 0 && Math.Abs(candidate.Length - target.Length) <= 10) return true;
        return false;
    }

    public static string StripNebimTitle(string title)
    {
        title = (title ?? "").Trim();
        string ad = title;
        if (title.StartsWith("Nebim V3 ERP - ", StringComparison.OrdinalIgnoreCase)) ad = title.Substring(15);
        else if (title.EndsWith(" - Nebim V3 ERP", StringComparison.OrdinalIgnoreCase)) ad = title.Substring(0, title.Length - 15);
        else if (title.StartsWith("Nebim V3 STORE - ", StringComparison.OrdinalIgnoreCase)) ad = title.Substring(17);
        else if (title.EndsWith(" - Nebim V3 STORE", StringComparison.OrdinalIgnoreCase)) ad = title.Substring(0, title.Length - 17);
        else if (string.Equals(title, "Nebim V3 ERP", StringComparison.OrdinalIgnoreCase) || string.Equals(title, "Nebim V3 STORE", StringComparison.OrdinalIgnoreCase)) ad = "";
        return ad.Trim().TrimStart('[').TrimEnd(']').Trim();
    }

    public static List<GuidedStep> DiscoverLiveGuidedSteps(AutomationElement erpWin, string screenName)
    {
        List<GuidedStep> steps = new List<GuidedStep>();
        AutomationElement activeScope = GetActiveScreenElement(erpWin, screenName);
        if (activeScope == null) return steps;

        List<DiscoveredField> primaryInputs = new List<DiscoveredField>();
        List<DiscoveredField> headerOrSecondaryInputs = new List<DiscoveredField>();
        List<DiscoveredField> actionButtons = new List<DiscoveredField>();
        Stopwatch sw = Stopwatch.StartNew();

        CollectScreenInteractiveFields(activeScope, screenName, 0, primaryInputs, headerOrSecondaryInputs, actionButtons, sw, 2500);

        if (primaryInputs.Count == 0 && headerOrSecondaryInputs.Count == 0 && !Automation.Compare(activeScope, erpWin))
        {
            Stopwatch swFallback = Stopwatch.StartNew();
            CollectScreenInteractiveFields(erpWin, screenName, 0, primaryInputs, headerOrSecondaryInputs, actionButtons, swFallback, 1800);
        }

        if (actionButtons.Count == 0 && !Automation.Compare(activeScope, erpWin))
        {
            Stopwatch swRibbon = Stopwatch.StartNew();
            CollectRibbonActionButtons(erpWin, 0, actionButtons, swRibbon, 600);
        }

        List<DiscoveredField> inputs = primaryInputs.Count > 0 ? primaryInputs : headerOrSecondaryInputs;

        inputs.Sort(delegate(DiscoveredField a, DiscoveredField b)
        {
            int rowA = a.ust / 16;
            int rowB = b.ust / 16;
            int cmp = rowA.CompareTo(rowB);
            return cmp != 0 ? cmp : a.sol.CompareTo(b.sol);
        });

        AtlasItem catalogItem = FindCatalogItemByTitle(screenName);
        string expectedFirstField = catalogItem != null && !string.IsNullOrEmpty(catalogItem.ilkVeriAlani)
            ? catalogItem.ilkVeriAlani
            : InferFirstInputField("", screenName, screenName);

        int matchedIdx = -1;
        if (inputs.Count > 0 && !string.IsNullOrEmpty(expectedFirstField))
        {
            for (int i = 0; i < inputs.Count; i++)
            {
                if (FieldNamesMatch(inputs[i].label, expectedFirstField))
                {
                    matchedIdx = i;
                    break;
                }
            }
        }

        if (matchedIdx > 0)
        {
            DiscoveredField matched = inputs[matchedIdx];
            inputs.RemoveAt(matchedIdx);
            inputs.Insert(0, matched);
        }

        HashSet<string> usedLabels = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        int maxInputSteps = 3;
        for (int i = 0; i < inputs.Count && steps.Count < maxInputSteps; i++)
        {
            DiscoveredField df = inputs[i];
            if (!usedLabels.Add(df.label)) continue;

            GuidedStep gs = new GuidedStep();
            gs.stepNo = steps.Count + 1;
            gs.fieldName = df.label;
            gs.element = df.element;
            gs.lastRect = df.rect;
            gs.initialValue = SafeGetValue(df.element);
            gs.isActionStep = false;
            gs.completed = false;

            if (gs.stepNo == 1)
            {
                gs.instruction = "İLK VERİ ALANI: \"" + df.label + "\" alanına veriyi girin / seçin ve Enter veya Tab tuşuna basın.";
            }
            else
            {
                gs.instruction = gs.stepNo + ". VERİ ALANI: \"" + df.label + "\" bilgisini girin / kontrol edin.";
            }
            steps.Add(gs);
        }

        if (catalogItem != null && steps.Count > 0 && steps[0].element != null)
        {
            string realFirst = steps[0].fieldName;
            string realSecond = steps.Count > 1 ? steps[1].fieldName : "";
            string realAction = actionButtons.Count > 0 ? actionButtons[0].label : "";
            SelfHealCatalogEntry(catalogItem, realFirst, realSecond, realAction, SafeGetName(erpWin));
        }

        if (steps.Count == 0)
        {
            GuidedStep fallback1 = new GuidedStep();
            fallback1.stepNo = 1;
            fallback1.fieldName = expectedFirstField;
            fallback1.element = null;
            fallback1.lastRect = System.Windows.Rect.Empty;
            fallback1.initialValue = "";
            fallback1.isActionStep = false;
            fallback1.completed = false;
            fallback1.instruction = "İLK VERİ ALANI: Ekrandaki \"" + expectedFirstField + "\" alanına veriyi girin ve Enter/Tab tuşuna basın.";
            steps.Add(fallback1);
        }

        if (actionButtons.Count > 0)
        {
            DiscoveredField act = actionButtons[0];
            GuidedStep actStep = new GuidedStep();
            actStep.stepNo = steps.Count + 1;
            actStep.fieldName = act.label;
            actStep.element = act.element;
            actStep.lastRect = act.rect;
            actStep.initialValue = "";
            actStep.isActionStep = true;
            actStep.completed = false;
            actStep.instruction = "SON ADIM (GÖRSEL REHBER): \"" + act.label + "\" düğmesine siz basarak işlemi tamamlayın (Asistan otomatik basmaz).";
            steps.Add(actStep);
        }
        else
        {
            GuidedStep actFallback = new GuidedStep();
            actFallback.stepNo = steps.Count + 1;
            actFallback.fieldName = "Çalıştır (F5) / Kaydet";
            actFallback.element = null;
            actFallback.lastRect = System.Windows.Rect.Empty;
            actFallback.initialValue = "";
            actFallback.isActionStep = true;
            actFallback.completed = false;
            actFallback.instruction = "SON ADIM (GÖRSEL REHBER): Verileri girdikten sonra \"Çalıştır (F5)\" veya \"Kaydet\" düğmesine siz basın.";
            steps.Add(actFallback);
        }

        return steps;
    }

    private static bool FieldNamesMatch(string actualLabel, string expectedLabel)
    {
        if (string.IsNullOrEmpty(actualLabel) || string.IsNullOrEmpty(expectedLabel)) return false;
        string a = actualLabel.Trim();
        string e = expectedLabel.Trim();
        if (string.Equals(a, e, StringComparison.OrdinalIgnoreCase)) return true;

        string[] parts = e.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
        for (int i = 0; i < parts.Length; i++)
        {
            string p = parts[i].Trim();
            if (p.Length >= 3 && a.IndexOf(p, StringComparison.OrdinalIgnoreCase) >= 0) return true;
        }
        return false;
    }

    private static void SelfHealCatalogEntry(AtlasItem catalogItem, string realFirst, string realSecond, string realAction, string winTitle)
    {
        if (catalogItem == null || string.IsNullOrEmpty(realFirst)) return;

        bool needsSave = !catalogItem.dogrulandi || !string.Equals(catalogItem.ilkVeriAlani, realFirst, StringComparison.OrdinalIgnoreCase);
        if (!needsSave) return;

        catalogItem.ilkVeriAlani = realFirst;
        catalogItem.dogrulandi = true;

        List<string> healedSteps = new List<string>();
        healedSteps.Add("1. İlk Veri Alanı (Doğrulandı): \"" + realFirst + "\" alanına veriyi girin ve Enter/Tab tuşuna basın.");
        if (!string.IsNullOrEmpty(realSecond))
        {
            healedSteps.Add("2. Sonraki Alan: \"" + realSecond + "\" bilgisini kontrol edin / doldurun.");
        }
        else
        {
            healedSteps.Add("2. Detay / Filtre Kontrolü: İlgili filtre veya satır bilgilerini kontrol edin.");
        }

        string actName = !string.IsNullOrEmpty(realAction) ? realAction : "Çalıştır (F5) / Kaydet";
        healedSteps.Add("3. Tamamlama: \"" + actName + "\" düğmesine siz basarak işlemi tamamlayın.");
        catalogItem.rehberAdimlari = healedSteps;

        LogLine("[SELF-HEALING OPT-12] '" + catalogItem.baslik + "' mağaza ekranının gerçek ilk veri alanı '" + realFirst + "' olarak doğrulandı.");
        SaveGuideCatalogJson(winTitle);
    }

    private class DiscoveredField
    {
        public AutomationElement element;
        public string label;
        public System.Windows.Rect rect;
        public int sol;
        public int ust;
    }

    private static void CollectScreenInteractiveFields(
        AutomationElement parent,
        string activeScreenName,
        int depth,
        List<DiscoveredField> primaryInputs,
        List<DiscoveredField> secondaryInputs,
        List<DiscoveredField> actions,
        Stopwatch sw,
        int timeoutMs)
    {
        if (parent == null || depth > MaxDepth || sw.ElapsedMilliseconds > timeoutMs) return;
        AutomationElementCollection ch = null;
        try { ch = parent.FindAll(TreeScope.Children, Condition.TrueCondition); } catch { return; }
        if (ch == null) return;

        int count = 0;
        foreach (AutomationElement c in ch)
        {
            if (++count > 120 || sw.ElapsedMilliseconds > timeoutMs) break;

            string cls = SafeGetClass(c);
            string aid = SafeGetAutomationId(c);
            string rawName = SafeGetName(c);

            if (cls.IndexOf("MenuNavBar", StringComparison.OrdinalIgnoreCase) >= 0 ||
                aid.IndexOf("MenuNavBar", StringComparison.OrdinalIgnoreCase) >= 0 ||
                aid.IndexOf("RibbonControl", StringComparison.OrdinalIgnoreCase) >= 0 ||
                aid.IndexOf("RibbonStatusBar", StringComparison.OrdinalIgnoreCase) >= 0 ||
                cls.IndexOf("NavBarControl", StringComparison.OrdinalIgnoreCase) >= 0 ||
                cls.IndexOf("Ribbon", StringComparison.OrdinalIgnoreCase) >= 0 ||
                cls.IndexOf("BarDock", StringComparison.OrdinalIgnoreCase) >= 0 ||
                string.Equals(rawName, "The Ribbon", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(rawName, "Status Bar", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            ControlType ct = SafeGetControlType(c);

            if (depth <= 2 && ct == ControlType.Window && !string.IsNullOrEmpty(activeScreenName))
            {
                string winTitle = StripNebimTitle(rawName);
                if (winTitle.Length > 0 && !MatchesScreenTitle(winTitle, activeScreenName))
                {
                    continue;
                }
            }

            System.Windows.Rect r = SafeGetRect(c);
            bool isOff = SafeIsOffscreen(c);
            bool isEn = SafeIsEnabled(c);

            if (!isOff && isEn && !r.IsEmpty && r.Left > 320 && r.Top > 145 && r.Width >= 40 && r.Height >= 16)
            {
                string clean = CleanTitle(rawName);
                bool isDevExpressInput =
                    cls.IndexOf("LookUpEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("ButtonEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("TextEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("DateEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("SpinEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("MemoEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    cls.IndexOf("CheckedComboBoxEdit", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    aid.StartsWith("btxt", StringComparison.OrdinalIgnoreCase) ||
                    aid.StartsWith("txt", StringComparison.OrdinalIgnoreCase) ||
                    aid.StartsWith("mtxt", StringComparison.OrdinalIgnoreCase) ||
                    aid.StartsWith("lookUp", StringComparison.OrdinalIgnoreCase) ||
                    aid.StartsWith("dte", StringComparison.OrdinalIgnoreCase) ||
                    aid.StartsWith("spn", StringComparison.OrdinalIgnoreCase);

                bool isBracketFilter = rawName.Length > 2 && rawName[0] == '[' && rawName.IndexOf(']') > 1;

                if (ct != ControlType.Text && ct != ControlType.Group && ct != ControlType.Pane && ct != ControlType.TabItem &&
                    (ct == ControlType.Edit || ct == ControlType.ComboBox || ct == ControlType.Document || isDevExpressInput || isBracketFilter))
                {
                    if (!rawName.EndsWith("Error Text", StringComparison.OrdinalIgnoreCase) &&
                        !rawName.EndsWith("Zorunlu", StringComparison.OrdinalIgnoreCase))
                    {
                        string lbl = ResolveFieldLabel(c, clean);
                        if (lbl.Length >= 2 && !SkipNames.Contains(lbl) && !lbl.StartsWith("TreeListColumn", StringComparison.OrdinalIgnoreCase))
                        {
                            DiscoveredField df = new DiscoveredField();
                            df.element = c;
                            df.label = lbl;
                            df.rect = r;
                            df.sol = (int)r.Left;
                            df.ust = (int)r.Top;
                            primaryInputs.Add(df);
                        }
                    }
                }
                else if (ct == ControlType.Header || ct == ControlType.HeaderItem)
                {
                    if (clean.Length >= 2 && !SkipNames.Contains(clean) && !clean.StartsWith("TreeListColumn", StringComparison.OrdinalIgnoreCase))
                    {
                        DiscoveredField hf = new DiscoveredField();
                        hf.element = c;
                        hf.label = clean + " (Kolon / Filtre)";
                        hf.rect = r;
                        hf.sol = (int)r.Left;
                        hf.ust = (int)r.Top;
                        secondaryInputs.Add(hf);
                    }
                }
                else if (ct == ControlType.Button || ct == ControlType.SplitButton)
                {
                    if (IsActionButtonName(clean))
                    {
                        DiscoveredField act = new DiscoveredField();
                        act.element = c;
                        act.label = clean;
                        act.rect = r;
                        act.sol = (int)r.Left;
                        act.ust = (int)r.Top;
                        actions.Add(act);
                    }
                }
            }

            if (ct == ControlType.DataItem || ct == ControlType.ListItem)
            {
                continue;
            }

            CollectScreenInteractiveFields(c, activeScreenName, depth + 1, primaryInputs, secondaryInputs, actions, sw, timeoutMs);
        }
    }

    private static void CollectRibbonActionButtons(AutomationElement erpWin, int depth, List<DiscoveredField> actions, Stopwatch sw, int timeoutMs)
    {
        if (erpWin == null || depth > 5 || sw.ElapsedMilliseconds > timeoutMs) return;
        AutomationElementCollection ch = null;
        try { ch = erpWin.FindAll(TreeScope.Children, Condition.TrueCondition); } catch { return; }
        if (ch == null) return;

        int count = 0;
        foreach (AutomationElement c in ch)
        {
            if (++count > 80 || sw.ElapsedMilliseconds > timeoutMs) break;
            System.Windows.Rect r = SafeGetRect(c);
            if (!r.IsEmpty && r.Top > 165) continue;

            ControlType ct = SafeGetControlType(c);
            string nm = CleanTitle(SafeGetName(c));
            if ((ct == ControlType.Button || ct == ControlType.SplitButton) && !r.IsEmpty && r.Width >= 16 && IsActionButtonName(nm))
            {
                DiscoveredField act = new DiscoveredField();
                act.element = c;
                act.label = nm;
                act.rect = r;
                act.sol = (int)r.Left;
                act.ust = (int)r.Top;
                actions.Add(act);
            }

            CollectRibbonActionButtons(c, depth + 1, actions, sw, timeoutMs);
        }
    }

    private static string ResolveFieldLabel(AutomationElement el, string currentName)
    {
        if (!string.IsNullOrEmpty(currentName) &&
            !SkipNames.Contains(currentName) &&
            !IsActionButtonName(currentName) &&
            !currentName.StartsWith("WindowsForms", StringComparison.OrdinalIgnoreCase) &&
            !currentName.StartsWith("textEdit", StringComparison.OrdinalIgnoreCase) &&
            !currentName.StartsWith("lookUp", StringComparison.OrdinalIgnoreCase) &&
            !currentName.StartsWith("buttonEdit", StringComparison.OrdinalIgnoreCase))
        {
            if (currentName.StartsWith("[") && currentName.IndexOf(']') > 1)
            {
                int closeIdx = currentName.IndexOf(']');
                return currentName.Substring(1, closeIdx - 1).Trim();
            }
            return currentName;
        }

        try
        {
            TreeWalker walker = TreeWalker.ControlViewWalker;
            AutomationElement prev = walker.GetPreviousSibling(el);
            for (int i = 0; i < 3 && prev != null; i++)
            {
                ControlType pct = SafeGetControlType(prev);
                if (pct != ControlType.Button && pct != ControlType.SplitButton)
                {
                    string pn = CleanTitle(SafeGetName(prev));
                    if (pn.Length >= 2 && pn.Length <= 60 && !SkipNames.Contains(pn) && !IsActionButtonName(pn))
                    {
                        return pn;
                    }
                }
                prev = walker.GetPreviousSibling(prev);
            }

            AutomationElement parent = walker.GetParent(el);
            if (parent != null)
            {
                string parentName = CleanTitle(SafeGetName(parent));
                if (parentName.Length >= 2 && parentName.Length <= 60 && !SkipNames.Contains(parentName) && !IsActionButtonName(parentName))
                {
                    return parentName;
                }
            }
        }
        catch { }

        string aid = SafeGetAutomationId(el);
        if (aid.Length >= 2 && aid.Length <= 50 && !SkipNames.Contains(aid)) return aid;
        return currentName.Length > 0 && !SkipNames.Contains(currentName) ? currentName : "Veri Giriş Alanı";
    }

    private static bool IsActionButtonName(string name)
    {
        if (string.IsNullOrEmpty(name)) return false;
        string[] actionWords = new string[]
        {
            "Çalıştır", "Sorgula", "Bul", "Listele", "Devam", "İleri", "Kaydet", "Kaydet ve Yeni", "Tamam", "Uygula", "Filtreyi Aç", "Yeni"
        };
        for (int i = 0; i < actionWords.Length; i++)
        {
            if (name.StartsWith(actionWords[i], StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }

    public static AtlasItem FindCatalogItemByTitle(string title)
    {
        if (string.IsNullOrEmpty(title)) return null;
        for (int i = 0; i < SolMenuCatalog.Count; i++)
        {
            if (MatchesScreenTitle(SolMenuCatalog[i].baslik, title) ||
                string.Equals(SolMenuCatalog[i].ekranId, title, StringComparison.OrdinalIgnoreCase))
            {
                return SolMenuCatalog[i];
            }
        }
        return null;
    }

    // =====================================================================================
    // [OPT-14] RDP-DOSTU ÇERÇEVE ÇİZİMİ VE KOORDİNAT TAKİBİ (RenkliCerceveForm)
    // =====================================================================================
    public class RenkliCerceveForm : Form
    {
        private System.Windows.Rect _lastRect = System.Windows.Rect.Empty;
        private string _lastStepText = "";
        private bool _lastActionMode = false;

        public RenkliCerceveForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            BackColor = Color.Magenta;
            TransparencyKey = Color.Magenta;
            DoubleBuffered = true;
            Bounds = new Rectangle(-2000, -2000, 10, 10);
        }

        protected override bool ShowWithoutActivation
        {
            get { return true; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams p = base.CreateParams;
                p.ExStyle |= 0x80000 | 0x20 | 0x08000000 | 0x80 | 0x8;
                return p;
            }
        }

        public void HideFrame()
        {
            if (Visible)
            {
                Visible = false;
            }
        }

        public void UpdateFrameTarget(System.Windows.Rect targetRect, string stepBadge, bool actionMode)
        {
            if (targetRect.IsEmpty || targetRect.Width < 6 || targetRect.Height < 6 || targetRect.Left < 0 || targetRect.Top < 0)
            {
                HideFrame();
                return;
            }

            string badge = stepBadge ?? "";
            bool posChanged = _lastRect.IsEmpty ||
                Math.Abs(targetRect.Left - _lastRect.Left) > 2.0 ||
                Math.Abs(targetRect.Top - _lastRect.Top) > 2.0 ||
                Math.Abs(targetRect.Width - _lastRect.Width) > 2.0 ||
                Math.Abs(targetRect.Height - _lastRect.Height) > 2.0;

            bool stepChanged = !string.Equals(badge, _lastStepText, StringComparison.Ordinal) || (actionMode != _lastActionMode);

            if (!posChanged && !stepChanged && Visible)
            {
                return;
            }

            _lastRect = targetRect;
            _lastStepText = badge;
            _lastActionMode = actionMode;

            int pad = 5;
            int topBannerHeight = 25;
            int x = Math.Max(0, (int)targetRect.Left - pad);
            int y = Math.Max(0, (int)targetRect.Top - pad - topBannerHeight);
            int w = Math.Max(230, (int)targetRect.Width + pad * 2);
            int h = (int)targetRect.Height + pad * 2 + topBannerHeight;

            SetBounds(x, y, w, h);
            if (!Visible)
            {
                Visible = true;
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            int topBannerHeight = 25;
            Color primaryColor = _lastActionMode
                ? Color.FromArgb(0, 230, 118)
                : Color.FromArgb(255, 140, 0);

            if (!string.IsNullOrEmpty(_lastStepText))
            {
                Rectangle bannerRect = new Rectangle(0, 0, Math.Min(Width - 2, 360), topBannerHeight - 2);
                using (SolidBrush bgBrush = new SolidBrush(Color.FromArgb(22, 28, 40)))
                {
                    e.Graphics.FillRectangle(bgBrush, bannerRect);
                }
                using (Pen borderPen = new Pen(primaryColor, 2))
                {
                    e.Graphics.DrawRectangle(borderPen, bannerRect);
                }
                using (Font f = new Font("Segoe UI", 8.8f, FontStyle.Bold))
                using (SolidBrush textBrush = new SolidBrush(Color.White))
                {
                    e.Graphics.DrawString(_lastStepText, f, textBrush, new PointF(6, 2));
                }
            }

            Rectangle fieldBox = new Rectangle(2, topBannerHeight, Width - 5, Height - topBannerHeight - 3);
            if (fieldBox.Width > 4 && fieldBox.Height > 4)
            {
                using (Pen framePen = new Pen(primaryColor, 3))
                {
                    e.Graphics.DrawRectangle(framePen, fieldBox);
                }
            }
        }
    }

    // =====================================================================================
    // [OPT-16] SESLİ ASİSTAN / SESLİ AJAN MOTORU (Türkçe TTS Okuma + Sesli Komut)
    // =====================================================================================
    public static class SesliAsistan
    {
        private static bool _aktif = true;
        private static bool _ayarYuklendi = false;
        private static object _kilit = new object();
        private static string _sonOkunanMetin = "";
        private static DateTime _sonOkumaZamani = DateTime.MinValue;
        private static string _seciliSesAdi = "Türkçe Ses (Tolga)";

        public static bool Aktif
        {
            get
            {
                if (!_ayarYuklendi) YukleAyar();
                return _aktif;
            }
            set
            {
                _aktif = value;
                _ayarYuklendi = true;
                KaydetAyar();
            }
        }

        public static string SeciliSesAdi
        {
            get { return _seciliSesAdi; }
        }

        private static string AyarDosyasi
        {
            get { return Path.Combine(ResolveOutputDir(), "sesli-asistan-ayar.json"); }
        }

        public static void YukleAyar()
        {
            _ayarYuklendi = true;
            try
            {
                if (File.Exists(AyarDosyasi))
                {
                    string raw = File.ReadAllText(AyarDosyasi, Encoding.UTF8);
                    if (raw.IndexOf("\"aktif\":false", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        raw.IndexOf("\"aktif\": false", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        _aktif = false;
                    }
                    else
                    {
                        _aktif = true;
                    }
                }
            }
            catch { _aktif = true; }
        }

        public static void KaydetAyar()
        {
            try
            {
                string json = "{\"aktif\":" + (_aktif ? "true" : "false") + ",\"guncelleme\":\"" + DateTime.Now.ToString("s") + "\"}";
                AtomicWriteText(AyarDosyasi, json);
            }
            catch { }
        }

        public static string MetniTemizle(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return "";
            string s = raw;
            s = s.Replace("₺", " TL ");
            s = s.Replace("PM3401", "P M 34 01");
            s = s.Replace("STORE", "Mağaza");
            s = s.Replace("UIA", "ekran");
            s = s.Replace("RDP", "uzak masaüstü");
            s = Regex.Replace(s, @"[\u2600-\u27BF]|[\uD83C-\uDBFF][\uDC00-\uDFFF]", " ");
            s = s.Replace("▶", " ").Replace("🧭", " ").Replace("⏳", " ").Replace("✅", " ")
                 .Replace("⚠️", " ").Replace("🚨", " ").Replace("🟧", " ").Replace("🟢", " ")
                 .Replace("⚡", " ").Replace("🛠", " ").Replace("📌", " ").Replace("🧠", " ")
                 .Replace("·", ", ").Replace("|", ", ").Replace("→", " ").Replace("—", ", ");
            s = Regex.Replace(s, @"\s+", " ").Trim();
            return s;
        }

        private static object _spVoiceInstance = null;
        private static Type _spVoiceType = null;

        private static void EnsureVoiceInitialized()
        {
            if (_spVoiceInstance != null && _spVoiceType != null) return;
            _spVoiceType = Type.GetTypeFromProgID("SAPI.SpVoice");
            if (_spVoiceType == null) return;
            _spVoiceInstance = Activator.CreateInstance(_spVoiceType);

            // Windows 10/11 OneCore Türkçe Ses (Microsoft Tolga - tr-TR) seçimi
            try
            {
                Type catType = Type.GetTypeFromProgID("SAPI.SpObjectTokenCategory");
                if (catType != null)
                {
                    object spCat = Activator.CreateInstance(catType);
                    catType.InvokeMember("SetId", System.Reflection.BindingFlags.InvokeMethod, null, spCat,
                        new object[] { @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices", false });
                    object tokens = catType.InvokeMember("EnumerateTokens", System.Reflection.BindingFlags.InvokeMethod, null, spCat, null);
                    if (tokens != null)
                    {
                        int count = Convert.ToInt32(tokens.GetType().InvokeMember("Count", System.Reflection.BindingFlags.GetProperty, null, tokens, null));
                        for (int i = 0; i < count; i++)
                        {
                            object token = tokens.GetType().InvokeMember("Item", System.Reflection.BindingFlags.InvokeMethod, null, tokens, new object[] { i });
                            string desc = Convert.ToString(token.GetType().InvokeMember("GetDescription", System.Reflection.BindingFlags.InvokeMethod, null, token, null));
                            if (desc.IndexOf("Tolga", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                desc.IndexOf("Turkish", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                desc.IndexOf("Türkçe", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                desc.IndexOf("tr-TR", StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                _spVoiceType.InvokeMember("Voice", System.Reflection.BindingFlags.SetProperty, null, _spVoiceInstance, new object[] { token });
                                _seciliSesAdi = desc;
                                break;
                            }
                        }
                    }
                }
            }
            catch { }

            try
            {
                _spVoiceType.InvokeMember("Rate", System.Reflection.BindingFlags.SetProperty, null, _spVoiceInstance, new object[] { 1 });
                _spVoiceType.InvokeMember("Volume", System.Reflection.BindingFlags.SetProperty, null, _spVoiceInstance, new object[] { 100 });
            }
            catch { }
        }

        public static void Durdur()
        {
            lock (_kilit)
            {
                try
                {
                    if (_spVoiceInstance != null && _spVoiceType != null)
                    {
                        // SVSFlagsAsync (1) | SVSFPurgeBeforeSpeak (2) = 3 ile boş metin göndererek anında sustur
                        _spVoiceType.InvokeMember("Speak", System.Reflection.BindingFlags.InvokeMethod, null, _spVoiceInstance, new object[] { "", 3 });
                    }
                }
                catch { }
            }
        }

        // Yalnızca kullanıcı özellikle istediğinde (zorla=true: Ciro Oku / Adım Oku / Sesli Komut) konuşur;
        // arka planda canlı ekranı veya uyarıları kendi kendine okuyup gürültü kirliliği yapmaz.
        public static void Konus(string metin, bool zorla = false)
        {
            if (!zorla) return;
            if (!Aktif) return;
            string temiz = MetniTemizle(metin);
            if (temiz.Length < 2) return;

            ThreadPool.QueueUserWorkItem(delegate
            {
                lock (_kilit)
                {
                    try
                    {
                        EnsureVoiceInitialized();
                        if (_spVoiceInstance == null || _spVoiceType == null) return;
                        // SVSFlagsAsync (1) | SVSFPurgeBeforeSpeak (2) = 3 -> önceki konuşmayı kesip yenisini okur
                        _spVoiceType.InvokeMember("Speak", System.Reflection.BindingFlags.InvokeMethod, null, _spVoiceInstance, new object[] { temiz, 3 });
                    }
                    catch { }
                }
            });
        }
    }

    // =====================================================================================
    // CANLI MAKİNE & EYLEM TELEMETRİ EKRANI (Daktilo Animasyonlu + Renkli Flaşörlü Uyarı Paneli)
    // =====================================================================================
    public enum MakineDurumModu
    {
        Hazir = 0,
        Calisiyor = 1,
        Uyari = 2,
        HataAlarm = 3
    }

    public class CanliMakineEkranPanel : Panel
    {
        public static CanliMakineEkranPanel ActiveInstance;

        private Label _srcTitle;
        private Label _srcDesc;
        private Label _srcStatus;

        private string _targetTitle = "";
        private string _targetDesc = "";
        private string _targetStatus = "";

        private int _visTitleLen = 0;
        private int _visDescLen = 0;
        private int _visStatusLen = 0;

        private MakineDurumModu _mode = MakineDurumModu.Hazir;
        private int _tickCount = 0;
        private int _scannerX = 0;
        private int _scannerDir = 1;
        private string _telemetryTag = "PM3401:AKTİF";
        private bool _rdpErpMissing = false;

        private int _demoStage = 0;
        private int _demoTicksLeft = 0;

        private static readonly string[] SpinnerFrames = new string[] { "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏" };

        public CanliMakineEkranPanel()
        {
            DoubleBuffered = true;
            SetStyle(
                ControlStyles.AllPaintingInWmPaint |
                ControlStyles.UserPaint |
                ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw,
                true);
            BackColor = Color.FromArgb(13, 19, 30);
            ActiveInstance = this;
        }

        public void BindSourceLabels(Label lblTitle, Label lblDesc, Label lblStatus)
        {
            _srcTitle = lblTitle;
            _srcDesc = lblDesc;
            _srcStatus = lblStatus;

            if (_srcTitle != null)
            {
                _srcTitle.Visible = false;
                _srcTitle.TextChanged += delegate { SyncFromSourceLabels(); };
            }
            if (_srcDesc != null)
            {
                _srcDesc.Visible = false;
                _srcDesc.TextChanged += delegate { SyncFromSourceLabels(); };
            }
            if (_srcStatus != null)
            {
                _srcStatus.Visible = false;
                _srcStatus.TextChanged += delegate { SyncFromSourceLabels(); };
            }

            SyncFromSourceLabels();
        }

        public void PushLiveAction(string title, string desc, string status)
        {
            if (_srcTitle != null && !string.IsNullOrEmpty(title)) _srcTitle.Text = title;
            if (_srcDesc != null && !string.IsNullOrEmpty(desc)) _srcDesc.Text = desc;
            if (_srcStatus != null && !string.IsNullOrEmpty(status)) _srcStatus.Text = status;
            SyncFromSourceLabels();
            Invalidate();
        }

        private Label _screenHeaderRef;

        public void StartLiveDemoSequence(Label lblScreenHeader)
        {
            _screenHeaderRef = lblScreenHeader;
            _demoStage = 1;
            _demoTicksLeft = 36;
            if (lblScreenHeader != null)
            {
                lblScreenHeader.Text = "🧭 Aktif Ekran: ⚡ " + Sube.Ad + " (" + Sube.Kod + ") Canlı Makine Testi...";
            }
            PushLiveAction(
                "⚡ EYLEM 1/3: " + Sube.Ad + " (" + Sube.Kod + ") STORE Kanalı Taranıyor",
                "NebimYardimci v6.0 kuyruk köprüsü üzerinden mağaza modülü, 'Ara...' kutusu ve çalışma alanı kontrol ediliyor...",
                "⏳ [CANLI EYLEM] Mağaza komut paketleri gönderiliyor ve UIA koordinatları okunuyor...");
        }

        public void SyncFromSourceLabels()
        {
            string newTitle = _srcTitle != null ? (_srcTitle.Text ?? "") : "";
            string newDesc = _srcDesc != null ? (_srcDesc.Text ?? "") : "";
            string newStatus = _srcStatus != null ? (_srcStatus.Text ?? "") : "";

            if (!string.Equals(newTitle, _targetTitle, StringComparison.Ordinal))
            {
                _targetTitle = newTitle;
                _visTitleLen = 0;
            }
            if (!string.Equals(newDesc, _targetDesc, StringComparison.Ordinal))
            {
                _targetDesc = newDesc;
                _visDescLen = 0;
            }
            if (!string.Equals(newStatus, _targetStatus, StringComparison.Ordinal))
            {
                _targetStatus = newStatus;
                _visStatusLen = 0;
            }

            _mode = ClassifyState(_targetTitle, _targetDesc, _targetStatus);
        }

        private MakineDurumModu ClassifyState(string title, string desc, string status)
        {
            string all = NormTr((title ?? "") + " " + (desc ?? "") + " " + (status ?? ""));

            if (_demoStage == 2 ||
                all.Contains("alarm aktif") ||
                (title != null && title.Contains("🚨")) ||
                (desc != null && desc.Contains("🚨")) ||
                (status != null && status.Contains("🚨")))
            {
                return MakineDurumModu.HataAlarm;
            }

            if ((status != null && status.Contains("⏳")) ||
                (title != null && title.Contains("⏳")) ||
                (title != null && title.Contains("⚡")) ||
                (title != null && title.Contains("⌨")) ||
                (title != null && title.Contains("🔍")) ||
                (title != null && title.Contains("🎯")) ||
                all.Contains("yaziliyor") ||
                all.Contains("aciliyor") ||
                all.Contains("okunuyor") ||
                all.Contains("taraniyor") ||
                all.Contains("bekleniyor..."))
            {
                return MakineDurumModu.Calisiyor;
            }

            if (_rdpErpMissing || all.Contains("penceresi acik degil"))
            {
                return MakineDurumModu.Uyari;
            }

            return MakineDurumModu.Hazir;
        }

        public void StepAnimationNow()
        {
            _tickCount++;

            if (_demoStage > 0)
            {
                _demoTicksLeft--;
                if (_demoTicksLeft <= 0)
                {
                    if (_demoStage == 1)
                    {
                        _demoStage = 2;
                        _demoTicksLeft = 52;
                        PushLiveAction(
                            "🚨 UYARI / ALARM: Hedef Mağaza Ekranı Açık Değil!",
                            "⚠️ RDP içinde 'Nebim V3 STORE' veya 'Nebim V3 ERP' penceresi açık değil. Veri giriş alanı odaklanamadı!",
                            "🚨 [ALARM AKTİF] Hata algılandı — Lütfen RDP içinde Nebim V3 STORE'u açın!");
                    }
                    else if (_demoStage == 2)
                    {
                        _demoStage = 0;
                        _demoTicksLeft = 0;
                        if (_screenHeaderRef != null)
                        {
                            _screenHeaderRef.Text = "🧭 Aktif Ekran: Bekleniyor...";
                        }
                        CheckRdpBridgeTelemetry(true);
                    }
                    else
                    {
                        _demoStage = 0;
                    }
                }
            }
            else if (_tickCount % 24 == 2)
            {
                CheckRdpBridgeTelemetry(false);
            }

            if (_visTitleLen < _targetTitle.Length)
            {
                _visTitleLen = Math.Min(_targetTitle.Length, _visTitleLen + 3);
            }
            if (_visDescLen < _targetDesc.Length)
            {
                _visDescLen = Math.Min(_targetDesc.Length, _visDescLen + 5);
            }
            if (_visStatusLen < _targetStatus.Length)
            {
                _visStatusLen = Math.Min(_targetStatus.Length, _visStatusLen + 5);
            }

            int stepSpeed = (_mode == MakineDurumModu.Calisiyor) ? 18 : ((_mode == MakineDurumModu.HataAlarm) ? 14 : 7);
            _scannerX += _scannerDir * stepSpeed;
            int maxScan = Math.Max(60, Width - 70);
            if (_scannerX >= maxScan)
            {
                _scannerX = maxScan;
                _scannerDir = -1;
            }
            else if (_scannerX <= 0)
            {
                _scannerX = 0;
                _scannerDir = 1;
            }

            Invalidate();
        }

        private static bool _lastGoodRdpErpOpen = true;
        private static string _lastGoodRdpEkran = "";
        private static DateTime _lastGoodTelemetryReadUtc = DateTime.MinValue;
        private int _consecutiveMissingCount = 0;

        public static bool IsRdpErpOpenFromTelemetry(out string rdpEkran, out bool rdpBridgeFresh)
        {
            rdpEkran = _lastGoodRdpEkran;
            rdpBridgeFresh = true;
            try
            {
                string durumPath = Path.Combine(ResolveOutputDir(), "yardimci-durum.json");
                if (!File.Exists(durumPath))
                {
                    if (FindRdpClientWindow() != IntPtr.Zero || FindErpWindow() != null)
                    {
                        return true;
                    }
                    return _lastGoodRdpErpOpen;
                }

                double ageSec = Math.Abs((DateTime.UtcNow - File.GetLastWriteTimeUtc(durumPath)).TotalSeconds);
                rdpBridgeFresh = ageSec <= 600.0;

                string raw = "";
                for (int r = 0; r < 4; r++)
                {
                    try
                    {
                        using (FileStream fs = new FileStream(durumPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                        using (StreamReader sr = new StreamReader(fs, Encoding.UTF8))
                        {
                            raw = sr.ReadToEnd();
                        }
                        if (!string.IsNullOrEmpty(raw)) break;
                    }
                    catch
                    {
                        Thread.Sleep(25);
                    }
                }

                if (string.IsNullOrEmpty(raw))
                {
                    return _lastGoodRdpErpOpen;
                }

                bool erpOpen = Regex.IsMatch(raw, "\"erp\"\\s*:\\s*true", RegexOptions.IgnoreCase) ||
                               Regex.IsMatch(raw, "\"store\"\\s*:\\s*true", RegexOptions.IgnoreCase) ||
                               Regex.IsMatch(raw, "\"sql\"\\s*:\\s*true", RegexOptions.IgnoreCase);
                if (!erpOpen && FindRdpClientWindow() != IntPtr.Zero)
                {
                    erpOpen = true;
                }
                rdpEkran = ExtractJsonStringField(raw, "ekran");

                _lastGoodRdpErpOpen = erpOpen;
                _lastGoodRdpEkran = rdpEkran ?? "";
                _lastGoodTelemetryReadUtc = DateTime.UtcNow;
                return erpOpen;
            }
            catch
            {
                return _lastGoodRdpErpOpen;
            }
        }

        public void CheckRdpBridgeTelemetry(bool updateTextsIfErpMissing)
        {
            try
            {
                string rdpEkran;
                bool rdpBridgeFresh;
                bool rdpErpOpen = IsRdpErpOpenFromTelemetry(out rdpEkran, out rdpBridgeFresh);
                bool localErpOpen = (FindErpWindow() != null);
                bool anyErpOpen = rdpErpOpen || localErpOpen;

                if (anyErpOpen)
                {
                    _consecutiveMissingCount = 0;
                    bool wasMissing = _rdpErpMissing;
                    _rdpErpMissing = false;
                    _telemetryTag = !string.IsNullOrEmpty(rdpEkran) ? (Sube.Kod + ":AKTİF") : (Sube.Kod + ":AÇIK");
                    bool showingClosedWarning =
                        (_targetDesc != null && _targetDesc.IndexOf("açık değil", StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (_targetStatus != null && _targetStatus.IndexOf("ERP kapalı", StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (_targetStatus != null && _targetStatus.IndexOf("STORE kapalı", StringComparison.OrdinalIgnoreCase) >= 0);

                    if ((wasMissing || showingClosedWarning) && _demoStage == 0)
                    {
                        PushLiveAction(
                            "▶ ADIM 1: İlk Veri Giriş Alanı (" + Sube.Ad + " - " + Sube.Kod + ")",
                            "Nebim V3 STORE / ERP penceresi algılandı! 9 mağaza karosuna tıklayarak ekran açabilirsiniz.",
                            "✅ " + Sube.Ad + " (" + Sube.Kod + ") STORE bağlantısı aktif (" + SolMenuCatalog.Count + " mağaza ekranı hazır).");
                    }
                    else
                    {
                        SyncFromSourceLabels();
                    }
                }
                else
                {
                    _consecutiveMissingCount++;
                    // Anlık dosya kilidi veya geçici gecikmede hemen "ERP Kapalı" uyarısına düşme; en az 4 ardışık kontrol bekle
                    if (!updateTextsIfErpMissing && _consecutiveMissingCount < 4)
                    {
                        SyncFromSourceLabels();
                        return;
                    }

                    bool wasMissing = _rdpErpMissing;
                    _rdpErpMissing = true;
                    _telemetryTag = "ERP:KAPALI";
                    bool falselySayingDetected =
                        (_targetDesc != null && _targetDesc.IndexOf("algılandı", StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (_targetStatus != null && _targetStatus.IndexOf("bağlantısı kuruldu", StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (_targetStatus != null && _targetStatus.IndexOf("bağlantısı aktif", StringComparison.OrdinalIgnoreCase) >= 0) ||
                        (_targetStatus != null && _targetStatus.IndexOf("motoru hazır", StringComparison.OrdinalIgnoreCase) >= 0);

                    if ((updateTextsIfErpMissing || !wasMissing || falselySayingDetected) && _demoStage == 0)
                    {
                        PushLiveAction(
                            "⚠️ UYARI: Nebim V3 STORE / ERP Penceresi Açık Değil",
                            "⚠️ RDP içinde 'Nebim V3 STORE' (" + Sube.Ad + " - " + Sube.Kod + ") penceresi açık değil. İşlem yapmak için lütfen Nebim'i açın.",
                            "⚠️ Durum: Nebim V3 STORE / ERP kapalı — Açıldığında otomatik algılanır.");
                    }
                    else
                    {
                        SyncFromSourceLabels();
                    }
                }
            }
            catch { }
        }

        private static System.Drawing.Drawing2D.GraphicsPath CreateRoundedRectPath(Rectangle bounds, int radius)
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            int d = radius * 2;
            if (d <= 0 || bounds.Width <= d || bounds.Height <= d)
            {
                path.AddRectangle(bounds);
                return path;
            }
            path.AddArc(bounds.X, bounds.Y, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Y, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.X, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            int w = Width;
            int h = Height;
            int cornerRadius = 11;

            Color parentBg = (Parent != null) ? Parent.BackColor : Color.FromArgb(228, 233, 242);
            g.Clear(parentBg);

            double pulseSpeed = (_mode == MakineDurumModu.HataAlarm) ? 0.42 :
                                (_mode == MakineDurumModu.Uyari ? 0.30 :
                                (_mode == MakineDurumModu.Calisiyor ? 0.35 : 0.16));
            double pulse = (Math.Sin(_tickCount * pulseSpeed) + 1.0) * 0.5;
            bool blinkOn = (_tickCount / 4) % 2 == 0;

            Color bgBase = Color.FromArgb(13, 19, 30);
            if (_mode == MakineDurumModu.HataAlarm)
            {
                int rGlow = 18 + (int)(pulse * 42);
                int gGlow = 12 + (int)(pulse * 8);
                bgBase = Color.FromArgb(rGlow, gGlow, 24);
            }
            else if (_mode == MakineDurumModu.Uyari)
            {
                int rGlow = 16 + (int)(pulse * 28);
                int gGlow = 18 + (int)(pulse * 16);
                bgBase = Color.FromArgb(rGlow, gGlow, 24);
            }

            Rectangle panelBounds = new Rectangle(1, 1, w - 3, h - 3);
            using (System.Drawing.Drawing2D.GraphicsPath mainPath = CreateRoundedRectPath(panelBounds, cornerRadius))
            {
                using (SolidBrush bgBr = new SolidBrush(bgBase))
                {
                    g.FillPath(bgBr, mainPath);
                }

                g.SetClip(mainPath);

                using (Pen scanPen = new Pen(Color.FromArgb(9, 160, 210, 255), 1))
                {
                    for (int sy = 25; sy < h - 4; sy += 4)
                    {
                        g.DrawLine(scanPen, 4, sy, w - 5, sy);
                    }
                }

                Color primaryColor;
                Color secondaryColor;
                string modeBadgeText;

                if (_mode == MakineDurumModu.HataAlarm)
                {
                    int rC = 255;
                    int gC = blinkOn ? (int)(35 + pulse * 40) : (int)(135 + pulse * 45);
                    int bC = blinkOn ? 55 : 15;
                    primaryColor = Color.FromArgb(rC, gC, bC);
                    secondaryColor = Color.FromArgb(255, 60, 60);
                    modeBadgeText = blinkOn ? "⚠ UYARI / ALARM AKTİF (" + Sube.Kod + ")" : "⚠ KRİTİK DURUM UYARISI (" + Sube.Kod + ")";
                }
                else if (_mode == MakineDurumModu.Uyari)
                {
                    int gC = 145 + (int)(pulse * 75);
                    primaryColor = Color.FromArgb(255, gC, 20);
                    secondaryColor = Color.FromArgb(255, 195, 60);
                    modeBadgeText = "⚠ DİKKAT / UYARI MODU (" + Sube.Kod + ")";
                }
                else if (_mode == MakineDurumModu.Calisiyor)
                {
                    int gC = 195 + (int)(pulse * 55);
                    primaryColor = Color.FromArgb(0, gC, 255);
                    secondaryColor = Color.FromArgb(80, 230, 255);
                    string sp = SpinnerFrames[_tickCount % SpinnerFrames.Length];
                    modeBadgeText = sp + " CANLI MAĞAZA EYLEMİ (" + Sube.Kod + ")";
                }
                else
                {
                    int gC = 195 + (int)(pulse * 50);
                    primaryColor = Color.FromArgb(16, gC, 120);
                    secondaryColor = Color.FromArgb(90, 245, 165);
                    modeBadgeText = "● CANLI MAĞAZA REHBERİ (" + Sube.Kod + ")";
                }

                using (SolidBrush hdrBr = new SolidBrush(Color.FromArgb(22, 30, 46)))
                {
                    g.FillRectangle(hdrBr, 1, 1, w - 2, 23);
                }

                using (SolidBrush leftBarBr = new SolidBrush(primaryColor))
                {
                    g.FillRectangle(leftBarBr, 1, 1, 5, h - 2);
                }

                int ledAlpha = 90 + (int)(pulse * 155);
                using (SolidBrush haloBr = new SolidBrush(Color.FromArgb(ledAlpha / 2, primaryColor)))
                {
                    g.FillEllipse(haloBr, 10, 5, 15, 15);
                }
                using (SolidBrush ledBr = new SolidBrush(primaryColor))
                {
                    g.FillEllipse(ledBr, 13, 8, 9, 9);
                }
                using (SolidBrush coreBr = new SolidBrush(Color.FromArgb(220, 255, 255, 255)))
                {
                    g.FillEllipse(coreBr, 15, 10, 3, 3);
                }

                using (Font fBadge = new Font("Segoe UI", 8.0f, FontStyle.Bold))
                using (SolidBrush badgeBr = new SolidBrush(primaryColor))
                {
                    g.DrawString(modeBadgeText, fBadge, badgeBr, new PointF(27, 4));
                }

                using (Font fTel = new Font("Consolas", 7.8f, FontStyle.Bold))
                using (SolidBrush telBr = new SolidBrush(Color.FromArgb(170, 200, 230)))
                {
                    SizeF ts = g.MeasureString(_telemetryTag, fTel);
                    g.DrawString(_telemetryTag, fTel, telBr, new PointF(w - 50 - ts.Width, 5));
                }

                for (int b = 0; b < 5; b++)
                {
                    double barPhase = Math.Sin((_tickCount * 0.45) + b * 1.1);
                    int barH = (_mode == MakineDurumModu.Calisiyor || _mode == MakineDurumModu.HataAlarm)
                        ? (4 + (int)((barPhase + 1.0) * 4.5))
                        : (3 + ((b + (_tickCount / 6)) % 3) * 2);
                    int bx = w - 42 + b * 6;
                    int by = 19 - barH;
                    using (SolidBrush bBr = new SolidBrush(primaryColor))
                    {
                        g.FillRectangle(bBr, bx, by, 4, barH);
                    }
                }

                using (Pen baseLinePen = new Pen(Color.FromArgb(65, primaryColor), 1))
                {
                    g.DrawLine(baseLinePen, 4, 24, w - 4, 24);
                }
                if (_mode == MakineDurumModu.HataAlarm || _mode == MakineDurumModu.Uyari)
                {
                    int flashAlpha = 110 + (int)(pulse * 145);
                    using (Pen alarmLinePen = new Pen(Color.FromArgb(flashAlpha, primaryColor), 2))
                    {
                        g.DrawLine(alarmLinePen, 4, 24, w - 4, 24);
                    }
                }
                using (Pen laserPen = new Pen(secondaryColor, 2))
                {
                    int lx = Math.Max(6, Math.Min(w - 66, _scannerX));
                    g.DrawLine(laserPen, lx, 24, lx + 62, 24);
                }

                string shownTitle = (_visTitleLen >= _targetTitle.Length)
                    ? _targetTitle
                    : _targetTitle.Substring(0, Math.Max(0, _visTitleLen)) + "▋";

                Color titleColor = (_mode == MakineDurumModu.HataAlarm)
                    ? (blinkOn ? Color.FromArgb(255, 110, 110) : Color.FromArgb(255, 210, 80))
                    : ((_mode == MakineDurumModu.Calisiyor) ? Color.FromArgb(90, 230, 255) : Color.FromArgb(255, 180, 60));

                using (Font fTitle = new Font("Segoe UI", 9.5f, FontStyle.Bold))
                {
                    TextRenderer.DrawText(
                        g,
                        shownTitle,
                        fTitle,
                        new Rectangle(12, 28, w - 22, 22),
                        titleColor,
                        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                }

                bool descTyping = _visDescLen < _targetDesc.Length;
                string shownDesc = descTyping
                    ? (_targetDesc.Substring(0, Math.Max(0, _visDescLen)) + "▋")
                    : (_targetDesc + ((_tickCount % 10 < 5 && _mode == MakineDurumModu.Calisiyor) ? " ▋" : ""));

                Color descColor = Color.FromArgb(235, 242, 252);
                if (_mode == MakineDurumModu.HataAlarm)
                {
                    descColor = blinkOn ? Color.FromArgb(255, 225, 130) : Color.FromArgb(255, 145, 135);
                }
                else if (_mode == MakineDurumModu.Uyari)
                {
                    descColor = blinkOn ? Color.FromArgb(255, 225, 140) : Color.FromArgb(245, 245, 250);
                }

                using (Font fDesc = new Font("Segoe UI", 8.8f, (_mode == MakineDurumModu.HataAlarm) ? FontStyle.Bold : FontStyle.Regular))
                {
                    TextRenderer.DrawText(
                        g,
                        shownDesc,
                        fDesc,
                        new Rectangle(12, 52, w - 22, 46),
                        descColor,
                        TextFormatFlags.Left | TextFormatFlags.Top | TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                }

                Rectangle statusRect = new Rectangle(10, h - 29, w - 18, 22);
                Color pillBg;
                Color pillBorder;
                Color pillText;

                if (_mode == MakineDurumModu.HataAlarm)
                {
                    pillBg = blinkOn
                        ? Color.FromArgb(165, 24, 36)
                        : Color.FromArgb(195, 85, 10);
                    pillBorder = blinkOn
                        ? Color.FromArgb(255, 90, 100)
                        : Color.FromArgb(255, 215, 70);
                    pillText = Color.FromArgb(255, 250, 220);
                }
                else if (_mode == MakineDurumModu.Uyari)
                {
                    pillBg = Color.FromArgb(85 + (int)(pulse * 55), 55 + (int)(pulse * 25), 10);
                    pillBorder = Color.FromArgb(255, 185, 45);
                    pillText = Color.FromArgb(255, 235, 160);
                }
                else if (_mode == MakineDurumModu.Calisiyor)
                {
                    pillBg = Color.FromArgb(14, 58 + (int)(pulse * 30), 98 + (int)(pulse * 35));
                    pillBorder = Color.FromArgb(0, 200, 255);
                    pillText = Color.FromArgb(185, 245, 255);
                }
                else
                {
                    pillBg = Color.FromArgb(14, 52, 38);
                    pillBorder = Color.FromArgb(30, 175, 105);
                    pillText = Color.FromArgb(135, 250, 180);
                }

                using (System.Drawing.Drawing2D.GraphicsPath pillPath = CreateRoundedRectPath(statusRect, 6))
                {
                    using (SolidBrush pBr = new SolidBrush(pillBg))
                    {
                        g.FillPath(pBr, pillPath);
                    }
                    using (Pen pPen = new Pen(pillBorder, 1))
                    {
                        g.DrawPath(pPen, pillPath);
                    }
                }

                string shownStatus = (_visStatusLen >= _targetStatus.Length)
                    ? _targetStatus
                    : (_targetStatus.Substring(0, Math.Max(0, _visStatusLen)) + "▋");

                using (Font fStat = new Font("Segoe UI", 8.2f, FontStyle.Bold))
                {
                    TextRenderer.DrawText(
                        g,
                        shownStatus,
                        fStat,
                        new Rectangle(statusRect.X + 7, statusRect.Y + 1, statusRect.Width - 14, statusRect.Height - 2),
                        pillText,
                        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                }

                g.ResetClip();

                int borderW = (_mode == MakineDurumModu.HataAlarm || _mode == MakineDurumModu.Uyari) ? 2 : 1;
                using (Pen borderPen = new Pen(primaryColor, borderW))
                {
                    g.DrawPath(borderPen, mainPath);
                }
            }
        }
    }


    // =====================================================================================
    // [OPT-11 & OPT-15] MAHMUTBEY (PM3401) HIZLI ERİŞİM KAROLARI + YOL GÖSTERİCİ PENCERESİ
    // =====================================================================================
    public class QuickTileDef
    {
        public string title;
        public string primaryMenu;
        public string fallbackMenu;
        public int sira;
        public Color color;

        public QuickTileDef(string t, string pMenu, string fMenu, int s, Color c)
        {
            title = t;
            primaryMenu = pMenu;
            fallbackMenu = fMenu;
            sira = s;
            color = c;
        }
    }

    public class RehberKontrolMerkezi : Form
    {
        // Üst Araç Çubuğu ve Hızlı Erişim Bileşenleri
        private Panel toolbarPanel;
        private Label lblStatusDot;
        private Button btnMini;
        private CheckBox chkTopMost;
        private Button btnMcpStatus;
        private Button btnVoice;
        private Button btnTheme;
        private Button btnUpdate;
        private Button btnTileSettings;
        private Label lblLiveSummary;
        private Button btnLiveRefresh;
        private Panel tileGridPanel;
        private QuickTileDef[] tileDefs;
        private List<Button> quickTileButtons = new List<Button>();

        // Karo Özelleştirme (Ayarlar Sekmesi) Bileşenleri
        private Panel settingsTabPanel;
        private bool isSettingsTabOpen = false;
        private int editingTileIdx = 0;
        private bool suppressTileSettingsEvents = false;
        private ComboBox cmbEditingTileIndex;
        private CheckBox chkAutoSyncTileName;
        private TextBox txtEditingTileName;
        private Button btnCopyMenuToTitle;
        private TextBox txtEditingMenuTarget;
        private ComboBox cmbEditingCategory;
        private TextBox txtEditingMenuSearch;
        private ListBox lstEditingMenus;
        private Button btnSaveTileSettings;
        private Button btnResetDefaultTiles;
        private Button btnCloseTileSettings;

        // Tüm Menüler Çekmecesi Bileşenleri
        private Button btnToggleAllMenus;
        private Panel drawerAllMenusPanel;
        private TextBox txtDrawerFilter;
        private ComboBox cmbDrawerCategory;
        private ListBox lstDrawerMenus;
        private Button btnDrawerOpen;
        private Button btnDrawerTeach;
        private Button btnDrawerPersonnel;
        private Button btnDrawerHelp;
        private bool isAllMenusExpanded = false;

        // Mahmutbey Asistan Canlı Yol Gösterici Bileşenleri
        private Panel guideMainPanel;
        private ComboBox cmbMenuSearch;
        private ListBox lstQuickSearchResults;
        private bool suppressQuickSearchEvents = false;
        private Label lblScreenTitle;
        private Button btnMicDictate;
        private Button btnVoiceMute;
        private TextBox txtInlineDictate;
        private Button btnInlineDictateRun;
        private bool isDictatingActive = false;
        private bool suppressInlineDictateEvent = false;
        private System.Windows.Forms.Timer dictateAutoExecTimer;
        private Button btnVoiceCommand;
        private Button btnSystemRestore;
        private Button btnMachineDemo;
        private CanliMakineEkranPanel stepBox;
        private Label lblActiveStepTitle;
        private Label lblActiveStepDesc;
        private Label lblFrameStatus;
        private Label lblStepsList;
        private Button btnNextStep;
        private Button btnDoneClose;

        private RenkliCerceveForm frameOverlay;
        private NotifyIcon trayIcon;
        private EventWaitHandle showEvent;
        private System.Windows.Forms.Timer monitorTimer;
        private System.Windows.Forms.Timer animTimer;

        private bool isCompactMode = false;
        private bool isLightTheme = true;
        private Button activeSpinningTile = null;
        private string activeSpinningTileBaseText = "";
        private int spinTickCount = 0;

        private string currentTrackedScreen = "";
        private string lastAutoClosedScreen = "";
        private List<GuidedStep> currentSteps = new List<GuidedStep>();
        private int currentStepIdx = 0;
        private int completionCountdown = 0;
        private int statusMessageHoldTicks = 0;
        private int binaryCheckCounter = 0;
        private string pendingStartupMenu = "";
        private bool startupMenuTriggered = false;
        private bool hiddenByPosShield = false;
        private MerkezSalesSummary currentSalesSummary = null;
        private bool isRefreshingSales = false;
        private bool isOpeningScreenBusy = false;

        public RehberKontrolMerkezi(string initialMenu)
        {
            pendingStartupMenu = initialMenu ?? "";
            tileDefs = BuildDefaultTileDefs();
            LoadCustomTileDefs();
            InitializeGuideWindow();
            InitializeTrayAndShowSignal();
            LoadCachedTodayMerkezSalesSummary();
            UpdateMerkezSalesBannerUI();

            frameOverlay = new RenkliCerceveForm();
            monitorTimer = new System.Windows.Forms.Timer();
            monitorTimer.Interval = 250;
            monitorTimer.Tick += OnMonitorTick;
            monitorTimer.Start();

            animTimer = new System.Windows.Forms.Timer();
            animTimer.Interval = 55;
            animTimer.Tick += delegate
            {
                if (stepBox != null && Visible && !isCompactMode)
                {
                    stepBox.StepAnimationNow();
                }
            };
            animTimer.Start();

            if (stepBox != null)
            {
                stepBox.CheckRdpBridgeTelemetry(true);
            }

            SesliAsistan.YukleAyar();
            GuncelleSesliButonGorunumu();
            if (SesliAsistan.Aktif)
            {
                SesliAsistan.Konus("Sesli Ajan hazır. " + Sube.Ad + " şubesi canlı makine ekranı aktif.", false);
            }

            GuncellemeHaberi();
        }

        private void InitializeTrayAndShowSignal()
        {
            try
            {
                Icon appIcon = SystemIcons.Application;
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sesli-ajan.ico");
                if (!File.Exists(icoPath)) icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pm-mahmutbey.ico");
                if (!File.Exists(icoPath)) icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "asistan.ico");
                if (File.Exists(icoPath))
                {
                    try
                    {
                        appIcon = new Icon(icoPath);
                        Icon = appIcon;
                    }
                    catch { }
                }

                ContextMenu trayMenu = new ContextMenu();
                trayMenu.MenuItems.Add("Göster (" + Sube.Ad + " - " + Sube.Kod + ")", delegate
                {
                    Show();
                    if (isCompactMode) ToggleCompactMode();
                    Activate();
                });
                trayMenu.MenuItems.Add("Ekran Ara (Ctrl+Boşluk)", delegate
                {
                    Show();
                    if (isCompactMode) ToggleCompactMode();
                    Activate();
                    if (cmbMenuSearch != null) { cmbMenuSearch.Focus(); cmbMenuSearch.SelectAll(); }
                });
                trayMenu.MenuItems.Add("Küçült / Aç", delegate { ToggleCompactMode(); });
                trayMenu.MenuItems.Add("-");
                MenuItem miSesToggle = new MenuItem(SesliAsistan.Aktif ? "🔊 Sesli Asistan: Açık (Kapatmak İçin Tıklayın)" : "🔇 Sesli Asistan: Kapalı (Açmak İçin Tıklayın)");
                miSesToggle.Click += delegate
                {
                    SesliAsistan.Aktif = !SesliAsistan.Aktif;
                    miSesToggle.Text = SesliAsistan.Aktif ? "🔊 Sesli Asistan: Açık (Kapatmak İçin Tıklayın)" : "🔇 Sesli Asistan: Kapalı (Açmak İçin Tıklayın)";
                    GuncelleSesliButonGorunumu();
                    if (!SesliAsistan.Aktif)
                    {
                        SesliAsistan.Durdur();
                    }
                };
                trayMenu.MenuItems.Add(miSesToggle);
                trayMenu.MenuItems.Add("📢 Bugünkü Ciroyu Sesli Oku", delegate { SesliCiroOku(); });
                trayMenu.MenuItems.Add("📖 Aktif Ekran ve Adımı Sesli Oku", delegate { SesliAdimOku(); });
                trayMenu.MenuItems.Add("🎤 Sesli Komut & Sesli Ajan Paneli...", delegate { SesliKomutDialog(); });
                trayMenu.MenuItems.Add("📚 Nebim Bilgi & Çözüm Kütüphanesi...", delegate { ShowKnowledgeAndSolutionLibraryDialog(""); });
                trayMenu.MenuItems.Add("-");
                trayMenu.MenuItems.Add("⬆ Güncelle (GitHub / Git)", delegate { GuncelleBaslat(); });
                trayMenu.MenuItems.Add("🛠️ Sistem Bütünlüğü Onar & Raporla (Restore)", delegate { RunSystemIntegrityRestoreAndReport(true); });
                trayMenu.MenuItems.Add("Şube Bilgisi (" + Sube.Kod + ")...", delegate { SubeDuzenleDialog(); });
                trayMenu.MenuItems.Add("Hakkında", delegate { HakkindaDialog(); });
                trayMenu.MenuItems.Add("-");
                trayMenu.MenuItems.Add("Çıkış", delegate
                {
                    if (trayIcon != null) trayIcon.Visible = false;
                    Application.Exit();
                });

                ContextMenu = trayMenu;

                trayIcon = new NotifyIcon
                {
                    Text = "Sesli Ajan · Nebim Asistanı — " + Sube.Ad + " (" + Sube.Kod + ")",
                    Icon = appIcon,
                    ContextMenu = trayMenu,
                    Visible = true
                };
                trayIcon.DoubleClick += delegate
                {
                    Show();
                    if (isCompactMode) ToggleCompactMode();
                    Activate();
                };
            }
            catch { }

            try
            {
                showEvent = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\NebimAssistantShowV1");
            }
            catch { }
        }

        private bool githubCheckStarted = false;
        private void GuncellemeHaberi()
        {
            try
            {
                string f = Path.Combine(ServiceRoot, "state", "guncelleme.json");
                if (File.Exists(f))
                {
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    Dictionary<string, object> d = js.Deserialize<Dictionary<string, object>>(File.ReadAllText(f, Encoding.UTF8).TrimStart('\uFEFF'));
                    object v;
                    if (d != null && d.TryGetValue("var", out v) && v is bool && (bool)v)
                    {
                        string yeni = d.ContainsKey("yeni") ? Convert.ToString(d["yeni"]) : "";
                        string msg = "⬆ GitHub'da yeni sürüm var (" + yeni + "). Tepsi menüsünden veya üst çubuktan Güncelle'yi seçin.";
                        if (lblFrameStatus != null) { lblFrameStatus.Text = msg; statusMessageHoldTicks = 40; }
                        if (trayIcon != null)
                        {
                            trayIcon.ShowBalloonTip(6000, "Sesli Ajan · Nebim Asistanı", "GitHub'da yeni sürüm var (" + yeni + "). Simgeye sağ tıklayıp Güncelle'yi seçin.", ToolTipIcon.Info);
                        }
                        return;
                    }
                }
                if (!githubCheckStarted)
                {
                    githubCheckStarted = true;
                    string gps = Path.Combine(ServiceRoot, "guncelle.ps1");
                    if (File.Exists(gps))
                    {
                        ThreadPool.QueueUserWorkItem(delegate
                        {
                            try
                            {
                                ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + gps + "\" -Kontrol")
                                {
                                    WorkingDirectory = ServiceRoot,
                                    UseShellExecute = false,
                                    CreateNoWindow = true
                                };
                                using (Process p = Process.Start(psi))
                                {
                                    if (p != null) p.WaitForExit(15000);
                                }
                                Thread.Sleep(500);
                                if (!IsDisposed && IsHandleCreated)
                                {
                                    BeginInvoke(new Action(delegate { GuncellemeHaberi(); }));
                                }
                            }
                            catch { }
                        });
                    }
                }
            }
            catch { }
        }

        private void GuncelleBaslat()
        {
            try
            {
                Show();
                if (isCompactMode) ToggleCompactMode();
                Activate();

                string subeGuncelle = Path.Combine(ServiceRoot, "GUNCELLE.cmd");
                string mahmutbeyKur = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "9-KARO-KUR.cmd");
                string hedef = File.Exists(subeGuncelle) ? subeGuncelle : (File.Exists(mahmutbeyKur) ? mahmutbeyKur : null);
                if (hedef == null)
                {
                    MessageBox.Show(this, "Güncelleme betiği (GUNCELLE.cmd) bulunamadı.", "Nebim Asistanı · Güncelle", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult dr = MessageBox.Show(
                    this,
                    "Asistan GitHub / Git deposu üzerinden güncellenecek.\n\nKurulum sırasında birkaç saniye kapanıp yeniden açılır; şube ve karo ayarlarınız korunur, Nebim'e hiçbir şey yazılmaz.\n\nDevam edilsin mi?",
                    "Sesli Ajan · Nebim Asistanı Güncelle",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (dr != DialogResult.Yes) return;

                ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c \"" + hedef + "\"")
                {
                    WorkingDirectory = Path.GetDirectoryName(hedef),
                    UseShellExecute = true
                };
                Process.Start(psi);
                string msg = "⟳ Güncelleme penceresi açıldı. Tamamlanınca asistan otomatik yeniden başlar.";
                if (lblFrameStatus != null) { lblFrameStatus.Text = msg; statusMessageHoldTicks = 40; }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Güncelleme başlatılamadı: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HakkindaDialog()
        {
            string surum = "v6.0";
            try
            {
                string sj = Path.Combine(ServiceRoot, "surum.json");
                if (File.Exists(sj))
                {
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    Dictionary<string, object> d = js.Deserialize<Dictionary<string, object>>(File.ReadAllText(sj, Encoding.UTF8).TrimStart('\uFEFF'));
                    if (d != null && d.ContainsKey("surum")) surum = "v6.0 · Paket " + Convert.ToString(d["surum"]);
                }
            }
            catch { }
            MessageBox.Show(
                this,
                "Sesli Ajan — Nebim Asistanı (" + surum + ")\nCanlı Makine Ekranlı Yol Gösterici, Sesli Asistan (Türkçe TTS + Sesli Komut) & 9 Karolu Şube Asistanı\n\nTasarım ve geliştirme: Ahmet Aksoy\nCopyright © 2026 Ahmet Aksoy. Tüm hakları saklıdır.\n\nŞube: " + Sube.Ad + " (" + Sube.Kod + ")\nSes Motoru: " + SesliAsistan.SeciliSesAdi + " (" + (SesliAsistan.Aktif ? "Açık" : "Kapalı") + ")",
                "Hakkında · Sesli Ajan",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void GuncelleSesliButonGorunumu()
        {
            if (btnVoice != null)
            {
                btnVoice.Text = SesliAsistan.Aktif ? "🔊 Sesli" : "🔇 Sessiz";
                btnVoice.BackColor = SesliAsistan.Aktif ? Color.FromArgb(18, 148, 78) : Color.FromArgb(175, 42, 48);
                btnVoice.Invalidate();
            }
            if (btnVoiceMute != null)
            {
                btnVoiceMute.BackColor = SesliAsistan.Aktif ? Color.FromArgb(18, 148, 78) : Color.FromArgb(175, 42, 48);
                btnVoiceMute.Invalidate();
            }
            if (btnMicDictate != null)
            {
                btnMicDictate.BackColor = isDictatingActive ? Color.FromArgb(235, 32, 32) : Color.FromArgb(215, 22, 85);
                btnMicDictate.Invalidate();
            }
            if (btnVoiceCommand != null)
            {
                btnVoiceCommand.Text = "📢 Ciro / Adım Oku";
                btnVoiceCommand.BackColor = Color.FromArgb(0, 132, 195);
            }
        }

        private static void PaintCustomMicrophoneButton(Control ctrl, PaintEventArgs pe, bool isListening, string topLine, string bottomLine)
        {
            Graphics g = pe.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Color bg = isListening ? Color.FromArgb(235, 30, 30) : Color.FromArgb(215, 22, 85);
            using (SolidBrush bgBr = new SolidBrush(bg))
            {
                g.FillRectangle(bgBr, 0, 0, ctrl.Width, ctrl.Height);
            }

            // Sol tarafta çok farkedilir parlak yuvarlak mikrofon rozeti
            int badgeSize = Math.Min(30, ctrl.Height - 6);
            int bx = 6;
            int by = (ctrl.Height - badgeSize) / 2;

            using (SolidBrush badgeFill = new SolidBrush(isListening ? Color.FromArgb(255, 240, 120) : Color.White))
            {
                g.FillEllipse(badgeFill, bx, by, badgeSize, badgeSize);
            }
            using (Pen ringPen = new Pen(Color.FromArgb(255, 205, 55), 2.0f))
            {
                g.DrawEllipse(ringPen, bx, by, badgeSize, badgeSize);
            }

            // Rozet içinde vektörel Mikrofon kapsülü + gövdesi + ses dalgaları
            int cx = bx + badgeSize / 2;
            int cy = by + badgeSize / 2;
            Color micCol = isListening ? Color.FromArgb(210, 15, 15) : Color.FromArgb(195, 14, 72);
            using (SolidBrush micBr = new SolidBrush(micCol))
            using (Pen micPen = new Pen(micCol, 2.1f))
            using (Pen wavePen = new Pen(Color.FromArgb(255, 125, 0), 1.5f))
            {
                g.FillEllipse(micBr, cx - 4, cy - 10, 8, 6);
                g.FillRectangle(micBr, cx - 4, cy - 7, 8, 7);
                g.FillEllipse(micBr, cx - 4, cy - 3, 8, 6);

                using (Pen grillePen = new Pen(Color.White, 1.0f))
                {
                    g.DrawLine(grillePen, cx - 2, cy - 6, cx + 2, cy - 6);
                    g.DrawLine(grillePen, cx - 2, cy - 3, cx + 2, cy - 3);
                }

                g.DrawArc(micPen, cx - 7, cy - 6, 14, 12, 0, 180);
                g.DrawLine(micPen, cx, cy + 6, cx, cy + 10);
                g.DrawLine(micPen, cx - 5, cy + 10, cx + 5, cy + 10);

                g.DrawArc(wavePen, cx - 11, cy - 8, 6, 10, 115, 130);
                g.DrawArc(wavePen, cx + 5, cy - 8, 6, 10, -65, 130);
            }

            int tx = bx + badgeSize + 5;
            using (Font fTop = new Font("Segoe UI", 9.0f, FontStyle.Bold))
            using (Font fBot = new Font("Segoe UI", 7.3f, FontStyle.Bold))
            using (SolidBrush topBr = new SolidBrush(Color.White))
            using (SolidBrush botBr = new SolidBrush(Color.FromArgb(255, 235, 150)))
            {
                g.DrawString(topLine, fTop, topBr, new PointF(tx, 3));
                g.DrawString(bottomLine, fBot, botBr, new PointF(tx, 19));
            }

            int w = ctrl.Width - 1;
            int h = ctrl.Height - 1;
            using (Pen light = new Pen(Color.FromArgb(170, 255, 235, 160), 1))
            using (Pen dark = new Pen(Color.FromArgb(170, 0, 0, 0), 1))
            {
                for (int i = 0; i < 2; i++)
                {
                    g.DrawLine(light, i, i, w - i, i);
                    g.DrawLine(light, i, i, i, h - i);
                    g.DrawLine(dark, i, h - i, w - i, h - i);
                    g.DrawLine(dark, w - i, i, w - i, h - i);
                }
            }
        }

        private static void PaintCustomSpeakerMuteButton(Control ctrl, PaintEventArgs pe, bool isVoiceOn, string topLine, string bottomLine)
        {
            Graphics g = pe.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            Color bg = isVoiceOn ? Color.FromArgb(18, 148, 78) : Color.FromArgb(175, 42, 48);
            using (SolidBrush bgBr = new SolidBrush(bg))
            {
                g.FillRectangle(bgBr, 0, 0, ctrl.Width, ctrl.Height);
            }

            int badgeSize = Math.Min(28, ctrl.Height - 8);
            int bx = 5;
            int by = (ctrl.Height - badgeSize) / 2;

            using (SolidBrush badgeFill = new SolidBrush(Color.FromArgb(45, 255, 255, 255)))
            using (Pen ringPen = new Pen(Color.FromArgb(190, 255, 255, 255), 1.5f))
            {
                g.FillEllipse(badgeFill, bx, by, badgeSize, badgeSize);
                g.DrawEllipse(ringPen, bx, by, badgeSize, badgeSize);
            }

            int cx = bx + badgeSize / 2;
            int cy = by + badgeSize / 2;
            Point[] cone = new Point[]
            {
                new Point(cx - 8, cy - 3),
                new Point(cx - 4, cy - 3),
                new Point(cx + 1, cy - 8),
                new Point(cx + 1, cy + 8),
                new Point(cx - 4, cy + 3),
                new Point(cx - 8, cy + 3)
            };
            using (SolidBrush whiteBr = new SolidBrush(Color.White))
            {
                g.FillPolygon(whiteBr, cone);
            }

            if (isVoiceOn)
            {
                using (Pen wavePen = new Pen(Color.FromArgb(255, 240, 130), 1.8f))
                {
                    g.DrawArc(wavePen, cx - 1, cy - 5, 7, 10, -55, 110);
                    g.DrawArc(wavePen, cx + 1, cy - 8, 9, 16, -55, 110);
                }
            }
            else
            {
                using (Pen mutePen = new Pen(Color.FromArgb(255, 230, 90), 2.2f))
                {
                    g.DrawLine(mutePen, cx + 3, cy - 4, cx + 9, cy + 4);
                    g.DrawLine(mutePen, cx + 9, cy - 4, cx + 3, cy + 4);
                }
            }

            int tx = bx + badgeSize + 5;
            using (Font fTop = new Font("Segoe UI", 9.0f, FontStyle.Bold))
            using (Font fBot = new Font("Segoe UI", 7.2f, FontStyle.Bold))
            using (SolidBrush topBr = new SolidBrush(Color.White))
            using (SolidBrush botBr = new SolidBrush(Color.FromArgb(230, 245, 235)))
            {
                g.DrawString(topLine, fTop, topBr, new PointF(tx, 3));
                g.DrawString(bottomLine, fBot, botBr, new PointF(tx, 19));
            }

            int w = ctrl.Width - 1;
            int h = ctrl.Height - 1;
            using (Pen light = new Pen(Color.FromArgb(140, 255, 255, 255), 1))
            using (Pen dark = new Pen(Color.FromArgb(160, 0, 0, 0), 1))
            {
                for (int i = 0; i < 2; i++)
                {
                    g.DrawLine(light, i, i, w - i, i);
                    g.DrawLine(light, i, i, i, h - i);
                    g.DrawLine(dark, i, h - i, w - i, h - i);
                    g.DrawLine(dark, w - i, i, w - i, h - i);
                }
            }
        }

        private void ToggleVoiceMuteDirect()
        {
            SesliAsistan.Aktif = !SesliAsistan.Aktif;
            if (!SesliAsistan.Aktif)
            {
                SesliAsistan.Durdur();
            }
            GuncelleSesliButonGorunumu();
            if (lblFrameStatus != null)
            {
                lblFrameStatus.Text = SesliAsistan.Aktif
                    ? "🔊 Sesli Mod AÇIK: İstediğinizde Ciro Oku / Adım Oku ile sesli dinleyebilirsiniz."
                    : "🔇 SESSİZ Mod AÇIK: Tüm sesli konuşmalar susturuldu.";
                lblFrameStatus.ForeColor = SesliAsistan.Aktif ? ThemeOkColor() : ThemeWarnColor();
                statusMessageHoldTicks = 18;
            }
        }

        private void StartDirectDictation()
        {
            Show();
            if (isCompactMode) ToggleCompactMode();
            Activate();

            isDictatingActive = true;
            GuncelleSesliButonGorunumu();

            if (txtInlineDictate != null)
            {
                suppressInlineDictateEvent = true;
                txtInlineDictate.Text = "";
                suppressInlineDictateEvent = false;
                txtInlineDictate.Focus();
            }

            if (lblFrameStatus != null)
            {
                lblFrameStatus.Text = "🎤 MİKROFON AÇIK: Komutunuzu söyleyin (örn: ciro oku, sipariş ver, sayım fişi)...";
                lblFrameStatus.ForeColor = Color.FromArgb(255, 215, 70);
                statusMessageHoldTicks = 30;
            }

            ThreadPool.QueueUserWorkItem(delegate
            {
                Thread.Sleep(180);
                try
                {
                    SendKeyDownUp(0x5B, false);
                    PressKey(0x48);
                    SendKeyDownUp(0x5B, true);
                }
                catch { }
            });
        }

        private void ExecuteInlineDictation()
        {
            if (dictateAutoExecTimer != null) dictateAutoExecTimer.Stop();
            isDictatingActive = false;
            GuncelleSesliButonGorunumu();

            string cmdText = (txtInlineDictate != null ? txtInlineDictate.Text : "").Trim();
            if (cmdText.Length < 2)
            {
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "🎤 Mikrofonla konuşmak için MİKROFON butonuna basın veya kutuya komut yazın.";
                    statusMessageHoldTicks = 14;
                }
                return;
            }
            SesliKomutCalistir(cmdText);
        }

        private void SesliCiroOku()
        {
            CultureInfo trK = new CultureInfo("tr-TR");
            if (currentSalesSummary != null && currentSalesSummary.ok)
            {
                string metin = currentSalesSummary.hasSales
                    ? (Sube.Ad + " şubesi bugünkü net satış: " + currentSalesSummary.netSales.ToString("N0", trK) + " TL. Toplam " + currentSalesSummary.transactionCount + " işlem ve " + currentSalesSummary.itemQuantity.ToString("N0", trK) + " adet ürün.")
                    : (Sube.Ad + " şubesinde bugün henüz satış kaydı bulunmuyor.");
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "🔊 Sesli Okunuyor: " + metin;
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 20;
                }
                SesliAsistan.Konus(metin, true);
            }
            else
            {
                string metin = Sube.Ad + " şubesi satış özeti henüz yenilenmedi. Şimdi yenileniyor.";
                SesliAsistan.Konus(metin, true);
                RefreshMerkezSalesSummary(true);
            }
        }

        private void SesliAdimOku()
        {
            string baslik = lblActiveStepTitle != null ? lblActiveStepTitle.Text : "";
            string aciklama = lblActiveStepDesc != null ? lblActiveStepDesc.Text : "";
            string durum = lblFrameStatus != null ? lblFrameStatus.Text : "";
            string birlesik = (baslik + ". " + aciklama).Trim();
            if (birlesik.Length < 4) birlesik = durum;
            if (birlesik.Length < 4) birlesik = Sube.Ad + " şubesi canlı makine ekranı hazır.";
            SesliAsistan.Konus(birlesik, true);
        }

        private void SesliKomutCalistir(string rawKomut)
        {
            string k = NormTr(rawKomut ?? "").Trim();
            if (k.Length < 2) return;

            LogLine("[SESLİ-KOMUT] Algılanan komut: '" + rawKomut + "' (norm: '" + k + "')");

            if (k.Contains("sessiz") || k.Contains("sustur") || k.Contains("sesi kapat"))
            {
                SesliAsistan.Aktif = false;
                SesliAsistan.Durdur();
                GuncelleSesliButonGorunumu();
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "🔇 Sessiz moda geçildi.";
                    statusMessageHoldTicks = 16;
                }
                return;
            }
            if (k == "sesli" || k.Contains("sesi ac") || k.Contains("sesli ac"))
            {
                SesliAsistan.Aktif = true;
                GuncelleSesliButonGorunumu();
                SesliAsistan.Konus("Sesli mod açıldı.", true);
                return;
            }
            if (k.Contains("ciro") || k.Contains("satis ozet") || k.Contains("ne kadar") || k.Contains("kasa"))
            {
                SesliCiroOku();
                return;
            }
            if (k.Contains("yenile"))
            {
                SesliAsistan.Konus(Sube.Ad + " mağaza satış özeti yenileniyor.", true);
                RefreshMerkezSalesSummary(true);
                return;
            }
            if (k.Contains("adim") || k.Contains("rehber") || k.Contains("oku"))
            {
                SesliAdimOku();
                return;
            }
            if (k.Contains("sonraki"))
            {
                AdvanceToNextStepManual();
                SesliAdimOku();
                return;
            }
            if (k.Contains("onar") || k.Contains("temizle") || k.Contains("restore"))
            {
                SesliAsistan.Konus("Sistem bütünlüğü onarımı başlatılıyor.", true);
                RunSystemIntegrityRestoreAndReport(true);
                return;
            }
            if (k.Contains("guncelle"))
            {
                SesliAsistan.Konus("GitHub güncelleme kontrolü başlatılıyor.", true);
                GuncelleBaslat();
                return;
            }
            if (k.Contains("kapat") || k.Contains("gizle") || k.Contains("iptal") || k == "dur")
            {
                if (dictateAutoExecTimer != null) dictateAutoExecTimer.Stop();
                isDictatingActive = false;
                GuncelleSesliButonGorunumu();
                CompleteAndAutoHideCurrentScreen();
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "✓ Çerçeve gizlendi ve dikte durduruldu.";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 16;
                }
                return;
            }
            if (k.Contains("cozum") || k.Contains("kutuphane") || k.Contains("akademi") || k.Contains("baglanti ihlali") || k.Contains("nasil yapilir"))
            {
                SesliAsistan.Konus("Nebim Bilgi ve Çözüm Kütüphanesi açılıyor.", true);
                ShowKnowledgeAndSolutionLibraryDialog(rawKomut);
                return;
            }
            if (k.Contains("test") || k.Contains("demo"))
            {
                SesliAsistan.Konus("Canlı makine ekranı testi başlatılıyor.", true);
                if (stepBox != null) stepBox.StartLiveDemoSequence(lblScreenTitle);
                return;
            }

            if (tileDefs != null)
            {
                for (int i = 0; i < tileDefs.Length; i++)
                {
                    string tn = NormTr(tileDefs[i].title);
                    string pm = NormTr(tileDefs[i].primaryMenu);
                    if (k.Contains(tn) || tn.Contains(k) || k.Contains(pm))
                    {
                        Button b = (quickTileButtons != null && i < quickTileButtons.Count) ? quickTileButtons[i] : null;
                        SesliAsistan.Konus(tileDefs[i].title + " ekranı açılıyor.", true);
                        OpenTileMenu(tileDefs[i].title, tileDefs[i].primaryMenu, tileDefs[i].fallbackMenu, tileDefs[i].sira, b);
                        return;
                    }
                }
            }

            AtlasItem voiceMatched;
            ResolveBestMenuQuery(rawKomut.Trim(), out voiceMatched);
            if (voiceMatched == null && k.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length >= 4)
            {
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "🎤 '" + rawKomut.Trim() + "' için eşleşen mağaza ekranı bulunamadı. Lütfen ekran adını söyleyin (Örn: Satış Sorumlusu, Ürün Sorgula).";
                    lblFrameStatus.ForeColor = ThemeWarnColor();
                    statusMessageHoldTicks = 18;
                }
                return;
            }

            SesliAsistan.Konus(rawKomut + " ekranı aranıyor ve açılıyor.", true);
            suppressQuickSearchEvents = true;
            cmbMenuSearch.Text = rawKomut.Trim();
            suppressQuickSearchEvents = false;
            TriggerAutoOpenSelectedMenu(true);
        }

        private void SesliKomutDialog()
        {
            Show();
            if (isCompactMode) ToggleCompactMode();
            Activate();

            using (Form f = new Form
            {
                Text = "🎤 Sesli Ajan — Mikrofon (Dikte) & Sesli/Sessiz Kontrol Merkezi (" + Sube.Kod + ")",
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                ClientSize = new Size(440, 315),
                BackColor = Color.FromArgb(20, 28, 42),
                ForeColor = Color.White,
                MaximizeBox = false,
                MinimizeBox = false,
                TopMost = true
            })
            {
                Label lblHdr = new Label
                {
                    Text = "🔊 SESLİ AJAN KONTROL MERKEZİ (" + Sube.Ad + " - " + Sube.Kod + ")",
                    Font = new Font("Segoe UI", 10.0f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(255, 200, 70),
                    Left = 14,
                    Top = 12,
                    Width = 412,
                    Height = 22
                };

                Label lblVoiceInfo = new Label
                {
                    Text = "Aktif Türkçe Ses Motoru: " + SesliAsistan.SeciliSesAdi + "  |  Durum: " + (SesliAsistan.Aktif ? "SESLİ 🔊" : "SESSİZ 🔇"),
                    Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(130, 235, 170),
                    Left = 14,
                    Top = 36,
                    Width = 412,
                    Height = 20
                };

                Button btnReadCiro = new Button
                {
                    Text = "📢 Bugünkü Ciroyu Sesli Oku",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(255, 140, 0),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Left = 14,
                    Top = 62,
                    Width = 200,
                    Height = 36,
                    Cursor = Cursors.Hand
                };
                btnReadCiro.FlatAppearance.BorderSize = 0;
                btnReadCiro.Click += delegate { SesliCiroOku(); };

                Button btnReadStep = new Button
                {
                    Text = "📖 Aktif Adımı Sesli Oku",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(0, 122, 230),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Left = 224,
                    Top = 62,
                    Width = 202,
                    Height = 36,
                    Cursor = Cursors.Hand
                };
                btnReadStep.FlatAppearance.BorderSize = 0;
                btnReadStep.Click += delegate { SesliAdimOku(); };

                bool dlgListening = false;
                Button btnMicWinH = new Button
                {
                    Text = "",
                    FlatStyle = FlatStyle.Flat,
                    Left = 14,
                    Top = 104,
                    Width = 200,
                    Height = 40,
                    Cursor = Cursors.Hand
                };
                btnMicWinH.FlatAppearance.BorderSize = 0;
                btnMicWinH.Paint += delegate(object s, PaintEventArgs pe)
                {
                    PaintCustomMicrophoneButton(
                        btnMicWinH,
                        pe,
                        dlgListening,
                        dlgListening ? "DİNLENİYOR..." : "MİKROFONU AÇ",
                        "Sesle Komut / Dikte (Win+H)");
                };

                Button btnToggleVoice = new Button
                {
                    Text = "",
                    FlatStyle = FlatStyle.Flat,
                    Left = 224,
                    Top = 104,
                    Width = 202,
                    Height = 40,
                    Cursor = Cursors.Hand
                };
                btnToggleVoice.FlatAppearance.BorderSize = 0;
                btnToggleVoice.Paint += delegate(object s, PaintEventArgs pe)
                {
                    PaintCustomSpeakerMuteButton(
                        btnToggleVoice,
                        pe,
                        SesliAsistan.Aktif,
                        SesliAsistan.Aktif ? "SESLİ AÇIK" : "SESSİZ (KAPALI)",
                        SesliAsistan.Aktif ? "Tıkla → Sessize Al" : "Tıkla → Sesliyi Aç");
                };
                btnToggleVoice.Click += delegate
                {
                    ToggleVoiceMuteDirect();
                    btnToggleVoice.Invalidate();
                    lblVoiceInfo.Text = "Aktif Türkçe Ses Motoru: " + SesliAsistan.SeciliSesAdi + "  |  Durum: " + (SesliAsistan.Aktif ? "SESLİ 🔊" : "SESSİZ 🔇");
                };

                Label lblCmdHint = new Label
                {
                    Text = "🎤 Mikrofon butonuna basıp konuşun veya aşağıya komut yazın:\nÖrnek: \"ciro oku\", \"sayım fişi\", \"sipariş ver\", \"masraf ekle\", \"gelen ürünleri onayla\", \"yenile\"",
                    Font = new Font("Segoe UI", 8.2f),
                    ForeColor = Color.FromArgb(200, 215, 235),
                    Left = 14,
                    Top = 152,
                    Width = 412,
                    Height = 36
                };

                TextBox txtCmd = new TextBox
                {
                    Font = new Font("Segoe UI", 10.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(32, 42, 60),
                    ForeColor = Color.White,
                    Left = 14,
                    Top = 192,
                    Width = 296,
                    Height = 28
                };

                Button btnExecCmd = new Button
                {
                    Text = "▶ Çalıştır",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(30, 155, 75),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Left = 316,
                    Top = 191,
                    Width = 110,
                    Height = 28,
                    Cursor = Cursors.Hand
                };
                btnExecCmd.FlatAppearance.BorderSize = 0;

                btnMicWinH.Click += delegate
                {
                    dlgListening = true;
                    btnMicWinH.Invalidate();
                    txtCmd.Focus();
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        Thread.Sleep(220);
                        try
                        {
                            SendKeyDownUp(0x5B, false);
                            PressKey(0x48);
                            SendKeyDownUp(0x5B, true);
                        }
                        catch { }
                    });
                };

                btnExecCmd.Click += delegate
                {
                    string cmdText = (txtCmd.Text ?? "").Trim();
                    if (cmdText.Length < 2)
                    {
                        SesliAsistan.Konus("Lütfen bir komut söyleyin veya yazın.", true);
                        return;
                    }
                    f.Close();
                    SesliKomutCalistir(cmdText);
                };

                string[] hizliKomutlar = new string[] { "Ciro Oku", "Stok Sayımı Yap", "Sipariş Ver", "Gelen Ürünleri Onayla", "Ürün İade Al" };
                int bx = 14;
                for (int i = 0; i < hizliKomutlar.Length; i++)
                {
                    string hk = hizliKomutlar[i];
                    Button bQuick = new Button
                    {
                        Text = hk,
                        Font = new Font("Segoe UI", 7.6f, FontStyle.Bold),
                        BackColor = Color.FromArgb(42, 58, 84),
                        ForeColor = Color.FromArgb(220, 235, 255),
                        FlatStyle = FlatStyle.Flat,
                        Left = bx,
                        Top = 228,
                        Width = 80,
                        Height = 26,
                        Cursor = Cursors.Hand
                    };
                    bQuick.FlatAppearance.BorderSize = 0;
                    bQuick.Click += delegate
                    {
                        f.Close();
                        SesliKomutCalistir(hk);
                    };
                    f.Controls.Add(bQuick);
                    bx += 83;
                }

                Button btnClose = new Button
                {
                    Text = "Kapat",
                    Font = new Font("Segoe UI", 8.8f, FontStyle.Bold),
                    BackColor = Color.FromArgb(80, 90, 108),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Left = 336,
                    Top = 266,
                    Width = 90,
                    Height = 30,
                    DialogResult = DialogResult.Cancel
                };
                btnClose.FlatAppearance.BorderSize = 0;

                f.Controls.AddRange(new Control[] { lblHdr, lblVoiceInfo, btnReadCiro, btnReadStep, btnMicWinH, btnToggleVoice, lblCmdHint, txtCmd, btnExecCmd, btnClose });
                f.AcceptButton = btnExecCmd;
                f.CancelButton = btnClose;
                f.Shown += delegate { txtCmd.Focus(); };
                f.ShowDialog(this);
            }
        }

        private void SubeDuzenleDialog()
        {
            using (Form f = new Form
            {
                Text = "Şube Bilgisi — Nebim Asistanı",
                FormBorderStyle = FormBorderStyle.FixedDialog,
                StartPosition = FormStartPosition.CenterParent,
                ClientSize = new Size(340, 155),
                MaximizeBox = false,
                MinimizeBox = false,
                TopMost = true
            })
            {
                Label l1 = new Label { Text = "Şube kodu (örn. PM3401):", Left = 12, Top = 14, Width = 150 };
                TextBox t1 = new TextBox { Text = Sube.Kod, Left = 166, Top = 11, Width = 158 };
                Label l2 = new Label { Text = "Şube adı (örn. Mahmutbey):", Left = 12, Top = 48, Width = 150 };
                TextBox t2 = new TextBox { Text = Sube.Ad, Left = 166, Top = 45, Width = 158 };
                Label info = new Label { Text = "", ForeColor = Color.Firebrick, Left = 12, Top = 78, Width = 312, Height = 32 };
                Button ok = new Button { Text = "Kaydet", Left = 166, Top = 115, Width = 75 };
                Button vazgec = new Button { Text = "Vazgeç", Left = 249, Top = 115, Width = 75, DialogResult = DialogResult.Cancel };
                ok.Click += delegate
                {
                    string err = SubeAyar.Save(SubeDosyasi, t1.Text, t2.Text, Sube);
                    if (err != null) { info.Text = err; return; }
                    Sube = SubeAyar.Load(SubeDosyasi);
                    Text = "Nebim Asistanı — " + Sube.Ad + " Şubesi (" + Sube.Kod + ") · Canlı Yol Gösterici (v6.0)";
                    if (trayIcon != null) trayIcon.Text = "Nebim Asistanı — " + Sube.Ad + " (" + Sube.Kod + ")";
                    UpdateMerkezSalesBannerUI();
                    ReconnectAndRefreshErpState();
                    f.DialogResult = DialogResult.OK;
                    f.Close();
                };
                f.Controls.AddRange(new Control[] { l1, t1, l2, t2, info, ok, vazgec });
                f.AcceptButton = ok;
                f.CancelButton = vazgec;
                f.ShowDialog(this);
            }
        }

        private static QuickTileDef[] BuildDefaultTileDefs()
        {
            // Mahmutbey Şubesi (PM3401) 9 Mağaza Hızlı Erişim Karosu (ekranlar.json mağaza kataloğu ile birebir uyumlu)
            return new QuickTileDef[]
            {
                new QuickTileDef("Sipariş Ver", "Verilen Siparişler", "Merkeze Eksik Ürün Siparişi", 1, Color.FromArgb(46, 170, 40)),
                new QuickTileDef("Masraf Ekle", "Mağaza Masraf Girişi", "Mağaza Masraf Girişi", 1, Color.FromArgb(232, 48, 48)),
                new QuickTileDef("Stok Sayımı Yap", "Mağaza Sayım Fişi", "Envanter ve Sayım Fark Raporu", 1, Color.FromArgb(0, 122, 230)),
                new QuickTileDef("Tüm Envanter", "Ürün Envanter Sorgula", "Ürün Envanter Raporu", 1, Color.FromArgb(255, 140, 0)),
                new QuickTileDef("Gelen Ürünleri Onayla", "Mağazaya Gelen İrsaliyeyi Onayla - Ürün Detaylı", "Mağazaya Gelen İrsaliyeyi Onayla - Fiş Bazında", 1, Color.FromArgb(0, 172, 150)),
                new QuickTileDef("Merkeze İadeler", "Merkeze İade", "Diğer Mağazaya Sevk", 1, Color.FromArgb(142, 60, 200)),
                new QuickTileDef("Şirkete Para Gönder", "Merkezin Banka Hesabına Nakit Çıkış", "Mağaza Hareket Özeti", 1, Color.FromArgb(20, 140, 50)),
                new QuickTileDef("Satış Sorumlusu", "Satış Sorumlusu", "Satış Sorumlusu", 4, Color.FromArgb(0, 160, 220)),
                new QuickTileDef("Ürün İade Al", "Perakende Satışlar Listesi", "Mağaza Hareket Özeti", 1, Color.FromArgb(224, 24, 110))
            };
        }

        private void LoadCustomTileDefs()
        {
            try
            {
                string path = Path.Combine(ResolveOutputDir(), "mahmutbey-karo-ayarlar.json");
                if (!File.Exists(path)) return;

                string[] lines = File.ReadAllLines(path, Encoding.UTF8);
                Regex rx = new Regex("\"idx\":(\\d+),\"title\":\"(.*?)\",\"primaryMenu\":\"(.*?)\",\"fallbackMenu\":\"(.*?)\",\"sira\":(\\d+),\"r\":(\\d+),\"g\":(\\d+),\"b\":(\\d+)");
                foreach (string line in lines)
                {
                    Match m = rx.Match(line);
                    if (!m.Success) continue;
                    int idx = int.Parse(m.Groups[1].Value);
                    if (idx < 0 || idx >= tileDefs.Length) continue;

                    string t = JsonUnescape(m.Groups[2].Value).Trim();
                    string pm = JsonUnescape(m.Groups[3].Value).Trim();
                    string fm = JsonUnescape(m.Groups[4].Value).Trim();
                    int sira = int.Parse(m.Groups[5].Value);
                    int r = Math.Max(0, Math.Min(255, int.Parse(m.Groups[6].Value)));
                    int g = Math.Max(0, Math.Min(255, int.Parse(m.Groups[7].Value)));
                    int b = Math.Max(0, Math.Min(255, int.Parse(m.Groups[8].Value)));

                    if (t.Length > 0 && pm.Length > 0)
                    {
                        tileDefs[idx].title = t;
                        tileDefs[idx].primaryMenu = pm;
                        tileDefs[idx].fallbackMenu = fm.Length > 0 ? fm : pm;
                        tileDefs[idx].sira = sira >= 1 ? sira : 1;
                        tileDefs[idx].color = Color.FromArgb(r, g, b);
                    }
                }
            }
            catch { }
        }

        private void SaveCustomTileDefs()
        {
            try
            {
                string path = Path.Combine(ResolveOutputDir(), "mahmutbey-karo-ayarlar.json");
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("{");
                sb.AppendLine("  \"subeKod\": \"" + JsonEscape(Sube.Kod) + "\",");
                sb.AppendLine("  \"subeAd\": \"" + JsonEscape(Sube.Ad) + "\",");
                sb.AppendLine("  \"guncelleme\": \"" + JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) + "\",");
                sb.AppendLine("  \"karolar\": [");
                for (int i = 0; i < tileDefs.Length; i++)
                {
                    QuickTileDef d = tileDefs[i];
                    string comma = (i + 1 < tileDefs.Length) ? "," : "";
                    sb.AppendLine("    {\"idx\":" + i +
                        ",\"title\":\"" + JsonEscape(d.title) +
                        "\",\"primaryMenu\":\"" + JsonEscape(d.primaryMenu) +
                        "\",\"fallbackMenu\":\"" + JsonEscape(d.fallbackMenu) +
                        "\",\"sira\":" + d.sira +
                        ",\"r\":" + d.color.R +
                        ",\"g\":" + d.color.G +
                        ",\"b\":" + d.color.B + "}" + comma);
                }
                sb.AppendLine("  ]");
                sb.AppendLine("}");
                AtomicWriteText(path, sb.ToString());
                LogLine("[MAHMUTBEY KARO-AYARLAR] Mağaza hızlı erişim karoları kaydedildi: " + path);
            }
            catch (Exception ex)
            {
                LogLine("[MAHMUTBEY KARO-AYARLAR] Kaydetme hatası: " + ex.Message);
            }
        }

        private static void Raise3D(Control ctrl, int depth)
        {
            ctrl.Paint += delegate(object s, PaintEventArgs pe)
            {
                Graphics g = pe.Graphics;
                int w = ctrl.Width - 1;
                int h = ctrl.Height - 1;
                using (Pen light = new Pen(Color.FromArgb(140, 255, 255, 255), 1))
                using (Pen dark = new Pen(Color.FromArgb(160, 0, 0, 0), 1))
                {
                    for (int i = 0; i < depth; i++)
                    {
                        g.DrawLine(light, i, i, w - i, i);
                        g.DrawLine(light, i, i, i, h - i);
                        g.DrawLine(dark, i, h - i, w - i, h - i);
                        g.DrawLine(dark, w - i, i, w - i, h - i);
                    }
                }
            };
        }

        private void StartTileSpinner(Button tileBtn)
        {
            StopTileSpinner();
            if (tileBtn == null) return;
            activeSpinningTile = tileBtn;
            activeSpinningTileBaseText = tileBtn.Text;
            spinTickCount = 12;
            tileBtn.Text = "⏳ " + activeSpinningTileBaseText + "\nAçılıyor...";
            Application.DoEvents();
        }

        private void StopTileSpinner()
        {
            if (activeSpinningTile != null)
            {
                try { activeSpinningTile.Text = activeSpinningTileBaseText; } catch { }
                activeSpinningTile = null;
                activeSpinningTileBaseText = "";
                spinTickCount = 0;
            }
        }

        private void InitializeGuideWindow()
        {
            Text = "Nebim Asistanı — " + Sube.Ad + " Şubesi (" + Sube.Kod + ") · Canlı Yol Gösterici (v6.0)";
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            ShowInTaskbar = true;
            TopMost = true;
            try
            {
                string icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sesli-ajan.ico");
                if (!File.Exists(icoPath)) icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pm-mahmutbey.ico");
                if (!File.Exists(icoPath)) icoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "asistan.ico");
                if (File.Exists(icoPath)) Icon = new Icon(icoPath);
                else Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
            }
            catch { }
            StartPosition = FormStartPosition.Manual;
            int maxInitH = Screen.PrimaryScreen.WorkingArea.Height - 40;
            Size = new Size(505, Math.Min(694, maxInitH));
            MinimumSize = new Size(420, 95);
            BackColor = Color.FromArgb(240, 240, 240);
            ForeColor = Color.FromArgb(30, 30, 30);
            DoubleBuffered = true;

            // Şube Asistanındaki 3px turuncu dış çerçeve
            Paint += delegate(object s, PaintEventArgs pe)
            {
                using (Pen orangePen = new Pen(Color.FromArgb(235, 150, 40), 3))
                {
                    pe.Graphics.DrawRectangle(orangePen, 1, 1, Width - 3, Height - 3);
                }
            };
            Resize += delegate { Invalidate(); };

            // Merkez Asistanı (sağ kenarda X = Right - 505 - 12) ile yan yana durması için hemen soluna konumlandır
            Rectangle workArea = Screen.PrimaryScreen.WorkingArea;
            int sideBySideX = Math.Max(10, workArea.Right - (Width * 2) - 24);
            int centerY = Math.Max(10, (workArea.Height - Height) / 2);
            Location = new Point(sideBySideX, centerY);

            // -----------------------------------------------------------------
            // 1. ÜST ARAÇ ÇUBUĞU (Durum Işığı | Küçült | Üstte | PM3401 Bağlı | Tema | Karo Ayarları)
            // -----------------------------------------------------------------
            toolbarPanel = new Panel();
            toolbarPanel.Location = new Point(10, 6);
            toolbarPanel.Size = new Size(470, 30);
            toolbarPanel.BackColor = Color.Transparent;
            Controls.Add(toolbarPanel);

            lblStatusDot = new Label();
            lblStatusDot.Size = new Size(16, 16);
            lblStatusDot.Location = new Point(2, 7);
            lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
            lblStatusDot.Paint += delegate(object s, PaintEventArgs pe)
            {
                Color dotCol = lblStatusDot.BackColor;
                pe.Graphics.Clear(BackColor);
                pe.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using (SolidBrush br = new SolidBrush(dotCol))
                {
                    pe.Graphics.FillEllipse(br, 1, 1, 13, 13);
                }
                using (Pen darkRing = new Pen(Color.FromArgb(90, 0, 0, 0), 1))
                {
                    pe.Graphics.DrawEllipse(darkRing, 1, 1, 13, 13);
                }
                using (SolidBrush shine = new SolidBrush(Color.FromArgb(160, 255, 255, 255)))
                {
                    pe.Graphics.FillEllipse(shine, 4, 3, 4, 4);
                }
            };
            toolbarPanel.Controls.Add(lblStatusDot);

            btnMini = new Button();
            btnMini.Tag = "tile";
            btnMini.Text = "Küçült";
            btnMini.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            btnMini.Location = new Point(22, 2);
            btnMini.Size = new Size(64, 26);
            btnMini.BackColor = Color.FromArgb(52, 78, 118);
            btnMini.ForeColor = Color.White;
            btnMini.FlatStyle = FlatStyle.Flat;
            btnMini.FlatAppearance.BorderSize = 0;
            btnMini.Cursor = Cursors.Hand;
            btnMini.Click += delegate { ToggleCompactMode(); };
            Raise3D(btnMini, 3);
            toolbarPanel.Controls.Add(btnMini);

            chkTopMost = new CheckBox();
            chkTopMost.Text = "Üstte";
            chkTopMost.Checked = true;
            chkTopMost.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            chkTopMost.Location = new Point(92, 4);
            chkTopMost.Size = new Size(62, 22);
            chkTopMost.CheckedChanged += delegate { TopMost = chkTopMost.Checked; };
            toolbarPanel.Controls.Add(chkTopMost);

            btnMcpStatus = new Button();
            btnMcpStatus.Tag = "tile";
            btnMcpStatus.Text = Sube.Kod + " · Açık";
            btnMcpStatus.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            btnMcpStatus.Location = new Point(156, 2);
            btnMcpStatus.Size = new Size(116, 26);
            btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
            btnMcpStatus.ForeColor = Color.White;
            btnMcpStatus.FlatStyle = FlatStyle.Flat;
            btnMcpStatus.FlatAppearance.BorderSize = 0;
            btnMcpStatus.Cursor = Cursors.Hand;
            btnMcpStatus.Click += delegate { ReconnectAndRefreshErpState(); };
            btnMcpStatus.MouseUp += delegate(object s, MouseEventArgs me)
            {
                if (me.Button == MouseButtons.Right) SubeDuzenleDialog();
            };
            Raise3D(btnMcpStatus, 3);
            toolbarPanel.Controls.Add(btnMcpStatus);

            btnTheme = new Button();
            btnTheme.Tag = "tile";
            btnTheme.Text = "Tema";
            btnTheme.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            btnTheme.Location = new Point(278, 2);
            btnTheme.Size = new Size(64, 26);
            btnTheme.BackColor = Color.FromArgb(128, 58, 186);
            btnTheme.ForeColor = Color.White;
            btnTheme.FlatStyle = FlatStyle.Flat;
            btnTheme.FlatAppearance.BorderSize = 0;
            btnTheme.Cursor = Cursors.Hand;
            btnTheme.Click += delegate
            {
                isLightTheme = !isLightTheme;
                ApplyCurrentTheme();
            };
            Raise3D(btnTheme, 3);
            toolbarPanel.Controls.Add(btnTheme);

            btnTileSettings = new Button();
            btnTileSettings.Tag = "tile";
            btnTileSettings.Text = "⚙ Karo Ayarları";
            btnTileSettings.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            btnTileSettings.Location = new Point(348, 2);
            btnTileSettings.Size = new Size(122, 26);
            btnTileSettings.BackColor = Color.FromArgb(255, 140, 0);
            btnTileSettings.ForeColor = Color.White;
            btnTileSettings.FlatStyle = FlatStyle.Flat;
            btnTileSettings.FlatAppearance.BorderSize = 0;
            btnTileSettings.Cursor = Cursors.Hand;
            btnTileSettings.Click += delegate { ToggleTileSettingsTab(editingTileIdx); };
            Raise3D(btnTileSettings, 3);
            toolbarPanel.Controls.Add(btnTileSettings);

            // -----------------------------------------------------------------
            // 2. TURUNCU MAĞAZA HAREKET ÖZETİ BANDI VE MAVİ YENİLE BUTONU
            //    (2 Satır: Mahmutbey PM3401 Satış Tutarı ve Mağaza İşlem Özeti)
            // -----------------------------------------------------------------
            lblLiveSummary = new Label();
            lblLiveSummary.Tag = "tile";
            lblLiveSummary.Location = new Point(10, 38);
            lblLiveSummary.Size = new Size(352, 54);
            lblLiveSummary.Font = new Font("Segoe UI", 8.6f, FontStyle.Bold);
            lblLiveSummary.BackColor = Color.FromArgb(255, 140, 0);
            lblLiveSummary.ForeColor = Color.White;
            lblLiveSummary.Padding = new Padding(8, 5, 6, 4);
            lblLiveSummary.Text = Sube.Ad + " (" + Sube.Kod + ") Satış: Yenile'ye Basın\nMağaza Özeti: 0 İşlem · 0 Adet";
            lblLiveSummary.Cursor = Cursors.Hand;
            lblLiveSummary.Click += delegate
            {
                RefreshMerkezSalesSummary(true);
            };
            Raise3D(lblLiveSummary, 2);
            Controls.Add(lblLiveSummary);

            btnLiveRefresh = new Button();
            btnLiveRefresh.Tag = "tile";
            btnLiveRefresh.Location = new Point(366, 38);
            btnLiveRefresh.Size = new Size(114, 54);
            btnLiveRefresh.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            btnLiveRefresh.BackColor = Color.FromArgb(0, 122, 230);
            btnLiveRefresh.ForeColor = Color.White;
            btnLiveRefresh.FlatStyle = FlatStyle.Flat;
            btnLiveRefresh.FlatAppearance.BorderSize = 0;
            btnLiveRefresh.Text = "⟳  Yenile";
            btnLiveRefresh.Cursor = Cursors.Hand;
            btnLiveRefresh.Click += delegate
            {
                RefreshMerkezSalesSummary(true);
            };
            Raise3D(btnLiveRefresh, 3);
            Controls.Add(btnLiveRefresh);

            // -----------------------------------------------------------------
            // 3. 3x3 MAĞAZA HIZLI ERİŞİM KAROLARI (Mahmutbey PM3401 — 9 Mağaza Karosu)
            // -----------------------------------------------------------------
            tileGridPanel = new Panel();
            tileGridPanel.Location = new Point(10, 97);
            tileGridPanel.Size = new Size(470, 182);
            tileGridPanel.BackColor = Color.Transparent;
            Controls.Add(tileGridPanel);

            int tileCols = 3;
            int tileGap = 4;
            int tileW = (tileGridPanel.Width - tileGap * (tileCols - 1)) / tileCols;
            int tileH = (tileGridPanel.Height - tileGap * 2) / 3;

            for (int idx = 0; idx < tileDefs.Length; idx++)
            {
                QuickTileDef def = tileDefs[idx];
                int r = idx / tileCols;
                int c = idx % tileCols;

                Button tBtn = new Button();
                tBtn.Tag = "tile";
                tBtn.Text = def.title;
                tBtn.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                tBtn.BackColor = def.color;
                tBtn.ForeColor = Color.White;
                tBtn.FlatStyle = FlatStyle.Flat;
                tBtn.FlatAppearance.BorderSize = 0;
                tBtn.Location = new Point(c * (tileW + tileGap), r * (tileH + tileGap));
                tBtn.Size = new Size(tileW, tileH);
                tBtn.Cursor = Cursors.Hand;
                Raise3D(tBtn, 3);

                int capturedIdx = idx;
                Button capturedBtn = tBtn;
                tBtn.Click += delegate
                {
                    if (isSettingsTabOpen)
                    {
                        LoadTileIntoSettingsEditor(capturedIdx);
                        return;
                    }
                    QuickTileDef cur = tileDefs[capturedIdx];
                    OpenTileMenu(cur.title, cur.primaryMenu, cur.fallbackMenu, cur.sira, capturedBtn);
                };
                tBtn.MouseUp += delegate(object s, MouseEventArgs me)
                {
                    if (me.Button == MouseButtons.Right)
                    {
                        if (!isSettingsTabOpen)
                        {
                            ToggleTileSettingsTab(capturedIdx);
                        }
                        else
                        {
                            LoadTileIntoSettingsEditor(capturedIdx);
                        }
                    }
                };

                tileGridPanel.Controls.Add(tBtn);
                quickTileButtons.Add(tBtn);
            }

            // -----------------------------------------------------------------
            // 3B. "⚙ KARO AYARLARI SEKMESİ" PANELİ
            // -----------------------------------------------------------------
            settingsTabPanel = new Panel();
            settingsTabPanel.Location = new Point(10, 283);
            settingsTabPanel.Size = new Size(470, 322);
            settingsTabPanel.BackColor = Color.FromArgb(24, 32, 48);
            settingsTabPanel.ForeColor = Color.White;
            settingsTabPanel.Visible = false;
            Controls.Add(settingsTabPanel);

            Label lblSetTitle = new Label();
            lblSetTitle.Text = "⚙ MAĞAZA KARO AYARLARI (" + Sube.Kod + ") — Düzenlemek İçin Karoya Tıklayın:";
            lblSetTitle.Font = new Font("Segoe UI", 8.2f, FontStyle.Bold);
            lblSetTitle.ForeColor = Color.FromArgb(255, 200, 70);
            lblSetTitle.Location = new Point(8, 6);
            lblSetTitle.Size = new Size(452, 18);
            settingsTabPanel.Controls.Add(lblSetTitle);

            Label lblPickTile = new Label();
            lblPickTile.Text = "Seçili Karo (1-9):";
            lblPickTile.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblPickTile.ForeColor = Color.FromArgb(200, 220, 245);
            lblPickTile.Location = new Point(8, 30);
            lblPickTile.Size = new Size(102, 20);
            settingsTabPanel.Controls.Add(lblPickTile);

            cmbEditingTileIndex = new ComboBox();
            cmbEditingTileIndex.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditingTileIndex.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            cmbEditingTileIndex.Location = new Point(112, 27);
            cmbEditingTileIndex.Size = new Size(168, 24);
            RefreshEditingTileDropdownItems();
            cmbEditingTileIndex.SelectedIndexChanged += delegate
            {
                if (!suppressTileSettingsEvents && cmbEditingTileIndex.SelectedIndex >= 0)
                {
                    LoadTileIntoSettingsEditor(cmbEditingTileIndex.SelectedIndex);
                }
            };
            settingsTabPanel.Controls.Add(cmbEditingTileIndex);

            chkAutoSyncTileName = new CheckBox();
            chkAutoSyncTileName.Text = "Menü adını karoya yaz";
            chkAutoSyncTileName.Font = new Font("Segoe UI", 8.0f);
            chkAutoSyncTileName.ForeColor = Color.FromArgb(180, 230, 190);
            chkAutoSyncTileName.Checked = false;
            chkAutoSyncTileName.Location = new Point(286, 29);
            chkAutoSyncTileName.Size = new Size(136, 20);
            settingsTabPanel.Controls.Add(chkAutoSyncTileName);

            Label lblTileName = new Label();
            lblTileName.Text = "Karo İsmi:";
            lblTileName.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblTileName.ForeColor = Color.FromArgb(200, 220, 245);
            lblTileName.Location = new Point(8, 58);
            lblTileName.Size = new Size(102, 20);
            settingsTabPanel.Controls.Add(lblTileName);

            txtEditingTileName = new TextBox();
            txtEditingTileName.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            txtEditingTileName.Location = new Point(112, 55);
            txtEditingTileName.Size = new Size(216, 23);
            txtEditingTileName.TextChanged += delegate
            {
                if (!suppressTileSettingsEvents)
                {
                    ApplyCurrentTileEditsToMemory();
                }
            };
            settingsTabPanel.Controls.Add(txtEditingTileName);

            btnCopyMenuToTitle = new Button();
            btnCopyMenuToTitle.Text = "Menü Adını Al";
            btnCopyMenuToTitle.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold);
            btnCopyMenuToTitle.BackColor = Color.FromArgb(40, 105, 175);
            btnCopyMenuToTitle.ForeColor = Color.White;
            btnCopyMenuToTitle.FlatStyle = FlatStyle.Flat;
            btnCopyMenuToTitle.FlatAppearance.BorderSize = 0;
            btnCopyMenuToTitle.Location = new Point(332, 54);
            btnCopyMenuToTitle.Size = new Size(88, 24);
            btnCopyMenuToTitle.Click += delegate
            {
                if (txtEditingMenuTarget.Text.Trim().Length > 0)
                {
                    txtEditingTileName.Text = txtEditingMenuTarget.Text.Trim();
                }
            };
            Raise3D(btnCopyMenuToTitle, 3);
            settingsTabPanel.Controls.Add(btnCopyMenuToTitle);

            Label lblMenuTarget = new Label();
            lblMenuTarget.Text = "Açacağı Menü:";
            lblMenuTarget.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblMenuTarget.ForeColor = Color.FromArgb(200, 220, 245);
            lblMenuTarget.Location = new Point(8, 85);
            lblMenuTarget.Size = new Size(102, 20);
            settingsTabPanel.Controls.Add(lblMenuTarget);

            txtEditingMenuTarget = new TextBox();
            txtEditingMenuTarget.Font = new Font("Segoe UI", 8.8f);
            txtEditingMenuTarget.Location = new Point(112, 82);
            txtEditingMenuTarget.Size = new Size(308, 23);
            txtEditingMenuTarget.TextChanged += delegate
            {
                if (!suppressTileSettingsEvents)
                {
                    ApplyCurrentTileEditsToMemory();
                }
            };
            settingsTabPanel.Controls.Add(txtEditingMenuTarget);

            Label lblTileColor = new Label();
            lblTileColor.Text = "Karo Rengi:";
            lblTileColor.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblTileColor.ForeColor = Color.FromArgb(200, 220, 245);
            lblTileColor.Location = new Point(8, 111);
            lblTileColor.Size = new Size(102, 20);
            settingsTabPanel.Controls.Add(lblTileColor);

            Color[] palette = new Color[]
            {
                Color.FromArgb(46, 170, 40),
                Color.FromArgb(232, 48, 48),
                Color.FromArgb(0, 122, 230),
                Color.FromArgb(255, 140, 0),
                Color.FromArgb(0, 172, 150),
                Color.FromArgb(142, 60, 200),
                Color.FromArgb(20, 140, 50),
                Color.FromArgb(0, 160, 220),
                Color.FromArgb(224, 24, 110)
            };
            for (int cIdx = 0; cIdx < palette.Length; cIdx++)
            {
                Color swatchColor = palette[cIdx];
                Button cBtn = new Button();
                cBtn.BackColor = swatchColor;
                cBtn.FlatStyle = FlatStyle.Flat;
                cBtn.FlatAppearance.BorderColor = Color.White;
                cBtn.FlatAppearance.BorderSize = 1;
                cBtn.Location = new Point(112 + cIdx * 34, 110);
                cBtn.Size = new Size(30, 20);
                cBtn.Cursor = Cursors.Hand;
                cBtn.Click += delegate
                {
                    if (editingTileIdx >= 0 && editingTileIdx < tileDefs.Length)
                    {
                        tileDefs[editingTileIdx].color = swatchColor;
                        if (editingTileIdx < quickTileButtons.Count)
                        {
                            quickTileButtons[editingTileIdx].BackColor = swatchColor;
                        }
                    }
                };
                settingsTabPanel.Controls.Add(cBtn);
            }

            Label lblMenuPickHint = new Label();
            lblMenuPickHint.Text = "Ekran Seç (" + SolMenuCatalog.Count + "):";
            lblMenuPickHint.Font = new Font("Segoe UI", 8.3f, FontStyle.Bold);
            lblMenuPickHint.ForeColor = Color.FromArgb(130, 200, 255);
            lblMenuPickHint.Location = new Point(8, 138);
            lblMenuPickHint.Size = new Size(102, 20);
            settingsTabPanel.Controls.Add(lblMenuPickHint);

            cmbEditingCategory = new ComboBox();
            cmbEditingCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEditingCategory.Font = new Font("Segoe UI", 8.3f);
            cmbEditingCategory.Location = new Point(112, 135);
            cmbEditingCategory.Size = new Size(138, 23);
            cmbEditingCategory.Items.Add("Tüm Gruplar");
            HashSet<string> setMods = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                string k = SolMenuCatalog[i].kategori ?? "";
                if (k.Length > 0 && setMods.Add(k)) cmbEditingCategory.Items.Add(k);
            }
            cmbEditingCategory.SelectedIndex = 0;
            cmbEditingCategory.SelectedIndexChanged += delegate { PopulateEditingMenusList(); };
            settingsTabPanel.Controls.Add(cmbEditingCategory);

            txtEditingMenuSearch = new TextBox();
            txtEditingMenuSearch.Font = new Font("Segoe UI", 8.6f);
            txtEditingMenuSearch.Location = new Point(254, 135);
            txtEditingMenuSearch.Size = new Size(166, 23);
            txtEditingMenuSearch.TextChanged += delegate { PopulateEditingMenusList(); };
            settingsTabPanel.Controls.Add(txtEditingMenuSearch);

            lstEditingMenus = new ListBox();
            lstEditingMenus.Font = new Font("Segoe UI", 8.6f);
            lstEditingMenus.Location = new Point(8, 162);
            lstEditingMenus.Size = new Size(412, 118);
            lstEditingMenus.SelectedIndexChanged += delegate
            {
                if (suppressTileSettingsEvents || lstEditingMenus.SelectedItem == null) return;
                string raw = lstEditingMenus.SelectedItem.ToString();
                int bIdx = raw.LastIndexOf("  [");
                string pickedTitle = bIdx > 0 ? raw.Substring(0, bIdx).Trim() : raw.Trim();
                if (pickedTitle.Length > 0)
                {
                    txtEditingMenuTarget.Text = pickedTitle;
                    if (chkAutoSyncTileName.Checked || txtEditingTileName.Text.Trim().Length == 0)
                    {
                        txtEditingTileName.Text = pickedTitle;
                    }
                    ApplyCurrentTileEditsToMemory();
                }
            };
            settingsTabPanel.Controls.Add(lstEditingMenus);

            btnSaveTileSettings = new Button();
            btnSaveTileSettings.Text = "💾 Kaydet ve Uygula";
            btnSaveTileSettings.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            btnSaveTileSettings.BackColor = Color.FromArgb(30, 155, 75);
            btnSaveTileSettings.ForeColor = Color.White;
            btnSaveTileSettings.FlatStyle = FlatStyle.Flat;
            btnSaveTileSettings.FlatAppearance.BorderSize = 0;
            btnSaveTileSettings.Location = new Point(8, 285);
            btnSaveTileSettings.Size = new Size(204, 30);
            btnSaveTileSettings.Click += delegate
            {
                ApplyCurrentTileEditsToMemory();
                SaveCustomTileDefs();
                ToggleTileSettingsTab(editingTileIdx);
                lblFrameStatus.Text = "✅ Mağaza hızlı erişim karoları kaydedildi ve güncellendi.";
                lblFrameStatus.ForeColor = Color.FromArgb(120, 245, 150);
                statusMessageHoldTicks = 14;
            };
            Raise3D(btnSaveTileSettings, 3);
            settingsTabPanel.Controls.Add(btnSaveTileSettings);

            btnResetDefaultTiles = new Button();
            btnResetDefaultTiles.Text = "↺ Varsayılanlar";
            btnResetDefaultTiles.Font = new Font("Segoe UI", 8.3f, FontStyle.Bold);
            btnResetDefaultTiles.BackColor = Color.FromArgb(65, 92, 132);
            btnResetDefaultTiles.ForeColor = Color.White;
            btnResetDefaultTiles.FlatStyle = FlatStyle.Flat;
            btnResetDefaultTiles.FlatAppearance.BorderSize = 0;
            btnResetDefaultTiles.Location = new Point(218, 285);
            btnResetDefaultTiles.Size = new Size(114, 30);
            btnResetDefaultTiles.Click += delegate
            {
                ResetTilesToDefaults();
            };
            Raise3D(btnResetDefaultTiles, 3);
            settingsTabPanel.Controls.Add(btnResetDefaultTiles);

            btnCloseTileSettings = new Button();
            btnCloseTileSettings.Text = "Kapat ✕";
            btnCloseTileSettings.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            btnCloseTileSettings.BackColor = Color.FromArgb(200, 48, 48);
            btnCloseTileSettings.ForeColor = Color.White;
            btnCloseTileSettings.FlatStyle = FlatStyle.Flat;
            btnCloseTileSettings.FlatAppearance.BorderSize = 0;
            btnCloseTileSettings.Location = new Point(338, 285);
            btnCloseTileSettings.Size = new Size(82, 30);
            btnCloseTileSettings.Click += delegate
            {
                SaveCustomTileDefs();
                ToggleTileSettingsTab(editingTileIdx);
            };
            Raise3D(btnCloseTileSettings, 3);
            settingsTabPanel.Controls.Add(btnCloseTileSettings);

            PopulateEditingMenusList();
            LoadTileIntoSettingsEditor(0);

            // -----------------------------------------------------------------
            // 4. "🧭 Tüm Menüler & Ekran Ara" AÇILIR ÇEKMECE BUTONU VE PANELİ
            // -----------------------------------------------------------------
            btnToggleAllMenus = new Button();
            btnToggleAllMenus.Location = new Point(10, 283);
            btnToggleAllMenus.Size = new Size(470, 28);
            btnToggleAllMenus.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            btnToggleAllMenus.BackColor = Color.FromArgb(26, 98, 178);
            btnToggleAllMenus.ForeColor = Color.White;
            btnToggleAllMenus.FlatStyle = FlatStyle.Flat;
            btnToggleAllMenus.FlatAppearance.BorderSize = 0;
            btnToggleAllMenus.TextAlign = ContentAlignment.MiddleLeft;
            btnToggleAllMenus.Text = "🧭 Tüm Menüler & Ekran Ara (" + SolMenuCatalog.Count + " Mağaza Ekranı) — Tıklayın ▾";
            btnToggleAllMenus.Cursor = Cursors.Hand;
            btnToggleAllMenus.Click += delegate { ToggleAllMenusDrawer(); };
            Raise3D(btnToggleAllMenus, 3);
            Controls.Add(btnToggleAllMenus);

            drawerAllMenusPanel = new Panel();
            drawerAllMenusPanel.Location = new Point(10, 314);
            drawerAllMenusPanel.Size = new Size(470, 175);
            drawerAllMenusPanel.BackColor = Color.FromArgb(230, 234, 240);
            drawerAllMenusPanel.Visible = false;
            Controls.Add(drawerAllMenusPanel);

            cmbDrawerCategory = new ComboBox();
            cmbDrawerCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDrawerCategory.Font = new Font("Segoe UI", 8.5f);
            cmbDrawerCategory.Location = new Point(6, 6);
            cmbDrawerCategory.Size = new Size(165, 24);
            cmbDrawerCategory.Items.Add("Tüm Mağaza Ekranları (" + SolMenuCatalog.Count + ")");
            HashSet<string> modSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                string kat = SolMenuCatalog[i].kategori ?? "";
                if (kat.Length > 0 && modSet.Add(kat))
                {
                    cmbDrawerCategory.Items.Add(kat);
                }
            }
            cmbDrawerCategory.SelectedIndex = 0;
            cmbDrawerCategory.SelectedIndexChanged += delegate { PopulateDrawerMenuList(); };
            drawerAllMenusPanel.Controls.Add(cmbDrawerCategory);

            txtDrawerFilter = new TextBox();
            txtDrawerFilter.Font = new Font("Segoe UI", 8.8f);
            txtDrawerFilter.Location = new Point(176, 6);
            txtDrawerFilter.Size = new Size(288, 23);
            txtDrawerFilter.TextChanged += delegate { PopulateDrawerMenuList(); };
            txtDrawerFilter.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    OpenSelectedDrawerMenu();
                }
            };
            drawerAllMenusPanel.Controls.Add(txtDrawerFilter);

            lstDrawerMenus = new ListBox();
            lstDrawerMenus.Font = new Font("Segoe UI", 8.8f);
            lstDrawerMenus.Location = new Point(6, 33);
            lstDrawerMenus.Size = new Size(458, 106);
            lstDrawerMenus.DoubleClick += delegate { OpenSelectedDrawerMenu(); };
            drawerAllMenusPanel.Controls.Add(lstDrawerMenus);

            btnDrawerOpen = new Button();
            btnDrawerOpen.Text = "▶ Seçili Ekranı Aç";
            btnDrawerOpen.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            btnDrawerOpen.BackColor = Color.FromArgb(0, 122, 230);
            btnDrawerOpen.ForeColor = Color.White;
            btnDrawerOpen.FlatStyle = FlatStyle.Flat;
            btnDrawerOpen.FlatAppearance.BorderSize = 0;
            btnDrawerOpen.Location = new Point(6, 142);
            btnDrawerOpen.Size = new Size(228, 28);
            btnDrawerOpen.Click += delegate { OpenSelectedDrawerMenu(); };
            Raise3D(btnDrawerOpen, 3);
            drawerAllMenusPanel.Controls.Add(btnDrawerOpen);

            btnDrawerTeach = new Button();
            btnDrawerTeach.Text = "📌 Öğret";
            btnDrawerTeach.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            btnDrawerTeach.BackColor = Color.FromArgb(230, 126, 34);
            btnDrawerTeach.ForeColor = Color.White;
            btnDrawerTeach.FlatStyle = FlatStyle.Flat;
            btnDrawerTeach.FlatAppearance.BorderSize = 0;
            btnDrawerTeach.Location = new Point(240, 142);
            btnDrawerTeach.Size = new Size(108, 28);
            btnDrawerTeach.Click += delegate { TeachCurrentActiveScreenManual(); };
            Raise3D(btnDrawerTeach, 3);
            drawerAllMenusPanel.Controls.Add(btnDrawerTeach);

            btnDrawerHelp = new Button();
            btnDrawerHelp.Text = "📚 Çözüm Merkezi";
            btnDrawerHelp.Font = new Font("Segoe UI", 8.2f, FontStyle.Bold);
            btnDrawerHelp.BackColor = Color.FromArgb(128, 58, 186);
            btnDrawerHelp.ForeColor = Color.White;
            btnDrawerHelp.FlatStyle = FlatStyle.Flat;
            btnDrawerHelp.FlatAppearance.BorderSize = 0;
            btnDrawerHelp.Location = new Point(354, 142);
            btnDrawerHelp.Size = new Size(110, 28);
            btnDrawerHelp.Click += delegate { ShowSelectedDrawerMenuHelp(); };
            Raise3D(btnDrawerHelp, 3);
            drawerAllMenusPanel.Controls.Add(btnDrawerHelp);

            PopulateDrawerMenuList();

            // -----------------------------------------------------------------
            // 5. MAHMUTBEY CANLI YOL GÖSTERİCİ BÖLÜMÜ (CanliMakineEkranPanel)
            // -----------------------------------------------------------------
            guideMainPanel = new Panel();
            guideMainPanel.Location = new Point(10, 315);
            guideMainPanel.Size = new Size(470, 334);
            guideMainPanel.BackColor = Color.FromArgb(22, 28, 40);
            guideMainPanel.ForeColor = Color.White;
            guideMainPanel.Tag = "guide";
            Controls.Add(guideMainPanel);

            cmbMenuSearch = new ComboBox();
            cmbMenuSearch.Visible = false;
            lstQuickSearchResults = new ListBox();
            lstQuickSearchResults.Visible = false;

            lblScreenTitle = new Label();
            lblScreenTitle.Tag = "guide";
            lblScreenTitle.Text = "🧭 Aktif Ekran: Bekleniyor...";
            lblScreenTitle.Font = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            lblScreenTitle.ForeColor = Color.FromArgb(255, 215, 80);
            lblScreenTitle.Location = new Point(2, 2);
            lblScreenTitle.Size = new Size(466, 20);
            lblScreenTitle.AutoEllipsis = true;
            guideMainPanel.Controls.Add(lblScreenTitle);

            // --- SATIR 2 (Y=24, H=38): FARKEDİLİR MİKROFON (DİKTE) & SESLİ/SESSİZ & CANLI DİKTE KUTUSU ---
            dictateAutoExecTimer = new System.Windows.Forms.Timer();
            dictateAutoExecTimer.Interval = 1600;
            dictateAutoExecTimer.Tick += delegate
            {
                dictateAutoExecTimer.Stop();
                if (isDictatingActive && txtInlineDictate != null && txtInlineDictate.Text.Trim().Length >= 2)
                {
                    ExecuteInlineDictation();
                }
            };

            btnMicDictate = new Button();
            btnMicDictate.Tag = "tile";
            btnMicDictate.Text = "";
            btnMicDictate.BackColor = Color.FromArgb(215, 22, 85);
            btnMicDictate.ForeColor = Color.White;
            btnMicDictate.FlatStyle = FlatStyle.Flat;
            btnMicDictate.FlatAppearance.BorderSize = 0;
            btnMicDictate.Location = new Point(0, 24);
            btnMicDictate.Size = new Size(152, 38);
            btnMicDictate.Cursor = Cursors.Hand;
            btnMicDictate.Paint += delegate(object s, PaintEventArgs pe)
            {
                PaintCustomMicrophoneButton(
                    btnMicDictate,
                    pe,
                    isDictatingActive,
                    isDictatingActive ? "DİNLENİYOR..." : "MİKROFON",
                    isDictatingActive ? "Konuşun (Dikte)" : "Sesli Dikte / Komut");
            };
            btnMicDictate.Click += delegate { StartDirectDictation(); };
            btnMicDictate.MouseUp += delegate(object s, MouseEventArgs me)
            {
                if (me.Button == MouseButtons.Right)
                {
                    SesliKomutDialog();
                }
            };
            guideMainPanel.Controls.Add(btnMicDictate);

            btnVoiceMute = new Button();
            btnVoiceMute.Tag = "tile";
            btnVoiceMute.Text = "";
            btnVoiceMute.BackColor = SesliAsistan.Aktif ? Color.FromArgb(18, 148, 78) : Color.FromArgb(175, 42, 48);
            btnVoiceMute.ForeColor = Color.White;
            btnVoiceMute.FlatStyle = FlatStyle.Flat;
            btnVoiceMute.FlatAppearance.BorderSize = 0;
            btnVoiceMute.Location = new Point(156, 24);
            btnVoiceMute.Size = new Size(118, 38);
            btnVoiceMute.Cursor = Cursors.Hand;
            btnVoiceMute.Paint += delegate(object s, PaintEventArgs pe)
            {
                PaintCustomSpeakerMuteButton(
                    btnVoiceMute,
                    pe,
                    SesliAsistan.Aktif,
                    SesliAsistan.Aktif ? "SESLİ AÇIK" : "SESSİZ",
                    SesliAsistan.Aktif ? "Tıkla → Sessiz" : "Tıkla → Sesli");
            };
            btnVoiceMute.Click += delegate { ToggleVoiceMuteDirect(); };
            guideMainPanel.Controls.Add(btnVoiceMute);

            txtInlineDictate = new TextBox();
            txtInlineDictate.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            txtInlineDictate.BackColor = Color.FromArgb(28, 38, 56);
            txtInlineDictate.ForeColor = Color.White;
            txtInlineDictate.Location = new Point(278, 30);
            txtInlineDictate.Size = new Size(146, 26);
            txtInlineDictate.TextChanged += delegate
            {
                if (suppressInlineDictateEvent) return;
                if (isDictatingActive && txtInlineDictate.Text.Trim().Length >= 2)
                {
                    dictateAutoExecTimer.Stop();
                    dictateAutoExecTimer.Start();
                }
            };
            txtInlineDictate.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    e.SuppressKeyPress = true;
                    ExecuteInlineDictation();
                }
            };
            guideMainPanel.Controls.Add(txtInlineDictate);

            btnInlineDictateRun = new Button();
            btnInlineDictateRun.Tag = "tile";
            btnInlineDictateRun.Text = "▶";
            btnInlineDictateRun.Font = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            btnInlineDictateRun.BackColor = Color.FromArgb(30, 155, 75);
            btnInlineDictateRun.ForeColor = Color.White;
            btnInlineDictateRun.FlatStyle = FlatStyle.Flat;
            btnInlineDictateRun.FlatAppearance.BorderSize = 0;
            btnInlineDictateRun.Location = new Point(428, 24);
            btnInlineDictateRun.Size = new Size(42, 38);
            btnInlineDictateRun.Cursor = Cursors.Hand;
            btnInlineDictateRun.Click += delegate { ExecuteInlineDictation(); };
            Raise3D(btnInlineDictateRun, 3);
            guideMainPanel.Controls.Add(btnInlineDictateRun);

            // --- SATIR 3 (Y=66, H=28): GENİŞ OKUMA, GÜNCELLEME, ONARIM VE TEST BUTONLARI ---
            btnVoiceCommand = new Button();
            btnVoiceCommand.Tag = "tile";
            btnVoiceCommand.Text = "📢 Ciro / Adım Oku";
            btnVoiceCommand.Font = new Font("Segoe UI", 8.3f, FontStyle.Bold);
            btnVoiceCommand.BackColor = Color.FromArgb(0, 132, 195);
            btnVoiceCommand.ForeColor = Color.White;
            btnVoiceCommand.FlatStyle = FlatStyle.Flat;
            btnVoiceCommand.FlatAppearance.BorderSize = 0;
            btnVoiceCommand.Location = new Point(0, 66);
            btnVoiceCommand.Size = new Size(122, 28);
            btnVoiceCommand.Cursor = Cursors.Hand;
            btnVoiceCommand.Click += delegate { SesliKomutDialog(); };
            Raise3D(btnVoiceCommand, 3);
            guideMainPanel.Controls.Add(btnVoiceCommand);

            btnUpdate = new Button();
            btnUpdate.Tag = "tile";
            btnUpdate.Text = "⬆ Güncelle";
            btnUpdate.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            btnUpdate.BackColor = Color.FromArgb(25, 118, 210);
            btnUpdate.ForeColor = Color.White;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.FlatAppearance.BorderSize = 0;
            btnUpdate.Location = new Point(126, 66);
            btnUpdate.Size = new Size(110, 28);
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.Click += delegate { GuncelleBaslat(); };
            Raise3D(btnUpdate, 3);
            guideMainPanel.Controls.Add(btnUpdate);

            btnSystemRestore = new Button();
            btnSystemRestore.Tag = "tile";
            btnSystemRestore.Text = "🛠️ Sistem Onar";
            btnSystemRestore.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            btnSystemRestore.BackColor = Color.FromArgb(214, 92, 18);
            btnSystemRestore.ForeColor = Color.White;
            btnSystemRestore.FlatStyle = FlatStyle.Flat;
            btnSystemRestore.FlatAppearance.BorderSize = 0;
            btnSystemRestore.Location = new Point(240, 66);
            btnSystemRestore.Size = new Size(112, 28);
            btnSystemRestore.Cursor = Cursors.Hand;
            btnSystemRestore.Click += delegate
            {
                RunSystemIntegrityRestoreAndReport(true);
            };
            Raise3D(btnSystemRestore, 3);
            guideMainPanel.Controls.Add(btnSystemRestore);

            btnMachineDemo = new Button();
            btnMachineDemo.Tag = "tile";
            btnMachineDemo.Text = "📚 Çözüm Merkezi";
            btnMachineDemo.Font = new Font("Segoe UI", 8.2f, FontStyle.Bold);
            btnMachineDemo.BackColor = Color.FromArgb(128, 58, 186);
            btnMachineDemo.ForeColor = Color.White;
            btnMachineDemo.FlatStyle = FlatStyle.Flat;
            btnMachineDemo.FlatAppearance.BorderSize = 0;
            btnMachineDemo.Location = new Point(356, 66);
            btnMachineDemo.Size = new Size(114, 28);
            btnMachineDemo.Cursor = Cursors.Hand;
            btnMachineDemo.Click += delegate
            {
                ShowKnowledgeAndSolutionLibraryDialog(currentTrackedScreen);
            };
            btnMachineDemo.MouseUp += delegate(object s, MouseEventArgs me)
            {
                if (me.Button == MouseButtons.Right && stepBox != null)
                {
                    stepBox.StartLiveDemoSequence(lblScreenTitle);
                }
            };
            Raise3D(btnMachineDemo, 3);
            guideMainPanel.Controls.Add(btnMachineDemo);

            stepBox = new CanliMakineEkranPanel();
            stepBox.Tag = "guide";
            stepBox.BackColor = Color.FromArgb(13, 19, 30);
            stepBox.Location = new Point(0, 98);
            stepBox.Size = new Size(470, 134);
            guideMainPanel.Controls.Add(stepBox);

            lblActiveStepTitle = new Label();
            lblActiveStepTitle.Tag = "guide";
            lblActiveStepTitle.Text = "▶ ADIM 1: İlk Veri Giriş Alanı (" + Sube.Ad + " - " + Sube.Kod + ")";
            lblActiveStepTitle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            lblActiveStepTitle.ForeColor = Color.FromArgb(255, 165, 50);
            lblActiveStepTitle.Location = new Point(8, 5);
            lblActiveStepTitle.Size = new Size(450, 20);
            lblActiveStepTitle.AutoEllipsis = false;
            stepBox.Controls.Add(lblActiveStepTitle);

            lblActiveStepDesc = new Label();
            lblActiveStepDesc.Tag = "guide";
            lblActiveStepDesc.Text = "Yukarıdaki 9 mağaza karosuna tıkladığınızda veya 'Tüm Menüler & Ekran Ara' bölümünden bir ekran açtığınızda ilk veri alanı otomatik odaklanır ve çerçevelenir.";
            lblActiveStepDesc.Font = new Font("Segoe UI", 8.8f, FontStyle.Regular);
            lblActiveStepDesc.ForeColor = Color.White;
            lblActiveStepDesc.Location = new Point(8, 26);
            lblActiveStepDesc.Size = new Size(450, 62);
            lblActiveStepDesc.MaximumSize = new Size(450, 0);
            lblActiveStepDesc.AutoEllipsis = false;
            stepBox.Controls.Add(lblActiveStepDesc);

            lblFrameStatus = new Label();
            lblFrameStatus.Tag = "guide";
            lblFrameStatus.Text = "Durum: " + Sube.Ad + " (" + Sube.Kod + ") mağaza karoları hazır...";
            lblFrameStatus.Font = new Font("Segoe UI", 8.2f, FontStyle.Italic);
            lblFrameStatus.ForeColor = Color.FromArgb(140, 235, 160);
            lblFrameStatus.Location = new Point(8, 92);
            lblFrameStatus.Size = new Size(450, 20);
            lblFrameStatus.AutoEllipsis = false;
            stepBox.Controls.Add(lblFrameStatus);

            stepBox.BindSourceLabels(lblActiveStepTitle, lblActiveStepDesc, lblFrameStatus);

            lblStepsList = new Label();
            lblStepsList.Tag = "guide";
            lblStepsList.Text = "Mağaza Yol Gösterici İşlem Adımları:\n⏳ 1. İlk veri alanına bilgiyi girin (Barkod / Ürün / Tarih)\n⏳ 2. Sonraki alanı kontrol edin\n⏳ 3. Çalıştır (F5) / Kaydet ile tamamlayın";
            lblStepsList.Font = new Font("Segoe UI", 8.5f);
            lblStepsList.ForeColor = Color.FromArgb(215, 225, 240);
            lblStepsList.Location = new Point(2, 236);
            lblStepsList.Size = new Size(466, 60);
            lblStepsList.MaximumSize = new Size(466, 0);
            lblStepsList.AutoEllipsis = false;
            guideMainPanel.Controls.Add(lblStepsList);

            btnNextStep = new Button();
            btnNextStep.Tag = "tile";
            btnNextStep.Text = "Sonraki Adıma Geç ⏭";
            btnNextStep.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            btnNextStep.BackColor = Color.FromArgb(0, 118, 215);
            btnNextStep.ForeColor = Color.White;
            btnNextStep.FlatStyle = FlatStyle.Flat;
            btnNextStep.FlatAppearance.BorderSize = 0;
            btnNextStep.Location = new Point(0, 300);
            btnNextStep.Size = new Size(231, 30);
            btnNextStep.Click += delegate { AdvanceToNextStepManual(); };
            Raise3D(btnNextStep, 3);
            guideMainPanel.Controls.Add(btnNextStep);

            btnDoneClose = new Button();
            btnDoneClose.Tag = "tile";
            btnDoneClose.Text = "Çerçeveyi Gizle / Tamam ✓";
            btnDoneClose.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            btnDoneClose.BackColor = Color.FromArgb(30, 152, 72);
            btnDoneClose.ForeColor = Color.White;
            btnDoneClose.FlatStyle = FlatStyle.Flat;
            btnDoneClose.FlatAppearance.BorderSize = 0;
            btnDoneClose.Location = new Point(239, 300);
            btnDoneClose.Size = new Size(231, 30);
            btnDoneClose.Click += delegate { CompleteAndAutoHideCurrentScreen(); };
            Raise3D(btnDoneClose, 3);
            guideMainPanel.Controls.Add(btnDoneClose);

            ApplyCurrentTheme();

            FormClosing += delegate
            {
                if (monitorTimer != null) monitorTimer.Stop();
                if (animTimer != null) animTimer.Stop();
                if (trayIcon != null) trayIcon.Visible = false;
                if (frameOverlay != null && !frameOverlay.IsDisposed) frameOverlay.Close();
            };
        }

        private void UpdateQuickSearchSuggestions()
        {
            if (lstQuickSearchResults == null || cmbMenuSearch == null) return;
            string q = (cmbMenuSearch.Text ?? "").Trim();
            if (q.Length < 1)
            {
                lstQuickSearchResults.Visible = false;
                return;
            }

            List<AtlasItem> matches = FilterMenusByQuery(q, 14);
            if (matches.Count == 0)
            {
                lstQuickSearchResults.Visible = false;
                return;
            }

            lstQuickSearchResults.BeginUpdate();
            lstQuickSearchResults.Items.Clear();
            for (int i = 0; i < matches.Count; i++)
            {
                AtlasItem it = matches[i];
                lstQuickSearchResults.Items.Add(it.baslik + "  [" + it.kategori + "]");
            }
            lstQuickSearchResults.EndUpdate();
            lstQuickSearchResults.SelectedIndex = 0;
            lstQuickSearchResults.Visible = true;
            lstQuickSearchResults.BringToFront();
        }

        private void SelectFromQuickSearchList(bool autoOpen)
        {
            if (lstQuickSearchResults == null || lstQuickSearchResults.SelectedItem == null) return;
            string raw = lstQuickSearchResults.SelectedItem.ToString();
            int bracketIdx = raw.LastIndexOf("  [");
            string cleanTitle = bracketIdx > 0 ? raw.Substring(0, bracketIdx).Trim() : raw.Trim();

            suppressQuickSearchEvents = true;
            cmbMenuSearch.Text = cleanTitle;
            suppressQuickSearchEvents = false;
            lstQuickSearchResults.Visible = false;

            if (autoOpen && cleanTitle.Length >= 2)
            {
                TriggerAutoOpenSelectedMenu(true);
            }
        }

        private void ToggleTileSettingsTab(int focusTileIndex)
        {
            if (isCompactMode)
            {
                ToggleCompactMode();
            }

            isSettingsTabOpen = !isSettingsTabOpen;
            if (isSettingsTabOpen)
            {
                isAllMenusExpanded = false;
                drawerAllMenusPanel.Visible = false;
                btnToggleAllMenus.Visible = false;
                guideMainPanel.Visible = false;
                settingsTabPanel.Visible = true;
                settingsTabPanel.BringToFront();
                btnTileSettings.Text = "✓ Ayarlar Açık";
                btnTileSettings.BackColor = Color.FromArgb(30, 155, 75);
                LoadTileIntoSettingsEditor(focusTileIndex);
                txtEditingTileName.Focus();
            }
            else
            {
                settingsTabPanel.Visible = false;
                btnToggleAllMenus.Visible = true;
                drawerAllMenusPanel.Visible = isAllMenusExpanded;
                guideMainPanel.Visible = true;
                btnTileSettings.Text = "⚙ Karo Ayarları";
                btnTileSettings.BackColor = Color.FromArgb(255, 140, 0);
                for (int i = 0; i < quickTileButtons.Count; i++)
                {
                    quickTileButtons[i].FlatAppearance.BorderSize = 0;
                }
            }
            UpdateLayoutHeights();
        }

        private void RefreshEditingTileDropdownItems()
        {
            if (cmbEditingTileIndex == null || tileDefs == null) return;
            suppressTileSettingsEvents = true;
            int prev = cmbEditingTileIndex.SelectedIndex;
            cmbEditingTileIndex.Items.Clear();
            for (int i = 0; i < tileDefs.Length; i++)
            {
                cmbEditingTileIndex.Items.Add((i + 1) + ". Karo: " + tileDefs[i].title);
            }
            if (prev >= 0 && prev < cmbEditingTileIndex.Items.Count)
            {
                cmbEditingTileIndex.SelectedIndex = prev;
            }
            else if (cmbEditingTileIndex.Items.Count > 0)
            {
                cmbEditingTileIndex.SelectedIndex = 0;
            }
            suppressTileSettingsEvents = false;
        }

        private void LoadTileIntoSettingsEditor(int idx)
        {
            if (tileDefs == null || idx < 0 || idx >= tileDefs.Length) return;
            editingTileIdx = idx;

            suppressTileSettingsEvents = true;
            RefreshEditingTileDropdownItems();
            cmbEditingTileIndex.SelectedIndex = idx;
            txtEditingTileName.Text = tileDefs[idx].title;
            txtEditingMenuTarget.Text = tileDefs[idx].primaryMenu;
            suppressTileSettingsEvents = false;

            for (int i = 0; i < quickTileButtons.Count; i++)
            {
                if (isSettingsTabOpen && i == idx)
                {
                    quickTileButtons[i].FlatAppearance.BorderColor = Color.Yellow;
                    quickTileButtons[i].FlatAppearance.BorderSize = 2;
                }
                else
                {
                    quickTileButtons[i].FlatAppearance.BorderSize = 0;
                }
            }
        }

        private void ApplyCurrentTileEditsToMemory()
        {
            if (tileDefs == null || editingTileIdx < 0 || editingTileIdx >= tileDefs.Length) return;

            string newTitle = (txtEditingTileName != null ? txtEditingTileName.Text : "").Trim();
            string newMenu = (txtEditingMenuTarget != null ? txtEditingMenuTarget.Text : "").Trim();

            if (newTitle.Length > 0)
            {
                tileDefs[editingTileIdx].title = newTitle;
                if (editingTileIdx < quickTileButtons.Count)
                {
                    quickTileButtons[editingTileIdx].Text = newTitle;
                }
            }
            if (newMenu.Length > 0)
            {
                tileDefs[editingTileIdx].primaryMenu = newMenu;
                tileDefs[editingTileIdx].fallbackMenu = newMenu;
                AtlasItem catItem = FindCatalogItemByTitle(newMenu);
                if (catItem != null && catItem.sira > 0)
                {
                    tileDefs[editingTileIdx].sira = catItem.sira;
                }
            }
            RefreshEditingTileDropdownItems();
        }

        private void PopulateEditingMenusList()
        {
            if (lstEditingMenus == null) return;
            string qNorm = NormTr(txtEditingMenuSearch != null ? txtEditingMenuSearch.Text : "");
            string selectedCat = (cmbEditingCategory != null && cmbEditingCategory.SelectedIndex > 0)
                ? cmbEditingCategory.SelectedItem.ToString()
                : "";

            suppressTileSettingsEvents = true;
            lstEditingMenus.BeginUpdate();
            lstEditingMenus.Items.Clear();

            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                AtlasItem it = SolMenuCatalog[i];
                if (selectedCat.Length > 0 && !string.Equals(it.kategori, selectedCat, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                if (qNorm.Length > 0)
                {
                    string bNorm = NormTr(it.baslik);
                    string kNorm = NormTr(it.kategori);
                    string yNorm = NormTr(it.menuYolu);
                    if (bNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0 &&
                        kNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0 &&
                        yNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0)
                    {
                        continue;
                    }
                }
                lstEditingMenus.Items.Add(it.baslik + "  [" + it.kategori + "]");
            }
            lstEditingMenus.EndUpdate();
            suppressTileSettingsEvents = false;
        }

        private void ResetTilesToDefaults()
        {
            QuickTileDef[] defaults = BuildDefaultTileDefs();
            for (int i = 0; i < tileDefs.Length && i < defaults.Length; i++)
            {
                tileDefs[i].title = defaults[i].title;
                tileDefs[i].primaryMenu = defaults[i].primaryMenu;
                tileDefs[i].fallbackMenu = defaults[i].fallbackMenu;
                tileDefs[i].sira = defaults[i].sira;
                tileDefs[i].color = defaults[i].color;
                if (i < quickTileButtons.Count)
                {
                    quickTileButtons[i].Text = tileDefs[i].title;
                    quickTileButtons[i].BackColor = tileDefs[i].color;
                }
            }
            SaveCustomTileDefs();
            LoadTileIntoSettingsEditor(editingTileIdx);
        }

        private void ToggleCompactMode()
        {
            isCompactMode = !isCompactMode;
            if (isCompactMode)
            {
                btnMini.Text = "Aç";
                lblLiveSummary.Visible = false;
                btnLiveRefresh.Visible = false;
                tileGridPanel.Visible = false;
                if (settingsTabPanel != null) settingsTabPanel.Visible = false;
                btnToggleAllMenus.Visible = false;
                drawerAllMenusPanel.Visible = false;
                guideMainPanel.Visible = false;
                Size = new Size(505, 82);
            }
            else
            {
                btnMini.Text = "Küçült";
                lblLiveSummary.Visible = true;
                btnLiveRefresh.Visible = true;
                tileGridPanel.Visible = true;
                if (isSettingsTabOpen)
                {
                    settingsTabPanel.Visible = true;
                    btnToggleAllMenus.Visible = false;
                    drawerAllMenusPanel.Visible = false;
                    guideMainPanel.Visible = false;
                }
                else
                {
                    if (settingsTabPanel != null) settingsTabPanel.Visible = false;
                    btnToggleAllMenus.Visible = true;
                    drawerAllMenusPanel.Visible = isAllMenusExpanded;
                    guideMainPanel.Visible = true;
                }
                UpdateLayoutHeights();
            }
        }

        private void ToggleAllMenusDrawer()
        {
            isAllMenusExpanded = !isAllMenusExpanded;
            drawerAllMenusPanel.Visible = isAllMenusExpanded;
            btnToggleAllMenus.Text = isAllMenusExpanded
                ? ("🧭 Tüm Menüler & Ekran Ara (" + SolMenuCatalog.Count + " Mağaza Ekranı) — Kapat ▴")
                : ("🧭 Tüm Menüler & Ekran Ara (" + SolMenuCatalog.Count + " Mağaza Ekranı) — Tıklayın ▾");
            UpdateLayoutHeights();
            if (isAllMenusExpanded)
            {
                txtDrawerFilter.Focus();
            }
        }

        private void UpdateLayoutHeights()
        {
            if (isCompactMode) return;
            Rectangle workArea = Screen.PrimaryScreen.WorkingArea;
            int maxH = workArea.Height - 40;
            int desiredH;
            if (isSettingsTabOpen)
            {
                desiredH = 652;
            }
            else if (isAllMenusExpanded)
            {
                guideMainPanel.Location = new Point(10, 492);
                desiredH = 872;
            }
            else
            {
                guideMainPanel.Location = new Point(10, 315);
                desiredH = 694;
            }
            int finalH = Math.Min(desiredH, maxH);
            Size = new Size(505, finalH);
            if (Top + finalH > workArea.Bottom - 6)
            {
                Top = Math.Max(workArea.Top + 6, workArea.Bottom - finalH - 6);
            }
            Invalidate();
        }

        private Color ThemeOkColor()
        {
            return isLightTheme ? Color.FromArgb(16, 125, 55) : Color.FromArgb(120, 245, 150);
        }

        private Color ThemeWarnColor()
        {
            return isLightTheme ? Color.FromArgb(185, 85, 0) : Color.FromArgb(255, 200, 80);
        }

        private Color ThemeStepTitleColor(bool isAction)
        {
            if (isAction)
            {
                return isLightTheme ? Color.FromArgb(14, 135, 65) : Color.FromArgb(0, 230, 118);
            }
            return isLightTheme ? Color.FromArgb(195, 85, 0) : Color.FromArgb(255, 165, 50);
        }

        private void ApplyCurrentTheme()
        {
            if (isLightTheme)
            {
                BackColor = Color.FromArgb(240, 242, 246);
                ForeColor = Color.FromArgb(25, 30, 40);
                btnMini.BackColor = Color.FromArgb(52, 78, 118);
                btnMini.ForeColor = Color.White;
                btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                btnMcpStatus.ForeColor = Color.White;
                btnTheme.BackColor = Color.FromArgb(128, 58, 186);
                btnTheme.ForeColor = Color.White;
                chkTopMost.ForeColor = Color.FromArgb(25, 30, 40);

                btnToggleAllMenus.BackColor = Color.FromArgb(26, 98, 178);
                btnToggleAllMenus.ForeColor = Color.White;
                drawerAllMenusPanel.BackColor = Color.FromArgb(230, 234, 242);
                if (cmbDrawerCategory != null)
                {
                    cmbDrawerCategory.BackColor = Color.White;
                    cmbDrawerCategory.ForeColor = Color.FromArgb(20, 25, 35);
                }
                if (txtDrawerFilter != null)
                {
                    txtDrawerFilter.BackColor = Color.White;
                    txtDrawerFilter.ForeColor = Color.FromArgb(20, 25, 35);
                }
                if (lstDrawerMenus != null)
                {
                    lstDrawerMenus.BackColor = Color.White;
                    lstDrawerMenus.ForeColor = Color.FromArgb(20, 25, 35);
                }

                if (settingsTabPanel != null)
                {
                    settingsTabPanel.BackColor = Color.FromArgb(230, 234, 242);
                    settingsTabPanel.ForeColor = Color.FromArgb(25, 30, 40);
                    foreach (Control c in settingsTabPanel.Controls)
                    {
                        if (c is Label)
                        {
                            c.ForeColor = c.Location.Y < 15
                                ? Color.FromArgb(190, 85, 0)
                                : Color.FromArgb(25, 50, 90);
                        }
                        else if (c is CheckBox)
                        {
                            c.ForeColor = Color.FromArgb(20, 110, 50);
                        }
                        else if (c is TextBox || c is ComboBox || c is ListBox)
                        {
                            c.BackColor = Color.White;
                            c.ForeColor = Color.FromArgb(20, 25, 35);
                        }
                    }
                    if (btnCopyMenuToTitle != null)
                    {
                        btnCopyMenuToTitle.BackColor = Color.FromArgb(40, 105, 175);
                        btnCopyMenuToTitle.ForeColor = Color.White;
                    }
                    if (btnResetDefaultTiles != null)
                    {
                        btnResetDefaultTiles.BackColor = Color.FromArgb(65, 92, 132);
                        btnResetDefaultTiles.ForeColor = Color.White;
                    }
                }

                if (guideMainPanel != null)
                {
                    guideMainPanel.BackColor = Color.FromArgb(240, 242, 246);
                    guideMainPanel.ForeColor = Color.FromArgb(25, 30, 40);
                    foreach (Control c in guideMainPanel.Controls)
                    {
                        if (c is Label && c != lblScreenTitle && c != lblStepsList)
                        {
                            c.ForeColor = Color.FromArgb(20, 65, 135);
                        }
                    }
                }
                if (cmbMenuSearch != null)
                {
                    cmbMenuSearch.BackColor = Color.White;
                    cmbMenuSearch.ForeColor = Color.FromArgb(20, 25, 35);
                }
                if (lstQuickSearchResults != null)
                {
                    lstQuickSearchResults.BackColor = Color.FromArgb(250, 252, 255);
                    lstQuickSearchResults.ForeColor = Color.FromArgb(20, 35, 65);
                }
                if (lblScreenTitle != null)
                {
                    lblScreenTitle.ForeColor = Color.FromArgb(185, 80, 0);
                }
                if (stepBox != null)
                {
                    stepBox.BackColor = Color.FromArgb(13, 19, 30);
                }
                if (lblActiveStepTitle != null)
                {
                    bool isAct = (currentSteps != null && currentStepIdx >= 0 && currentStepIdx < currentSteps.Count && currentSteps[currentStepIdx].isActionStep);
                    lblActiveStepTitle.ForeColor = ThemeStepTitleColor(isAct);
                }
                if (lblActiveStepDesc != null)
                {
                    lblActiveStepDesc.ForeColor = Color.FromArgb(25, 32, 45);
                }
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
                if (lblStepsList != null)
                {
                    lblStepsList.ForeColor = Color.FromArgb(30, 42, 62);
                }
                if (btnNextStep != null)
                {
                    btnNextStep.BackColor = Color.FromArgb(0, 118, 215);
                    btnNextStep.ForeColor = Color.White;
                }
            }
            else
            {
                BackColor = Color.FromArgb(18, 22, 32);
                ForeColor = Color.FromArgb(235, 240, 248);
                btnMini.BackColor = Color.FromArgb(52, 78, 118);
                btnMini.ForeColor = Color.White;
                btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                btnMcpStatus.ForeColor = Color.White;
                btnTheme.BackColor = Color.FromArgb(128, 58, 186);
                btnTheme.ForeColor = Color.White;
                chkTopMost.ForeColor = Color.White;

                btnToggleAllMenus.BackColor = Color.FromArgb(26, 98, 178);
                btnToggleAllMenus.ForeColor = Color.White;
                drawerAllMenusPanel.BackColor = Color.FromArgb(26, 34, 48);
                if (cmbDrawerCategory != null)
                {
                    cmbDrawerCategory.BackColor = Color.FromArgb(34, 44, 62);
                    cmbDrawerCategory.ForeColor = Color.FromArgb(235, 240, 250);
                }
                if (txtDrawerFilter != null)
                {
                    txtDrawerFilter.BackColor = Color.FromArgb(34, 44, 62);
                    txtDrawerFilter.ForeColor = Color.FromArgb(235, 240, 250);
                }
                if (lstDrawerMenus != null)
                {
                    lstDrawerMenus.BackColor = Color.FromArgb(28, 36, 52);
                    lstDrawerMenus.ForeColor = Color.FromArgb(235, 240, 250);
                }

                if (settingsTabPanel != null)
                {
                    settingsTabPanel.BackColor = Color.FromArgb(24, 32, 48);
                    settingsTabPanel.ForeColor = Color.White;
                    foreach (Control c in settingsTabPanel.Controls)
                    {
                        if (c is Label)
                        {
                            c.ForeColor = c.Location.Y < 15
                                ? Color.FromArgb(255, 200, 70)
                                : Color.FromArgb(200, 220, 245);
                        }
                        else if (c is CheckBox)
                        {
                            c.ForeColor = Color.FromArgb(180, 230, 190);
                        }
                        else if (c is TextBox || c is ComboBox || c is ListBox)
                        {
                            c.BackColor = Color.FromArgb(34, 44, 62);
                            c.ForeColor = Color.FromArgb(235, 240, 250);
                        }
                    }
                    if (btnCopyMenuToTitle != null)
                    {
                        btnCopyMenuToTitle.BackColor = Color.FromArgb(40, 105, 175);
                        btnCopyMenuToTitle.ForeColor = Color.White;
                    }
                    if (btnResetDefaultTiles != null)
                    {
                        btnResetDefaultTiles.BackColor = Color.FromArgb(65, 92, 132);
                        btnResetDefaultTiles.ForeColor = Color.White;
                    }
                }

                if (guideMainPanel != null)
                {
                    guideMainPanel.BackColor = Color.FromArgb(22, 28, 40);
                    guideMainPanel.ForeColor = Color.White;
                    foreach (Control c in guideMainPanel.Controls)
                    {
                        if (c is Label && c != lblScreenTitle && c != lblStepsList)
                        {
                            c.ForeColor = Color.FromArgb(130, 200, 255);
                        }
                    }
                }
                if (cmbMenuSearch != null)
                {
                    cmbMenuSearch.BackColor = Color.FromArgb(34, 44, 62);
                    cmbMenuSearch.ForeColor = Color.FromArgb(240, 245, 255);
                }
                if (lstQuickSearchResults != null)
                {
                    lstQuickSearchResults.BackColor = Color.FromArgb(28, 38, 56);
                    lstQuickSearchResults.ForeColor = Color.FromArgb(235, 242, 255);
                }
                if (lblScreenTitle != null)
                {
                    lblScreenTitle.ForeColor = Color.FromArgb(255, 215, 80);
                }
                if (stepBox != null)
                {
                    stepBox.BackColor = Color.FromArgb(13, 19, 30);
                }
                if (lblActiveStepTitle != null)
                {
                    bool isAct = (currentSteps != null && currentStepIdx >= 0 && currentStepIdx < currentSteps.Count && currentSteps[currentStepIdx].isActionStep);
                    lblActiveStepTitle.ForeColor = ThemeStepTitleColor(isAct);
                }
                if (lblActiveStepDesc != null)
                {
                    lblActiveStepDesc.ForeColor = Color.White;
                }
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
                if (lblStepsList != null)
                {
                    lblStepsList.ForeColor = Color.FromArgb(215, 225, 240);
                }
                if (btnNextStep != null)
                {
                    btnNextStep.BackColor = Color.FromArgb(0, 118, 215);
                    btnNextStep.ForeColor = Color.White;
                }
            }
            Invalidate(true);
        }

        private void PopulateDrawerMenuList()
        {
            if (suppressQuickSearchEvents || lstDrawerMenus == null) return;
            string qNorm = NormTr(txtDrawerFilter != null ? txtDrawerFilter.Text : "");
            string selectedCat = (cmbDrawerCategory != null && cmbDrawerCategory.SelectedIndex > 0)
                ? cmbDrawerCategory.SelectedItem.ToString()
                : "";

            List<AtlasItem> filtered = new List<AtlasItem>();
            string learnedTarget = "";
            if (qNorm.Length > 0)
            {
                LearnedQueryToMenu.TryGetValue(qNorm, out learnedTarget);
            }

            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                AtlasItem it = SolMenuCatalog[i];
                if (selectedCat.Length > 0 && !string.Equals(it.kategori, selectedCat, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                if (qNorm.Length > 0)
                {
                    if (!string.IsNullOrEmpty(learnedTarget) && string.Equals(it.baslik, learnedTarget, StringComparison.OrdinalIgnoreCase))
                    {
                        filtered.Add(it);
                        continue;
                    }
                    string bNorm = NormTr(it.baslik);
                    string kNorm = NormTr(it.kategori);
                    string yNorm = NormTr(it.menuYolu);
                    string kwNorm = (it.anahtarKelimeler != null && it.anahtarKelimeler.Count > 0)
                        ? NormTr(string.Join(" ", it.anahtarKelimeler.ToArray()))
                        : "";
                    if (bNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0 &&
                        kNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0 &&
                        yNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0 &&
                        kwNorm.IndexOf(qNorm, StringComparison.Ordinal) < 0)
                    {
                        continue;
                    }
                }
                filtered.Add(it);
            }

            filtered.Sort(delegate(AtlasItem a, AtlasItem b)
            {
                if (!string.IsNullOrEmpty(learnedTarget))
                {
                    bool aL = string.Equals(a.baslik, learnedTarget, StringComparison.OrdinalIgnoreCase);
                    bool bL = string.Equals(b.baslik, learnedTarget, StringComparison.OrdinalIgnoreCase);
                    if (aL != bL) return aL ? -1 : 1;
                }
                int ca = GetScreenUsageCount(a.baslik);
                int cb = GetScreenUsageCount(b.baslik);
                if (ca != cb) return cb.CompareTo(ca);
                int catCmp = string.Compare(a.kategori, b.kategori, StringComparison.OrdinalIgnoreCase);
                return catCmp != 0 ? catCmp : string.Compare(a.baslik, b.baslik, StringComparison.OrdinalIgnoreCase);
            });

            lstDrawerMenus.BeginUpdate();
            lstDrawerMenus.Items.Clear();
            for (int i = 0; i < filtered.Count; i++)
            {
                AtlasItem it = filtered[i];
                string prefix = IsLearnedFavoriteScreen(it.baslik) ? "⭐ " : "";
                lstDrawerMenus.Items.Add(prefix + it.baslik + "  [" + it.kategori + "]");
            }
            lstDrawerMenus.EndUpdate();
            if (lstDrawerMenus.Items.Count > 0) lstDrawerMenus.SelectedIndex = 0;
        }

        private string ExtractDrawerSelectedMenuTitle()
        {
            if (lstDrawerMenus == null || lstDrawerMenus.SelectedItem == null) return "";
            string raw = lstDrawerMenus.SelectedItem.ToString();
            int bracketIdx = raw.LastIndexOf("  [");
            string title = bracketIdx > 0 ? raw.Substring(0, bracketIdx).Trim() : raw.Trim();
            if (title.StartsWith("⭐ ")) title = title.Substring(2).Trim();
            return title;
        }

        private void TeachCurrentActiveScreenManual()
        {
            string activeScr = currentTrackedScreen;
            if (string.IsNullOrEmpty(activeScr))
            {
                string rdpScr;
                bool fresh;
                if (CanliMakineEkranPanel.IsRdpErpOpenFromTelemetry(out rdpScr, out fresh) && !string.IsNullOrEmpty(rdpScr))
                {
                    activeScr = rdpScr;
                }
            }
            if (string.IsNullOrEmpty(activeScr))
            {
                activeScr = ExtractDrawerSelectedMenuTitle();
            }
            if (string.IsNullOrEmpty(activeScr))
            {
                MessageBox.Show(this, "Öğretmek için önce Nebim'de doğru ekranı açın veya listeden ekranı seçin.", "📌 Asistana Öğret", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string queryToBind = (txtDrawerFilter != null ? txtDrawerFilter.Text : "").Trim();
            if (queryToBind.Length < 2 && !string.IsNullOrEmpty(LastRequestedQuery))
            {
                queryToBind = LastRequestedQuery;
            }
            if (queryToBind.Length < 2)
            {
                queryToBind = activeScr;
            }

            ApplyLearnedCorrection(queryToBind, activeScr, LastRequestedTileIdx, false);
            PopulateDrawerMenuList();
        }

        private void ApplyLearnedCorrection(string queryOrTileName, string correctScreen, int tileIdx, bool isAuto)
        {
            if (string.IsNullOrEmpty(correctScreen)) return;
            correctScreen = correctScreen.Trim();
            string qKey = NormTr(queryOrTileName);
            if (qKey.Length >= 2)
            {
                LearnedQueryToMenu[qKey] = correctScreen;
            }

            int curCount = GetScreenUsageCount(correctScreen);
            ScreenUsageCounts[correctScreen] = curCount + (isAuto ? 3 : 5);

            AddLearnedMenuToStoreAtlas("Öğrenilen Mağaza Ekranları", correctScreen, qKey.Length >= 2 ? new string[] { qKey } : null);
            EnrichAllAtlasItemsWithGuideMetadata();

            if (tileIdx >= 0 && tileDefs != null && tileIdx < tileDefs.Length)
            {
                tileDefs[tileIdx].primaryMenu = correctScreen;
                SaveCustomTileDefs();
            }

            SaveUserMemory();

            string msg = isAuto
                ? ("🧠 Otomatik Öğrenildi: '" + queryOrTileName + "' artık '" + correctScreen + "' ekranını açacak!")
                : ("📌 Öğretildi: '" + queryOrTileName + "' araması/karosu '" + correctScreen + "' ekranına bağlandı!");
            LogLine("[ÖĞRENME-MOTORU] " + msg);
            if (lblFrameStatus != null)
            {
                lblFrameStatus.Text = msg;
                lblFrameStatus.ForeColor = ThemeOkColor();
                statusMessageHoldTicks = 24;
            }
            if (stepBox != null)
            {
                stepBox.PushLiveAction("🧠 KULLANICI ALIŞKANLIĞI ÖĞRENİLDİ", msg, msg);
            }
        }

        private void RecordScreenUsageAndCheckCorrection(string activeScreen)
        {
            if (string.IsNullOrEmpty(activeScreen)) return;
            activeScreen = activeScreen.Trim();
            if (activeScreen.Length < 2 || SkipNames.Contains(activeScreen)) return;
            if (string.Equals(activeScreen, "Mağaza Hareket Özeti", StringComparison.OrdinalIgnoreCase) && isRefreshingSales) return;
            if (string.Equals(activeScreen, LastRecordedUsageScreen, StringComparison.OrdinalIgnoreCase)) return;

            LastRecordedUsageScreen = activeScreen;
            int cnt = GetScreenUsageCount(activeScreen);
            ScreenUsageCounts[activeScreen] = cnt + 1;
            SaveUserMemory();
        }

        private void OpenSelectedDrawerMenu()
        {
            string title = ExtractDrawerSelectedMenuTitle();
            if (title.Length < 2 && txtDrawerFilter != null)
            {
                title = (txtDrawerFilter.Text ?? "").Trim();
            }
            if (title.Length < 2) return;
            if (isAllMenusExpanded)
            {
                isAllMenusExpanded = false;
                drawerAllMenusPanel.Visible = false;
                btnToggleAllMenus.Text = "🧭 Tüm Menüler & Ekran Ara (" + SolMenuCatalog.Count + " Mağaza Ekranı) — Tıklayın ▾";
                UpdateLayoutHeights();
            }
            suppressQuickSearchEvents = true;
            cmbMenuSearch.Text = title;
            suppressQuickSearchEvents = false;
            if (lstQuickSearchResults != null) lstQuickSearchResults.Visible = false;
            TriggerAutoOpenSelectedMenu(true);
        }

        private class LibraryEntryItem
        {
            public bool isSolutionArticle;
            public string kategori;
            public string baslik;
            public string menuYolu;
            public string ilkVeriAlani;
            public string amacVeNeden;
            public List<string> adimlar = new List<string>();
            public string beklenenSonuc;
            public string sorunVeCozum;
            public string ilgiliEkran;
            public string searchBlob;
        }

        private void ShowSelectedDrawerMenuHelp()
        {
            string title = ExtractDrawerSelectedMenuTitle();
            if (title.Length < 2) title = (txtDrawerFilter != null ? txtDrawerFilter.Text : "").Trim();
            if (title.Length < 2) title = currentTrackedScreen;
            ShowKnowledgeAndSolutionLibraryDialog(title);
        }

        private List<LibraryEntryItem> LoadAllLibraryEntries()
        {
            List<LibraryEntryItem> list = new List<LibraryEntryItem>();
            HashSet<string> addedSolutions = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            // 1. Yerleşik Kritik Çözüm Merkezi Makaleleri (Her zaman hazır garantili omurga)
            string[][] builtInArticles = new string[][]
            {
                new string[] {
                    "Sorun & Hata Çözümleri",
                    "Satış Sorumlusu Silinemiyor ('Fatura Satır' Tablosu İle Bağlantı İhlali Çözümü)",
                    "Mağaza Ayarları → Genel Kodlamalar → Satış Sorumlusu",
                    "Perakende Satış Yapar (Onay Kutusu)",
                    "Geçmiş tarihli herhangi bir satış faturasında veya fiş satırında adı geçen Satış Sorumlusu, Nebim V3 veritabanı bütünlük kuralı (Foreign Key) nedeniyle silinemez.",
                    "1. ADIM (Ekranı Açın): Asistandan veya sol üst 'Ara...' kutusundan 'Satış Sorumlusu' ekranını açın.\n2. ADIM (Kişiyi Seçin): Listeden işten ayrılan veya pasife alınacak personelin satırına çift tıklayarak kartını açın.\n3. ADIM (Mesajı Kapatın): Eğer 'Sil (X)' tuşuna bastıysanız çıkan Bağlantı İhlali uyarısında 'Tamam'a basın.\n4. ADIM (Pasife Alın): Kartın alt kısmındaki 'Perakende Satış Yapar' (ve işaretliyse 'Toptan Satış Yapar') kutucuğunun işaretini kaldırın.\n5. ADIM (Son İşlem - Kaydet): Kartın üst şeridindeki 'Kaydet' (disket simgesi) düğmesine basın.",
                    "Satış sorumlusu geçmiş faturaları bozmadan pasife alınır ve artık POS / Fatura ekranlarında aktif satış sorumlusu listesine gelmez.",
                    "Sil (X) düğmesi yalnızca hiç işlem görmemiş, yeni açılmış hatalı kodlar için kullanılabilir.",
                    "Satış Sorumlusu"
                },
                new string[] {
                    "Sorun & Hata Çözümleri",
                    "NebimAkademi Butonu Neden Açılmıyor ve Çözüm Merkezi Nasıl Kullanılır?",
                    "Üst Şerit (Ribbon) → Genel → NebimAkademi / Asistan 📚 Çözüm Merkezi",
                    "📚 Çözüm Merkezi Arama Kutusu",
                    "Nebim üst şeridindeki 'NebimAkademi' butonu dış internetteki akademi.nebim.com.tr portalına NebimExtra kurumsal SSO şifresiyle bağlanmaya çalışır. Mağaza RDP oturumunda gömülü tarayıcı ve NebimExtra hesabı tanımlı olmadığı için tepki vermez.",
                    "1. ADIM: Nebim içindeki çalışmayan NebimAkademi butonu yerine Asistan üzerindeki '📚 Çözüm Merkezi' butonuna tıklayın.\n2. ADIM: Arama kutusuna yapmak istediğiniz işlemi (örn: 'irsaliye onay', 'sayım', 'masraf', 'iade', 'satış sorumlusu') veya aldığınız hata mesajını yazın.\n3. ADIM: Sağ panelde açılıştan son kayda ve netice kontrolüne kadar tüm 5 aşamalı eylem adımlarını okuyun veya '🔊 Sesli Anlat' ile dinleyin.\n4. ADIM: '🚀 Bu Ekranı Nebim'de Aç ve Canlı Rehberi Başlat' butonuna basarak işlemi doğrudan canlı çerçeve eşliğinde uygulayın.",
                    "İnternet veya NebimExtra şifresine ihtiyaç duymadan tüm 1.372+ mağaza ve merkez ekranının uçtan uca kullanım ve çözüm rehberine anında ulaşılır.",
                    "Görsel Özellikler Devre Dışı uyarısı ise Uzak Masaüstü (RDP) hızlandırma modudur; hata değildir.",
                    "Mağaza Hareket Özeti"
                },
                new string[] {
                    "Sorun & Hata Çözümleri",
                    "Rapor Filtrelerinde 'v3DateFunctionOperator / FilterControl' Çökme Hatası ve Güvenli Kullanım",
                    "Tüm Nebim V3 Raporları (Mağaza Hareket Özeti, Perakende Satışlar Listesi vb.)",
                    "Çalıştır (F5) Butonu",
                    "Nebim V3 raporlarının altındaki DevExpress FilterControl ('[Başlangıç Tarihi] EŞİTTİR [Bugün]') bileşenine klavye kısayolu (Ctrl+A / Ctrl+C) gönderildiğinde veya tarih düğümü yanlış tetiklendiğinde Nebim hata verir.",
                    "1. ADIM: Rapor ekranı açıldığında doğrudan sağ alttaki veya üst şeritteki 'Çalıştır (F5)' düğmesine basın.\n2. ADIM: Tarih değiştirecekseniz '[Bugün]' yazan kutucuğa fare ile tek tıklayıp listeden tarihi seçin.\n3. ADIM: Günlük ciro ve satış adedini görmek için rapor açmanıza bile gerek yoktur; Asistanın üstündeki mavi '⟳ Yenile' butonu doğrudan SQL üzerinden 0.2 saniyede hatasız okur.",
                    "Raporlar hiçbir çökme veya filtre hatası olmadan güvenle listelenir.",
                    "Asistan v2026.10.30.8 sürümüyle FilterControl düğümlerine otomatik tıklamayı tamamen engellemiştir.",
                    "Perakende Satışlar Listesi"
                },
                new string[] {
                    "Stok & Sevkiyat Çözümleri",
                    "Merkezden Gelen Ürünleri (İrsaliyeyi) Onaylama — Uçtan Uca Mal Kabul Rehberi",
                    "Envanter Yönetimi → Merkez ile Transferler → Mağazaya Gelen İrsaliyeyi Onayla - Ürün Detaylı",
                    "İrsaliye Ref. Numarası / Bekleyen İrsaliye Listesi",
                    "Merkez depodan veya başka şubeden mağazaya gönderilen ürünlerin mağaza stoğuna (PM3401) girmesi için irsaliyenin onaylanması gerekir.",
                    "1. ADIM (Ekran Açılışı): '📦 Gelen Ürünleri Onayla' karosuna basın.\n2. ADIM (İrsaliye Seçimi): Açılan ekranda onay bekleyen sevk irsaliyesini seçip 'İleri >' düğmesine basın.\n3. ADIM (Barkod / Adet Kontrolü): Ürün Detaylı ekranda koliden çıkan ürünleri okutun veya miktarların irsaliye ile birebir uyduğunu doğrulayın.\n4. ADIM (Son İşlem - Onayla): Sağ alttaki 'İleri >' / 'Onayla' / 'Kaydet' düğmesine basın.\n5. ADIM (Netice Kontrolü): İrsaliyenin onay bekleyenler listesinden kalktığını ve ürünlerin 'Ürün Envanter Sorgula' ekranında stoğa eklendiğini teyit edin.",
                    "Onaylanan ürünler anında mağaza kullanılabilir envanterine dahil olur ve POS kasada eksi stok uyarısı vermeden satılabilir.",
                    "Eğer bekleyen irsaliye görünmüyorsa sevkiyat henüz merkez tarafından onaylanmamış veya farklı şube koduna kesilmiştir.",
                    "Mağazaya Gelen İrsaliyeyi Onayla - Ürün Detaylı"
                },
                new string[] {
                    "Stok & Sevkiyat Çözümleri",
                    "Eksi Stok / 'Envanter Yetersiz' Uyarısı ve Çözümü",
                    "Envanter Yönetimi → Ürün Envanter Sorgula / Sayım Fişi",
                    "Barkod / Madde Kodu",
                    "Satış, iade veya transfer sırasında ürünün Nebim'deki sistem stoğu 0 veya altında görünüyorsa Nebim işlemi durdurur.",
                    "1. ADIM (Stok Kontrolü): '🔍 Ürün / Stok Sorgula' karosuna tıklayıp ürün barkodunu okutun ve mevcut depo bakiyesini görün.\n2. ADIM (Bekleyen İrsaliye Kontrolü): Ürün mağazaya yeni geldiyse '📦 Gelen Ürünleri Onayla' ekranında onaylanmamış irsaliyesi olup olmadığını kontrol edin ve varsa onaylayın.\n3. ADIM (Renk/Beden/Kod Kontrolü): Benzer başka bir ürün barkodu ile karışıp karışmadığını kontrol edin.\n4. ADIM (Sayım / Merkez Bildirimi): Fiziki rafta ürün var ama sistemde yoksa sayım fişi / merkez stok düzeltmesi için merkez depoya bilgi verin.",
                    "Ürün stoğu güncellendikten sonra satış veya transfer işlemi hatasız tamamlanır.",
                    "Onaylanmamış transferlerdeki adetler onaylanana kadar kullanılabilir envantere dahil edilmez.",
                    "Ürün Envanter Sorgula"
                }
            };

            for (int i = 0; i < builtInArticles.Length; i++)
            {
                string[] a = builtInArticles[i];
                LibraryEntryItem it = new LibraryEntryItem();
                it.isSolutionArticle = true;
                it.kategori = a[0];
                it.baslik = a[1];
                it.menuYolu = a[2];
                it.ilkVeriAlani = a[3];
                it.amacVeNeden = a[4];
                string[] stLines = a[5].Split('\n');
                for (int s = 0; s < stLines.Length; s++) it.adimlar.Add(stLines[s].Trim());
                it.beklenenSonuc = a[6];
                it.sorunVeCozum = a[7];
                it.ilgiliEkran = a[8];
                it.searchBlob = NormTr(it.kategori + " " + it.baslik + " " + it.amacVeNeden + " " + a[5] + " " + it.beklenenSonuc + " " + it.ilgiliEkran);
                list.Add(it);
                addedSolutions.Add(it.baslik);
            }

            // 2. nebim-bilgi-cozum-kutuphanesi.json içindeki Çözüm Makalelerini yükle
            JavaScriptSerializer js = new JavaScriptSerializer();
            js.MaxJsonLength = 32 * 1024 * 1024;
            string[] libPaths = new string[]
            {
                Path.Combine(ResolveOutputDir(), "nebim-bilgi-cozum-kutuphanesi.json"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nebim-bilgi-cozum-kutuphanesi.json")
            };
            Dictionary<string, Dictionary<string, object>> enrichedMenuMap = new Dictionary<string, Dictionary<string, object>>(StringComparer.OrdinalIgnoreCase);

            for (int lp = 0; lp < libPaths.Length; lp++)
            {
                if (!File.Exists(libPaths[lp])) continue;
                try
                {
                    string raw = File.ReadAllText(libPaths[lp], Encoding.UTF8).TrimStart('\uFEFF');
                    Dictionary<string, object> doc = js.Deserialize<Dictionary<string, object>>(raw);
                    if (doc == null) continue;

                    if (doc.ContainsKey("cozumMerkeziMakaleleri") && doc["cozumMerkeziMakaleleri"] is System.Collections.IEnumerable)
                    {
                        foreach (object o in (System.Collections.IEnumerable)doc["cozumMerkeziMakaleleri"])
                        {
                            Dictionary<string, object> d = o as Dictionary<string, object>;
                            if (d == null) continue;
                            string bas = d.ContainsKey("baslik") ? Convert.ToString(d["baslik"]).Trim() : "";
                            if (bas.Length < 3 || !addedSolutions.Add(bas)) continue;

                            LibraryEntryItem it = new LibraryEntryItem();
                            it.isSolutionArticle = true;
                            it.kategori = d.ContainsKey("kategori") ? Convert.ToString(d["kategori"]).Trim() : "Sorun & Hata Çözümleri";
                            it.baslik = bas;
                            it.ilgiliEkran = d.ContainsKey("ilgiliEkran") ? Convert.ToString(d["ilgiliEkran"]).Trim() : "";
                            it.menuYolu = it.ilgiliEkran.Length > 0 ? ("İlgili Ekran: " + it.ilgiliEkran) : it.kategori;
                            it.ilkVeriAlani = d.ContainsKey("ilkVeriAlani") ? Convert.ToString(d["ilkVeriAlani"]).Trim() : "İlgili Ekran Kontrolü";
                            it.amacVeNeden = (d.ContainsKey("sorunOzeti") ? Convert.ToString(d["sorunOzeti"]) : "") +
                                             (d.ContainsKey("nedenOlur") ? (" — Neden: " + Convert.ToString(d["nedenOlur"])) : "");
                            if (d.ContainsKey("cozumAdimlari") && d["cozumAdimlari"] is System.Collections.IEnumerable)
                            {
                                foreach (object so in (System.Collections.IEnumerable)d["cozumAdimlari"])
                                {
                                    string st = Convert.ToString(so ?? "").Trim();
                                    if (st.Length > 0) it.adimlar.Add(st);
                                }
                            }
                            it.beklenenSonuc = d.ContainsKey("beklenenSonuc") ? Convert.ToString(d["beklenenSonuc"]).Trim() : "Sorun giderilerek işlem tamamlanır.";
                            it.sorunVeCozum = d.ContainsKey("onemliNot") ? Convert.ToString(d["onemliNot"]).Trim() : "";
                            it.searchBlob = NormTr(it.kategori + " " + it.baslik + " " + it.amacVeNeden + " " + string.Join(" ", it.adimlar.ToArray()) + " " + it.ilgiliEkran);
                            list.Add(it);
                        }
                    }

                    if (doc.ContainsKey("menuler") && doc["menuler"] is System.Collections.IEnumerable)
                    {
                        foreach (object o in (System.Collections.IEnumerable)doc["menuler"])
                        {
                            Dictionary<string, object> m = o as Dictionary<string, object>;
                            if (m == null || !m.ContainsKey("baslik")) continue;
                            string b = Convert.ToString(m["baslik"]).Trim();
                            if (b.Length > 0 && !enrichedMenuMap.ContainsKey(b))
                            {
                                enrichedMenuMap[b] = m;
                            }
                        }
                    }
                    break;
                }
                catch { }
            }

            // 3. hata-sozlugu.json içindeki uyarı/hata çözümlerini de Çözüm Merkezi'ne dahil et
            try
            {
                string[] errPaths = new string[]
                {
                    Path.Combine(ResolveOutputDir(), "hata-sozlugu.json"),
                    Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hata-sozlugu.json")
                };
                for (int ep = 0; ep < errPaths.Length; ep++)
                {
                    if (!File.Exists(errPaths[ep])) continue;
                    string rawErr = File.ReadAllText(errPaths[ep], Encoding.UTF8).TrimStart('\uFEFF');
                    Dictionary<string, object> edoc = js.Deserialize<Dictionary<string, object>>(rawErr);
                    if (edoc != null && edoc.ContainsKey("hatalar") && edoc["hatalar"] is System.Collections.IEnumerable)
                    {
                        foreach (object o in (System.Collections.IEnumerable)edoc["hatalar"])
                        {
                            Dictionary<string, object> h = o as Dictionary<string, object>;
                            if (h == null) continue;
                            string bas = h.ContainsKey("baslik") ? Convert.ToString(h["baslik"]).Trim() : "";
                            if (bas.Length < 2 || !addedSolutions.Add("Nebim Uyarısı: " + bas)) continue;
                            string aciklama = h.ContainsKey("aciklama") ? Convert.ToString(h["aciklama"]).Trim() : "";
                            string yapilacak = h.ContainsKey("yapilacak") ? Convert.ToString(h["yapilacak"]).Trim() : "";

                            LibraryEntryItem it = new LibraryEntryItem();
                            it.isSolutionArticle = true;
                            it.kategori = "Sorun & Hata Çözümleri";
                            it.baslik = "Nebim Uyarısı Çözümü: " + bas;
                            it.menuYolu = "Nebim V3 Uyarı / Hata Sözlüğü";
                            it.ilkVeriAlani = "Uyarı Penceresi / İlgili Veri Alanı";
                            it.amacVeNeden = aciklama;
                            it.adimlar.Add("1. ADIM (Uyarıyı Okuyun): " + aciklama);
                            it.adimlar.Add("2. ADIM (Çözüm Eylemi): " + yapilacak);
                            it.adimlar.Add("3. ADIM (Doğrulama): Gerekli alanı düzelttikten sonra işlemi tekrar çalıştırın veya kaydedin.");
                            it.beklenenSonuc = "Uyarı giderilir ve Nebim işlemi normal şekilde tamamlar.";
                            it.sorunVeCozum = yapilacak;
                            it.searchBlob = NormTr(it.baslik + " " + aciklama + " " + yapilacak);
                            list.Add(it);
                        }
                    }
                    break;
                }
            }
            catch { }

            // 4. Tüm Mağaza ve Merkez Menülerini (SolMenuCatalog - 1.372+ Ekran) Uçtan Uca 5 Adımlı Rehberleriyle ekle
            for (int i = 0; i < SolMenuCatalog.Count; i++)
            {
                AtlasItem src = SolMenuCatalog[i];
                LibraryEntryItem it = new LibraryEntryItem();
                it.isSolutionArticle = false;
                it.kategori = src.kategori ?? "Genel";
                it.baslik = src.baslik ?? "";
                it.menuYolu = src.menuYolu ?? (it.kategori + " → " + it.baslik);
                it.ilkVeriAlani = !string.IsNullOrEmpty(src.ilkVeriAlani) ? src.ilkVeriAlani : InferFirstInputField(it.kategori, it.baslik, it.menuYolu);
                it.ilgiliEkran = it.baslik;

                Dictionary<string, object> em;
                if (enrichedMenuMap.TryGetValue(it.baslik, out em) && em != null)
                {
                    it.amacVeNeden = em.ContainsKey("amac") ? Convert.ToString(em["amac"]).Trim() : "";
                    it.beklenenSonuc = em.ContainsKey("beklenenSonuc") ? Convert.ToString(em["beklenenSonuc"]).Trim() : "";
                    it.sorunVeCozum = em.ContainsKey("olasiSorunVeCozum") ? Convert.ToString(em["olasiSorunVeCozum"]).Trim() : "";
                    if (em.ContainsKey("rehberAdimlari") && em["rehberAdimlari"] is System.Collections.IEnumerable)
                    {
                        foreach (object so in (System.Collections.IEnumerable)em["rehberAdimlari"])
                        {
                            string st = Convert.ToString(so ?? "").Trim();
                            if (st.Length > 0) it.adimlar.Add(st);
                        }
                    }
                }

                if (it.adimlar.Count == 0)
                {
                    List<string> defSteps = BuildDefaultGuideSteps(it.kategori, it.baslik, it.ilkVeriAlani);
                    for (int s = 0; s < defSteps.Count; s++) it.adimlar.Add(defSteps[s]);
                }
                if (string.IsNullOrEmpty(it.amacVeNeden))
                {
                    it.amacVeNeden = "'" + it.baslik + "' (" + it.menuYolu + ") ekranında " + it.ilkVeriAlani + " alanından başlayarak son kayıt/rapor sonucuna kadar adım adım işlem kılavuzu.";
                }
                if (string.IsNullOrEmpty(it.beklenenSonuc))
                {
                    it.beklenenSonuc = "Son adımda Çalıştır (F5) veya Kaydet düğmesine basıldığında işlem tamamlanır ve sonuç ekranda/listede doğrulanır.";
                }
                if (string.IsNullOrEmpty(it.sorunVeCozum))
                {
                    it.sorunVeCozum = "Zorunlu alan veya filtre uyarısı alırsanız '" + it.ilkVeriAlani + "' ve depo (" + Sube.Kod + ") alanlarının dolu olduğunu kontrol edin.";
                }

                it.searchBlob = NormTr(it.kategori + " " + it.baslik + " " + it.menuYolu + " " + it.ilkVeriAlani + " " + it.amacVeNeden + " " + string.Join(" ", it.adimlar.ToArray()));
                list.Add(it);
            }

            return list;
        }

        private void ShowKnowledgeAndSolutionLibraryDialog(string initialSearch)
        {
            Show();
            if (isCompactMode) ToggleCompactMode();
            Activate();

            List<LibraryEntryItem> allEntries = LoadAllLibraryEntries();
            List<LibraryEntryItem> currentFiltered = new List<LibraryEntryItem>();

            using (Form dlg = new Form
            {
                Text = "📚 Nebim Bilgi & Çözüm Kütüphanesi — Tam Yetkili Adım Adım Eylem & Çözüm Merkezi (" + Sube.Ad + " - " + Sube.Kod + ")",
                FormBorderStyle = FormBorderStyle.Sizable,
                StartPosition = FormStartPosition.CenterScreen,
                Size = new Size(980, 660),
                MinimumSize = new Size(860, 560),
                BackColor = Color.FromArgb(18, 25, 38),
                ForeColor = Color.White,
                TopMost = true
            })
            {
                Label lblHeader = new Label
                {
                    Text = "📚 NEBİM V3 BİLGİ & ÇÖZÜM KÜTÜPHANESİ — Tüm Menüler, Uçtan Uca Eylem Adımları ve Hata Çözüm Merkezi",
                    Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(255, 205, 70),
                    Location = new Point(14, 10),
                    Size = new Size(930, 22),
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                };
                dlg.Controls.Add(lblHeader);

                Label lblCat = new Label
                {
                    Text = "Bölüm / Modül:",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(180, 215, 255),
                    Location = new Point(14, 40),
                    Size = new Size(98, 22)
                };
                dlg.Controls.Add(lblCat);

                ComboBox cmbCat = new ComboBox
                {
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(28, 38, 56),
                    ForeColor = Color.White,
                    Location = new Point(114, 37),
                    Size = new Size(270, 26)
                };
                cmbCat.Items.Add("🌟 Tümü (Çözüm Merkezi + Tüm Menüler)");
                cmbCat.Items.Add("🛠️ Sadece Sorun & Hata Çözüm Merkezi");
                cmbCat.Items.Add("🧭 Sadece Mağaza & ERP Menü Rehberleri");
                HashSet<string> cats = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                for (int i = 0; i < allEntries.Count; i++)
                {
                    if (!allEntries[i].isSolutionArticle && allEntries[i].kategori.Length > 0 && cats.Add(allEntries[i].kategori))
                    {
                        cmbCat.Items.Add("📁 " + allEntries[i].kategori);
                    }
                }
                cmbCat.SelectedIndex = 0;
                dlg.Controls.Add(cmbCat);

                Label lblSearch = new Label
                {
                    Text = "🔍 Kütüphanede Ara:",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    ForeColor = Color.FromArgb(180, 215, 255),
                    Location = new Point(396, 40),
                    Size = new Size(128, 22)
                };
                dlg.Controls.Add(lblSearch);

                TextBox txtSearch = new TextBox
                {
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    BackColor = Color.FromArgb(28, 38, 56),
                    ForeColor = Color.White,
                    Location = new Point(526, 37),
                    Size = new Size(320, 25),
                    Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                };
                dlg.Controls.Add(txtSearch);

                Button btnClearSearch = new Button
                {
                    Text = "Temizle",
                    Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                    BackColor = Color.FromArgb(65, 85, 115),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(854, 36),
                    Size = new Size(94, 26),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Top | AnchorStyles.Right
                };
                btnClearSearch.FlatAppearance.BorderSize = 0;
                dlg.Controls.Add(btnClearSearch);

                ListBox lstItems = new ListBox
                {
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Regular),
                    BackColor = Color.FromArgb(24, 33, 48),
                    ForeColor = Color.White,
                    Location = new Point(14, 70),
                    Size = new Size(370, 495),
                    IntegralHeight = false,
                    Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left
                };
                dlg.Controls.Add(lstItems);

                TextBox txtDetail = new TextBox
                {
                    Multiline = true,
                    ReadOnly = true,
                    ScrollBars = ScrollBars.Vertical,
                    Font = new Font("Segoe UI", 9.8f, FontStyle.Regular),
                    BackColor = Color.FromArgb(14, 20, 32),
                    ForeColor = Color.FromArgb(235, 242, 252),
                    Location = new Point(392, 70),
                    Size = new Size(556, 495),
                    Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
                };
                dlg.Controls.Add(txtDetail);

                Button btnOpenInNebim = new Button
                {
                    Text = "🚀 Bu Ekranı Şimdi Nebim'de Aç ve Adım Adım Göster",
                    Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                    BackColor = Color.FromArgb(22, 152, 74),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(14, 574),
                    Size = new Size(410, 36),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Left
                };
                btnOpenInNebim.FlatAppearance.BorderSize = 0;
                dlg.Controls.Add(btnOpenInNebim);

                Button btnReadAloud = new Button
                {
                    Text = "🔊 Adımları Sesli Anlat",
                    Font = new Font("Segoe UI", 9.2f, FontStyle.Bold),
                    BackColor = Color.FromArgb(0, 128, 210),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(432, 574),
                    Size = new Size(210, 36),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Left
                };
                btnReadAloud.FlatAppearance.BorderSize = 0;
                dlg.Controls.Add(btnReadAloud);

                Button btnStopVoice = new Button
                {
                    Text = "🔇 Sesi Durdur",
                    Font = new Font("Segoe UI", 9.0f, FontStyle.Bold),
                    BackColor = Color.FromArgb(175, 42, 48),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(650, 574),
                    Size = new Size(140, 36),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Left
                };
                btnStopVoice.FlatAppearance.BorderSize = 0;
                dlg.Controls.Add(btnStopVoice);

                Button btnCloseDlg = new Button
                {
                    Text = "Kapat ✕",
                    Font = new Font("Segoe UI", 9.2f, FontStyle.Bold),
                    BackColor = Color.FromArgb(80, 95, 120),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    Location = new Point(798, 574),
                    Size = new Size(150, 36),
                    Cursor = Cursors.Hand,
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Right
                };
                btnCloseDlg.FlatAppearance.BorderSize = 0;
                btnCloseDlg.Click += delegate { dlg.Close(); };
                dlg.Controls.Add(btnCloseDlg);

                Action renderSelectedDetail = delegate
                {
                    int idx = lstItems.SelectedIndex;
                    if (idx < 0 || idx >= currentFiltered.Count)
                    {
                        txtDetail.Text = "Sol listeden bir çözüm makalesi veya mağaza menüsü seçin.";
                        return;
                    }
                    LibraryEntryItem sel = currentFiltered[idx];
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("======================================================================");
                    sb.AppendLine((sel.isSolutionArticle ? "🛠️ ÇÖZÜM MERKEZİ REHBERİ: " : "🧭 NEBİM EKRAN & EYLEM KILAVUZU: ") + sel.baslik.ToUpperInvariant());
                    sb.AppendLine("======================================================================");
                    sb.AppendLine("• Kategori / Grup      : " + sel.kategori);
                    sb.AppendLine("• Menü Yolu / Konum    : " + sel.menuYolu);
                    sb.AppendLine("• İlk Odaklanacak Alan : " + sel.ilkVeriAlani);
                    if (!string.IsNullOrEmpty(sel.ilgiliEkran))
                    {
                        sb.AppendLine("• Açılacak Nebim Ekranı: " + sel.ilgiliEkran);
                    }
                    sb.AppendLine();
                    sb.AppendLine("📌 AMAÇ VE AÇIKLAMA:");
                    sb.AppendLine("   " + sel.amacVeNeden);
                    sb.AppendLine();
                    sb.AppendLine("----------------------------------------------------------------------");
                    sb.AppendLine("📋 SON İŞLEM VE NETİCE ALININCAYA KADAR ADIM ADIM EYLEM REHBERİ:");
                    sb.AppendLine("----------------------------------------------------------------------");
                    for (int s = 0; s < sel.adimlar.Count; s++)
                    {
                        sb.AppendLine("   " + sel.adimlar[s]);
                        sb.AppendLine();
                    }
                    sb.AppendLine("----------------------------------------------------------------------");
                    sb.AppendLine("🎯 BEKLENEN NETİCE (SONUÇ DOĞRULAMA):");
                    sb.AppendLine("   " + sel.beklenenSonuc);
                    sb.AppendLine();
                    sb.AppendLine("⚠️ DİKKAT EDİLECEKLER & OLASI UYARI ÇÖZÜMÜ:");
                    sb.AppendLine("   " + sel.sorunVeCozum);
                    txtDetail.Text = sb.ToString();
                    txtDetail.SelectionStart = 0;
                    txtDetail.ScrollToCaret();
                };

                Action refreshFilter = delegate
                {
                    string q = NormTr(txtSearch.Text ?? "").Trim();
                    string[] tokens = q.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    int catIdx = cmbCat.SelectedIndex;
                    string catName = catIdx >= 3 ? cmbCat.SelectedItem.ToString().Substring(2).Trim() : "";

                    currentFiltered.Clear();
                    for (int i = 0; i < allEntries.Count; i++)
                    {
                        LibraryEntryItem it = allEntries[i];
                        if (catIdx == 1 && !it.isSolutionArticle) continue;
                        if (catIdx == 2 && it.isSolutionArticle) continue;
                        if (catIdx >= 3 && (it.isSolutionArticle || !string.Equals(it.kategori, catName, StringComparison.OrdinalIgnoreCase))) continue;

                        if (tokens.Length > 0)
                        {
                            bool matchAll = true;
                            for (int t = 0; t < tokens.Length; t++)
                            {
                                if (!it.searchBlob.Contains(tokens[t]))
                                {
                                    matchAll = false;
                                    break;
                                }
                            }
                            if (!matchAll) continue;
                        }
                        currentFiltered.Add(it);
                    }

                    lstItems.BeginUpdate();
                    lstItems.Items.Clear();
                    int limit = Math.Min(currentFiltered.Count, 600);
                    for (int i = 0; i < limit; i++)
                    {
                        LibraryEntryItem it = currentFiltered[i];
                        string tag = it.isSolutionArticle ? "🛠️ [ÇÖZÜM] " : ("🧭 [" + it.kategori + "] ");
                        lstItems.Items.Add(tag + it.baslik);
                    }
                    lstItems.EndUpdate();
                    if (lstItems.Items.Count > 0) lstItems.SelectedIndex = 0;
                    else renderSelectedDetail();
                };

                lstItems.SelectedIndexChanged += delegate { renderSelectedDetail(); };
                cmbCat.SelectedIndexChanged += delegate { refreshFilter(); };
                txtSearch.TextChanged += delegate { refreshFilter(); };
                btnClearSearch.Click += delegate
                {
                    txtSearch.Text = "";
                    cmbCat.SelectedIndex = 0;
                    txtSearch.Focus();
                };

                btnReadAloud.Click += delegate
                {
                    int idx = lstItems.SelectedIndex;
                    if (idx < 0 || idx >= currentFiltered.Count) return;
                    LibraryEntryItem sel = currentFiltered[idx];
                    StringBuilder sbSpeech = new StringBuilder();
                    sbSpeech.Append(sel.baslik).Append(". ");
                    sbSpeech.Append(sel.amacVeNeden).Append(" ");
                    for (int s = 0; s < sel.adimlar.Count; s++)
                    {
                        sbSpeech.Append(sel.adimlar[s]).Append(" ");
                    }
                    sbSpeech.Append("Beklenen netice: ").Append(sel.beklenenSonuc);
                    SesliAsistan.Aktif = true;
                    GuncelleSesliButonGorunumu();
                    SesliAsistan.Konus(sbSpeech.ToString(), true);
                };

                btnStopVoice.Click += delegate { SesliAsistan.Durdur(); };

                Action openSelectedInNebim = delegate
                {
                    int idx = lstItems.SelectedIndex;
                    if (idx < 0 || idx >= currentFiltered.Count) return;
                    LibraryEntryItem sel = currentFiltered[idx];
                    string targetMenu = !string.IsNullOrEmpty(sel.ilgiliEkran) ? sel.ilgiliEkran : sel.baslik;
                    dlg.Close();
                    suppressQuickSearchEvents = true;
                    cmbMenuSearch.Text = targetMenu;
                    suppressQuickSearchEvents = false;
                    TriggerAutoOpenSelectedMenu(true);
                };

                btnOpenInNebim.Click += delegate { openSelectedInNebim(); };
                lstItems.DoubleClick += delegate { openSelectedInNebim(); };

                string cleanInit = (initialSearch ?? "").Trim();
                if (cleanInit.StartsWith("🧭") || cleanInit.Contains("Bekleniyor")) cleanInit = "";
                if (cleanInit.Length >= 2)
                {
                    txtSearch.Text = cleanInit;
                    if (currentFiltered.Count == 0)
                    {
                        txtSearch.Text = "";
                        refreshFilter();
                    }
                }
                else
                {
                    refreshFilter();
                }

                dlg.ShowDialog(this);
            }
        }

        private void SyncPersonnelAndCommissionToPanel()
        {
            // Personel ve Prim aktarımı bu sürümden kaldırılmıştır; hiçbir işlem yapmaz.
            return;
        }

        private void RunSystemIntegrityRestoreAndReport(bool showDialog)
        {
            try
            {
                long memBeforeKb = GC.GetTotalMemory(false) / 1024;
                string outDir = ResolveOutputDir();
                string kuyrukDir = Path.Combine(outDir, "kuyruk");
                Directory.CreateDirectory(kuyrukDir);

                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = "🛠️ Sistem bütünlüğü onarılıyor, çöp kayıtlar temizleniyor ve değerlendirme raporu hazırlanıyor...";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 20;
                }
                if (stepBox != null)
                {
                    stepBox.PushLiveAction(
                        "🛠️ SİSTEM BÜTÜNLÜĞÜ ONARIM & RESTORE BAŞLADI",
                        "Kilitlenmeler, çakışmalar ve çöp kayıtlar temizleniyor; doğru kullanım ve öğrenilmiş davranışlar korunuyor...",
                        "⏳ Çapraz Atlas ve mağaza hafıza bütünlüğü doğrulanıyor...");
                }
                Application.DoEvents();

                // 1. Kilitlenme / Çakışma Çözümü
                StopTileSpinner();
                isRefreshingSales = false;
                completionCountdown = 0;
                RdpVerifiedGraceTicks = 0;
                lastAutoClosedScreen = "";
                if (frameOverlay != null) frameOverlay.HideFrame();

                int cleanedQueueFiles = 0;
                try
                {
                    string[] qFiles = Directory.GetFiles(kuyrukDir, "*.*");
                    for (int i = 0; i < qFiles.Length; i++)
                    {
                        try { File.Delete(qFiles[i]); cleanedQueueFiles++; } catch { }
                    }
                }
                catch { }

                // Sunucu / RDP NebimYardimci önbelleklerini de sıfırlat
                string helperRestoreSummary = "Yerel mod";
                try
                {
                    string reqId = DateTime.Now.ToString("yyyyMMddHHmmss") + "-onr-" + Guid.NewGuid().ToString("N").Substring(0, 4);
                    string tmpP = Path.Combine(kuyrukDir, "istek-" + reqId + ".tmp");
                    string reqP = Path.Combine(kuyrukDir, "istek-" + reqId + ".json");
                    string resP = Path.Combine(kuyrukDir, "sonuc-" + reqId + ".json");
                    File.WriteAllText(tmpP, "{\"id\":\"" + JsonEscape(reqId) + "\",\"zaman\":\"" + JsonEscape(DateTime.Now.ToString("s")) + "\",\"islem\":\"sistem-onar\"}", new UTF8Encoding(false));
                    if (File.Exists(reqP)) File.Delete(reqP);
                    File.Move(tmpP, reqP);
                    Stopwatch swH = Stopwatch.StartNew();
                    while (swH.ElapsedMilliseconds < 4500)
                    {
                        Thread.Sleep(90);
                        if (File.Exists(resP))
                        {
                            string rawH = File.ReadAllText(resP, Encoding.UTF8);
                            try { File.Delete(resP); } catch { }
                            string msgH = ExtractJsonStringField(rawH, "mesaj");
                            if (!string.IsNullOrEmpty(msgH)) helperRestoreSummary = msgH;
                            break;
                        }
                    }
                    try { if (File.Exists(reqP)) File.Delete(reqP); } catch { }
                }
                catch { }

                // 2. Doğrulanmış Ortak Atlas Referans Kümesini Oluştur
                HashSet<string> validScreensNorm = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (AtlasItem it in SolMenuCatalog)
                {
                    if (it != null && !string.IsNullOrEmpty(it.baslik) && !IsPollutedUiControlName(it.baslik))
                    {
                        validScreensNorm.Add(NormTr(it.baslik));
                    }
                }

                // 3. Kullanım İstatistiklerini (ScreenUsageCounts) Temizle — Geçerli Kullanımları Koru
                int purgedUsageCount = 0;
                int keptUsageCount = 0;
                List<string> usageKeys = new List<string>(ScreenUsageCounts.Keys);
                for (int i = 0; i < usageKeys.Count; i++)
                {
                    string k = usageKeys[i];
                    if (IsPollutedUiControlName(k) || ScreenUsageCounts[k] <= 0)
                    {
                        ScreenUsageCounts.Remove(k);
                        purgedUsageCount++;
                    }
                    else
                    {
                        keptUsageCount++;
                    }
                }

                // 4. Öğrenilmiş Eşleşmeleri (LearnedQueryToMenu) Denetle — Doğru Öğretileri Koru, Çöp Olanları Sil
                int purgedLearnedCount = 0;
                int keptLearnedCount = 0;
                List<string> keptLearnedDetails = new List<string>();
                List<string> purgedLearnedDetails = new List<string>();
                List<string> lKeys = new List<string>(LearnedQueryToMenu.Keys);
                for (int i = 0; i < lKeys.Count; i++)
                {
                    string qk = lKeys[i];
                    string targetVal = LearnedQueryToMenu[qk];
                    string tNorm = NormTr(targetVal);
                    bool hasConflict = (!qk.Contains("kontrol listesi") && tNorm.Contains("kontrol listesi")) ||
                                       (!qk.Contains("rapor") && !qk.Contains("listesi") && tNorm.Contains("v.u.k")) ||
                                       (qk.Contains("satis sorumlusu") && tNorm == "tedarikci");
                    if (!IsPollutedUiControlName(targetVal) && validScreensNorm.Contains(tNorm) && !hasConflict)
                    {
                        keptLearnedCount++;
                        keptLearnedDetails.Add("'" + qk + "' -> '" + targetVal + "'");
                    }
                    else
                    {
                        LearnedQueryToMenu.Remove(qk);
                        purgedLearnedCount++;
                        purgedLearnedDetails.Add("'" + qk + "' -> '" + targetVal + "'");
                    }
                }
                SaveUserMemory();

                // 5. Hızlı Erişim Karolarını (tileDefs) Denetle — Bozuk Karoları Varsayılana Restore Et
                QuickTileDef[] defaults = BuildDefaultTileDefs();
                int restoredTileCount = 0;
                int keptTileCount = 0;
                for (int i = 0; i < tileDefs.Length && i < defaults.Length; i++)
                {
                    string pm = (tileDefs[i].primaryMenu ?? "").Trim();
                    string pmNorm = NormTr(pm);
                    bool tileCorrupted = IsPollutedUiControlName(pm) ||
                                         !validScreensNorm.Contains(pmNorm) ||
                                         pmNorm.Contains("v.u.k") ||
                                         (NormTr(tileDefs[i].title).Contains("satis sorumlusu") && pmNorm == "tedarikci");
                    if (tileCorrupted)
                    {
                        tileDefs[i].title = defaults[i].title;
                        tileDefs[i].primaryMenu = defaults[i].primaryMenu;
                        tileDefs[i].fallbackMenu = defaults[i].fallbackMenu;
                        tileDefs[i].sira = defaults[i].sira;
                        tileDefs[i].color = defaults[i].color;
                        if (i < quickTileButtons.Count)
                        {
                            quickTileButtons[i].Text = tileDefs[i].title;
                            quickTileButtons[i].BackColor = tileDefs[i].color;
                        }
                        restoredTileCount++;
                    }
                    else
                    {
                        keptTileCount++;
                    }
                }
                SaveCustomTileDefs();

                // 6. sira-hafiza.json İçindeki Bozuk Satır Kayıtlarını Temizle, Doğrulanmış Sıraları Koru
                int keptSiraCount = 0;
                int purgedSiraCount = 0;
                try
                {
                    string siraPath = Path.Combine(outDir, "sira-hafiza.json");
                    Dictionary<string, int> cleanSira = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                    cleanSira["satis sorumlusu"] = 4;
                    cleanSira["iade gelen urunleri onayla (onl.bayi) - fis bazinda"] = 1;
                    cleanSira["magazaya gelen irsaliyeyi onayla - urun detayli"] = 1;
                    cleanSira["toptan alis faturasi"] = 1;
                    cleanSira["magaza sayim fisi"] = 1;
                    cleanSira["ofis ve magaza depolari sayim fisi"] = 1;
                    cleanSira["gunluk magaza ciro raporu"] = 1;
                    if (File.Exists(siraPath))
                    {
                        string rawS = File.ReadAllText(siraPath, Encoding.UTF8);
                        MatchCollection mS = Regex.Matches(rawS, "\"([^\"]+)\"\\s*:\\s*(\\d+)");
                        foreach (Match m in mS)
                        {
                            string sk = m.Groups[1].Value.Trim();
                            int sv = 1;
                            int.TryParse(m.Groups[2].Value, out sv);
                            if (sk == "surum" || sk == "guncelleme" || sk == "aciklama" || sk == "siralar") continue;
                            if (sk == "tedarikci" || sv < 1 || sv > 8 || IsPollutedUiControlName(sk))
                            {
                                purgedSiraCount++;
                            }
                            else
                            {
                                cleanSira[sk] = sv;
                            }
                        }
                    }
                    keptSiraCount = cleanSira.Count;
                    StringBuilder sbSira = new StringBuilder();
                    sbSira.AppendLine("{");
                    sbSira.AppendLine("  \"surum\": \"6.9\",");
                    sbSira.AppendLine("  \"guncelleme\": \"" + DateTime.Now.ToString("s") + "\",");
                    sbSira.AppendLine("  \"aciklama\": \"Sistem Onarım & Çapraz Test Doğrulanmış Sıra Hafızası\",");
                    sbSira.AppendLine("  \"siralar\": {");
                    int sIdx = 0;
                    foreach (KeyValuePair<string, int> kv in cleanSira)
                    {
                        sIdx++;
                        string comma = sIdx < cleanSira.Count ? "," : "";
                        sbSira.AppendLine("    \"" + JsonEscape(kv.Key) + "\": " + kv.Value + comma);
                    }
                    sbSira.AppendLine("  }");
                    sbSira.AppendLine("}");
                    AtomicWriteText(siraPath, sbSira.ToString());
                }
                catch { }

                // 7. Atlas ve Arayüz Listelerini Yenile + Bellek Temizliği (GC)
                LoadStoreCatalogFromEkranlarJson();
                EnrichAllAtlasItemsWithGuideMetadata();
                PopulateDrawerMenuList();
                PopulateEditingMenusList();

                GC.Collect();
                GC.WaitForPendingFinalizers();
                GC.Collect();
                long memAfterKb = GC.GetTotalMemory(true) / 1024;

                // 8. Son Logları ve Çapraz Test Kayıtlarını Analiz Ederek Değerlendirme Raporu Yaz
                List<string> recentCrossRed = new List<string>();
                List<string> recentCrossMap = new List<string>();
                List<string> recentTimeouts = new List<string>();
                int verifiedSuccessCount = 0;
                try
                {
                    string yLogPath = Path.Combine(outDir, "yardimci-log.txt");
                    if (File.Exists(yLogPath))
                    {
                        string[] lines = File.ReadAllLines(yLogPath, Encoding.UTF8);
                        int startL = Math.Max(0, lines.Length - 250);
                        for (int i = startL; i < lines.Length; i++)
                        {
                            string ln = lines[i];
                            if (ln.IndexOf("ÇAPRAZ-TEST RED", StringComparison.OrdinalIgnoreCase) >= 0 && recentCrossRed.Count < 8)
                                recentCrossRed.Add(ln);
                            else if (ln.IndexOf("ÇAPRAZ-HARİTA EŞLEME", StringComparison.OrdinalIgnoreCase) >= 0 && recentCrossMap.Count < 8)
                                recentCrossMap.Add(ln);
                            else if (ln.IndexOf("BAŞARISIZ", StringComparison.OrdinalIgnoreCase) >= 0 && recentTimeouts.Count < 8)
                                recentTimeouts.Add(ln);
                            else if (ln.IndexOf("DOĞRULANDI", StringComparison.OrdinalIgnoreCase) >= 0 || (ln.IndexOf("Sonuç ", StringComparison.OrdinalIgnoreCase) >= 0 && ln.IndexOf("acildi", StringComparison.OrdinalIgnoreCase) >= 0))
                                verifiedSuccessCount++;
                        }
                    }
                }
                catch { }

                List<KeyValuePair<string, int>> topUsed = new List<KeyValuePair<string, int>>(ScreenUsageCounts);
                topUsed.Sort(delegate(KeyValuePair<string, int> a, KeyValuePair<string, int> b) { return b.Value.CompareTo(a.Value); });

                string reportTxtPath = Path.Combine(outDir, "sistem-onarim-degerlendirme-raporu.txt");
                string reportJsonPath = Path.Combine(outDir, "sistem-onarim-degerlendirme-raporu.json");
                string historyPath = Path.Combine(outDir, "onarim-gecmisi.jsonl");

                StringBuilder sbRep = new StringBuilder();
                sbRep.AppendLine("================================================================================");
                sbRep.AppendLine("  NEBİM ASİSTANI — SİSTEM BÜTÜNLÜĞÜ ONARIM (RESTORE) VE DEĞERLENDİRME RAPORU");
                sbRep.AppendLine("================================================================================");
                sbRep.AppendLine("Rapor Tarihi / Saati       : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sbRep.AppendLine("Tetikleyen Asistan Profili : " + Sube.Ad + " Şube Asistanı (" + Sube.Kod + " - v6.0) + Ortak Çapraz Atlas");
                sbRep.AppendLine("Sunucu Yardımcı Durumu     : " + helperRestoreSummary);
                sbRep.AppendLine("Birleşik Atlas Ekran Sayısı: " + SolMenuCatalog.Count + " Doğrulanmış Ekran (Mahmutbey STORE + Merkez ERP)");
                sbRep.AppendLine("Bellek Optimizasyonu (GC)  : " + memBeforeKb + " KB -> " + memAfterKb + " KB");
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine("1. TEMİZLENEN ÇÖP KAYIT, KİLİT VE ÇAKIŞMA ÖZETİ");
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine(" • Temizlenen Takılı Kuyruk/Kilit Dosyası : " + cleanedQueueFiles + " adet");
                sbRep.AppendLine(" • Silinen Parazit Kullanım Kaydı         : " + purgedUsageCount + " adet");
                sbRep.AppendLine(" • Silinen Hatalı/Çelişkili Öğrenme Kaydı : " + purgedLearnedCount + " adet" + (purgedLearnedDetails.Count > 0 ? (" (" + string.Join(", ", purgedLearnedDetails.ToArray()) + ")") : ""));
                sbRep.AppendLine(" • Varsayılana Restore Edilen Bozuk Karo  : " + restoredTileCount + " / 9 karo");
                sbRep.AppendLine(" • Temizlenen Hatalı Sıra Hafıza Kaydı    : " + purgedSiraCount + " adet");
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine("2. KORUNAN DOĞRU KULLANIM VE ÖĞRENİLMİŞ DAVRANIŞLAR");
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine(" • Korunan Doğru Hızlı Erişim Karosu      : " + keptTileCount + " / 9 karo");
                sbRep.AppendLine(" • Korunan Doğrulanmış Sıra Hafızası      : " + keptSiraCount + " ekran");
                sbRep.AppendLine(" • Korunan '📌 Öğret' Kullanıcı Eşleşmesi  : " + keptLearnedCount + " adet" + (keptLearnedDetails.Count > 0 ? (" (" + string.Join(", ", keptLearnedDetails.ToArray()) + ")") : ""));
                sbRep.AppendLine(" • Korunan Sık Kullanılan Ekranlar (Top 8):");
                for (int i = 0; i < topUsed.Count && i < 8; i++)
                {
                    sbRep.AppendLine("    - " + topUsed[i].Key + " (" + topUsed[i].Value + " kez açıldı)");
                }
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine("3. SON ÇAPRAZ TEST & LOG ANALİZİ VE SİSTEM GÜNCELLEME ÖNERİLERİ");
                sbRep.AppendLine("--------------------------------------------------------------------------------");
                sbRep.AppendLine(" • Doğrulanmış Başarılı Ekran Açılışı     : " + verifiedSuccessCount + " işlem");
                sbRep.AppendLine(" • Otomatik Yakalanıp Düzeltilen Çapraz Red: " + recentCrossRed.Count + " olay");
                for (int i = 0; i < recentCrossRed.Count; i++)
                {
                    sbRep.AppendLine("    [RED->TELAFİ] " + recentCrossRed[i]);
                }
                sbRep.AppendLine(" • Merkez <-> Mahmutbey Çapraz Eşleme     : " + recentCrossMap.Count + " olay");
                for (int i = 0; i < recentCrossMap.Count; i++)
                {
                    sbRep.AppendLine("    [ÇAPRAZ-HARİTA] " + recentCrossMap[i]);
                }
                sbRep.AppendLine(" • Zaman Aşımı / Açılmayan Ekran Olayı    : " + recentTimeouts.Count + " olay");
                for (int i = 0; i < recentTimeouts.Count; i++)
                {
                    sbRep.AppendLine("    [ZAMAN-AŞIMI] " + recentTimeouts[i]);
                }
                sbRep.AppendLine();
                sbRep.AppendLine(" [SİSTEM GÜNCELLEME TASARIM ÖNERİLERİ]:");
                if (recentCrossRed.Count > 0)
                {
                    sbRep.AppendLine("  1) Çapraz testin yakaladığı ekranlar için doğrulanan sıra numaraları sira-hafiza.json'a kilitlendi; sonraki açılışlarda doğrudan doğru satır seçilecek.");
                }
                else
                {
                    sbRep.AppendLine("  1) Son işlemlerde çapraz test uyuşmazlığı görülmedi; mevcut sira-hafiza.json tablosu kararlı çalışıyor.");
                }
                if (recentTimeouts.Count > 0)
                {
                    sbRep.AppendLine("  2) Zaman aşımı görülen ekranlarda Nebim V3 ERP/STORE oturum türü (Merkez vs Mağaza) farkı 'ResolveCrossAtlasTarget' ile otomatik eşlendi.");
                }
                else
                {
                    sbRep.AppendLine("  2) 'Ara...' kutusu odak + pano yapıştırma + (87, 199) çift tık zinciri 0 zaman aşımı ile çalışıyor.");
                }
                sbRep.AppendLine("  3) Kullanıcı alışkanlık verileri (" + keptUsageCount + " ekran) temiz tutuldu; en sık kullanılan ekranlar arama çekmecesinde ⭐ işaretiyle en üstte listelenmeye devam ediyor.");
                sbRep.AppendLine("================================================================================");

                AtomicWriteText(reportTxtPath, sbRep.ToString());

                string jsonSummary = "{\"tarih\":\"" + JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) +
                    "\",\"profil\":\"Mahmutbey-" + JsonEscape(Sube.Kod) + "-v6.0\",\"birlesikAtlasEkranSayisi\":" + SolMenuCatalog.Count +
                    ",\"temizlenenKuyrukDosyasi\":" + cleanedQueueFiles +
                    ",\"silinenCopKullanim\":" + purgedUsageCount +
                    ",\"silinenHataliOgrenme\":" + purgedLearnedCount +
                    ",\"onarılanKaro\":" + restoredTileCount +
                    ",\"korunanKullanim\":" + keptUsageCount +
                    ",\"korunanOgrenme\":" + keptLearnedCount +
                    ",\"korunanSiraHafiza\":" + keptSiraCount +
                    ",\"dogrulananAcilis\":" + verifiedSuccessCount +
                    ",\"caprazTestRedSayisi\":" + recentCrossRed.Count +
                    ",\"zamanAsimiSayisi\":" + recentTimeouts.Count +
                    ",\"raporDosyasi\":\"" + JsonEscape(reportTxtPath) + "\"}";
                AtomicWriteText(reportJsonPath, jsonSummary);
                try { File.AppendAllText(historyPath, jsonSummary + Environment.NewLine, new UTF8Encoding(false)); } catch { }

                ReconnectAndRefreshErpState();

                string doneMsg = "✅ Sistem Onarıldı & Restore Edildi: " + cleanedQueueFiles + " kilit, " + (purgedUsageCount + purgedLearnedCount + purgedSiraCount) + " çöp kayıt temizlendi; " + keptUsageCount + " kullanım ve " + keptLearnedCount + " doğru öğreti korundu.";
                LogLine("[MAHMUTBEY SİSTEM-ONAR] " + doneMsg + " | Rapor: " + reportTxtPath);
                if (lblFrameStatus != null)
                {
                    lblFrameStatus.Text = doneMsg;
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 28;
                }
                if (stepBox != null)
                {
                    stepBox.PushLiveAction("✓ SİSTEM BÜTÜNLÜĞÜ ONARILDI & RAPOR YAZILDI", doneMsg, "📄 Değerlendirme Raporu: sistem-onarim-degerlendirme-raporu.txt");
                }

                if (showDialog)
                {
                    DialogResult dr = MessageBox.Show(
                        this,
                        doneMsg + "\n\n" +
                        "• Birleşik Atlas (Mağaza + Merkez): " + SolMenuCatalog.Count + " ekran\n" +
                        "• Korunan Doğru Karo: " + keptTileCount + " / 9 (Onarılan: " + restoredTileCount + ")\n" +
                        "• Korunan Doğrulanmış Sıra Hafızası: " + keptSiraCount + " ekran\n" +
                        "• Rapor: " + reportTxtPath + "\n\n" +
                        "Değerlendirme raporunu şimdi ekranda açmak ister misiniz?",
                        "🛠️ Sistem Bütünlüğü Onarım & Değerlendirme Raporu (" + Sube.Ad + ")",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);
                    if (dr == DialogResult.Yes)
                    {
                        try { Process.Start("notepad.exe", reportTxtPath); } catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                LogLine("[MAHMUTBEY SİSTEM-ONAR] Hata: " + ex.Message);
            }
        }

        private void ReconnectAndRefreshErpState()
        {
            StartMcpServiceIfNeeded();
            if (stepBox != null)
            {
                stepBox.CheckRdpBridgeTelemetry(true);
            }

            AutomationElement erpWin = FindErpWindow();
            if (erpWin != null)
            {
                lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
                lblStatusDot.Invalidate();
                btnMcpStatus.Text = Sube.Kod + " · Bağlı";
                btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                string activeScr = GetActiveScreenName(erpWin);
                if (!string.IsNullOrEmpty(activeScr))
                {
                    currentTrackedScreen = activeScr;
                    currentSteps = DiscoverLiveGuidedSteps(erpWin, activeScr);
                    currentStepIdx = 0;
                    RefreshStepUi();
                    UpdateSummaryBannerWithActiveState();
                }
                else
                {
                    lblFrameStatus.Text = "✓ Nebim V3 STORE (" + Sube.Kod + ") bağlı (" + SolMenuCatalog.Count + " mağaza ekranı hazır).";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 12;
                }
                return;
            }

            IntPtr rdpHwnd = FindRdpClientWindow();
            string rdpEkran;
            bool bridgeFresh;
            bool rdpErpOpen = CanliMakineEkranPanel.IsRdpErpOpenFromTelemetry(out rdpEkran, out bridgeFresh);
            if (rdpHwnd != IntPtr.Zero || rdpErpOpen)
            {
                if (rdpErpOpen)
                {
                    lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
                    lblStatusDot.Invalidate();
                    btnMcpStatus.Text = Sube.Kod + " · Açık";
                    btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                    lblFrameStatus.Text = "✓ Nebim V3 STORE (" + Sube.Kod + ") bağlantısı açık (" + SolMenuCatalog.Count + " ekran hazır).";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
                else
                {
                    lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
                    lblStatusDot.Invalidate();
                    btnMcpStatus.Text = Sube.Kod + " · Bağlı";
                    btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                    lblFrameStatus.Text = "✓ Uzak Masaüstü (" + Sube.Kod + ") bağlı.";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
                statusMessageHoldTicks = 12;
                return;
            }

            lblStatusDot.BackColor = Color.FromArgb(210, 45, 45);
            lblStatusDot.Invalidate();
            btnMcpStatus.Text = "ERP Bekleniyor";
            btnMcpStatus.BackColor = Color.FromArgb(195, 50, 50);
            lblFrameStatus.Text = "⚠️ Nebim V3 STORE veya Uzak Masaüstü penceresi bulunamadı!";
            lblFrameStatus.ForeColor = ThemeWarnColor();
            statusMessageHoldTicks = 12;
        }

        // =====================================================================
        // MAHMUTBEY (PM3401) SATIŞ VE MAĞAZA HAREKET ÖZETİ — 2 SATIRLIK ÖZET MOTORU
        // =====================================================================
        private void RefreshSummaryAndActiveScreen()
        {
            RefreshMerkezSalesSummary(true);
        }

        private void UpdateSummaryBannerWithActiveState()
        {
            UpdateMerkezSalesBannerUI();
        }

        private void UpdateMerkezSalesBannerUI()
        {
            if (lblLiveSummary == null) return;
            CultureInfo trK = new CultureInfo("tr-TR");

            if (currentSalesSummary != null && currentSalesSummary.ok)
            {
                bool hasAnySales = Math.Abs(currentSalesSummary.netSales) > 0.009 ||
                                   currentSalesSummary.transactionCount > 0 ||
                                   Math.Abs(currentSalesSummary.itemQuantity) > 0.009;

                if (hasAnySales)
                {
                    string tutarStr = currentSalesSummary.netSales.ToString("N2", trK);
                    if (tutarStr.EndsWith(",00", StringComparison.Ordinal))
                    {
                        tutarStr = currentSalesSummary.netSales.ToString("N0", trK);
                    }
                    int islem = currentSalesSummary.transactionCount > 0
                        ? currentSalesSummary.transactionCount
                        : (Math.Abs(currentSalesSummary.itemQuantity) > 0 ? 1 : 0);
                    string adetBilgi = Math.Abs(currentSalesSummary.itemQuantity) > 0.009
                        ? (" · " + currentSalesSummary.itemQuantity.ToString("N0", trK) + " Adet")
                        : "";
                    string odemeDetay = "";
                    if (Math.Abs(currentSalesSummary.cashSales) > 0.009 || Math.Abs(currentSalesSummary.cardSales) > 0.009)
                    {
                        odemeDetay = " (N:" + currentSalesSummary.cashSales.ToString("N0", trK) + " K:" + currentSalesSummary.cardSales.ToString("N0", trK) + ")";
                    }

                    string line1 = Sube.Ad + " (" + Sube.Kod + ") Satış: ₺" + tutarStr;
                    string line2 = "Mağaza Özeti: " + islem + " İşlem" + adetBilgi + odemeDetay;
                    SetTwoLineBannerText(line1, line2);
                }
                else
                {
                    string line1 = Sube.Ad + " (" + Sube.Kod + ") Satış: ₺0,00 (Satış Yok)";
                    string line2 = "Mağaza Özeti: 0 İşlem · 0 Adet";
                    SetTwoLineBannerText(line1, line2);
                }
            }
            else
            {
                SetTwoLineBannerText(
                    Sube.Ad + " (" + Sube.Kod + ") Satış: Yenile'ye Basın",
                    "Mağaza Özeti: 0 İşlem · 0 Adet");
            }
        }

        private void SetTwoLineBannerText(string line1, string line2)
        {
            if (lblLiveSummary == null) return;
            string combined = (line1 ?? "").Trim() + "\n" + (line2 ?? "").Trim();
            lblLiveSummary.Text = combined;
            try
            {
                int availW = Math.Max(180, lblLiveSummary.ClientSize.Width - lblLiveSummary.Padding.Horizontal - 4);
                for (float sz = 8.8f; sz >= 7.2f; sz -= 0.3f)
                {
                    Font testFont = new Font("Segoe UI", sz, FontStyle.Bold);
                    Size s1 = TextRenderer.MeasureText(line1 ?? "", testFont);
                    Size s2 = TextRenderer.MeasureText(line2 ?? "", testFont);
                    if (s1.Width <= availW && s2.Width <= availW)
                    {
                        lblLiveSummary.Font = testFont;
                        return;
                    }
                    testFont.Dispose();
                }
                lblLiveSummary.Font = new Font("Segoe UI", 7.2f, FontStyle.Bold);
            }
            catch { }
        }

        private void LoadCachedTodayMerkezSalesSummary()
        {
            try
            {
                string path = Path.Combine(ResolveOutputDir(), "mahmutbey-satis-ozet.json");
                if (!File.Exists(path)) return;
                string raw = File.ReadAllText(path, Encoding.UTF8);
                string today = DateTime.Now.ToString("yyyy-MM-dd");
                if (raw.IndexOf("\"tarih\":\"" + today + "\"", StringComparison.OrdinalIgnoreCase) < 0 &&
                    raw.IndexOf("\"tarih\": \"" + today + "\"", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    return;
                }

                MerkezSalesSummary s = new MerkezSalesSummary();
                s.ok = true;
                s.dateKey = today;

                Match mNet = Regex.Match(raw, "\"netSatis\"\\s*:\\s*([-0-9.]+)");
                if (mNet.Success) double.TryParse(mNet.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out s.netSales);

                Match mNakit = Regex.Match(raw, "\"nakitSatis\"\\s*:\\s*([-0-9.]+)");
                if (mNakit.Success) double.TryParse(mNakit.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out s.cashSales);

                Match mKart = Regex.Match(raw, "\"kartSatis\"\\s*:\\s*([-0-9.]+)");
                if (mKart.Success) double.TryParse(mKart.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out s.cardSales);

                Match mIsl = Regex.Match(raw, "\"islemAdedi\"\\s*:\\s*(\\d+)");
                if (mIsl.Success) int.TryParse(mIsl.Groups[1].Value, out s.transactionCount);

                Match mAdet = Regex.Match(raw, "\"urunAdedi\"\\s*:\\s*([-0-9.]+)");
                if (mAdet.Success) double.TryParse(mAdet.Groups[1].Value, NumberStyles.Any, CultureInfo.InvariantCulture, out s.itemQuantity);

                Match mSaat = Regex.Match(raw, "\"saat\"\\s*:\\s*\"(.*?)\"");
                s.updatedAt = mSaat.Success ? mSaat.Groups[1].Value : DateTime.Now.ToString("HH:mm");

                Match mRap = Regex.Match(raw, "\"rapor\"\\s*:\\s*\"(.*?)\"");
                s.sourceReport = mRap.Success ? JsonUnescape(mRap.Groups[1].Value) : "Mağaza Hareket Özeti";

                s.hasSales = Math.Abs(s.netSales) > 0.009 || s.transactionCount > 0 || Math.Abs(s.itemQuantity) > 0.009;
                currentSalesSummary = s;
            }
            catch { }
        }

        private void SaveMerkezSalesSummaryCache(MerkezSalesSummary s)
        {
            if (s == null || !s.ok) return;
            try
            {
                string path = Path.Combine(ResolveOutputDir(), "mahmutbey-satis-ozet.json");
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("{");
                sb.AppendLine("  \"tarih\": \"" + DateTime.Now.ToString("yyyy-MM-dd") + "\",");
                sb.AppendLine("  \"saat\": \"" + JsonEscape(s.updatedAt ?? DateTime.Now.ToString("HH:mm")) + "\",");
                sb.AppendLine("  \"subeKod\": \"" + JsonEscape(Sube.Kod) + "\",");
                sb.AppendLine("  \"magaza\": \"" + JsonEscape(Sube.Ad) + "\",");
                sb.AppendLine("  \"posDahil\": true,");
                sb.AppendLine("  \"satisVar\": " + (s.hasSales ? "true" : "false") + ",");
                sb.AppendLine("  \"netSatis\": " + s.netSales.ToString("0.##", CultureInfo.InvariantCulture) + ",");
                sb.AppendLine("  \"nakitSatis\": " + s.cashSales.ToString("0.##", CultureInfo.InvariantCulture) + ",");
                sb.AppendLine("  \"kartSatis\": " + s.cardSales.ToString("0.##", CultureInfo.InvariantCulture) + ",");
                sb.AppendLine("  \"islemAdedi\": " + s.transactionCount + ",");
                sb.AppendLine("  \"urunAdedi\": " + s.itemQuantity.ToString("0.##", CultureInfo.InvariantCulture) + ",");
                sb.AppendLine("  \"rapor\": \"" + JsonEscape(s.sourceReport ?? "Mağaza Hareket Özeti") + "\"");
                sb.AppendLine("}");
                AtomicWriteText(path, sb.ToString());
                MerkezKutusunaYaz(s);
            }
            catch { }
        }

        private static void MerkezKutusunaYaz(MerkezSalesSummary s)
        {
            if (s == null || !s.ok) return;
            try
            {
                string dir = Path.Combine(ServiceRoot, "state", "merkez-kutusu");
                Directory.CreateDirectory(dir);
                var paket = new Dictionary<string, object>
                {
                    { "tur", "sube-durum-paketi" },
                    { "surum", 1 },
                    { "zaman", DateTime.Now.ToString("o") },
                    { "sube", new Dictionary<string, object> { { "kod", Sube.Kod }, { "ad", Sube.Ad }, { "sunucu", Sube.Sunucu } } },
                    { "ozet", new Dictionary<string, object>
                        {
                            { "satis", s.netSales },
                            { "nakit", s.cashSales },
                            { "kart", s.cardSales },
                            { "islem", s.transactionCount },
                            { "adet", s.itemQuantity },
                            { "rapor", s.sourceReport ?? "Mağaza Hareket Özeti" }
                        }
                    }
                };
                string json = new JavaScriptSerializer().Serialize(paket);
                string son = Path.Combine(dir, "son.json");
                AtomicWriteText(son, json);
            }
            catch { }
        }

        private MerkezSalesSummary TryQuerySalesSummaryViaSqlQueue(string targetStore)
        {
            try
            {
                string outDir = ResolveOutputDir();
                string queueDir = Path.Combine(outDir, "kuyruk");
                if (!Directory.Exists(queueDir)) Directory.CreateDirectory(queueDir);

                string safeStore = Regex.Replace((targetStore ?? Sube.Kod ?? "PM3401").Trim().ToUpperInvariant(), @"[^A-Z0-9_]", "");
                if (safeStore.Length == 0) safeStore = "PM3401";
                bool isStoreFilter = !string.Equals(safeStore, "TUMU", StringComparison.OrdinalIgnoreCase) &&
                                     !string.Equals(safeStore, "MERKEZ", StringComparison.OrdinalIgnoreCase);

                string whereStoreInv = isStoreFilter ? ("h.StoreCode = '" + safeStore + "' AND ") : "";
                string whereStorePay = isStoreFilter ? ("p.StoreCode = '" + safeStore + "' AND ") : "";
                string fastSql =
                    "SELECT " +
                    "(SELECT COUNT(DISTINCT h.InvoiceHeaderID) FROM AllInvoices h WITH (NOLOCK) WHERE " + whereStoreInv + "CONVERT(date, h.InvoiceDate) = CONVERT(date, GETDATE()) AND ISNULL(h.IsSuspended, 0) = 0) AS BugunFaturaSayisi, " +
                    "(SELECT CAST(ISNULL(SUM(CASE WHEN h.IsReturn = 1 THEN -ISNULL(h.Qty1, 0) ELSE ISNULL(h.Qty1, 0) END), 0) AS decimal(18,2)) FROM AllInvoices h WITH (NOLOCK) WHERE " + whereStoreInv + "CONVERT(date, h.InvoiceDate) = CONVERT(date, GETDATE()) AND ISNULL(h.IsSuspended, 0) = 0) AS BugunNetAdet, " +
                    "(SELECT CAST(ISNULL(SUM(CASE WHEN h.IsReturn = 1 THEN -ISNULL(h.Loc_NetAmount, 0) ELSE ISNULL(h.Loc_NetAmount, 0) END), 0) AS decimal(18,2)) FROM AllInvoices h WITH (NOLOCK) WHERE " + whereStoreInv + "CONVERT(date, h.InvoiceDate) = CONVERT(date, GETDATE()) AND ISNULL(h.IsSuspended, 0) = 0) AS BugunNetCiro, " +
                    "(SELECT CAST(ISNULL(SUM(CASE WHEN p.PaymentTypeCode = 1 THEN p.Loc_Payment ELSE 0 END), 0) AS decimal(18,2)) FROM AllPayments p WITH (NOLOCK) WHERE " + whereStorePay + "CONVERT(date, p.DocumentDate) = CONVERT(date, GETDATE())) AS BugunNakitSatis, " +
                    "(SELECT CAST(ISNULL(SUM(CASE WHEN p.PaymentTypeCode = 2 THEN p.Loc_Payment ELSE 0 END), 0) AS decimal(18,2)) FROM AllPayments p WITH (NOLOCK) WHERE " + whereStorePay + "CONVERT(date, p.DocumentDate) = CONVERT(date, GETDATE())) AS BugunKartSatis";

                string reqId = DateTime.Now.ToString("yyyyMMddHHmmss") + "-sql-" + Guid.NewGuid().ToString("N").Substring(0, 4);
                string tmpPath = Path.Combine(queueDir, "istek-" + reqId + ".tmp");
                string reqPath = Path.Combine(queueDir, "istek-" + reqId + ".json");
                string resPath = Path.Combine(queueDir, "sonuc-" + reqId + ".json");

                string reqJson = "{\"id\":\"" + JsonEscape(reqId) + "\",\"islem\":\"sql-oku\",\"sube\":\"" + JsonEscape(safeStore) + "\",\"sorgu\":\"" + JsonEscape(fastSql) + "\",\"zaman\":\"" + DateTime.Now.ToString("s") + "\"}";
                File.WriteAllText(tmpPath, reqJson, new UTF8Encoding(false));
                if (File.Exists(reqPath)) File.Delete(reqPath);
                File.Move(tmpPath, reqPath);

                Stopwatch sw = Stopwatch.StartNew();
                string rawRes = "";
                while (sw.ElapsedMilliseconds < 12000)
                {
                    Thread.Sleep(75);
                    if (CanliMakineEkranPanel.ActiveInstance != null)
                    {
                        CanliMakineEkranPanel.ActiveInstance.StepAnimationNow();
                    }
                    Application.DoEvents();
                    if (!File.Exists(resPath)) continue;

                    for (int r = 0; r < 4; r++)
                    {
                        try
                        {
                            rawRes = File.ReadAllText(resPath, Encoding.UTF8);
                            File.Delete(resPath);
                            break;
                        }
                        catch { Thread.Sleep(45); }
                    }
                    if (rawRes.Length > 0) break;
                }

                if (string.IsNullOrEmpty(rawRes))
                {
                    try { if (File.Exists(reqPath)) File.Delete(reqPath); } catch { }
                    string subePkgPath = Path.Combine(outDir, "sube-ozet-" + safeStore + ".json");
                    if (File.Exists(subePkgPath) && Math.Abs((DateTime.UtcNow - File.GetLastWriteTimeUtc(subePkgPath)).TotalMinutes) < 15)
                    {
                        try
                        {
                            string subeRaw = File.ReadAllText(subePkgPath, Encoding.UTF8);
                            string todayStr = DateTime.Now.ToString("yyyy-MM-dd");
                            if (subeRaw.IndexOf(todayStr, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                JavaScriptSerializer jsSube = new JavaScriptSerializer { MaxJsonLength = 4 * 1024 * 1024 };
                                Dictionary<string, object> sd = jsSube.Deserialize<Dictionary<string, object>>(subeRaw.TrimStart('\uFEFF'));
                                if (sd != null && sd.ContainsKey("netSatis"))
                                {
                                    MerkezSalesSummary sSub = new MerkezSalesSummary();
                                    sSub.ok = true;
                                    sSub.updatedAt = DateTime.Now.ToString("HH:mm");
                                    sSub.dateKey = todayStr;
                                    sSub.netSales = Convert.ToDouble(sd["netSatis"], CultureInfo.InvariantCulture);
                                    if (sd.ContainsKey("nakitSatis")) sSub.cashSales = Convert.ToDouble(sd["nakitSatis"], CultureInfo.InvariantCulture);
                                    if (sd.ContainsKey("kartSatis")) sSub.cardSales = Convert.ToDouble(sd["kartSatis"], CultureInfo.InvariantCulture);
                                    if (sd.ContainsKey("islemSayisi")) sSub.transactionCount = Convert.ToInt32(sd["islemSayisi"], CultureInfo.InvariantCulture);
                                    else if (sd.ContainsKey("islemAdedi")) sSub.transactionCount = Convert.ToInt32(sd["islemAdedi"], CultureInfo.InvariantCulture);
                                    if (sd.ContainsKey("urunAdedi")) sSub.itemQuantity = Convert.ToDouble(sd["urunAdedi"], CultureInfo.InvariantCulture);
                                    sSub.hasSales = Math.Abs(sSub.netSales) > 0.009 || sSub.transactionCount > 0 || Math.Abs(sSub.itemQuantity) > 0.009;
                                    sSub.sourceReport = "SQL Canlı (PM_V3)";
                                    return sSub;
                                }
                            }
                        }
                        catch { }
                    }

                    string pkgPath = Path.Combine(outDir, "sql-canli-veri-paketi.json");
                    if (File.Exists(pkgPath) && Math.Abs((DateTime.UtcNow - File.GetLastWriteTimeUtc(pkgPath)).TotalMinutes) < 30)
                    {
                        for (int r = 0; r < 4; r++)
                        {
                            try { rawRes = File.ReadAllText(pkgPath, Encoding.UTF8); break; }
                            catch { Thread.Sleep(60); }
                        }
                    }
                }

                if (string.IsNullOrEmpty(rawRes)) return null;

                JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 4 * 1024 * 1024 };
                Dictionary<string, object> d = js.Deserialize<Dictionary<string, object>>(rawRes.TrimStart('\uFEFF'));
                if (d == null || !d.ContainsKey("pmV3BaglantiAcik") || !Convert.ToBoolean(d["pmV3BaglantiAcik"])) return null;

                double netVal = 0;
                double cashVal = 0;
                double cardVal = 0;
                int txCnt = 0;
                double qtyVal = 0;
                bool parsedFastSql = false;

                if (d.ContainsKey("sqlVeri") && d["sqlVeri"] is Dictionary<string, object>)
                {
                    Dictionary<string, object> sv = (Dictionary<string, object>)d["sqlVeri"];
                    if (sv.ContainsKey("ozelSorguSonuc") && sv["ozelSorguSonuc"] is System.Collections.IEnumerable)
                    {
                        foreach (object rowObj in (System.Collections.IEnumerable)sv["ozelSorguSonuc"])
                        {
                            Dictionary<string, object> r = rowObj as Dictionary<string, object>;
                            if (r == null) continue;
                            if (r.ContainsKey("BugunNetCiro") && r["BugunNetCiro"] != null) netVal = Convert.ToDouble(r["BugunNetCiro"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunNakitSatis") && r["BugunNakitSatis"] != null) cashVal = Convert.ToDouble(r["BugunNakitSatis"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunKartSatis") && r["BugunKartSatis"] != null) cardVal = Convert.ToDouble(r["BugunKartSatis"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunFaturaSayisi") && r["BugunFaturaSayisi"] != null) txCnt = Convert.ToInt32(r["BugunFaturaSayisi"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunNetAdet") && r["BugunNetAdet"] != null) qtyVal = Convert.ToDouble(r["BugunNetAdet"], CultureInfo.InvariantCulture);
                            parsedFastSql = true;
                            break;
                        }
                    }
                }

                if (!parsedFastSql && d.ContainsKey("ozelSorgu") && d["ozelSorgu"] is Dictionary<string, object>)
                {
                    Dictionary<string, object> ozel = (Dictionary<string, object>)d["ozelSorgu"];
                    if (ozel.ContainsKey("ok") && Convert.ToBoolean(ozel["ok"]) && ozel.ContainsKey("satirlar") && ozel["satirlar"] is System.Collections.IEnumerable)
                    {
                        foreach (object rowObj in (System.Collections.IEnumerable)ozel["satirlar"])
                        {
                            Dictionary<string, object> r = rowObj as Dictionary<string, object>;
                            if (r == null) continue;
                            if (r.ContainsKey("BugunNetCiro") && r["BugunNetCiro"] != null) netVal = Convert.ToDouble(r["BugunNetCiro"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunNakitSatis") && r["BugunNakitSatis"] != null) cashVal = Convert.ToDouble(r["BugunNakitSatis"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunKartSatis") && r["BugunKartSatis"] != null) cardVal = Convert.ToDouble(r["BugunKartSatis"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunFaturaSayisi") && r["BugunFaturaSayisi"] != null) txCnt = Convert.ToInt32(r["BugunFaturaSayisi"], CultureInfo.InvariantCulture);
                            if (r.ContainsKey("BugunNetAdet") && r["BugunNetAdet"] != null) qtyVal = Convert.ToDouble(r["BugunNetAdet"], CultureInfo.InvariantCulture);
                            parsedFastSql = true;
                            break;
                        }
                    }
                }

                Dictionary<string, object> oz = null;
                if (!parsedFastSql)
                {
                    if (!d.ContainsKey("ozet") || !(d["ozet"] is Dictionary<string, object>)) return null;
                    oz = (Dictionary<string, object>)d["ozet"];
                    if (isStoreFilter && string.Equals(safeStore, "PM3401", StringComparison.OrdinalIgnoreCase) && oz.ContainsKey("pm3401Bugun") && oz["pm3401Bugun"] is Dictionary<string, object>)
                    {
                        Dictionary<string, object> pNode = (Dictionary<string, object>)oz["pm3401Bugun"];
                        if (pNode.ContainsKey("netSatis")) netVal = Convert.ToDouble(pNode["netSatis"], CultureInfo.InvariantCulture);
                        if (pNode.ContainsKey("nakitSatis")) cashVal = Convert.ToDouble(pNode["nakitSatis"], CultureInfo.InvariantCulture);
                        if (pNode.ContainsKey("kartSatis")) cardVal = Convert.ToDouble(pNode["kartSatis"], CultureInfo.InvariantCulture);
                        if (pNode.ContainsKey("islemSayisi")) txCnt = Convert.ToInt32(pNode["islemSayisi"], CultureInfo.InvariantCulture);
                        if (pNode.ContainsKey("urunAdedi")) qtyVal = Convert.ToDouble(pNode["urunAdedi"], CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        if (oz.ContainsKey("netSatis")) netVal = Convert.ToDouble(oz["netSatis"], CultureInfo.InvariantCulture);
                        if (oz.ContainsKey("nakitSatis")) cashVal = Convert.ToDouble(oz["nakitSatis"], CultureInfo.InvariantCulture);
                        if (oz.ContainsKey("kartSatis")) cardVal = Convert.ToDouble(oz["kartSatis"], CultureInfo.InvariantCulture);
                        if (oz.ContainsKey("islemSayisi")) txCnt = Convert.ToInt32(oz["islemSayisi"], CultureInfo.InvariantCulture);
                        if (oz.ContainsKey("urunAdedi")) qtyVal = Convert.ToDouble(oz["urunAdedi"], CultureInfo.InvariantCulture);
                    }
                }

                MerkezSalesSummary s = new MerkezSalesSummary();
                s.ok = true;
                s.updatedAt = DateTime.Now.ToString("HH:mm");
                s.dateKey = DateTime.Now.ToString("yyyy-MM-dd");
                s.netSales = netVal;
                s.cashSales = cashVal;
                s.cardSales = cardVal;
                s.transactionCount = txCnt;
                s.itemQuantity = qtyVal;
                s.hasSales = Math.Abs(s.netSales) > 0.009 || s.transactionCount > 0 || Math.Abs(s.itemQuantity) > 0.009;
                s.sourceReport = "SQL Canlı (PM_V3)";

                if (!s.hasSales && oz != null && oz.ContainsKey("sonAktifGun") && oz["sonAktifGun"] is Dictionary<string, object>)
                {
                    Dictionary<string, object> sa = (Dictionary<string, object>)oz["sonAktifGun"];
                    string saTarih = sa.ContainsKey("tarih") ? Convert.ToString(sa["tarih"] ?? "") : "";
                    int saFatura = sa.ContainsKey("islemSayisi") ? Convert.ToInt32(sa["islemSayisi"], CultureInfo.InvariantCulture) : 0;
                    double saCiro = sa.ContainsKey("netSatis") ? Convert.ToDouble(sa["netSatis"], CultureInfo.InvariantCulture) : 0;
                    double saAdet = sa.ContainsKey("urunAdedi") ? Convert.ToDouble(sa["urunAdedi"], CultureInfo.InvariantCulture) : 0;
                    if (saFatura > 0 && !string.IsNullOrEmpty(saTarih))
                    {
                        CultureInfo trK = new CultureInfo("tr-TR");
                        s.detailNote = "Son Aktif (" + saTarih + "): ₺" + saCiro.ToString("N2", trK) + " · " + saFatura + " İşlem (" + saAdet.ToString("N0", trK) + " Adet)";
                    }
                }
                LogLine("[SQL CANLI OKUMA] PM_V3 doğrudan SQL sorgusu başarılı (Hedef=" + safeStore + ", Ciro=" + s.netSales.ToString("N2") + ", Nakit=" + s.cashSales.ToString("N2") + ", Kart=" + s.cardSales.ToString("N2") + ", Fatura=" + s.transactionCount + ", Adet=" + s.itemQuantity + ")");
                return s;
            }
            catch (Exception ex)
            {
                LogLine("[SQL CANLI OKUMA] Uyarı: " + ex.Message);
                return null;
            }
        }

        private void RefreshMerkezSalesSummary(bool openReportIfNeeded)
        {
            if (isRefreshingSales) return;
            isRefreshingSales = true;
            try
            {
                LogLine("=== [MAHMUTBEY SATIŞ ÖZETİ YENİLE] " + Sube.Ad + " (" + Sube.Kod + ") Mağaza Hareket Özeti sorgulanıyor... ===");
                btnLiveRefresh.Text = "⏳ Okunuyor";
                SetTwoLineBannerText(
                    "⏳ " + Sube.Ad + " (" + Sube.Kod + ") Satış Okunuyor...",
                    "Mağaza Hareket Özeti & POS Satış Hesaplanıyor...");
                lblFrameStatus.Text = "⏳ " + Sube.Ad + " (" + Sube.Kod + ") mağaza satış ve işlem özeti okunuyor...";
                lblFrameStatus.ForeColor = ThemeWarnColor();
                statusMessageHoldTicks = 14;
                Application.DoEvents();

                if (CanliMakineEkranPanel.ActiveInstance != null)
                {
                    CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                        "⚡ EYLEM: " + Sube.Ad + " (" + Sube.Kod + ") Mağaza Hareket Özeti",
                        "NebimYardimci kuyruğu ve Mağaza Hareket Özeti üzerinden bugünkü satış, nakit/kart ve işlem adedi okunuyor...",
                        "⏳ [CANLI ÖZET] " + Sube.Ad + " (" + Sube.Kod + ") verileri sorgulanıyor...");
                }

                MerkezSalesSummary summary = TryQuerySalesSummaryViaSqlQueue(Sube.Kod);
                if (summary == null || !summary.ok)
                {
                    Thread.Sleep(1200);
                    Application.DoEvents();
                    summary = TryQuerySalesSummaryViaSqlQueue(Sube.Kod);
                }
                if (summary == null || !summary.ok)
                {
                    LoadCachedTodayMerkezSalesSummary();
                    if (currentSalesSummary != null && currentSalesSummary.ok)
                    {
                        summary = currentSalesSummary;
                    }
                }

                if (summary != null && summary.ok)
                {
                    currentSalesSummary = summary;
                    SaveMerkezSalesSummaryCache(summary);
                    UpdateMerkezSalesBannerUI();

                    CultureInfo trK = new CultureInfo("tr-TR");
                    string msg = summary.hasSales
                        ? ("✅ " + Sube.Ad + " (" + Sube.Kod + ") Satış: ₺" + summary.netSales.ToString("N2", trK) + " | " + summary.transactionCount + " İşlem (" + summary.itemQuantity.ToString("N0", trK) + " Adet)")
                        : ("✅ " + Sube.Ad + " (" + Sube.Kod + ") mağazada bugün henüz satış kaydı bulunmuyor (₺0,00 · 0 İşlem).");
                    lblFrameStatus.Text = msg;
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 16;
                    LogLine("[MAHMUTBEY SATIŞ ÖZETİ] " + msg);
                    WriteLiveTestReport(Sube.Ad + " (" + Sube.Kod + ") Mağaza Hareket Özeti", true, msg);
                    SesliAsistan.Konus(msg, false);
                }
                else
                {
                    UpdateMerkezSalesBannerUI();
                    string errNote = (summary != null && !string.IsNullOrEmpty(summary.detailNote))
                        ? summary.detailNote
                        : ("⚠️ Nebim V3 STORE (" + Sube.Kod + ") penceresi veya rapor verisi bulunamadı.");
                    lblFrameStatus.Text = errNote;
                    lblFrameStatus.ForeColor = ThemeWarnColor();
                    statusMessageHoldTicks = 14;
                    LogLine("[MAHMUTBEY SATIŞ ÖZETİ] Uyarı: " + errNote);
                    WriteLiveTestReport(Sube.Ad + " (" + Sube.Kod + ") Mağaza Hareket Özeti", false, errNote);
                    SesliAsistan.Konus(errNote, false);
                }
            }
            catch (Exception ex)
            {
                LogLine("[MAHMUTBEY SATIŞ ÖZETİ] Hata: " + ex.Message);
                UpdateMerkezSalesBannerUI();
            }
            finally
            {
                if (frameOverlay != null)
                {
                    frameOverlay.HideFrame();
                }
                if (LastRdpFrameActive)
                {
                    SendRdpFrameQueueCommand("cerceve-gizle", null, 0);
                    LastRdpFrameActive = false;
                }
                if (MatchesScreenTitle(currentTrackedScreen, "Günlük Mağaza Ciro Raporu") ||
                    MatchesScreenTitle(currentTrackedScreen, "Mağaza Hareket Özeti") ||
                    MatchesScreenTitle(currentTrackedScreen, "Mağaza Ciro Raporu"))
                {
                    currentTrackedScreen = "";
                    if (currentSteps != null) currentSteps.Clear();
                    lblScreenTitle.Text = "🧭 Aktif Ekran: " + Sube.Ad + " (" + Sube.Kod + ") Satış Özeti Güncellendi";
                }
                btnLiveRefresh.Text = "⟳  Yenile";
                isRefreshingSales = false;
            }
        }

        private MerkezSalesSummary TryQueryStoreSummaryViaQueue(IntPtr rdpHwnd)
        {
            try
            {
                string rdpEkran;
                bool bridgeFresh;
                bool rdpErpOpen = CanliMakineEkranPanel.IsRdpErpOpenFromTelemetry(out rdpEkran, out bridgeFresh);
                if (!rdpErpOpen) return null;

                string queueDir = Path.Combine(ResolveOutputDir(), "kuyruk");
                if (!Directory.Exists(queueDir)) Directory.CreateDirectory(queueDir);

                string reqId = DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "-" + (new Random().Next(100, 999));
                string reqPath = Path.Combine(queueDir, "istek-" + reqId + ".json");
                string resPath = Path.Combine(queueDir, "sonuc-" + reqId + ".json");

                string reqJson = "{\"id\":\"" + JsonEscape(reqId) + "\",\"islem\":\"ozet\",\"sube\":\"" + JsonEscape(Sube.Kod) + "\",\"zaman\":\"" + DateTime.Now.ToString("s") + "\"}";
                AtomicWriteText(reqPath, reqJson);

                if (rdpHwnd != IntPtr.Zero && !IsPosForeground())
                {
                    BringWindowToFrontSafe(rdpHwnd);
                }

                Stopwatch sw = Stopwatch.StartNew();
                string rawRes = "";
                while (sw.ElapsedMilliseconds < 22000)
                {
                    Thread.Sleep(150);
                    if (CanliMakineEkranPanel.ActiveInstance != null)
                    {
                        CanliMakineEkranPanel.ActiveInstance.StepAnimationNow();
                    }
                    Application.DoEvents();
                    if (!File.Exists(resPath)) continue;

                    for (int r = 0; r < 4; r++)
                    {
                        try
                        {
                            rawRes = File.ReadAllText(resPath, Encoding.UTF8);
                            File.Delete(resPath);
                            break;
                        }
                        catch { Thread.Sleep(70); }
                    }
                    if (rawRes.Length > 0) break;
                }

                if (string.IsNullOrEmpty(rawRes))
                {
                    try { if (File.Exists(reqPath)) File.Delete(reqPath); } catch { }
                    return null;
                }

                return ParseNebimYardimciOzetJson(rawRes);
            }
            catch
            {
                return null;
            }
        }

        private static MerkezSalesSummary ParseNebimYardimciOzetJson(string rawJson)
        {
            if (string.IsNullOrEmpty(rawJson)) return null;
            try
            {
                JavaScriptSerializer js = new JavaScriptSerializer { MaxJsonLength = 4 * 1024 * 1024 };
                Dictionary<string, object> d = js.Deserialize<Dictionary<string, object>>(rawJson.TrimStart('\uFEFF'));
                if (d == null) return null;

                Dictionary<string, object> ozetNode = d;
                if (d.ContainsKey("veri") && d["veri"] is Dictionary<string, object>)
                {
                    ozetNode = (Dictionary<string, object>)d["veri"];
                }
                if (ozetNode.ContainsKey("ozet") && ozetNode["ozet"] is Dictionary<string, object>)
                {
                    ozetNode = (Dictionary<string, object>)ozetNode["ozet"];
                }

                if (!ozetNode.ContainsKey("satirlar") || !(ozetNode["satirlar"] is System.Collections.IEnumerable))
                {
                    return null;
                }

                double satis = double.NaN;
                double nakit = 0;
                double kart = 0;
                double diger = 0;
                double iade = 0;
                double masraf = 0;
                double miktar = 0;
                int satirSayisi = 0;

                foreach (object o in (System.Collections.IEnumerable)ozetNode["satirlar"])
                {
                    Dictionary<string, object> r = o as Dictionary<string, object>;
                    if (r == null) continue;
                    string ad = r.ContainsKey("ad") && r["ad"] != null ? Convert.ToString(r["ad"]) : "";
                    string deger = r.ContainsKey("deger") && r["deger"] != null ? Convert.ToString(r["deger"]) : "";
                    string n = Norm(ad + " " + deger);

                    double son = double.NaN;
                    double mkt = double.NaN;
                    string[] parcalar = deger.Split('|');
                    for (int idx = parcalar.Length - 1; idx >= 0; idx--)
                    {
                        double dVal = ParseNumber(parcalar[idx]);
                        if (!double.IsNaN(dVal))
                        {
                            if (double.IsNaN(son)) son = dVal;
                            else if (double.IsNaN(mkt)) mkt = dVal;
                        }
                    }
                    if (double.IsNaN(son)) continue;

                    if (n.Contains(" odeme tipi aciklamasi ") || n.Contains(" pesinat "))
                    {
                        if (n.Contains(" nakit ")) nakit += son;
                        else if (n.Contains(" kredi kart") || n.Contains(" banka kart") || n.Contains(" pos ")) kart += son;
                        else if (!n.Contains(" toplam ")) diger += son;
                    }
                    else if (n.Contains(" surec aciklamasi "))
                    {
                        if (n.Contains(" perakende satis ") && double.IsNaN(satis))
                        {
                            satis = son;
                            if (!double.IsNaN(mkt)) miktar += Math.Abs(mkt);
                            satirSayisi++;
                        }
                        else if (n.Contains(" masraf ")) masraf += Math.Abs(son);
                        else if (n.Contains(" iade ")) iade += Math.Abs(son);
                    }
                }

                if (double.IsNaN(satis) && (nakit > 0 || kart > 0 || diger > 0))
                {
                    satis = nakit + kart + diger;
                }

                if (double.IsNaN(satis)) satis = 0;

                MerkezSalesSummary res = new MerkezSalesSummary();
                res.ok = true;
                res.netSales = satis;
                res.cashSales = nakit;
                res.cardSales = kart;
                res.itemQuantity = miktar;
                res.transactionCount = satirSayisi > 0 ? satirSayisi : (Math.Abs(satis) > 0.009 ? 1 : 0);
                res.hasSales = Math.Abs(res.netSales) > 0.009 || res.transactionCount > 0 || Math.Abs(res.itemQuantity) > 0.009;
                res.updatedAt = DateTime.Now.ToString("HH:mm");
                res.dateKey = DateTime.Now.ToString("yyyy-MM-dd");
                res.sourceReport = "Mağaza Hareket Özeti (" + Sube.Kod + ")";
                return res;
            }
            catch
            {
                return null;
            }
        }

        private MerkezSalesSummary ReadOrRunMerkezSalesOnErpWindow(AutomationElement erpWin, bool openReportIfNeeded)
        {
            MerkezSalesSummary s = new MerkezSalesSummary();
            s.updatedAt = DateTime.Now.ToString("HH:mm");
            s.dateKey = DateTime.Now.ToString("yyyy-MM-dd");

            string[] salesReportTitles = new string[]
            {
                "Mağaza Hareket Özeti",
                "Günlük Mağaza Ciro Raporu",
                "Mağaza Ciro Raporu",
                "Perakende Satışlar Listesi"
            };

            AutomationElement reportWin = null;
            string foundReportTitle = "";
            for (int i = 0; i < salesReportTitles.Length; i++)
            {
                AutomationElement cand;
                if (IsScreenOpen(erpWin, salesReportTitles[i], out cand))
                {
                    reportWin = cand != null ? cand : erpWin;
                    foundReportTitle = salesReportTitles[i];
                    break;
                }
            }

            if (reportWin != null)
            {
                MerkezSalesSummary existingRead = ExtractMerkezSalesFromUiaElement(reportWin, foundReportTitle);
                if (existingRead != null && existingRead.ok)
                {
                    return existingRead;
                }
            }

            if (openReportIfNeeded && !IsPosForeground())
            {
                string openMsg;
                bool openedByUs = false;
                if (reportWin == null)
                {
                    openedByUs = OpenScreenViaSearchBox(erpWin, "Mağaza Hareket Özeti", 1, true, out openMsg);
                    if (openedByUs)
                    {
                        foundReportTitle = "Mağaza Hareket Özeti";
                    }
                    else
                    {
                        openedByUs = OpenScreenViaSearchBox(erpWin, "Günlük Mağaza Ciro Raporu", 1, true, out openMsg);
                        if (openedByUs) foundReportTitle = "Günlük Mağaza Ciro Raporu";
                    }
                    Thread.Sleep(600);
                }

                AutomationElement activeReportScope = GetActiveScreenElement(erpWin, foundReportTitle);
                if (activeReportScope == null) activeReportScope = erpWin;

                AutomationElement runBtn = FindReportRunButtonUia(activeReportScope, erpWin);
                if (runBtn != null && !IsPosForeground())
                {
                    try
                    {
                        object invObj;
                        if (runBtn.TryGetCurrentPattern(InvokePattern.Pattern, out invObj))
                        {
                            ((InvokePattern)invObj).Invoke();
                        }
                        else
                        {
                            System.Windows.Rect br = SafeGetRect(runBtn);
                            if (!br.IsEmpty) ClickAt((int)(br.Left + br.Width / 2), (int)(br.Top + br.Height / 2));
                        }
                        LogLine("[MAHMUTBEY SATIŞ ÖZETİ] '" + foundReportTitle + "' için Çalıştır (btnRun) tetiklendi.");
                    }
                    catch { }
                }
                else if (!IsPosForeground())
                {
                    PressKey(VK_F5);
                }

                MerkezSalesSummary finalResult = null;
                for (int w = 0; w < 6; w++)
                {
                    Thread.Sleep(500);
                    Application.DoEvents();
                    AutomationElement latestScope = GetActiveScreenElement(erpWin, foundReportTitle);
                    if (latestScope == null) latestScope = erpWin;
                    MerkezSalesSummary afterRun = ExtractMerkezSalesFromUiaElement(latestScope, foundReportTitle);
                    if (afterRun != null && afterRun.ok)
                    {
                        finalResult = afterRun;
                        break;
                    }
                }

                if (openedByUs && !IsPosForeground())
                {
                    CloseTemporaryReportWindowUia(erpWin, foundReportTitle);
                }

                if (finalResult != null)
                {
                    return finalResult;
                }

                s.ok = true;
                s.hasSales = false;
                s.netSales = 0;
                s.transactionCount = 0;
                s.itemQuantity = 0;
                s.sourceReport = foundReportTitle.Length > 0 ? foundReportTitle : "Mağaza Hareket Özeti";
                return s;
            }

            s.ok = false;
            s.detailNote = "ℹ️ Mağaza Hareket Özeti açılıp çalıştırıldığında " + Sube.Ad + " (" + Sube.Kod + ") satış özeti gösterilir.";
            return s;
        }

        private static void CloseTemporaryReportWindowUia(AutomationElement erpWin, string reportTitle)
        {
            if (erpWin == null || string.IsNullOrEmpty(reportTitle)) return;
            try
            {
                AutomationElement childWin;
                if (IsScreenOpen(erpWin, reportTitle, out childWin) && childWin != null && !Automation.Compare(childWin, erpWin))
                {
                    object wp;
                    if (childWin.TryGetCurrentPattern(WindowPattern.Pattern, out wp))
                    {
                        ((WindowPattern)wp).Close();
                        LogLine("[MAHMUTBEY SATIŞ ÖZETİ] Geçici açılan '" + reportTitle + "' rapor penceresi otomatik kapatıldı.");
                        return;
                    }
                    AutomationElement closeBtn = childWin.FindFirst(TreeScope.Descendants,
                        new AndCondition(
                            new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button),
                            new PropertyCondition(AutomationElement.NameProperty, "Close")));
                    object ip;
                    if (closeBtn != null && closeBtn.TryGetCurrentPattern(InvokePattern.Pattern, out ip))
                    {
                        ((InvokePattern)ip).Invoke();
                        LogLine("[MAHMUTBEY SATIŞ ÖZETİ] Geçici açılan '" + reportTitle + "' rapor penceresi (Close düğmesi ile) kapatıldı.");
                    }
                }
            }
            catch { }
        }

        private static AutomationElement FindReportRunButtonUia(AutomationElement reportScope, AutomationElement erpWin)
        {
            AutomationElement[] scopes = new AutomationElement[] { reportScope, erpWin };
            for (int s = 0; s < scopes.Length; s++)
            {
                AutomationElement root = scopes[s];
                if (root == null) continue;
                try
                {
                    AutomationElement byId = root.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.AutomationIdProperty, "btnRun"));
                    if (byId != null && !SafeIsOffscreen(byId)) return byId;
                }
                catch { }

                try
                {
                    AutomationElementCollection btns = root.FindAll(TreeScope.Descendants, new PropertyCondition(AutomationElement.ControlTypeProperty, ControlType.Button));
                    if (btns != null)
                    {
                        foreach (AutomationElement b in btns)
                        {
                            if (SafeIsOffscreen(b)) continue;
                            string nm = NormTr(SafeGetName(b));
                            if (nm == "calistir" || nm.StartsWith("calistir ", StringComparison.Ordinal) || nm.StartsWith("calistir(", StringComparison.Ordinal))
                            {
                                return b;
                            }
                        }
                    }
                }
                catch { }
            }
            return null;
        }

        private static MerkezSalesSummary ExtractMerkezSalesFromUiaElement(AutomationElement scope, string reportName)
        {
            if (scope == null) return null;
            try
            {
                AutomationElementCollection all = scope.FindAll(TreeScope.Descendants, Condition.TrueCondition);
                if (all == null || all.Count == 0) return null;

                TreeWalker walker = TreeWalker.ControlViewWalker;
                List<Dictionary<string, string>> gridRows = new List<Dictionary<string, string>>();
                int seen = 0;

                foreach (AutomationElement el in all)
                {
                    if (++seen > 12000) break;
                    ControlType ct = SafeGetControlType(el);
                    if (ct != ControlType.DataItem && ct != ControlType.ListItem && ct != ControlType.TreeItem) continue;

                    string rowName = SafeGetName(el);
                    if (rowName.StartsWith("[", StringComparison.Ordinal) || rowName.IndexOf("Equals", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        continue;
                    }

                    Dictionary<string, string> rowCells = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    AutomationElement child = null;
                    try { child = walker.GetFirstChild(el); } catch { child = null; }
                    int cGuard = 0;
                    while (child != null && ++cGuard < 45)
                    {
                        string cn = SafeGetName(child);
                        string cv = SafeGetValue(child);
                        Match mCol = Regex.Match(cn, @"^(.*?)\s+(?:satır|row)\s+\d+$", RegexOptions.IgnoreCase);
                        if (mCol.Success)
                        {
                            cn = mCol.Groups[1].Value.Trim();
                        }
                        if (!string.IsNullOrEmpty(cn) && !string.IsNullOrEmpty(cv))
                        {
                            rowCells[NormTr(cn)] = cv.Trim();
                        }
                        try { child = walker.GetNextSibling(child); } catch { child = null; }
                    }

                    if (rowCells.Count >= 2)
                    {
                        rowCells["__satir_adi__"] = rowName;
                        gridRows.Add(rowCells);
                    }
                }

                if (gridRows.Count == 0) return null;
                return ComputeMahmutbeySummaryFromDictionaries(gridRows, reportName);
            }
            catch
            {
                return null;
            }
        }

        private MerkezSalesSummary ReadOrRunMerkezSalesViaRdp(IntPtr rdpHwnd, bool openReportIfNeeded)
        {
            MerkezSalesSummary summary = null;

            bool isSalesReportAlreadyTracked =
                MatchesScreenTitle(currentTrackedScreen, "Mağaza Hareket Özeti") ||
                MatchesScreenTitle(currentTrackedScreen, "Günlük Mağaza Ciro Raporu") ||
                MatchesScreenTitle(currentTrackedScreen, "Mağaza Ciro Raporu");

            if (isSalesReportAlreadyTracked)
            {
                summary = TryCopyAndParseSalesGridFromRdp(rdpHwnd, false);
                if (summary != null && summary.ok)
                {
                    return summary;
                }
            }

            if (openReportIfNeeded)
            {
                if (frameOverlay != null) frameOverlay.HideFrame();

                AtlasItem matchedItem;
                string searchQuery = ResolveBestMenuQuery("Mağaza Hareket Özeti", out matchedItem);
                string statusMsg;
                bool ok = OpenScreenViaNebimYardimciQueue(rdpHwnd, "Mağaza Hareket Özeti", searchQuery, 1, matchedItem, out statusMsg);
                if (!ok)
                {
                    MerkezSalesSummary failSummary = new MerkezSalesSummary();
                    failSummary.ok = false;
                    failSummary.hasSales = false;
                    failSummary.updatedAt = DateTime.Now.ToString("HH:mm");
                    failSummary.dateKey = DateTime.Now.ToString("yyyy-MM-dd");
                    failSummary.detailNote = !string.IsNullOrEmpty(statusMsg)
                        ? statusMsg
                        : "⚠️ RDP içinde 'Nebim V3 STORE' (" + Sube.Kod + ") penceresi açık değil; önce Nebim'i açın.";
                    return failSummary;
                }

                Thread.Sleep(700);
                summary = TryCopyAndParseSalesGridFromRdp(rdpHwnd, true);

                CloseActiveMdiWindowInRdp(rdpHwnd);

                if (summary != null && summary.ok)
                {
                    return summary;
                }
            }

            LoadCachedTodayMerkezSalesSummary();
            if (currentSalesSummary != null && currentSalesSummary.ok)
            {
                return currentSalesSummary;
            }

            MerkezSalesSummary zeroSummary = new MerkezSalesSummary();
            zeroSummary.ok = true;
            zeroSummary.hasSales = false;
            zeroSummary.netSales = 0;
            zeroSummary.transactionCount = 0;
            zeroSummary.itemQuantity = 0;
            zeroSummary.updatedAt = DateTime.Now.ToString("HH:mm");
            zeroSummary.dateKey = DateTime.Now.ToString("yyyy-MM-dd");
            zeroSummary.sourceReport = "Mağaza Hareket Özeti (" + Sube.Kod + ")";
            return zeroSummary;
        }

        private static void CloseActiveMdiWindowInRdp(IntPtr rdpHwnd)
        {
            if (rdpHwnd == IntPtr.Zero || IsPosForeground()) return;
            try
            {
                BringWindowToFrontSafe(rdpHwnd);
                Thread.Sleep(80);
                SendKeyDownUp(VK_CONTROL, false);
                PressKey(VK_F4);
                SendKeyDownUp(VK_CONTROL, true);
                Thread.Sleep(150);
                LogLine("[MAHMUTBEY RDP-KÖPRÜ] Yenile sonrası geçici rapor alt penceresi (Ctrl+F4) otomatik kapatıldı.");
            }
            catch { }
        }

        private MerkezSalesSummary TryCopyAndParseSalesGridFromRdp(IntPtr rdpHwnd, bool triggerRunFirst)
        {
            try
            {
                System.Windows.Rect canvas = GetRdpCanvasRect(rdpHwnd);
                if (canvas.IsEmpty || canvas.Width < 400 || canvas.Height < 300) return null;

                BringWindowToFrontSafe(rdpHwnd);
                Thread.Sleep(150);

                if (triggerRunFirst)
                {
                    PressKey(VK_F5);
                    Thread.Sleep(80);
                    for (int k = 6; k >= 0; k--)
                    {
                        int runX = (int)(canvas.Left + 740 + 26 * k);
                        int runY = (int)(canvas.Top + 745 + 26 * k);
                        ClickAt(runX, runY);
                        Thread.Sleep(55);
                    }
                    Thread.Sleep(1400);
                }

                string marker = "__NEBIM_MAHMUTBEY_RAPOR_OKU__";
                try { Clipboard.SetText(marker); } catch { }
                Thread.Sleep(80);

                int gridX = (int)(canvas.Left + 540);
                int gridY = (int)(canvas.Top + 310);
                ClickAt(gridX, gridY);
                Thread.Sleep(120);

                SendKeyDownUp(VK_CONTROL, false);
                PressKey(VK_A);
                SendKeyDownUp(VK_CONTROL, true);
                Thread.Sleep(80);

                SendKeyDownUp(VK_CONTROL, false);
                PressKey(VK_C);
                SendKeyDownUp(VK_CONTROL, true);
                Thread.Sleep(260);

                string clipText = "";
                try { clipText = Clipboard.GetText() ?? ""; } catch { clipText = ""; }

                if (string.IsNullOrEmpty(clipText) || clipText == marker)
                {
                    ClickAt((int)(canvas.Left + 460), (int)(canvas.Top + 260));
                    Thread.Sleep(100);
                    SendKeyDownUp(VK_CONTROL, false);
                    PressKey(VK_C);
                    SendKeyDownUp(VK_CONTROL, true);
                    Thread.Sleep(240);
                    try { clipText = Clipboard.GetText() ?? ""; } catch { clipText = ""; }
                }

                if (!string.IsNullOrEmpty(clipText) && clipText != marker && clipText.IndexOf('\t') >= 0)
                {
                    MerkezSalesSummary parsed = ParseTabDelimitedMahmutbeySales(clipText, "Mağaza Hareket Özeti (" + Sube.Kod + ")");
                    if (parsed != null && parsed.ok)
                    {
                        return parsed;
                    }
                }
            }
            catch { }
            return null;
        }

        private static MerkezSalesSummary ParseTabDelimitedMahmutbeySales(string tabText, string reportName)
        {
            if (string.IsNullOrEmpty(tabText)) return null;
            string[] lines = tabText.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            if (lines.Length == 0) return null;

            string[] headers = lines[0].Split('\t');
            List<Dictionary<string, string>> rows = new List<Dictionary<string, string>>();

            bool firstLineIsHeader = false;
            for (int h = 0; h < headers.Length; h++)
            {
                string nh = NormTr(headers[h]);
                if (nh.Contains("tutar") || nh.Contains("ciro") || nh.Contains("miktar") || nh.Contains("magaza") || nh.Contains("surec") || nh.Contains("adet") || nh.Contains("fis"))
                {
                    firstLineIsHeader = true;
                    break;
                }
            }

            if (firstLineIsHeader && lines.Length >= 2)
            {
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] cols = lines[i].Split('\t');
                    Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    int maxC = Math.Min(headers.Length, cols.Length);
                    for (int c = 0; c < maxC; c++)
                    {
                        string colKey = NormTr(headers[c]).Trim();
                        if (colKey.Length > 0) d[colKey] = cols[c].Trim();
                    }
                    d["__satir_adi__"] = cols.Length > 0 ? cols[0].Trim() : "";
                    if (d.Count > 0) rows.Add(d);
                }
            }
            else
            {
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] cols = lines[i].Split('\t');
                    if (cols.Length < 2) continue;
                    Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    d["surec aciklamasi"] = cols[0].Trim();
                    if (cols.Length >= 3)
                    {
                        d["miktar"] = cols[cols.Length - 2].Trim();
                        d["net tutar"] = cols[cols.Length - 1].Trim();
                    }
                    else
                    {
                        d["net tutar"] = cols[1].Trim();
                    }
                    d["__satir_adi__"] = cols[0].Trim();
                    rows.Add(d);
                }
            }

            if (rows.Count == 0) return null;
            return ComputeMahmutbeySummaryFromDictionaries(rows, reportName);
        }

        private static MerkezSalesSummary ComputeMahmutbeySummaryFromDictionaries(List<Dictionary<string, string>> rows, string reportName)
        {
            if (rows == null || rows.Count == 0) return null;

            bool hasStoreColumn = false;
            for (int i = 0; i < rows.Count; i++)
            {
                foreach (string k in rows[i].Keys)
                {
                    if (k.Contains("magaza") || k.Contains("sube") || k.Contains("depo") || k.Contains("ofis") || k == "storecode")
                    {
                        hasStoreColumn = true;
                        break;
                    }
                }
                if (hasStoreColumn) break;
            }

            double sumNet = 0;
            double sumQty = 0;
            int sumTx = 0;
            double grandTotalNet = double.NaN;
            double grandTotalQty = double.NaN;
            int grandTotalTx = 0;
            int matchedRows = 0;

            for (int i = 0; i < rows.Count; i++)
            {
                Dictionary<string, string> r = rows[i];

                // Mağaza kolonu varsa aktif şubeye (Mahmutbey / PM3401) ait satırları filtrele
                if (hasStoreColumn)
                {
                    string storeVal = GetDictValueByPartialKey(r, new string[] { "magaza adi", "magaza aciklamasi", "magaza kodu", "magaza", "ofis", "depo", "sube" });
                    if (!string.IsNullOrEmpty(storeVal) && !IsCurrentBranchStoreText(storeVal))
                    {
                        continue;
                    }
                }

                string rowLabel = NormTr(GetDictValueByPartialKey(r, new string[] { "surec aciklamasi", "islem tipi", "hareket", "__satir_adi__" }));
                string iadeCol = NormTr(GetDictValueByPartialKey(r, new string[] { "iade" }));

                if (r.ContainsKey("odeme tipi aciklamasi") || r.ContainsKey("pesinat"))
                {
                    continue;
                }

                string netStr = GetDictValueByPartialKey(r, new string[] { "net tutar", "toplam ciro", "net ciro", "ciro", "satis tutari", "tutar (vd)", "tutar" });
                string qtyStr = GetDictValueByPartialKey(r, new string[] { "miktar", "satis miktari", "net miktar", "adet" });
                string txStr = GetDictValueByPartialKey(r, new string[] { "fis sayisi", "islem sayisi", "islem adedi", "belge sayisi", "musteri sayisi" });

                double netVal = ParseTrDouble(netStr);
                double qtyVal = ParseTrDouble(qtyStr);
                double txVal = ParseTrDouble(txStr);

                if (double.IsNaN(netVal) && double.IsNaN(qtyVal) && double.IsNaN(txVal))
                {
                    continue;
                }

                bool isGrandTotal = rowLabel.Contains("genel toplam") || (!hasStoreColumn && rowLabel == "toplam");
                bool isSubTotal = !isGrandTotal && (rowLabel.Contains("toplam") || iadeCol == "toplam");

                if (isGrandTotal && !hasStoreColumn)
                {
                    if (!double.IsNaN(netVal)) grandTotalNet = netVal;
                    if (!double.IsNaN(qtyVal)) grandTotalQty = qtyVal;
                    if (!double.IsNaN(txVal) && txVal > 0) grandTotalTx = (int)Math.Round(txVal);
                    matchedRows++;
                }
                else if (!isSubTotal)
                {
                    if (!double.IsNaN(netVal)) sumNet += netVal;
                    if (!double.IsNaN(qtyVal)) sumQty += qtyVal;
                    if (!double.IsNaN(txVal) && txVal > 0)
                    {
                        sumTx += (int)Math.Round(txVal);
                    }
                    else if ((!double.IsNaN(netVal) && Math.Abs(netVal) > 0.009) || (!double.IsNaN(qtyVal) && Math.Abs(qtyVal) > 0.009))
                    {
                        sumTx += 1;
                    }
                    matchedRows++;
                }
            }

            MerkezSalesSummary res = new MerkezSalesSummary();
            res.ok = true;
            res.updatedAt = DateTime.Now.ToString("HH:mm");
            res.dateKey = DateTime.Now.ToString("yyyy-MM-dd");
            res.sourceReport = string.IsNullOrEmpty(reportName) ? ("Mağaza Hareket Özeti (" + Sube.Kod + ")") : reportName;

            if (matchedRows == 0)
            {
                res.hasSales = false;
                res.netSales = 0;
                res.transactionCount = 0;
                res.itemQuantity = 0;
                return res;
            }

            res.netSales = !double.IsNaN(grandTotalNet) ? grandTotalNet : sumNet;
            res.itemQuantity = !double.IsNaN(grandTotalQty) ? grandTotalQty : sumQty;
            res.transactionCount = grandTotalTx > 0 ? grandTotalTx : sumTx;
            if (res.transactionCount <= 0 && (Math.Abs(res.netSales) > 0.009 || Math.Abs(res.itemQuantity) > 0.009))
            {
                res.transactionCount = matchedRows;
            }
            res.hasSales = Math.Abs(res.netSales) > 0.009 || res.transactionCount > 0 || Math.Abs(res.itemQuantity) > 0.009;
            return res;
        }

        private static bool IsCurrentBranchStoreText(string storeText)
        {
            string n = NormTr(storeText).Trim();
            if (n.Length == 0) return true;
            string kodNorm = NormTr(Sube.Kod ?? "PM3401");
            string adNorm = NormTr(Sube.Ad ?? "Mahmutbey");
            if (kodNorm.Length > 0 && n.Contains(kodNorm)) return true;
            if (adNorm.Length > 0 && n.Contains(adNorm)) return true;
            if (n.Contains("mahmutbey") || n.Contains("pm3401")) return true;
            return false;
        }

        private static string GetDictValueByPartialKey(Dictionary<string, string> d, string[] candidates)
        {
            if (d == null || candidates == null) return "";
            for (int i = 0; i < candidates.Length; i++)
            {
                string key = candidates[i];
                string val;
                if (d.TryGetValue(key, out val) && !string.IsNullOrEmpty(val))
                {
                    return val;
                }
                foreach (KeyValuePair<string, string> kv in d)
                {
                    if (kv.Key.Contains(key) && !string.IsNullOrEmpty(kv.Value))
                    {
                        return kv.Value;
                    }
                }
            }
            return "";
        }

        private static double ParseTrDouble(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return double.NaN;
            string cleaned = Regex.Replace(raw, @"[^\d,\.\-]", "").Trim();
            if (cleaned.Length == 0 || cleaned == "-") return double.NaN;

            if (cleaned.IndexOf(',') >= 0 && cleaned.IndexOf('.') >= 0)
            {
                cleaned = cleaned.Replace(".", "").Replace(",", ".");
            }
            else if (cleaned.IndexOf(',') >= 0)
            {
                cleaned = cleaned.Replace(",", ".");
            }

            double v;
            if (double.TryParse(cleaned, NumberStyles.Any, CultureInfo.InvariantCulture, out v))
            {
                return v;
            }
            return double.NaN;
        }

        private void OpenTileMenu(string tileTitle, string primaryMenu, string fallbackMenu, int sira, Button clickedTileBtn)
        {
            if (isOpeningScreenBusy)
            {
                LogLine("[ÇAKIŞMA-KORUMA] Ekran açılışı devam ederken mükerrer tıklama yoksayıldı: '" + tileTitle + "'");
                return;
            }
            isOpeningScreenBusy = true;
            try
            {
                OpenTileMenuCore(tileTitle, primaryMenu, fallbackMenu, sira, clickedTileBtn);
            }
            finally
            {
                isOpeningScreenBusy = false;
            }
        }

        private void OpenTileMenuCore(string tileTitle, string primaryMenu, string fallbackMenu, int sira, Button clickedTileBtn)
        {
            LogLine("=== [MAHMUTBEY KARO TIKLANDI] Karo: '" + tileTitle + "' -> Hedef: '" + primaryMenu + "' (Yedek: '" + fallbackMenu + "', Sıra: " + sira + ") ===");
            LastRequestedQuery = tileTitle;
            LastRequestedTileIdx = quickTileButtons != null ? quickTileButtons.IndexOf(clickedTileBtn) : -1;
            LastAssistantOpenedScreen = primaryMenu;
            LastRequestTime = DateTime.Now;

            string learnedOverride;
            if (LearnedQueryToMenu.TryGetValue(NormTr(tileTitle), out learnedOverride) && !string.IsNullOrEmpty(learnedOverride))
            {
                primaryMenu = learnedOverride;
            }
            lastAutoClosedScreen = "";
            if (frameOverlay != null) frameOverlay.HideFrame();
            if (lstQuickSearchResults != null) lstQuickSearchResults.Visible = false;

            // "Ürün İade Al" karosu tıklandığında POS iade adımlarını da canlı makine ekranında rehber olarak göster
            bool isPosReturnTile = NormTr(tileTitle).Contains("urun iade al");
            if (isPosReturnTile && CanliMakineEkranPanel.ActiveInstance != null)
            {
                CanliMakineEkranPanel.ActiveInstance.PushLiveAction(
                    "▶ ÜRÜN İADE AL REHBERİ (POS + Mağaza Satış Listesi)",
                    "Müşteri iadesi POS'ta yapılır: Nebim V3 POS → Peşin Satış İade → Ürün barkodunu okutun. Satış fişini bulmak için '" + primaryMenu + "' ekranı açılıyor...",
                    "⏳ [" + tileTitle + "] '" + primaryMenu + "' ekranı açılıyor...");
            }

            StartTileSpinner(clickedTileBtn);

            suppressQuickSearchEvents = true;
            cmbMenuSearch.Text = primaryMenu;
            suppressQuickSearchEvents = false;

            lblScreenTitle.Text = "🧭 Aktif Ekran: RDP içinde NebimYardimci yanıtı bekleniyor...";
            lblFrameStatus.Text = "⏳ [" + tileTitle + "] '" + primaryMenu + "' mağaza ekranı açılıyor...";
            lblFrameStatus.ForeColor = ThemeWarnColor();
            statusMessageHoldTicks = 12;
            Application.DoEvents();

            AutomationElement erpWin = FindErpWindow();
            string msg;
            string usedMenu = primaryMenu;
            bool ok = OpenScreenViaSearchBox(erpWin, primaryMenu, sira, true, out msg);

            if (!ok && !string.IsNullOrEmpty(fallbackMenu) && !string.Equals(primaryMenu, fallbackMenu, StringComparison.OrdinalIgnoreCase))
            {
                LogLine("[MAHMUTBEY KARO YEDEK] '" + primaryMenu + "' doğrulanamadı, yedek mağaza ekranı deneniyor: '" + fallbackMenu + "'");
                usedMenu = fallbackMenu;
                suppressQuickSearchEvents = true;
                cmbMenuSearch.Text = fallbackMenu;
                suppressQuickSearchEvents = false;
                erpWin = FindErpWindow();
                ok = OpenScreenViaSearchBox(erpWin, fallbackMenu, 1, true, out msg);
            }

            StopTileSpinner();

            lblFrameStatus.Text = msg;
            lblFrameStatus.ForeColor = ok ? ThemeOkColor() : ThemeWarnColor();
            statusMessageHoldTicks = 14;
            currentTrackedScreen = "";
            currentSteps.Clear();

            erpWin = FindErpWindow();
            if (erpWin != null)
            {
                string activeScreen = GetActiveScreenName(erpWin);
                if (!string.IsNullOrEmpty(activeScreen))
                {
                    currentTrackedScreen = activeScreen;
                    currentSteps = DiscoverLiveGuidedSteps(erpWin, activeScreen);
                    currentStepIdx = 0;
                    RefreshStepUi();
                    UpdateSummaryBannerWithActiveState();
                }
                else
                {
                    if (frameOverlay != null) frameOverlay.HideFrame();
                    lblScreenTitle.Text = "🧭 Aktif Ekran: Ekran henüz açılmadı";
                }
            }
            else if (ok && !string.IsNullOrEmpty(LastVerifiedRdpScreen))
            {
                currentTrackedScreen = LastVerifiedRdpScreen;
                currentSteps = new List<GuidedStep>(LastVerifiedRdpSteps);
                currentStepIdx = 0;
                RefreshStepUi();
                UpdateSummaryBannerWithActiveState();
            }
            else
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                if (isPosReturnTile)
                {
                    lblScreenTitle.Text = "🧭 Aktif Ekran: " + usedMenu;
                    lblActiveStepTitle.Text = "▶ ÜRÜN İADE AL (Nebim V3 POS → Peşin Satış İade)";
                    lblActiveStepDesc.Text = "Müşteri iadesi POS'ta yapılır: Nebim V3 POS → Peşin Satış İade → Ürün barkodunu okutun.";
                }
                else
                {
                    currentTrackedScreen = usedMenu;
                    currentSteps = BuildCatalogFallbackGuidedSteps(usedMenu);
                    currentStepIdx = 0;
                    RefreshStepUi();
                    lblFrameStatus.Text = "✓ '" + usedMenu + "' mağaza rehberi hazır — Adımları aşağıdan takip edebilirsiniz.";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                    statusMessageHoldTicks = 18;
                }
            }
            WriteLiveTestReport(tileTitle + " -> " + usedMenu, ok, msg);
        }

        private List<GuidedStep> BuildCatalogFallbackGuidedSteps(string screenName)
        {
            List<GuidedStep> steps = new List<GuidedStep>();
            string target = (screenName ?? "").Trim();
            if (target.Length == 0) target = "Mağaza Ekranı";

            AtlasItem matched = null;
            ResolveBestMenuQuery(target, out matched);
            string kategori = (matched != null && !string.IsNullOrEmpty(matched.kategori)) ? matched.kategori : "Mağaza İşlemleri";
            string ilkAlan = (matched != null && !string.IsNullOrEmpty(matched.ilkVeriAlani))
                ? matched.ilkVeriAlani
                : InferFirstInputField(kategori, target, "");
            List<string> rawSteps = (matched != null && matched.rehberAdimlari != null && matched.rehberAdimlari.Count > 0)
                ? matched.rehberAdimlari
                : BuildDefaultGuideSteps(kategori, target, ilkAlan);

            if (NormTr(target).Contains("satis sorumlusu"))
            {
                rawSteps = BuildDefaultGuideSteps(kategori, target, ilkAlan);
            }

            for (int i = 0; i < rawSteps.Count; i++)
            {
                GuidedStep gs = new GuidedStep();
                gs.stepNo = i + 1;
                if (i == 0) gs.fieldName = ilkAlan;
                else if (i == 1 && NormTr(target).Contains("satis sorumlusu")) gs.fieldName = "Perakende Satış Yapar (Pasife Alma)";
                else if (i == rawSteps.Count - 1) gs.fieldName = "Kaydet / Çalıştır";
                else gs.fieldName = "Adım " + (i + 1);
                gs.instruction = rawSteps[i];
                gs.isActionStep = (i == rawSteps.Count - 1);
                gs.completed = false;
                gs.lastRect = System.Windows.Rect.Empty;
                steps.Add(gs);
            }
            return steps;
        }

        private void TriggerAutoOpenSelectedMenu(bool fromButton)
        {
            if (isOpeningScreenBusy) return;
            isOpeningScreenBusy = true;
            try
            {
                TriggerAutoOpenSelectedMenuCore(fromButton);
            }
            finally
            {
                isOpeningScreenBusy = false;
            }
        }

        private void TriggerAutoOpenSelectedMenuCore(bool fromButton)
        {
            string rawMenu = (cmbMenuSearch.Text ?? "").Trim();
            if (rawMenu.StartsWith("⭐ ")) rawMenu = rawMenu.Substring(2).Trim();
            if (rawMenu.Length < 2) return;
            if (frameOverlay != null) frameOverlay.HideFrame();
            if (lstQuickSearchResults != null) lstQuickSearchResults.Visible = false;

            AtlasItem matchedItem;
            string searchQuery = ResolveBestMenuQuery(rawMenu, out matchedItem);
            string targetMenu = (matchedItem != null && !string.IsNullOrEmpty(matchedItem.baslik)) ? matchedItem.baslik : rawMenu;
            int targetSira = (matchedItem != null && matchedItem.sira > 0) ? matchedItem.sira : 1;

            LastRequestedQuery = rawMenu;
            LastRequestedTileIdx = -1;
            LastAssistantOpenedScreen = targetMenu;
            LastRequestTime = DateTime.Now;

            suppressQuickSearchEvents = true;
            cmbMenuSearch.Text = targetMenu;
            suppressQuickSearchEvents = false;

            lastAutoClosedScreen = "";
            lblScreenTitle.Text = "🧭 Aktif Ekran: RDP içinde NebimYardimci yanıtı bekleniyor...";
            lblFrameStatus.Text = "⏳ 'Ara…' kutusuna '" + searchQuery + "' otomatik yazılıyor...";
            lblFrameStatus.ForeColor = ThemeWarnColor();
            statusMessageHoldTicks = 12;
            Application.DoEvents();

            AutomationElement erpWin = FindErpWindow();
            string msg;
            bool ok = OpenScreenViaSearchBox(erpWin, targetMenu, targetSira, fromButton, out msg);

            lblFrameStatus.Text = msg;
            lblFrameStatus.ForeColor = ok ? ThemeOkColor() : ThemeWarnColor();
            statusMessageHoldTicks = 14;
            currentTrackedScreen = "";
            currentSteps.Clear();

            erpWin = FindErpWindow();
            if (erpWin != null)
            {
                string activeScreen = GetActiveScreenName(erpWin);
                if (!string.IsNullOrEmpty(activeScreen))
                {
                    currentTrackedScreen = activeScreen;
                    currentSteps = DiscoverLiveGuidedSteps(erpWin, activeScreen);
                    currentStepIdx = 0;
                    RefreshStepUi();
                    UpdateSummaryBannerWithActiveState();
                }
                else
                {
                    if (frameOverlay != null) frameOverlay.HideFrame();
                    lblScreenTitle.Text = "🧭 Aktif Ekran: Ekran henüz açılmadı";
                }
            }
            else if (ok && !string.IsNullOrEmpty(LastVerifiedRdpScreen))
            {
                currentTrackedScreen = LastVerifiedRdpScreen;
                currentSteps = new List<GuidedStep>(LastVerifiedRdpSteps);
                currentStepIdx = 0;
                RefreshStepUi();
                UpdateSummaryBannerWithActiveState();
            }
            else
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                currentTrackedScreen = targetMenu;
                currentSteps = BuildCatalogFallbackGuidedSteps(targetMenu);
                currentStepIdx = 0;
                RefreshStepUi();
                lblFrameStatus.Text = "✓ '" + targetMenu + "' mağaza rehberi hazır — Adımları aşağıdan takip edebilirsiniz.";
                lblFrameStatus.ForeColor = ThemeOkColor();
                statusMessageHoldTicks = 18;
            }
            WriteLiveTestReport(targetMenu, ok, msg);
        }

        private void WriteLiveTestReport(string requestedMenu, bool openSuccess, string openMessage)
        {
            try
            {
                AutomationElement erpWin = FindErpWindow();
                IntPtr rdpHwnd = FindRdpClientWindow();
                string erpTitle = erpWin != null ? SafeGetName(erpWin) : ((rdpHwnd != IntPtr.Zero || LastVerifiedRdpScreen.Length > 0) ? "Uzak Masaüstü (Nebim V3 STORE)" : "(Yok)");
                string activeScr = currentTrackedScreen;
                string firstField = (currentSteps != null && currentSteps.Count > 0) ? currentSteps[0].fieldName : "";
                System.Windows.Rect r = (currentSteps != null && currentSteps.Count > 0) ? currentSteps[0].lastRect : System.Windows.Rect.Empty;
                bool hasLiveElement = (currentSteps != null && currentSteps.Count > 0 && (currentSteps[0].element != null || !r.IsEmpty || currentSteps[0].rdpGenislik > 30));

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("{");
                sb.AppendLine("  \"surum\": \"5.0\",");
                sb.AppendLine("  \"subeKod\": \"" + JsonEscape(Sube.Kod) + "\",");
                sb.AppendLine("  \"subeAd\": \"" + JsonEscape(Sube.Ad) + "\",");
                sb.AppendLine("  \"tarih\": \"" + JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) + "\",");
                sb.AppendLine("  \"istenenMenu\": \"" + JsonEscape(requestedMenu) + "\",");
                sb.AppendLine("  \"acmaBasarili\": " + (openSuccess ? "true" : "false") + ",");
                sb.AppendLine("  \"acmaMesaji\": \"" + JsonEscape(openMessage) + "\",");
                sb.AppendLine("  \"erpPencereBasligi\": \"" + JsonEscape(erpTitle) + "\",");
                sb.AppendLine("  \"aktifEkran\": \"" + JsonEscape(activeScr) + "\",");
                sb.AppendLine("  \"cercevelenenIlkAlan\": \"" + JsonEscape(firstField) + "\",");
                sb.AppendLine("  \"canliCerceveAktif\": " + (hasLiveElement ? "true" : "false") + ",");
                sb.AppendLine("  \"alanKoordinat\": {\"sol\":" + (int)r.Left + ",\"ust\":" + (int)r.Top + ",\"genislik\":" + (int)r.Width + ",\"yukseklik\":" + (int)r.Height + "},");
                sb.AppendLine("  \"adimSayisi\": " + (currentSteps != null ? currentSteps.Count : 0));
                sb.AppendLine("}");

                AtomicWriteText(Path.Combine(ResolveOutputDir(), "mahmutbey-canli-test-sonuc.json"), sb.ToString());
            }
            catch { }
        }

        private void AdvanceToNextStepManual()
        {
            if (currentSteps == null || currentSteps.Count == 0) return;
            if (currentStepIdx >= 0 && currentStepIdx < currentSteps.Count)
            {
                currentSteps[currentStepIdx].completed = true;
                currentStepIdx++;
                if (currentStepIdx >= currentSteps.Count)
                {
                    StartAutoCloseCountdown();
                }
                else
                {
                    statusMessageHoldTicks = 0;
                    RefreshStepUi();
                    if (LastRdpFrameActive && currentStepIdx < currentSteps.Count)
                    {
                        SendRdpFrameQueueCommand("cerceve-adim", currentSteps[currentStepIdx], currentSteps.Count);
                    }
                }
            }
        }

        private void CompleteAndAutoHideCurrentScreen()
        {
            lastAutoClosedScreen = currentTrackedScreen;
            if (frameOverlay != null) frameOverlay.HideFrame();
            if (LastRdpFrameActive)
            {
                SendRdpFrameQueueCommand("cerceve-gizle", null, 0);
            }
            lblFrameStatus.Text = "✓ Çerçeve gizlendi. Yeni işlem için yukarıdaki mağaza karolarına tıklayın.";
            lblFrameStatus.ForeColor = ThemeOkColor();
            statusMessageHoldTicks = 10;
        }

        private void StartAutoCloseCountdown()
        {
            completionCountdown = 6;
            if (frameOverlay != null) frameOverlay.HideFrame();
            if (LastRdpFrameActive)
            {
                SendRdpFrameQueueCommand("cerceve-gizle", null, 0);
            }
            lblActiveStepTitle.Text = "✅ MAĞAZA İŞLEM ADIMI TAMAMLANDI!";
            lblActiveStepTitle.ForeColor = ThemeStepTitleColor(true);
            lblActiveStepDesc.Text = "'" + currentTrackedScreen + "' ekranındaki işlem adımı tamamlandı. Çerçeve otomatik gizlendi.";
            lblFrameStatus.Text = "✓ Yeni ekran açıldığında veya karolara tıklandığında tekrar devreye girer.";
            RefreshStepsChecklistText();
            SesliAsistan.Konus(currentTrackedScreen + " ekranındaki işlem adımı tamamlandı.", false);
        }

        private bool isMonitorTickBusy = false;

        private void OnMonitorTick(object sender, EventArgs e)
        {
            if (isMonitorTickBusy) return;
            isMonitorTickBusy = true;
            try
            {
                OnMonitorTickCore();
            }
            finally
            {
                isMonitorTickBusy = false;
            }
        }

        private void OnMonitorTickCore()
        {
            try
            {
                if (showEvent != null && showEvent.WaitOne(0))
                {
                    Show();
                    if (isCompactMode) ToggleCompactMode();
                    Activate();
                }
            }
            catch { }

            if (spinTickCount > 0)
            {
                spinTickCount--;
                if (spinTickCount == 0) StopTileSpinner();
            }

            // [OPT-11.1] Ön plandaki pencere "POS" ise hem RenkliCerceveForm hem RehberKontrolMerkezi anında gizlenir
            if (IsPosForeground())
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                if (Visible)
                {
                    hiddenByPosShield = true;
                    Visible = false;
                }
                return;
            }

            if (hiddenByPosShield && !Visible)
            {
                hiddenByPosShield = false;
                Visible = true;
            }

            if (statusMessageHoldTicks > 0)
            {
                statusMessageHoldTicks--;
            }

            if (++binaryCheckCounter >= 8)
            {
                binaryCheckCounter = 0;
                if (CheckIfRemoteBinaryUpdated())
                {
                    Close();
                    return;
                }
            }

            CheckExternalGuideQueue();

            if (!startupMenuTriggered && pendingStartupMenu.Length >= 2)
            {
                startupMenuTriggered = true;
                suppressQuickSearchEvents = true;
                cmbMenuSearch.Text = pendingStartupMenu;
                suppressQuickSearchEvents = false;
                TriggerAutoOpenSelectedMenu(true);
                return;
            }

            AutomationElement erpWin = FindErpWindow();
            if (erpWin == null)
            {
                IntPtr rdpHwnd = FindRdpClientWindow();
                string rdpTelemetryScreen;
                bool rdpBridgeFresh;
                bool rdpErpOpen = CanliMakineEkranPanel.IsRdpErpOpenFromTelemetry(out rdpTelemetryScreen, out rdpBridgeFresh);
                if (rdpHwnd != IntPtr.Zero || rdpErpOpen)
                {
                    if (rdpErpOpen)
                    {
                        lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
                        btnMcpStatus.Text = Sube.Kod + " · Açık";
                        btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                        if (rdpBridgeFresh && !string.IsNullOrEmpty(rdpTelemetryScreen))
                        {
                            RecordScreenUsageAndCheckCorrection(rdpTelemetryScreen);
                        }
                    }
                    else
                    {
                        lblStatusDot.BackColor = Color.FromArgb(46, 170, 40);
                        btnMcpStatus.Text = Sube.Kod + " · Bağlı";
                        btnMcpStatus.BackColor = Color.FromArgb(0, 152, 136);
                    }
                    if (rdpHwnd == IntPtr.Zero || IsIconic(rdpHwnd) || !IsErpOrSelfForeground(null, Handle) || !rdpErpOpen)
                    {
                        if (frameOverlay != null) frameOverlay.HideFrame();
                        return;
                    }
                    if (completionCountdown > 0)
                    {
                        completionCountdown--;
                        if (completionCountdown == 0) CompleteAndAutoHideCurrentScreen();
                        return;
                    }
                    if (RdpVerifiedGraceTicks > 0)
                    {
                        RdpVerifiedGraceTicks--;
                    }
                    else if (currentTrackedScreen.Length > 0 && rdpBridgeFresh)
                    {
                        try
                        {
                            if (string.IsNullOrEmpty(rdpTelemetryScreen))
                            {
                                if (frameOverlay != null) frameOverlay.HideFrame();
                                currentTrackedScreen = "";
                                currentSteps.Clear();
                                lblScreenTitle.Text = "🧭 Aktif Ekran: Ekran henüz açılmadı";
                                UpdateSummaryBannerWithActiveState();
                                return;
                            }
                        }
                        catch { }
                    }
                    if (currentSteps != null && currentStepIdx >= 0 && currentStepIdx < currentSteps.Count && !string.Equals(currentTrackedScreen, lastAutoClosedScreen, StringComparison.OrdinalIgnoreCase))
                    {
                        GuidedStep rdpStep = currentSteps[currentStepIdx];
                        if (rdpStep.isActionStep && ((GetAsyncKeyState(VK_F5) & 0x8000) != 0))
                        {
                            rdpStep.completed = true;
                            StartAutoCloseCountdown();
                            return;
                        }
                        UpdateFrameForCurrentStep(rdpStep);
                    }
                    else
                    {
                        if (frameOverlay != null) frameOverlay.HideFrame();
                    }
                    return;
                }

                lblStatusDot.BackColor = Color.FromArgb(210, 45, 45);
                if (frameOverlay != null) frameOverlay.HideFrame();
                return;
            }
            lblStatusDot.BackColor = Color.FromArgb(31, 87, 153);

            if (IsErpWindowMinimized(erpWin) || !IsErpOrSelfForeground(erpWin, Handle))
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                return;
            }

            if (completionCountdown > 0)
            {
                completionCountdown--;
                if (completionCountdown == 0)
                {
                    CompleteAndAutoHideCurrentScreen();
                }
                return;
            }

            string activeScreen = GetActiveScreenName(erpWin);

            if (string.IsNullOrEmpty(activeScreen))
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                if (currentTrackedScreen.Length > 0 && Visible)
                {
                    currentTrackedScreen = "";
                    UpdateSummaryBannerWithActiveState();
                }
                return;
            }

            if (!string.Equals(activeScreen, currentTrackedScreen, StringComparison.OrdinalIgnoreCase))
            {
                if (string.Equals(activeScreen, lastAutoClosedScreen, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }

                currentTrackedScreen = activeScreen;
                RecordScreenUsageAndCheckCorrection(activeScreen);
                currentSteps = DiscoverLiveGuidedSteps(erpWin, activeScreen);
                currentStepIdx = 0;

                if (!Visible)
                {
                    Visible = true;
                }
                RefreshStepUi();
                UpdateSummaryBannerWithActiveState();
                WriteLiveTestReport(activeScreen, true, "Aktif mağaza ekranı otomatik algılandı ve alanları çerçevelendi.");
                return;
            }

            if (currentSteps != null && currentStepIdx >= 0 && currentStepIdx < currentSteps.Count)
            {
                GuidedStep step = currentSteps[currentStepIdx];
                CheckLiveStepProgress(erpWin, step);
            }
        }

        private void CheckLiveStepProgress(AutomationElement erpWin, GuidedStep step)
        {
            if (step == null) return;

            try
            {
                AutomationElement focused = AutomationElement.FocusedElement;
                if (focused != null)
                {
                    for (int nextIdx = currentStepIdx + 1; nextIdx < currentSteps.Count; nextIdx++)
                    {
                        GuidedStep nextStep = currentSteps[nextIdx];
                        if (nextStep.element != null && AreElementsSameOrChild(focused, nextStep.element))
                        {
                            for (int k = currentStepIdx; k < nextIdx; k++) currentSteps[k].completed = true;
                            currentStepIdx = nextIdx;
                            RefreshStepUi();
                            return;
                        }
                    }
                }
            }
            catch { }

            if (step.element != null)
            {
                string nowVal = SafeGetValue(step.element);
                bool valChanged = !string.IsNullOrEmpty(nowVal) && !string.Equals(nowVal, step.initialValue, StringComparison.Ordinal);

                bool enterOrTabPressed = ((GetAsyncKeyState(VK_RETURN) & 0x8000) != 0) || ((GetAsyncKeyState(VK_TAB) & 0x8000) != 0);
                if (valChanged && enterOrTabPressed)
                {
                    step.completed = true;
                    currentStepIdx++;
                    if (currentStepIdx >= currentSteps.Count)
                    {
                        StartAutoCloseCountdown();
                    }
                    else
                    {
                        RefreshStepUi();
                    }
                    return;
                }
            }

            if (step.isActionStep)
            {
                bool f5Pressed = (GetAsyncKeyState(VK_F5) & 0x8000) != 0;
                if (f5Pressed)
                {
                    step.completed = true;
                    StartAutoCloseCountdown();
                    return;
                }
            }

            UpdateFrameForCurrentStep(step);
        }

        private void UpdateFrameForCurrentStep(GuidedStep step)
        {
            if (step == null)
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                return;
            }

            if (LastRdpFrameActive && step.rdpGenislik > 30)
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                if (statusMessageHoldTicks <= 0)
                {
                    lblFrameStatus.Text = "🟧 Renkli Çerçeve Aktif (RDP İçi): '" + step.fieldName + "' alanı işaretlendi ve odaklandı.";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
                return;
            }

            System.Windows.Rect r = step.lastRect;
            if (step.element != null)
            {
                System.Windows.Rect liveRect = SafeGetRect(step.element);
                if (!liveRect.IsEmpty && liveRect.Width > 30 && liveRect.Height >= 16)
                {
                    r = liveRect;
                    step.lastRect = liveRect;
                }
            }

            if (!r.IsEmpty && r.Left > 320 && (r.Top > 145 || step.isActionStep) && r.Width > 30 && r.Height >= 16)
            {
                string badge = "ADIM " + step.stepNo + "/" + currentSteps.Count + ": " + step.fieldName;
                frameOverlay.UpdateFrameTarget(r, badge, step.isActionStep);
                if (statusMessageHoldTicks <= 0)
                {
                    lblFrameStatus.Text = "🟧 Renkli Çerçeve Aktif: '" + step.fieldName + "' alanı işaretlendi.";
                    lblFrameStatus.ForeColor = ThemeOkColor();
                }
            }
            else
            {
                if (frameOverlay != null) frameOverlay.HideFrame();
                if (statusMessageHoldTicks <= 0)
                {
                    lblFrameStatus.Text = "ℹ️ Bilgi Penceresi Modu: '" + step.fieldName + "' alanını seçip işlemi yapın.";
                    lblFrameStatus.ForeColor = ThemeWarnColor();
                }
            }
        }

        private void RefreshStepUi()
        {
            lblScreenTitle.Text = "🧭 Aktif Ekran: " + (currentTrackedScreen.Length > 0 ? currentTrackedScreen : "(Bekleniyor)");

            if (currentSteps == null || currentSteps.Count == 0 || currentStepIdx >= currentSteps.Count)
            {
                return;
            }

            GuidedStep step = currentSteps[currentStepIdx];
            lblActiveStepTitle.Text = "▶ ADIM " + step.stepNo + " / " + currentSteps.Count + ": " + step.fieldName;
            lblActiveStepTitle.ForeColor = ThemeStepTitleColor(step.isActionStep);
            lblActiveStepDesc.Text = step.instruction;

            UpdateFrameForCurrentStep(step);
            RefreshStepsChecklistText();
            SesliAsistan.Konus("Adım " + step.stepNo + ": " + step.fieldName + ". " + step.instruction, false);
        }

        private void RefreshStepsChecklistText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Mağaza Yol Gösterici İşlem Adımları:");
            for (int i = 0; i < currentSteps.Count; i++)
            {
                GuidedStep s = currentSteps[i];
                string icon = s.completed ? "✅" : (i == currentStepIdx ? "👉" : "⏳");
                sb.AppendLine(icon + " Adım " + s.stepNo + ": " + s.fieldName + (s.completed ? " (Tamamlandı)" : ""));
            }
            lblStepsList.Text = sb.ToString();
        }

        private void CheckExternalGuideQueue()
        {
            try
            {
                string reqPath = Path.Combine(ResolveOutputDir(), "mahmutbey-rehber-istek.json");
                if (!File.Exists(reqPath)) return;

                string raw = File.ReadAllText(reqPath, Encoding.UTF8).Trim();
                File.Delete(reqPath);

                Match mCmd = Regex.Match(raw, "\"komut\"\\s*:\\s*\"(.*?)\"");
                if (mCmd.Success)
                {
                    string cmd = JsonUnescape(mCmd.Groups[1].Value).Trim().ToLowerInvariant();
                    LogLine("[MAHMUTBEY KUYRUK-KOMUT] Dış komut alındı: '" + cmd + "'");
                    if (cmd == "yenile" || cmd == "sql-yenile")
                    {
                        RefreshMerkezSalesSummary(false);
                        return;
                    }
                    if (cmd == "sistem-onar")
                    {
                        RunSystemIntegrityRestoreAndReport(false);
                        return;
                    }
                }

                Match m = Regex.Match(raw, "\"menu\"\\s*:\\s*\"(.*?)\"");
                string menuName = m.Success ? JsonUnescape(m.Groups[1].Value) : raw;
                if (menuName.Length >= 2)
                {
                    LogLine("[MAHMUTBEY KUYRUK] Dış istek alındı: '" + menuName + "'");
                    if (!Visible) Visible = true;
                    suppressQuickSearchEvents = true;
                    cmbMenuSearch.Text = menuName;
                    suppressQuickSearchEvents = false;
                    TriggerAutoOpenSelectedMenu(true);
                }
            }
            catch { }
        }

        private static bool AreElementsSameOrChild(AutomationElement focused, AutomationElement target)
        {
            if (focused == null || target == null) return false;
            try
            {
                if (Automation.Compare(focused, target)) return true;
                System.Windows.Rect rf = SafeGetRect(focused);
                System.Windows.Rect rt = SafeGetRect(target);
                if (!rf.IsEmpty && !rt.IsEmpty && Math.Abs(rf.Left - rt.Left) <= 20 && Math.Abs(rf.Top - rt.Top) <= 12)
                {
                    return true;
                }
            }
            catch { }
            return false;
        }
    }

    // =====================================================================================
    // [OPT-11] ÖN PLAN, SİMGE DURUMU (IsIconic), SESSION-ID VE POS KORUMA FONKSİYONLARI
    // =====================================================================================
    public static bool IsErpWindowMinimized(AutomationElement erpWin)
    {
        if (erpWin == null) return true;
        try
        {
            IntPtr hWnd = new IntPtr(erpWin.Current.NativeWindowHandle);
            if (hWnd != IntPtr.Zero && IsIconic(hWnd))
            {
                return true;
            }
        }
        catch { }
        return false;
    }

    public static bool IsErpOrSelfForeground(AutomationElement erpWin, IntPtr selfHandle)
    {
        try
        {
            IntPtr fg = GetForegroundWindow();
            if (fg == IntPtr.Zero) return false;
            if (fg == selfHandle || fg == GetConsoleWindow()) return true;

            IntPtr rdpHwnd = FindRdpClientWindow();
            if (rdpHwnd != IntPtr.Zero && fg == rdpHwnd) return true;

            StringBuilder sb = new StringBuilder(512);
            GetWindowText(fg, sb, 512);
            string fgTitle = sb.ToString();
            if (IsPosWindowTitle(fgTitle)) return false;
            if (fgTitle.IndexOf("Nebim V3 ERP", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Nebim V3 STORE", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Uzak Masaüstü", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Remote Desktop", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Merkez Asistan Yol Gösterici", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Merkez Yol Gösterici", StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (fgTitle.IndexOf("Nebim Asistanı", StringComparison.OrdinalIgnoreCase) >= 0) return true;

            uint fgPid;
            GetWindowThreadProcessId(fg, out fgPid);
            if (fgPid != 0 && (int)fgPid == Process.GetCurrentProcess().Id) return true;

            if (erpWin != null)
            {
                IntPtr erpHandle = new IntPtr(erpWin.Current.NativeWindowHandle);
                if (fg == erpHandle) return true;
                if (fgPid != 0 && (int)fgPid == erpWin.Current.ProcessId)
                {
                    return true;
                }
            }
        }
        catch { }
        return false;
    }

    public static bool IsPosWindowTitle(string title)
    {
        if (string.IsNullOrEmpty(title)) return false;
        if (title.IndexOf("Nebim V3 POS", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("NebimV3POS", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        return false;
    }

    public static bool IsExcludedNonErpTitle(string title)
    {
        if (string.IsNullOrEmpty(title)) return true;
        if (IsPosWindowTitle(title)) return true;
        if (title.IndexOf("Merkez Keşif", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Merkez Atlas", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Merkez Asistan", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Yol Gösterici", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Nebim Asistanı", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Antigravity", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        if (title.IndexOf("Visual Studio", StringComparison.OrdinalIgnoreCase) >= 0) return true;
        return false;
    }

    public static AutomationElement FindErpWindow()
    {
        int selfPid = Process.GetCurrentProcess().Id;
        int mySession = Process.GetCurrentProcess().SessionId;
        HashSet<int> validErpPids = new HashSet<int>();

        // 1. Önce doğrudan bu oturumdaki (SessionId) NebimV3STORE / NebimV3ERP proseslerinden gerçek ana pencereyi bul
        try
        {
            string[] erpNames = new string[] { "NebimV3STORE", "NebimV3ERP" };
            for (int n = 0; n < erpNames.Length; n++)
            {
                Process[] procs = Process.GetProcessesByName(erpNames[n]);
                for (int i = 0; i < procs.Length; i++)
                {
                    try
                    {
                        if (procs[i].SessionId != mySession) continue;
                        validErpPids.Add(procs[i].Id);
                        IntPtr h = procs[i].MainWindowHandle;
                        if (h != IntPtr.Zero && IsWindowVisible(h))
                        {
                            AutomationElement el = AutomationElement.FromHandle(h);
                            if (el != null)
                            {
                                string t = SafeGetName(el);
                                if (!IsExcludedNonErpTitle(t))
                                {
                                    return el;
                                }
                            }
                        }
                    }
                    catch { }
                    finally { try { procs[i].Dispose(); } catch { } }
                }
            }
        }
        catch { }

        if (validErpPids.Count == 0)
        {
            return null;
        }

        // 2. Yalnızca doğrulanmış NebimV3STORE / NebimV3ERP proseslerine ait görünür WindowsForms10 penceresini ara
        IntPtr foundHwnd = IntPtr.Zero;
        IntPtr fallbackHwnd = IntPtr.Zero;
        try
        {
            EnumWindows(delegate(IntPtr hWnd, IntPtr lParam)
            {
                if (!IsWindowVisible(hWnd)) return true;
                uint pid;
                GetWindowThreadProcessId(hWnd, out pid);
                if ((int)pid == selfPid || !validErpPids.Contains((int)pid)) return true;

                StringBuilder sbCls = new StringBuilder(128);
                GetClassName(hWnd, sbCls, 128);
                string cls = sbCls.ToString();
                if (!cls.StartsWith("WindowsForms10.", StringComparison.OrdinalIgnoreCase)) return true;

                StringBuilder sbTitle = new StringBuilder(256);
                GetWindowText(hWnd, sbTitle, 256);
                string title = sbTitle.ToString();
                if (IsExcludedNonErpTitle(title)) return true;

                if (title.IndexOf("Nebim V3 STORE", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    title.IndexOf("Nebim V3 ERP", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    foundHwnd = hWnd;
                    return false;
                }
                if (fallbackHwnd == IntPtr.Zero && title.IndexOf("Nebim V3", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    fallbackHwnd = hWnd;
                }
                return true;
            }, IntPtr.Zero);

            IntPtr targetH = foundHwnd != IntPtr.Zero ? foundHwnd : fallbackHwnd;
            if (targetH != IntPtr.Zero)
            {
                return AutomationElement.FromHandle(targetH);
            }
        }
        catch { }
        return null;
    }

    public static bool IsPosForeground()
    {
        try
        {
            IntPtr fg = GetForegroundWindow();
            if (fg == IntPtr.Zero) return false;

            StringBuilder sb = new StringBuilder(512);
            GetWindowText(fg, sb, 512);
            string title = sb.ToString();
            if (IsPosWindowTitle(title))
            {
                return true;
            }

            uint pid;
            GetWindowThreadProcessId(fg, out pid);
            if (pid != 0)
            {
                Process p = Process.GetProcessById((int)pid);
                string procName = p.ProcessName ?? "";
                if (procName.Equals("NebimV3POS", StringComparison.OrdinalIgnoreCase) ||
                    procName.IndexOf("NebimV3POS", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }
        }
        catch { }
        return false;
    }

    private static string JsonUnescape(string s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        string res = s
            .Replace("\\u0027", "'")
            .Replace("\\u0026", "&")
            .Replace("\\u003e", ">")
            .Replace("\\u003c", "<")
            .Replace("\\u0022", "\"");
        if (res.IndexOf("\\u", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            res = Regex.Replace(res, "\\\\u([0-9a-fA-F]{4})", delegate(Match m)
            {
                int code;
                if (int.TryParse(m.Groups[1].Value, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out code))
                {
                    return ((char)code).ToString();
                }
                return m.Value;
            });
        }
        return res.Replace("\\\"", "\"").Replace("\\\\", "\\").Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t");
    }

    private static void ClickAt(int x, int y)
    {
        SetCursorPos(x, y);
        Thread.Sleep(45);
        INPUT down = new INPUT();
        down.type = 0;
        down.u.mi.dwFlags = MOUSEEVENTF_LEFTDOWN;
        INPUT up = new INPUT();
        up.type = 0;
        up.u.mi.dwFlags = MOUSEEVENTF_LEFTUP;
        SendInput(2, new INPUT[] { down, up }, Marshal.SizeOf(typeof(INPUT)));
    }

    private static void SendKeyDownUp(ushort vk, bool keyUp)
    {
        INPUT inp = new INPUT();
        inp.type = 1;
        inp.u.ki.wVk = vk;
        inp.u.ki.dwFlags = keyUp ? KEYEVENTF_KEYUP : 0;
        SendInput(1, new INPUT[] { inp }, Marshal.SizeOf(typeof(INPUT)));
    }

    private static void PressKey(ushort vk)
    {
        SendKeyDownUp(vk, false);
        Thread.Sleep(20);
        SendKeyDownUp(vk, true);
        Thread.Sleep(20);
    }

    private static void TypeUnicodeText(string text)
    {
        if (string.IsNullOrEmpty(text)) return;
        int cb = Marshal.SizeOf(typeof(INPUT));
        foreach (char c in text)
        {
            INPUT down = new INPUT();
            down.type = 1;
            down.u.ki.wScan = c;
            down.u.ki.dwFlags = KEYEVENTF_UNICODE;

            INPUT up = new INPUT();
            up.type = 1;
            up.u.ki.wScan = c;
            up.u.ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;

            SendInput(2, new INPUT[] { down, up }, cb);
            Thread.Sleep(15);
        }
    }

    private static string CleanTitle(string raw)
    {
        string s = (raw ?? "").Trim();
        if (s.Length > 2 && s[0] == '[' && s[s.Length - 1] == ']')
        {
            s = s.Substring(1, s.Length - 2).Trim();
        }
        return s;
    }

    private static string _cachedOutputDir = null;

    public static string ResolveOutputDir()
    {
        if (!string.IsNullOrEmpty(_cachedOutputDir)) return _cachedOutputDir;

        string appDataAraclar = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), @"Parfum Mutfagi\veri\nebim-gelen\araclar");
        try
        {
            if (Directory.Exists(appDataAraclar))
            {
                _cachedOutputDir = appDataAraclar;
                return _cachedOutputDir;
            }
        }
        catch { }

        string tsClientAraclar = @"\\tsclient\N\araclar";
        try
        {
            if (Directory.Exists(tsClientAraclar))
            {
                _cachedOutputDir = tsClientAraclar;
                return _cachedOutputDir;
            }
        }
        catch { }

        _cachedOutputDir = AppDomain.CurrentDomain.BaseDirectory;
        return _cachedOutputDir;
    }

    private static void AtomicWriteText(string filePath, string content)
    {
        string tmpPath = filePath + ".tmp";
        File.WriteAllText(tmpPath, content, new UTF8Encoding(false));
        if (File.Exists(filePath))
        {
            File.Delete(filePath);
        }
        File.Move(tmpPath, filePath);
    }

    private static void SaveGuideCatalogJson(string windowTitle)
    {
        string outDir = ResolveOutputDir();
        int verifiedCount = 0;
        for (int i = 0; i < SolMenuCatalog.Count; i++)
        {
            if (SolMenuCatalog[i].dogrulandi) verifiedCount++;
        }

        StringBuilder sb = new StringBuilder();
        sb.AppendLine("{");
        sb.AppendLine("  \"surum\": \"5.0\",");
        sb.AppendLine("  \"subeKod\": \"" + JsonEscape(Sube.Kod) + "\",");
        sb.AppendLine("  \"subeAd\": \"" + JsonEscape(Sube.Ad) + "\",");
        sb.AppendLine("  \"tarih\": \"" + JsonEscape(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")) + "\",");
        sb.AppendLine("  \"aciklama\": \"Nebim V3 STORE Mahmutbey (" + JsonEscape(Sube.Kod) + ") Kendi Kendini Iyilesitiren (Self-Healing) Magaza Rehber Katalogu\",");
        sb.AppendLine("  \"toplamMenu\": " + SolMenuCatalog.Count + ",");
        sb.AppendLine("  \"dogrulananMenuSayisi\": " + verifiedCount + ",");
        sb.AppendLine("  \"menuler\": [");

        for (int i = 0; i < SolMenuCatalog.Count; i++)
        {
            AtlasItem it = SolMenuCatalog[i];
            sb.Append("    {");
            sb.Append("\"kategori\":\"").Append(JsonEscape(it.kategori)).Append("\",");
            sb.Append("\"baslik\":\"").Append(JsonEscape(it.baslik)).Append("\",");
            sb.Append("\"menuYolu\":\"").Append(JsonEscape(it.menuYolu)).Append("\",");
            sb.Append("\"araMetni\":\"").Append(JsonEscape(it.araMetni)).Append("\",");
            sb.Append("\"ilkVeriAlani\":\"").Append(JsonEscape(it.ilkVeriAlani)).Append("\",");
            sb.Append("\"dogrulandi\":").Append(it.dogrulandi ? "true" : "false").Append(",");
            sb.Append("\"rehberAdimlari\":[");
            if (it.rehberAdimlari != null)
            {
                for (int s = 0; s < it.rehberAdimlari.Count; s++)
                {
                    sb.Append("\"").Append(JsonEscape(it.rehberAdimlari[s])).Append("\"");
                    if (s < it.rehberAdimlari.Count - 1) sb.Append(",");
                }
            }
            sb.Append("]}");
            if (i < SolMenuCatalog.Count - 1) sb.Append(",");
            sb.AppendLine();
        }

        sb.AppendLine("  ]");
        sb.AppendLine("}");

        string content = sb.ToString();
        try
        {
            AtomicWriteText(Path.Combine(outDir, "mahmutbey-rehber-katalog.json"), content);
        }
        catch { }
    }

    private static string JsonEscape(string s)
    {
        if (string.IsNullOrEmpty(s)) return "";
        StringBuilder sb = new StringBuilder(s.Length + 8);
        foreach (char c in s)
        {
            switch (c)
            {
                case '\\': sb.Append("\\\\"); break;
                case '\"': sb.Append("\\\""); break;
                case '\r': sb.Append("\\r"); break;
                case '\n': sb.Append("\\n"); break;
                case '\t': sb.Append("\\t"); break;
                default:
                    if (c < 32) sb.Append("\\u").Append(((int)c).ToString("x4"));
                    else sb.Append(c);
                    break;
            }
        }
        return sb.ToString();
    }

    private static string SafeGetName(AutomationElement el)
    {
        try { return (el.Current.Name ?? "").Trim(); } catch { return ""; }
    }

    private static string SafeGetClass(AutomationElement el)
    {
        try { return (el.Current.ClassName ?? "").Trim(); } catch { return ""; }
    }

    private static string SafeGetAutomationId(AutomationElement el)
    {
        try { return (el.Current.AutomationId ?? "").Trim(); } catch { return ""; }
    }

    private static ControlType SafeGetControlType(AutomationElement el)
    {
        try { return el.Current.ControlType; } catch { return null; }
    }

    private static string SafeGetControlTypeName(AutomationElement el)
    {
        try
        {
            ControlType ct = el.Current.ControlType;
            return ct != null ? ct.ProgrammaticName : "";
        }
        catch { return ""; }
    }

    private static System.Windows.Rect SafeGetRect(AutomationElement el)
    {
        try { return el.Current.BoundingRectangle; } catch { return System.Windows.Rect.Empty; }
    }

    private static bool SafeIsOffscreen(AutomationElement el)
    {
        try { return el.Current.IsOffscreen; } catch { return false; }
    }

    private static bool SafeIsEnabled(AutomationElement el)
    {
        try { return el.Current.IsEnabled; } catch { return true; }
    }

    private static string SafeGetValue(AutomationElement el)
    {
        try
        {
            object vp;
            if (el.TryGetCurrentPattern(ValuePattern.Pattern, out vp))
            {
                return (((ValuePattern)vp).Current.Value ?? "").Trim();
            }
        }
        catch { }
        return "";
    }
}
