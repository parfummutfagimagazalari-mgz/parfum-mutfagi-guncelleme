@echo off
rem Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
rem Nebim Asistani - DENEME: hicbir sey kurmaz, yalniz derleme ve oz-testleri yapar.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1" -Dene
pause
