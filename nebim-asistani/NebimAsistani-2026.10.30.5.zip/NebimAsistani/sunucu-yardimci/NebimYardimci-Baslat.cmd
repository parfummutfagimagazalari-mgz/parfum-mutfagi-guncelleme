@echo off
rem Nebim Yardimci - sunucu acilisinda baslatici + izleyici (surum 4, SQL dogrudan baglanti destekli).
rem Yardimcinin yerel kopyasini calistirir; kapanirsa veya yeni surum gelirse 15 sn icinde gunceller ve baslatir.
rem Tepsiden "Cikis" yapilirsa (araclar\yardimci-durdur.txt) yeniden baslatmaz. Nebim'e hicbir sey yazmaz.
setlocal
set "A=\\tsclient\N\araclar"
set "L=%LOCALAPPDATA%\NebimYardimci"
if not exist "%L%" mkdir "%L%"
if /i "%~1"=="izle" goto izle
rem Izleyici zaten calisiyorsa kilit dosyasi acik olur: ikinci kopyayi baslatma.
2>nul (type nul>>"%L%\izleyici.kilit") || exit /b 0
for /l %%i in (1,1,60) do (
  if exist "%A%\NebimYardimci.exe" goto hazir
  ping -n 6 127.0.0.1 >nul
)
exit /b 0
:hazir
copy /y "%A%\NebimYardimci-Baslat.cmd" "%L%\izleyici.cmd" >nul 2>&1
if not exist "%L%\izleyici.cmd" copy /y "%~f0" "%L%\izleyici.cmd" >nul 2>&1
>"%L%\gizli.vbs" echo CreateObject("WScript.Shell").Run "cmd /c """"%L%\izleyici.cmd"" izle""", 0, False
wscript //nologo "%L%\gizli.vbs"
exit /b 0
:izle
2>nul (call :dongu 9>>"%L%\izleyici.kilit")
exit /b 0
:dongu
>"%L%\izleyici-nabiz.txt" echo %date% %time%
if exist "%A%\NebimYardimci.exe" if not exist "%A%\yardimci-durdur.txt" (
  for %%a in ("%A%\NebimYardimci.exe") do set "SZ_A=%%~za"
  set "SZ_L=0"
  if exist "%L%\NebimYardimci.exe" for %%b in ("%L%\NebimYardimci.exe") do set "SZ_L=%%~zb"
  if not "%SZ_A%"=="%SZ_L%" (
    taskkill /F /IM NebimYardimci.exe /FI "USERNAME eq %USERNAME%" >nul 2>&1
    ping -n 2 127.0.0.1 >nul
  )
  tasklist /FI "IMAGENAME eq NebimYardimci.exe" /FI "USERNAME eq %USERNAME%" /NH 2>nul | find /I "NebimYardimci.exe" >nul
  if errorlevel 1 (
    copy /y "%A%\NebimYardimci.exe" "%L%\NebimYardimci.exe" >nul 2>&1
    start "" "%L%\NebimYardimci.exe"
    >>"%L%\izleyici-log.txt" echo %date% %time% yardimci baslatildi/guncellendi
  )
)
ping -n 16 127.0.0.1 >nul
goto dongu
