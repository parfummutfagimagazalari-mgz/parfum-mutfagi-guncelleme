@echo off
rem Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
rem Nebim Asistani - guncelleme. Yeni surum varsa indirir, dogrular ve kurar; sube ayarlari korunur.
rem Basariliysa pencere 3 sn sonra, hata varsa 60 sn sonra kendiliginden kapanir.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0guncelle.ps1"
if errorlevel 1 (
  echo.
  echo Guncelleme tamamlanamadi; ayrinti yukarida. Pencere 60 sn sonra kapanir.
  timeout /t 60 >nul
) else (
  echo.
  echo Tamam. Pencere kapaniyor...
  timeout /t 3 >nul
)
