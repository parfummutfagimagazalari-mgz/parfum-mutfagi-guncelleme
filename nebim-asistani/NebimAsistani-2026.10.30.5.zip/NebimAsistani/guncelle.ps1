﻿# Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
# Nebim Asistani - GUNCELLEYICI (22.10.2026)
# Yeni surumu GitHub'daki surum bildiriminden bulur, zip'i indirir, SHA-256 ile dogrular ve kur.ps1 ile kurar.
# Sube ayarlari (sube.json: kod, ad, sunucu, merkez) korunur. Nebim'e HICBIR SEY yazmaz.
#   -Kontrol : yalniz yeni surum var mi bakar, state\guncelleme.json'a yazar (asistan haber verir). Hicbir sey kurmaz.
param([switch]$Kontrol)

$ErrorActionPreference = 'Stop'
$BILDIRIM = 'https://raw.githubusercontent.com/parfummutfagimagazalari-mgz/parfum-mutfagi-guncelleme/main/nebim-asistani/surum.json'
$IZINLI = 'https://raw.githubusercontent.com/parfummutfagimagazalari-mgz/parfum-mutfagi-guncelleme/main/nebim-asistani/paketler/'
$kok = $PSScriptRoot
$durumDosyasi = Join-Path $kok 'state\guncelleme.json'

function Yaz([string]$m) { Write-Host ('{0:HH:mm:ss} {1}' -f (Get-Date), $m) }
function Durum($veri) {
  try {
    New-Item -ItemType Directory -Force (Split-Path $durumDosyasi) | Out-Null
    [IO.File]::WriteAllText($durumDosyasi, ($veri | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
  } catch {}
}

try {
  # Windows PowerShell 5.1 varsayilan olarak eski TLS kullanabilir; GitHub TLS 1.2 ister.
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

  $mevcutDosya = Join-Path $kok 'surum.json'
  $mevcut = '0.0.0.0'
  if (Test-Path $mevcutDosya) { $mevcut = [string](Get-Content -LiteralPath $mevcutDosya -Raw -Encoding UTF8 | ConvertFrom-Json).surum }

  $b = Invoke-RestMethod -Uri ($BILDIRIM + '?t=' + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 20
  if (-not $b.surum -or -not $b.zip -or -not $b.sha256) { throw 'Surum bildirimi eksik (surum/zip/sha256).' }
  if (-not ([string]$b.zip).StartsWith($IZINLI)) { throw ('Surum bildirimindeki indirme adresi izinli depoda degil: ' + $b.zip) }
  if ([string]$b.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'Surum bildirimindeki SHA-256 gecersiz.' }
  $yeniVar = ([version]$b.surum) -gt ([version]$mevcut)

  if ($Kontrol) {
    Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = $mevcut; yeni = [string]$b.surum; var = $yeniVar; notlar = [string]$b.notlar })
    exit 0
  }

  Yaz ('Kurulu surum: ' + $mevcut + ' | yayindaki surum: ' + $b.surum)
  if (-not $yeniVar) {
    Yaz 'Asistan guncel. Yapilacak bir sey yok.'
    Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = $mevcut; yeni = [string]$b.surum; var = $false; notlar = '' })
    exit 0
  }
  if ($b.notlar) { Yaz ('Yenilikler: ' + $b.notlar) }

  $is = Join-Path $env:TEMP ('NebimAsistani-guncelleme-' + $b.surum)
  if (Test-Path $is) { Remove-Item $is -Recurse -Force }
  New-Item -ItemType Directory -Force $is | Out-Null
  $zip = Join-Path $is 'NebimAsistani.zip'
  Yaz 'Indiriliyor...'
  Invoke-WebRequest -Uri $b.zip -OutFile $zip -UseBasicParsing -TimeoutSec 300
  $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
  if ($hash -ne ([string]$b.sha256).ToUpperInvariant()) { throw ('Indirilen dosya dogrulanamadi (SHA-256 farkli). Kurulum yapilmadi. Beklenen ' + $b.sha256 + ', gelen ' + $hash) }
  Yaz 'Dosya dogrulandi (SHA-256)'

  $acik = Join-Path $is 'acik'
  Expand-Archive -LiteralPath $zip -DestinationPath $acik -Force
  $kur = Get-ChildItem -Path $acik -Filter 'kur.ps1' -Recurse | Select-Object -First 1
  if (-not $kur) { throw 'Paketin icinde kur.ps1 bulunamadi.' }
  Yaz 'Kuruluyor (sube ayarlari korunuyor)...'
  & powershell -NoProfile -ExecutionPolicy Bypass -File $kur.FullName
  if ($LASTEXITCODE -ne 0) { throw 'Kurulum tamamlanamadi; ayrinti masaustundeki NEBIM-ASISTAN-KURULUM-SONUC.txt dosyasinda. Eski surum calismaya devam ediyor.' }
  Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = [string]$b.surum; yeni = [string]$b.surum; var = $false; notlar = '' })
  Remove-Item $is -Recurse -Force -ErrorAction SilentlyContinue
  Yaz ('GUNCELLEME TAMAM: surum ' + $b.surum)
} catch {
  if ($Kontrol) { Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); var = $false; hata = $_.Exception.Message }); exit 0 }
  Yaz ('GUNCELLEME YAPILAMADI: ' + $_.Exception.Message)
  Yaz 'Mevcut asistan calismaya devam ediyor; Nebim''e hicbir sey yazilmadi.'
  exit 1
}
