# Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
# Nebim Asistani - SUBE KURULUMU (22.10.2026)
# Tek bilgisayara (subenin kasa/arka ofis PC'si) kurar. Nebim'e ve panele HICBIR SEY yazmaz.
# Yaptiklari:
#   1) Sube bilgisi (kod, ad, Nebim sunucu adresi) -> <kurulum>\sube.json
#   2) Nebim yardimcisi (sunucuda menu acan/okuyan) derlenir + oz-test -> %APPDATA%\Parfum Mutfagi\veri\nebim-gelen\araclar
#   3) Asistan derlenir + oz-test -> <kurulum>\desktop\NebimAssistant.exe
#   4) N: surucusu (uzak masaustune paylasilan araclar klasoru), oturum acilisinda otomatik baslatma, masaustu kisayolu
#   5) Nebim.rdp yoksa olusturulur; varsa N: surucusunun paylasildigi kontrol edilir
# Parametreler:  -Kod PM3402 -Ad "Bakirkoy" -Sunucu 172.22.16.98   (verilmezse sorulur)
#                -Dene  : hicbir sey kurmadan yalniz derleme + oz-testleri yapar (her bilgisayarda guvenli)
param([string]$Kod = '', [string]$Ad = '', [string]$Sunucu = '', [switch]$Dene, [switch]$Zorla)

$ErrorActionPreference = 'Stop'
$paket = $PSScriptRoot
$log = New-Object System.Collections.Generic.List[string]
function L([string]$m) { $s = ('{0:HH:mm:ss} {1}' -f (Get-Date), $m); $log.Add($s); Write-Host $s }
function Hata([string]$m) { throw $m }

$sonucDosyasi = Join-Path ([Environment]::GetFolderPath('Desktop')) 'NEBIM-ASISTAN-KURULUM-SONUC.txt'
if ($Dene) { $sonucDosyasi = Join-Path $env:TEMP 'NEBIM-ASISTAN-DENEME-SONUC.txt' }
$basarili = $false
try {
  L 'Nebim Asistani - Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Kullanim izni Ahmet Aksoy tarafindan verilir (LISANS.txt).'
  L ('Nebim Asistani kurulumu basladi' + $(if ($Dene) { ' (DENEME: hicbir sey kurulmayacak)' } else { '' }))

  # ---------- 0) On kontroller ----------
  # Paket turu: HAZIR (derlenmis exe, kaynak yok - subelere giden) ya da KAYNAK (gelistirme, csc ile derlenir)
  $hazirA = Join-Path $paket 'desktop\NebimAssistant.exe'
  $hazirY = Join-Path $paket 'sunucu-yardimci\NebimYardimci.exe'
  $hazir = (Test-Path $hazirA) -and (Test-Path $hazirY)
  $ortak = @('sunucu-yardimci\NebimYardimci-Baslat.cmd', 'sunucu-yardimci\ekranlar.json', 'sunucu-yardimci\hata-sozlugu.json', 'surum.json', 'guncelle.ps1', 'GUNCELLE.cmd', 'LISANS.txt')
  if ($hazir) { $gerekli = $ortak } else { $gerekli = @('desktop\Assistant.v5.cs', 'sunucu-yardimci\NebimYardimci.cs') + $ortak }
  foreach ($f in $gerekli) {
    if (-not (Test-Path (Join-Path $paket $f))) { Hata ('Paket eksik: ' + $f + '. Zip dosyasini tamamen acip KUR.cmd''yi oradan calistirin.') }
  }
  foreach ($j in @('sunucu-yardimci\ekranlar.json', 'sunucu-yardimci\hata-sozlugu.json')) {
    try { $null = Get-Content -LiteralPath (Join-Path $paket $j) -Raw -Encoding UTF8 | ConvertFrom-Json } catch { Hata ('Bozuk JSON: ' + $j) }
  }
  if (-not $hazir) {
    $csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    $wpf = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\WPF'
    if (-not (Test-Path $csc)) { Hata '.NET Framework 4 derleyicisi (csc.exe) bulunamadi. Windows Update ile .NET Framework 4.8 kurun.' }
    if (-not (Test-Path (Join-Path $wpf 'UIAutomationClient.dll'))) { Hata 'UIAutomation kutuphanesi bulunamadi (WPF klasoru). .NET Framework 4.8 kurun.' }
  }
  L ('On kontroller tamam (paket turu: ' + $(if ($hazir) { 'hazir program' } else { 'kaynaktan derleme' }) + ')')

  # ---------- 1) Program + oz-test (once gecici klasorde; basarisizsa hicbir sey degismez) ----------
  $tmp = Join-Path $env:TEMP ('NebimAsistani-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  New-Item -ItemType Directory -Force $tmp | Out-Null
  New-Item -ItemType Directory -Force (Join-Path $tmp 'desktop') | Out-Null
  $yExe = Join-Path $tmp 'NebimYardimci.exe'
  $aExe = Join-Path $tmp 'desktop\NebimAssistant.exe'

  if ($hazir) {
    Copy-Item $hazirY $yExe -Force
    Copy-Item $hazirA $aExe -Force
  } else {
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $o = & $csc /nologo /target:winexe "/lib:$wpf" /r:UIAutomationClient.dll /r:UIAutomationTypes.dll /r:WindowsBase.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll "/out:$yExe" (Join-Path $paket 'sunucu-yardimci\NebimYardimci.cs') 2>&1 | Out-String
    $kod1 = $LASTEXITCODE; $ErrorActionPreference = $eap
    if ($kod1 -ne 0) { Hata ("Nebim yardimcisi derlenemedi:`r`n" + $o) }
    Copy-Item (Join-Path $paket 'desktop\Assistant.v5.cs') (Join-Path $tmp 'desktop\Assistant.cs') -Force
    $ikon = Join-Path $paket 'desktop\asistan.ico'
    $ikonArg = @(); if (Test-Path $ikon) { $ikonArg = @("/win32icon:$ikon") }
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $o = & $csc /nologo /target:winexe "/out:$aExe" @ikonArg /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Net.Http.dll /r:System.Web.Extensions.dll (Join-Path $tmp 'desktop\Assistant.cs') 2>&1 | Out-String
    $kod2 = $LASTEXITCODE; $ErrorActionPreference = $eap
    if ($kod2 -ne 0) { Hata ("Asistan derlenemedi:`r`n" + $o) }
    Remove-Item (Join-Path $tmp 'desktop\Assistant.cs') -Force -ErrorAction SilentlyContinue
  }
  $p = Start-Process -FilePath $yExe -ArgumentList '--self-test' -Wait -PassThru -WindowStyle Hidden
  if ($p.ExitCode -ne 0) { Hata ('Nebim yardimcisi oz-testi basarisiz (kod ' + $p.ExitCode + ')') }
  L 'Nebim yardimcisi oz-test GECTI'
  $p = Start-Process -FilePath $aExe -ArgumentList '--self-test' -Wait -PassThru -WindowStyle Hidden
  if ($p.ExitCode -ne 0) { Hata ('Asistan oz-testi basarisiz (kod ' + $p.ExitCode + ')') }
  L 'Asistan oz-test GECTI'

  if ($Dene) {
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    L 'DENEME BITTI: derleme ve oz-testler basarili. Bu bilgisayarda hicbir sey degistirilmedi.'
    $basarili = $true
    return
  }

  # ---------- 2) Mahmutbey koruma ----------
  $mahmutbeyYollar = @((Join-Path $env:USERPROFILE 'Documents\Codex\NebimMCP\desktop\NebimAssistant.exe'), (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Codex\NebimMCP\desktop\NebimAssistant.exe'))
  if ((@($mahmutbeyYollar | Where-Object { Test-Path $_ }).Count -gt 0) -and -not $Zorla) {
    Hata 'Bu bilgisayarda Mahmutbey kurulumu (Documents\Codex\NebimMCP) var. Ona dokunmamak icin durdum. Mahmutbey guncellemesi icin 9-KARO-KUR.cmd kullanin.'
  }

  # ---------- 3) Sube bilgisi ----------
  $kok = Join-Path $env:USERPROFILE 'Documents\NebimAsistani'
  $subeDosyasi = Join-Path $kok 'sube.json'
  $eski = $null
  if (Test-Path $subeDosyasi) { try { $eski = Get-Content -LiteralPath $subeDosyasi -Raw -Encoding UTF8 | ConvertFrom-Json } catch {} }
  if (-not $Kod -and $eski) { $Kod = [string]$eski.kod }
  if (-not $Ad -and $eski) { $Ad = [string]$eski.ad }
  if (-not $Sunucu -and $eski) { $Sunucu = [string]$eski.sunucu }
  while ($Kod -notmatch '^([A-Za-z]{2}[0-9]{3,5}|MERKEZ|ANKARA|M01|M|CIGDEM|PM0000)$') { $Kod = (Read-Host 'Sube kodu (Nebim magaza kodu, or. PM3402 veya MERKEZ)').Trim() }
  $Kod = $Kod.ToUpperInvariant()
  while (-not $Ad -or $Ad.Trim().Length -lt 2) { $Ad = (Read-Host 'Sube adi (or. Bakirkoy)').Trim() }
  if (-not $Sunucu) {
    $Sunucu = (Read-Host 'Nebim uzak masaustu sunucu adresi [Enter = 172.22.16.98]').Trim()
    if (-not $Sunucu) { $Sunucu = '172.22.16.98' }
  }
  if ($Sunucu -notmatch '^[A-Za-z0-9.\-]+$') { Hata ('Sunucu adresi gecersiz: ' + $Sunucu) }
  New-Item -ItemType Directory -Force $kok, (Join-Path $kok 'desktop'), (Join-Path $kok 'state') | Out-Null
  # Ankara merkez bolumu: onceki kurulumdaki ayar korunur; yoksa KAPALI gelir (Ankara hazir olunca acilir).
  $merkez = [ordered]@{ etkin = $false; bind = ''; port = 3443; certFile = ''; keyFile = ''; caFile = ''; clientFingerprints = @() }
  if ($eski -and $eski.merkez) { $merkez = $eski.merkez }
  $sube = [ordered]@{ kod = $Kod; ad = $Ad.Trim(); sunucu = $Sunucu; mcp = $(if ($eski -and $null -ne $eski.mcp) { [bool]$eski.mcp } else { $false }); kurulum = (Get-Date -Format 's'); merkez = $merkez }
  [IO.File]::WriteAllText($subeDosyasi, ($sube | ConvertTo-Json -Depth 5), (New-Object System.Text.UTF8Encoding($false)))
  L ('Sube: ' + $Kod + ' ' + $Ad.Trim() + ' | sunucu ' + $Sunucu + ' | kurulum klasoru ' + $kok)

  # ---------- 4) araclar klasoru (uzak masaustunde \\tsclient\N\araclar) ----------
  $gelen = Join-Path $env:APPDATA 'Parfum Mutfagi\veri\nebim-gelen'
  $araclar = Join-Path $gelen 'araclar'
  New-Item -ItemType Directory -Force $araclar, (Join-Path $araclar 'kuyruk') | Out-Null
  $damga = Get-Date -Format 'yyyyMMdd-HHmmss'
  foreach ($f in @('ekranlar.json', 'hata-sozlugu.json', 'NebimYardimci-Baslat.cmd')) {
    $h = Join-Path $araclar $f
    if (Test-Path $h) { Copy-Item $h ($h + '.yedek-' + $damga) -Force }
    Copy-Item (Join-Path $paket ('sunucu-yardimci\' + $f)) $h -Force
  }
  function YedekTemizle([string]$dosya) { Get-ChildItem -Path ($dosya + '.yedek-*') -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -Skip 2 | Remove-Item -Force -ErrorAction SilentlyContinue }
  foreach ($f in @('ekranlar.json', 'hata-sozlugu.json', 'NebimYardimci-Baslat.cmd')) { YedekTemizle (Join-Path $araclar $f) }
  $yHedef = Join-Path $araclar 'NebimYardimci.exe'
  if (Test-Path $yHedef) { Copy-Item $yHedef ($yHedef + '.yedek-' + $damga) -Force }
  Copy-Item $yExe $yHedef -Force; YedekTemizle $yHedef
  L ('Nebim yardimcisi ve ekran listesi kondu: ' + $araclar)

  # ---------- 5) Asistan ----------
  Get-Process NebimAssistant -ErrorAction SilentlyContinue | Where-Object { $_.Path -like ($kok + '*') } | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 1
  $aHedef = Join-Path $kok 'desktop\NebimAssistant.exe'
  if (Test-Path $aHedef) { Copy-Item $aHedef ($aHedef + '.yedek-' + $damga) -Force }
  Copy-Item $aExe $aHedef -Force; YedekTemizle $aHedef
  # Sube kurulumunda kaynak kod tutulmaz; eski kurulumdan kalan kaynak varsa kaldirilir.
  Remove-Item (Join-Path $kok 'desktop\Assistant.v5.cs') -Force -ErrorAction SilentlyContinue
  L ('Asistan kondu: ' + $aHedef)
  # Ankara merkez ucu (kapali gelir) + testleri + belgeler
  foreach ($k in @('merkez', 'test', 'docs')) { if (Test-Path (Join-Path $paket $k)) { Copy-Item (Join-Path $paket $k) $kok -Recurse -Force } }
  if (Test-Path (Join-Path $paket 'package.json')) { Copy-Item (Join-Path $paket 'package.json') $kok -Force }
  foreach ($f in @('surum.json', 'guncelle.ps1', 'GUNCELLE.cmd', 'OKU-BENI.txt', 'LISANS.txt')) { Copy-Item (Join-Path $paket $f) $kok -Force }
  $surumBilgi = Get-Content -LiteralPath (Join-Path $paket 'surum.json') -Raw -Encoding UTF8 | ConvertFrom-Json
  L ('Surum ' + $surumBilgi.surum + ' kuruldu; guncelleme denetimi hazir')
  $node = Join-Path $env:ProgramFiles 'nodejs\node.exe'
  if (-not (Test-Path (Join-Path $kok 'merkez\merkez-ucu.mjs'))) { L 'Ankara merkez ucu bu pakette yok; Ankara baglantisi acilinca ayrica verilecek.' }
  elseif (Test-Path $node) { L 'Ankara merkez ucu kondu (KAPALI). Node.js var; Ankara hazir olunca yalniz sube.json > merkez acilacak.' }
  else { L 'Ankara merkez ucu kondu (KAPALI). Not: Node.js yok; Ankara baglantisi acilacagi zaman Node.js LTS kurulmali.' }
  # Tailscale (Ankara baglantisi icin ozel ag) - yalniz durum yazilir, kurulmaz. Asistan icin gerekmez.
  $ts = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
  if (Test-Path $ts) {
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $tsIp = (& $ts ip -4 2>$null | Select-Object -First 1); $ErrorActionPreference = $eap
    if ($tsIp) { L ('Tailscale var, adres ' + $tsIp + ' (Ankara baglantisi acilinca merkez.bind bu adres olacak)') } else { L 'Tailscale kurulu ama bagli degil (simgeden Log in yapin)' }
  } else { L 'Tailscale yok: asistan icin gerekmez; Ankara baglantisi icin OKU-BENI.txt > TAILSCALE' }

  # ---------- 6) N: surucusu ----------
  $nBilgi = (& "$env:SystemRoot\System32\subst.exe") | Where-Object { $_ -match '^N:\\' }
  if ($nBilgi) {
    $nHedef = (([string]$nBilgi) -replace '^N:\\: => ', '').Trim().TrimEnd('\')
    if ($nHedef -ne $gelen.TrimEnd('\')) { Hata ('N: surucusu baska bir klasore bagli: ' + $nBilgi + '. Once "subst N: /D" ile kaldirin ya da BT ile gorusun.') }
    L 'N: surucusu zaten dogru klasore bagli'
  } elseif (Test-Path 'N:\') {
    Hata 'N: surucusu baska bir disk/ag surucusu olarak kullaniliyor. Nebim paylasimi icin N: bos olmali; BT ile gorusun.'
  } else {
    & "$env:SystemRoot\System32\subst.exe" 'N:' $gelen
    if ($LASTEXITCODE -ne 0) { Hata 'N: surucusu olusturulamadi.' }
    L 'N: surucusu olusturuldu'
  }

  # ---------- 7) Oturum acilisinda baslat + masaustu kisayolu ----------
  $baslangic = [Environment]::GetFolderPath('Startup')
  $bCmd = Join-Path $baslangic 'NebimAsistani.cmd'
  $satirlar = @(
    '@echo off',
    'rem Nebim Asistani - oturum acilisi (sube kurulumu). Nebim''e veri yazmaz.',
    'if not exist N:\ subst N: "%APPDATA%\Parfum Mutfagi\veri\nebim-gelen"',
    'start "" "%USERPROFILE%\Documents\NebimAsistani\desktop\NebimAssistant.exe" --tray',
    'rem Ankara merkez ucu: sube.json > merkez.etkin=false iken hicbir port acmadan hemen kapanir.',
    'if exist "%ProgramFiles%\nodejs\node.exe" if exist "%USERPROFILE%\Documents\NebimAsistani\merkez\gizli-baslat.vbs" wscript //nologo "%USERPROFILE%\Documents\NebimAsistani\merkez\gizli-baslat.vbs"',
    'rem Guncelleme: yalniz yeni surum var mi bakar (kurmaz); asistan haber verir.',
    'start "" /min powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%USERPROFILE%\Documents\NebimAsistani\guncelle.ps1" -Kontrol'
  )
  $arg = '""' + $node + '"" ""' + (Join-Path $kok 'merkez\merkez-ucu.mjs') + '"" ""' + $subeDosyasi + '""'
  $vbs = 'CreateObject("WScript.Shell").Run "' + $arg + '", 0, False'
  # Turkce karakterli kullanici adlarinda da calissin: VBS Unicode (UTF-16), .cmd konsolun OEM kod sayfasinda yazilir.
  if (Test-Path (Join-Path $kok 'merkez\merkez-ucu.mjs')) { [IO.File]::WriteAllText((Join-Path $kok 'merkez\gizli-baslat.vbs'), $vbs, [System.Text.Encoding]::Unicode) }
  [IO.File]::WriteAllLines($bCmd, $satirlar, [System.Text.Encoding]::ASCII)
  $wsh = New-Object -ComObject WScript.Shell
  Copy-Item (Join-Path $paket 'desktop\asistan.ico') (Join-Path $kok 'desktop\asistan.ico') -Force -ErrorAction SilentlyContinue
  $eskiLnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nebim Asistani.lnk'; if (Test-Path $eskiLnk) { Remove-Item $eskiLnk -Force }
  $lnk = $wsh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) ('Nebim Asistan' + [char]0x0131 + '.lnk')))
  $lnk.TargetPath = $aHedef; $lnk.WorkingDirectory = (Split-Path $aHedef)
  $lnk.Description = 'Nebim Asistani - ' + $Ad.Trim() + ' (' + $Kod + '): karolar Nebim ekranlarini acar, Yenile gunun satisini okur. Nebim''e veri yazmaz.'
  if (Test-Path (Join-Path $kok 'desktop\asistan.ico')) { $lnk.IconLocation = (Join-Path $kok 'desktop\asistan.ico') + ',0' }
  $lnk.Save()
  $glnk = $wsh.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) ('Nebim Asistan' + [char]0x0131 + ' G' + [char]0x00FC + 'ncelle.lnk')))
  $glnk.TargetPath = (Join-Path $kok 'GUNCELLE.cmd'); $glnk.WorkingDirectory = $kok
  $glnk.Description = 'Nebim Asistani icin yeni surum varsa indirir, dogrular ve kurar. Sube ayarlari korunur.'
  if (Test-Path (Join-Path $kok 'desktop\asistan.ico')) { $glnk.IconLocation = (Join-Path $kok 'desktop\asistan.ico') + ',0' }
  $glnk.Save()
  L 'Oturum acilisinda otomatik baslatma ve simgeli masaustu kisayolu (Nebim Asistani) hazir'

  # ---------- 8) Nebim.rdp ----------
  $rdp = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Nebim.rdp'
  if (Test-Path $rdp) {
    $icerik = Get-Content -LiteralPath $rdp
    if (($icerik -join "`n") -match '(?im)^drivestoredirect:s:.*N:') { L 'Nebim.rdp var ve N: surucusunu paylasiyor' }
    else {
      Copy-Item $rdp ($rdp + '.yedek-' + $damga) -Force
      $mevcut = @($icerik | Where-Object { $_ -match '(?i)^drivestoredirect:s:' } | Select-Object -First 1)
      $deger = if ($mevcut.Count -gt 0) { ([string]$mevcut[0]).Substring(19).Trim() } else { '' }
      if ($deger -eq '*') { L 'Nebim.rdp tum suruculeri paylasiyor (N: dahil)'; $deger = $null }
      if ($null -ne $deger) {
        if ($deger -and -not $deger.EndsWith(';')) { $deger += ';' }
        $yeni = @($icerik | Where-Object { $_ -notmatch '(?i)^drivestoredirect:s:' }) + ('drivestoredirect:s:' + $deger + 'N:\;')
        Set-Content -LiteralPath $rdp -Value $yeni -Encoding Unicode
        L 'Nebim.rdp guncellendi: N: surucusu paylasima eklendi, onceki paylasimlar korundu (yedek alindi)'
      }
    }
  } else {
    $yeni = @('screen mode id:i:2', 'use multimon:i:0', ('full address:s:' + $Sunucu), 'prompt for credentials:i:1', 'redirectclipboard:i:1', 'drivestoredirect:s:N:\;', 'autoreconnection enabled:i:1')
    Set-Content -LiteralPath $rdp -Value $yeni -Encoding Unicode
    L ('Masaustune Nebim.rdp olusturuldu (sunucu ' + $Sunucu + ', N: paylasimli)')
  }

  # ---------- 9) Baslat ----------
  Start-Process -FilePath $aHedef -ArgumentList '--tray' -WorkingDirectory (Split-Path $aHedef)
  Start-Sleep -Seconds 4
  if (Get-Process NebimAssistant -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $aHedef }) { L 'Asistan calisiyor' } else { L 'UYARI: asistan acilamadi; masaustundeki "Nebim Asistani" kisayoluna cift tiklayin' }
  Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

  L ''
  L 'SON ADIM (bir kez): masaustundeki Nebim.rdp ile Nebim sunucusuna baglanin.'
  L '  Uzak masaustunde Baslat > Calistir''a  \\tsclient\N\araclar\NebimYardimci.exe  yazip Enter''a basin.'
  L '  Yardimci kendini sunucu oturumunun baslangicina ekler; sonraki girislerde kendiliginden acilir.'
  $basarili = $true
} catch {
  L ('SONUC: HATA - ' + $_.Exception.Message)
  L 'Hicbir Nebim kaydi degistirilmedi. Sorunu giderip KUR.cmd''yi tekrar calistirabilirsiniz.'
} finally {
  if ($basarili) { L 'SONUC: TAMAM' }
  try { [IO.File]::WriteAllLines($sonucDosyasi, $log, (New-Object System.Text.UTF8Encoding($true))) } catch {}
}
if (-not $basarili) { exit 1 }
