@echo off
rem Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
rem Nebim Asistani - sube kurulumu. Cift tiklayin; sube kodu ve adi sorulur.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1" %*
pause
