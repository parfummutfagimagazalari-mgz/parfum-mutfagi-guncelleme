# Nebim Asistanı kuralları (22.10.2026)

Bu kurallar yüzen **Nebim Asistanı** ve sunucu tarafındaki **Nebim Yardımcısı** içindir. Şube paneline dokunulmaz.

## Temel kural: Nebim'e veri yazma yok
- Asistan Nebim ekranlarını ve raporlarını açabilir (STORE'un "Ara…" kutusuyla).
- Rapor filtresindeki **Çalıştır**'a basabilir. Bu yalnız raporu çalıştırır, kayıt oluşturmaz.
- **Kaydet · Onayla · Onayı Kaldır · Sil · İade · Sevk · Eşitle · Yeni** düğmelerine asistan asla basmaz. Bunlar kullanıcıdadır.
- Nebim'in soru pencerelerine (ör. "POS Terminali", "Kayıt Bulunamadı") asistan basmaz; kullanıcı cevaplar.

## POS (kasa)
- POS öndeyken asistan **hiçbir yere tıklamaz, tuşa basmaz, ekran açmaz**. Böylece satış bölünmez.
- POS'ta **Mağaza Hareket Özeti** açıksa yalnız **okur**: adet, net tutar, nakit ve kart.
- Nakit ve kart, ödemelerdeki **Peşinat** sütunundan okunur. "Toplam" sütunu merkeze gönderilen nakdi de içerdiği için kullanılmaz.
- POS satış ekranı hiç açılmaz. "Ürün iade al" karosu yalnız yönlendirme mesajı gösterir.

## 9 karo
| Karo | Açtığı Nebim ekranı |
|---|---|
| SİPARİŞ VER | Verilen Siparişler – Toptan Alış |
| MASRAF EKLE | Mağaza Masraf Girişi |
| STOK SAYIMI YAP | Mağaza Sayım Fişi |
| TÜM ENVANTER | Ürün Envanter Sorgula (yalnız bakış) |
| GELEN ÜRÜNLERİ ONAYLA | Mağazaya Gelen İrsaliyeyi Onayla – Ürün Detaylı |
| MERKEZE İADELER | Merkeze İade |
| ŞİRKETE PARA GÖNDER | Merkezin Banka Hesabına Nakit Çıkış |
| SATIŞ SORUMLUSU | Satış Sorumlusu (Ara listesinde 4. satır) |
| ÜRÜN İADE AL | yalnız POS'a yönlendirme |

Karo yalnız ekranı açar. Bilgileri kullanıcı girer ve kaydeder.

## Rakam satırı (turuncu)
`[POS ·] saat · adet · Nakit · Kart · ₺net` biçimindedir; tutar en sondadır.
Rapor okunamazsa tahmini rakam gösterilmez, "rakam okunamadı" yazar.

## Veri ve gizlilik
- Raporun **Müşteriler** sekmesi açıksa okuma yapılmaz (kişisel veri).
- Şifre ve anahtar dosyaya yazılmaz.
- Okunan özet yalnız şube bilgisayarındaki **merkez kutusu**na yazılır (`state\merkez-kutusu`). Ankara bağlantısı açılana kadar hiçbir yere gönderilmez. Ayrıntı: `ANKARA-MERKEZ-PLANI.md`.

## Hata önleme (22.10.2026 testleriyle eklendi)
- POS yazıları 1–3 piksel kaysa da aynı satırda sayılır; değerler en çok örtüştükleri sütuna yazılır.
- Ara toplam satırı ("Peşin Satış · Toplam") ciroya ikinci kez eklenmez.
- STORE'da başka bir rapor açık olsa bile yalnız o anki raporun Çalıştır düğmesine basılır.
- Çalıştır'a basmadan hemen önce POS öne geçtiyse işlem durur.
- Gün planı kilidi aynı anda gelen istekleri sıraya koyar (eskiden 10 istekten 9'u reddediliyordu).
