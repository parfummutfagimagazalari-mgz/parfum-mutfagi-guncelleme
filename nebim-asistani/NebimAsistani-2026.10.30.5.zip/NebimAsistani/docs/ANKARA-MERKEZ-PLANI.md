# Ankara merkez paneli bağlantı planı (22.10.2026)

Amaç: Ankara merkez paneli hazır olduğunda **tüm şubelerin asistan verilerini** (Nebim'den okunan günlük satış özeti) tek yerden okumak. Şubelerde bugünden hazırlık yapılır; bağlantı **kapalı** gelir.

## Bugün her şube kurulumunda hazır olanlar
> Not: Şubelere giden hazır program paketinde merkez ucu (`merkez\`) ve testler bulunmaz; kaynak kod yalnız Mahmutbey bilgisayarında tutulur. Ankara bağlantısı açılınca merkez ucu şubelere ayrıca kurulur.

| Parça | Yeri | Durum |
|---|---|---|
| Merkez kutusu | `Documents\NebimAsistani\state\merkez-kutusu\son.json` (+ 40 günlük gün dosyaları) | Asistan her Yenile'de yazar |
| Merkez ucu | `Documents\NebimAsistani\merkez\merkez-ucu.mjs` | Kurulu, **kapalı** (port açmaz) |
| Merkez ayarı | `Documents\NebimAsistani\sube.json` → `merkez` bölümü | `etkin: false` |
| Ankara istemcisi | `merkez\central-client.mjs` | Ankara sunucusuna taşınacak |
| Testler | `test\merkez-ucu.test.mjs` (`npm test`) | 7/7 geçti |

## Nasıl çalışacak
1. Asistan Nebim'den rakamı okur, şube bilgisayarındaki merkez kutusuna yazar. Nebim'e hiçbir şey yazılmaz.
2. Ankara paneli, **Tailscale** özel ağı üzerinden her şubeye şu isteği atar:
   `GET https://<şubenin Tailscale adresi 100.x.y.z>:3443/v1/branches/<ŞUBE KODU>/status`
3. Şube yalnız şunu döner:
   ```json
   {"version":1,"branch":"PM3402","checkedAt":"…","readOnly":true,"state":"guncel","readAt":"…","readFrom":"pos",
    "summary":{"quantity":9,"net":9900,"cash":5700,"card":4200,"currency":"TRY"}}
   ```
   `state`: `guncel` · `bayat` (36 saatten eski) · `okuma-yok` · `kutu-okunamadi` · `kutu-sube-eslesmedi`.
4. Yalnız bu küçük özet şubeden çıkar. Müşteri, personel veya ürün ayrıntısı çıkmaz.

## Güvenlik
- Karşılıklı sertifikalı HTTPS (TLS 1.2+). Sertifikasız bağlantı reddedilir.
- Yalnız `sube.json`'da SHA-256 izi yazılı **Ankara sertifikası** kabul edilir. Aynı sertifika otoritesinden başka sertifika da reddedilir (403).
- Yalnız `GET …/status` vardır. Başka yol, başka şube kodu ve POST reddedilir (404).
- Yalnız şubenin Tailscale adresinde (100.x.y.z) dinler. `0.0.0.0` ve `::` kabul edilmez; internete açılmaz.
- 22.10.2026'da bu kurallar gerçek sertifikalarla uçtan uca denendi: 4/4 geçti.

## Özel ağ: Tailscale
Şubeler ve Ankara farklı şehirlerde, farklı internet bağlantılarında. Modemde port açmadan birbirine ulaşmaları için **Tailscale** kullanılır (Mahmutbey'de kurulu: `100.78.27.127`).
- **Asistan için gerekmez.** Asistan Nebim'e uzak masaüstüyle bağlanır, güncellemeyi GitHub'dan alır.
- **Her şube bilgisayarına ve Ankara sunucusuna bir kez kurulur**, hepsi şirketin aynı Google hesabıyla girer.
- Her makinede: "Run unattended" açık, login.tailscale.com'da "Disable key expiry" yapılmış olmalı (yoksa 180 günde bir giriş ister).
- KUR.cmd, Tailscale kuruluysa şubenin 100.x adresini kurulum sonuç dosyasına yazar.
- Önerilen erişim kuralı (login.tailscale.com > Access controls): şubelerin 3443 portuna **yalnız Ankara sunucusu** erişebilsin.
  ```json
  {"tagOwners": {"tag:ankara": ["autogroup:admin"], "tag:sube": ["autogroup:admin"]},
   "acls": [{"action": "accept", "src": ["tag:ankara"], "dst": ["tag:sube:3443"]}]}
  ```
  Ankara sunucusuna `tag:ankara`, şube bilgisayarlarına `tag:sube` etiketi verilir. Mevcut başka erişimler (telefondan panel vb.) için kurallar ayrıca eklenir; kural değişikliği yapılmadan önce mevcut kurallar yedeklenmeli.

## Ankara hazır olduğunda yapılacaklar
**Ankara tarafı (bir kez):**
1. Ankara sunucusuna Tailscale kurulur (şirketin aynı Google hesabı, `tag:ankara`), erişim kuralı eklenir.
2. Ankara sunucusunda bir sertifika otoritesi (CA) ve Ankara istemci sertifikası oluşturulur.
3. `central-client.mjs` Ankara paneline eklenir. Şube listesi `central-ankara.example.json` biçimindedir: kod, ad, `https://<şubenin Tailscale adresi>:3443/`.

**Her şube için (5 dakika):**
1. Şubeye CA'dan imzalı şube sertifikası (`sube.crt`, `sube.key`) ve `ca.crt` verilir. Örnek yer: `Documents\NebimAsistani\merkez\sertifika\`. Şube sertifikasının adı (SAN) şubenin Tailscale adresi olmalı (ör. `IP:100.78.27.127`); yoksa Ankara bağlantıyı reddeder.
2. Tailscale kurulu ve bağlı olmalı (`tag:sube`); Node.js LTS kurulur (yoksa).
3. `sube.json` → `merkez` bölümü doldurulur:
   ```json
   "merkez": {"etkin": true, "bind": "<şubenin Tailscale adresi, 100.x.y.z>", "port": 3443,
     "certFile": "…\\sube.crt", "keyFile": "…\\sube.key", "caFile": "…\\ca.crt",
     "clientFingerprints": ["<Ankara sertifikasının SHA-256 izi>"]}
   ```
4. Windows Güvenlik Duvarı'nda 3443 portu **yalnız Ankara sunucusunun Tailscale adresine** açılır.
5. Oturum kapatılıp açılır. Merkez ucu başlangıçta kendiliğinden açılır.
6. Ankara'dan şube kontrol edilir: "Bakırköy şubesini kontrol et".

## Sonraki genişleme (Ankara isterse)
- Kutuya sayım, gelen irsaliye ve iade özetleri eklenebilir. Her yeni alan önce izin listesine (`merkezOzeti`) yazılır; liste dışındaki alan şubeden çıkmaz.
- Mahmutbey'in mevcut 3033 beyni de aynı `central.mjs`'i kullanıyor; Ankara ile aynı yoldan eşleşir.
