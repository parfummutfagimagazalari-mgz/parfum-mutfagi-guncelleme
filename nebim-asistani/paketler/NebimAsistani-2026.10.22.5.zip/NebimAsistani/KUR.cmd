@echo off
rem Nebim Asistani - sube kurulumu. Cift tiklayin; sube kodu ve adi sorulur.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1" %*
pause
