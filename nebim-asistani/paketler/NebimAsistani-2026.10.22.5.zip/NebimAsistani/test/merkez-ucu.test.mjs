import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs/promises';import os from 'node:os';import path from 'node:path';
import {merkezOzeti,merkezAyari,baslat} from '../merkez/merkez-ucu.mjs';
import {validateCentral,centralHandler} from '../merkez/central.mjs';

async function kurulum(son){
 const kok=await fs.mkdtemp(path.join(os.tmpdir(),'sube-'));
 await fs.mkdir(path.join(kok,'state','merkez-kutusu'),{recursive:true});
 if(son!==undefined)await fs.writeFile(path.join(kok,'state','merkez-kutusu','son.json'),typeof son==='string'?son:JSON.stringify(son));
 return kok;
}
const simdi=()=>new Date('2026-10-22T13:00:00Z');
const kayit={version:1,branch:'PM3402',ad:'Bakırköy',readAt:'2026-10-22T15:33:00+03:00',source:'pos',summary:{quantity:9,net:9900,cash:5700,card:4200,currency:'TRY'},gizli:'sızmamalı'};

test('son özet yalnız izinli alanlarla döner',async()=>{
 const r=await merkezOzeti({kok:await kurulum(kayit),branch:'PM3402',now:simdi});
 assert.equal(r.version,1);assert.equal(r.branch,'PM3402');assert.equal(r.readOnly,true);assert.equal(r.state,'guncel');assert.equal(r.readFrom,'pos');
 assert.deepEqual(r.summary,{quantity:9,net:9900,cash:5700,card:4200,currency:'TRY'});
 assert.equal(JSON.stringify(r).includes('sızmamalı'),false);
});
test('Ankara istemcisinin kontrolleri geçer (sürüm, şube, salt okuma, zaman)',async()=>{
 const r=await merkezOzeti({kok:await kurulum(kayit),branch:'PM3402'});
 assert.ok(r.version===1&&r.branch==='PM3402'&&r.readOnly===true&&Math.abs(Date.now()-Date.parse(r.checkedAt))<120000);
});
test('başka şubenin kutusu verilmez',async()=>{
 const r=await merkezOzeti({kok:await kurulum({...kayit,branch:'PM3401'}),branch:'PM3402',now:simdi});
 assert.equal(r.summary,null);assert.equal(r.state,'kutu-sube-eslesmedi');
});
test('kutu yok / bozuk / bayat',async()=>{
 assert.equal((await merkezOzeti({kok:await kurulum(),branch:'PM3402',now:simdi})).state,'okuma-yok');
 assert.equal((await merkezOzeti({kok:await kurulum('{bozuk'),branch:'PM3402',now:simdi})).state,'kutu-okunamadi');
 const eski=await merkezOzeti({kok:await kurulum(kayit),branch:'PM3402',now:()=>new Date('2026-10-25T13:00:00Z')});
 assert.equal(eski.state,'bayat');
});
test('kapalı gelir: port açmaz',async()=>{
 const kok=await kurulum(kayit);const f=path.join(kok,'sube.json');
 await fs.writeFile(f,JSON.stringify({kod:'PM3402',ad:'Bakırköy',merkez:{etkin:false}}));
 assert.equal(await baslat(f),null);
 assert.equal(validateCentral(merkezAyari({kod:'PM3402'}),'PM3402'),false);
});
test('etkinleştirilince sertifikasız/eksik ayar reddedilir',()=>{
 assert.throws(()=>validateCentral(merkezAyari({kod:'PM3402',merkez:{etkin:true,bind:'0.0.0.0'}}),'PM3402'));
 assert.throws(()=>validateCentral(merkezAyari({kod:'PM3402',merkez:{etkin:true,bind:'10.8.0.12',port:3443}}),'PM3402'),/sertifika/);
});
test('yalnız tanımlı Ankara sertifikası ve yalnız GET status kabul edilir',async()=>{
 const iz='A'.repeat(64);
 const h=centralHandler({config:{clientFingerprints:[iz]},branch:'PM3402',snapshot:async()=>({ok:1})});
 const cagir=(authorized,fp,method,url)=>new Promise(res=>{const out={};h({socket:{authorized,getPeerCertificate:()=>({fingerprint256:fp})},method,url},{writeHead:c=>out.code=c,end:b=>res({...out,body:JSON.parse(b)})});});
 assert.equal((await cagir(false,iz,'GET','/v1/branches/PM3402/status')).code,403);
 assert.equal((await cagir(true,'B'.repeat(64),'GET','/v1/branches/PM3402/status')).code,403);
 assert.equal((await cagir(true,iz,'POST','/v1/branches/PM3402/status')).code,404);
 assert.equal((await cagir(true,iz,'GET','/v1/branches/PM3401/status')).code,404);
 assert.equal((await cagir(true,iz,'GET','/v1/branches/PM3402/status')).code,200);
});
