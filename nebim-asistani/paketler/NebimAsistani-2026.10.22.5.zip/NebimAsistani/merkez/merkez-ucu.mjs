// Nebim Asistanı — Ankara merkez ucu (şube tarafı). 22.10.2026
// Ankara merkez paneli hazır olunca etkinleştirilir. O zamana kadar KAPALI gelir ve hiçbir ağ portu açmaz.
// Ankara, VPN üzerinden karşılıklı sertifikalı HTTPS ile yalnız şu isteği atabilir:
//   GET /v1/branches/<ŞUBE KODU>/status
// Yanıt yalnız asistanın son okuduğu özeti içerir (adet, net, nakit, kart). Nebim'e ve panele hiçbir şey yazılmaz.
// Kullanım: node merkez/merkez-ucu.mjs "<kurulum>\sube.json"
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {startCentral,CENTRAL_VERSION} from './central.mjs';

export const KUTU_EN_ESKI_SAAT=36; // bundan eski özet "bayat" sayılır

// Kutudaki son özeti okur ve yalnız izinli alanları döndürür.
export async function merkezOzeti({kok,branch,now=()=>new Date()}){
 const base={version:CENTRAL_VERSION,branch,checkedAt:now().toISOString(),readOnly:true,source:'nebim-asistani'};
 let kayit;
 try{kayit=JSON.parse((await fs.readFile(path.join(kok,'state','merkez-kutusu','son.json'),'utf8')).replace(/^﻿/,''));}
 catch(e){if(e.code==='ENOENT')return {...base,summary:null,state:'okuma-yok'};return {...base,summary:null,state:'kutu-okunamadi'};}
 if(!kayit||kayit.version!==1||kayit.branch!==branch)return {...base,summary:null,state:'kutu-sube-eslesmedi'};
 const readAt=Date.parse(kayit.readAt);
 if(!Number.isFinite(readAt))return {...base,summary:null,state:'kutu-gecersiz'};
 const num=v=>typeof v==='number'&&Number.isFinite(v)?Math.round(v*100)/100:null;
 const s=kayit.summary||{};
 const stale=now().getTime()-readAt>KUTU_EN_ESKI_SAAT*3600e3;
 return {...base,state:stale?'bayat':'guncel',readAt:new Date(readAt).toISOString(),readFrom:kayit.source==='pos'?'pos':'store',
  summary:{quantity:num(s.quantity),net:num(s.net),cash:num(s.cash),card:num(s.card),currency:'TRY'}};
}

// sube.json'un "merkez" bölümünü central.mjs biçimine çevirir.
export function merkezAyari(sube){
 const m=sube?.merkez||{};
 return {enabled:m.etkin===true,branch:sube?.kod,bind:m.bind||'',port:m.port||3443,certFile:m.certFile||'',keyFile:m.keyFile||'',caFile:m.caFile||'',clientFingerprints:Array.isArray(m.clientFingerprints)?m.clientFingerprints:[]};
}

export async function baslat(subeDosyasi){
 const kok=path.dirname(path.resolve(subeDosyasi));
 const sube=JSON.parse((await fs.readFile(subeDosyasi,'utf8')).replace(/^﻿/,''));
 if(!/^[A-Z]{2}[0-9]{3,5}$/.test(sube.kod||''))throw Error('sube.json içindeki şube kodu geçersiz.');
 const config=merkezAyari(sube);
 if(!config.enabled){console.log('Merkez bağlantısı kapalı (sube.json > merkez.etkin=false). Port açılmadı.');return null;}
 const server=await startCentral({config,branch:sube.kod,snapshot:()=>merkezOzeti({kok,branch:sube.kod})});
 console.log(`Merkez ucu açık: https://${config.bind}:${config.port}/v1/branches/${sube.kod}/status (yalnız eşleştirilmiş Ankara sertifikası)`);
 return server;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 baslat(process.argv[2]||path.join(process.cwd(),'sube.json')).catch(e=>{console.error('Merkez ucu başlatılamadı: '+e.message);process.exit(1);});
}
