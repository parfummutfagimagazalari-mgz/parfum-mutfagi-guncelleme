import https from 'node:https';
import fs from 'node:fs/promises';
import {isIP} from 'node:net';

export const CENTRAL_VERSION=1;
const fingerprint=value=>String(value||'').replaceAll(':','').toUpperCase();
export function centralStatus(config={}) {
 return {hazir:true,etkin:config.enabled===true,surum:CENTRAL_VERSION,kapsam:'salt-okunur-durum',
  neden:config.enabled===true?'Merkez bağlantı modülü etkin; erişim eşleştirilmiş istemci sertifikası gerektirir.':'Ankara bağlantı modülü hazır. Merkez kurulumu sırasında adres ve sertifikalar eşleştirilecek; uzak erişim şu anda kapalı.'};
}
export function validateCentral(config,branch) {
 if(config.enabled!==true)return false;
 if(!isIP(config.bind)||['0.0.0.0','::'].includes(config.bind))throw Error('Merkez için belirli bir ağ IP adresi gerekli.');
 if(!Number.isInteger(config.port)||config.port<1024||config.port>65535)throw Error('Merkez portu geçersiz.');
 if(config.branch!==branch)throw Error('Merkez yapılandırması şubeyle eşleşmiyor.');
 for(const key of ['certFile','keyFile','caFile'])if(typeof config[key]!=='string'||!config[key])throw Error('Merkez sertifika dosyaları gerekli.');
 if(!Array.isArray(config.clientFingerprints)||!config.clientFingerprints.length||config.clientFingerprints.some(v=>!/^[A-F0-9]{64}$/.test(fingerprint(v))))throw Error('Yetkili merkez sertifikasının SHA256 izi gerekli.');
 return true;
}
// Only this small, explicitly selected status schema may leave the branch.
export async function centralSnapshot({branch,importer,exportJob}) {
 const connection=await importer.checkConnection();
 const job=(await exportJob.status()).job;
 return {version:CENTRAL_VERSION,branch,checkedAt:new Date().toISOString(),readOnly:true,
  connection:{reachable:connection.panelErisilebilir===true,branchVerified:connection.subeDogrulandi===true,authenticated:connection.oturumDogrulandi===true},
  report:{state:job?(['waiting','ready','error','cancelled'].includes(job.state)?job.state:'unknown'):'idle',screenAutomation:false}};
}
export function centralHandler({config,branch,snapshot}) {
 const allowed=new Set(config.clientFingerprints.map(fingerprint));
 return async(req,res)=>{
  const send=(code,value)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));};
  if(!req.socket.authorized||!allowed.has(fingerprint(req.socket.getPeerCertificate()?.fingerprint256)))return send(403,{error:'Merkez kimliği doğrulanmadı.'});
  if(req.method!=='GET'||req.url!==`/v1/branches/${encodeURIComponent(branch)}/status`)return send(404,{error:'Desteklenmeyen işlem.'});
  try{return send(200,await snapshot());}catch{return send(503,{error:'Şube durumu okunamadı.'});}
 };
}
export async function startCentral({config={},branch,snapshot}) {
 if(!validateCentral(config,branch))return null;
 const [cert,key,ca]=await Promise.all(['certFile','keyFile','caFile'].map(k=>fs.readFile(config[k])));
 const server=https.createServer({cert,key,ca,requestCert:true,rejectUnauthorized:true,minVersion:'TLSv1.2'},centralHandler({config,branch,snapshot}));
 server.requestTimeout=10000;server.headersTimeout=10000;server.maxHeadersCount=30;
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(config.port,config.bind,resolve);});
 return server;
}
