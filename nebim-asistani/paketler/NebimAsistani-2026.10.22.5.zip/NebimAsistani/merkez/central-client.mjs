import https from 'node:https';
import fs from 'node:fs/promises';

// Runs in the future Ankara panel backend, never in browser JavaScript.
export function resolveBranch(command,branches) {
 const text=String(command).trim().toLocaleLowerCase('tr-TR');
 const matches=branches.filter(b=>[b.code,b.name,...(b.aliases||[])].some(n=>text===`${String(n).toLocaleLowerCase('tr-TR')} şubesini kontrol et`));
 if(matches.length!==1)throw Error('Şube komutu belirsiz veya tanımlı değil.');
 return matches[0];
}
export async function checkBranch(branch,tls) {
 if(branch.enabled!==true)throw Error('Bu şube merkezde henüz eşleştirilmedi.');
 const url=new URL(branch.url);
 if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)throw Error('Şube için HTTPS kök adresi gerekli.');
 if(!/^[A-Za-z0-9_-]{1,40}$/.test(branch.code))throw Error('Geçersiz şube kodu.');
 const [cert,key,ca]=await Promise.all(['certFile','keyFile','caFile'].map(k=>fs.readFile(tls[k])));
 url.pathname=`/v1/branches/${branch.code}/status`;
 return new Promise((resolve,reject)=>{
  const req=https.get(url,{cert,key,ca,rejectUnauthorized:true,minVersion:'TLSv1.2'},res=>{
   if(res.statusCode!==200){res.resume();return reject(Error('Şube kontrolü başarısız: HTTP '+res.statusCode));}
   let data='';res.setEncoding('utf8');
   res.on('data',chunk=>{data+=chunk;if(Buffer.byteLength(data)>16384)req.destroy(Error('Şube yanıtı sınırı aşıldı.'));});
   res.on('error',reject);
   res.on('end',()=>{try{const result=JSON.parse(data);if(result.version!==1||result.branch!==branch.code||result.readOnly!==true||!Number.isFinite(Date.parse(result.checkedAt))||Math.abs(Date.now()-Date.parse(result.checkedAt))>120000)throw Error('Şube yanıtı kimlik/sürüm/zaman kontrolünden geçmedi.');resolve(result);}catch{reject(Error('Şube yanıtı doğrulanamadı.'));}});
  });
  const deadline=setTimeout(()=>req.destroy(Error('Şube yanıtı zaman aşımına uğradı.')),10000);
  req.once('close',()=>clearTimeout(deadline));req.on('error',()=>reject(Error('Şubeye güvenli bağlantı kurulamadı.')));
 });
}
