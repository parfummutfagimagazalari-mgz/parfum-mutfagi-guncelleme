@echo off
rem Nebim Asistani - DENEME: hicbir sey kurmaz, yalniz derleme ve oz-testleri yapar.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0kur.ps1" -Dene
pause
