@echo off
rem Nebim Asistani - guncelleme. Yeni surum varsa indirir, dogrular ve kurar; sube ayarlari korunur.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0guncelle.ps1"
pause
