@echo off
rem Nebim Yardimci - sunucu acilisinda baslatici + izleyici (surum 3, Claude, kullanici istegiyle).
rem Yardimcinin yerel kopyasini calistirir; kapanirsa 15 sn icinde yeniden baslatir.
rem Lenovo'da yeni surum kurulunca yardimci kendini kapatir, izleyici yeni kopyayla acar.
rem Tepsiden "Cikis" yapilirsa (araclar\yardimci-durdur.txt) yeniden baslatmaz. Nebim'e hicbir sey yazmaz.
setlocal
set "A=\\tsclient\N\araclar"
set "L=%LOCALAPPDATA%\NebimYardimci"
if not exist "%L%" mkdir "%L%"
if /i "%~1"=="izle" goto izle
rem Izleyici zaten calisiyorsa kilit dosyasi acik olur: ikinci kopyayi baslatma.
2>nul (type nul>>"%L%\izleyici.kilit") || exit /b 0
for /l %%i in (1,1,60) do (
  if exist "%A%\NebimYardimci.exe" goto hazir
  ping -n 6 127.0.0.1 >nul
)
exit /b 0
:hazir
copy /y "%A%\NebimYardimci-Baslat.cmd" "%L%\izleyici.cmd" >nul 2>&1
if not exist "%L%\izleyici.cmd" copy /y "%~f0" "%L%\izleyici.cmd" >nul 2>&1
>"%L%\gizli.vbs" echo CreateObject("WScript.Shell").Run "cmd /c """"%L%\izleyici.cmd"" izle""", 0, False
wscript //nologo "%L%\gizli.vbs"
exit /b 0
:izle
2>nul (call :dongu 9>>"%L%\izleyici.kilit")
exit /b 0
:dongu
>"%L%\izleyici-nabiz.txt" echo %date% %time%
if exist "%A%\NebimYardimci.exe" if not exist "%A%\yardimci-durdur.txt" (
  tasklist /FI "IMAGENAME eq NebimYardimci.exe" /FI "USERNAME eq %USERNAME%" /NH 2>nul | find /I "NebimYardimci.exe" >nul
  if errorlevel 1 (
    copy /y "%A%\NebimYardimci.exe" "%L%\NebimYardimci.exe" >nul 2>&1
    start "" "%L%\NebimYardimci.exe"
    >>"%L%\izleyici-log.txt" echo %date% %time% yardimci baslatildi
  )
)
ping -n 16 127.0.0.1 >nul
goto dongu
