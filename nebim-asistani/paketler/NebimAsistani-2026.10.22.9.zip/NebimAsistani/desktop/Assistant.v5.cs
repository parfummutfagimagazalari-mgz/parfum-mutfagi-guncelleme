﻿// =====================================================================================
// Nebim Asistanı — Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.
// Tasarım ve geliştirme: Ahmet Aksoy. Fikri ve ticari haklar Ahmet Aksoy'a aittir.
// Ahmet Aksoy'un yazılı izni olmadan değiştirilemez, kopyalanamaz, çoğaltılamaz,
// dağıtılamaz, satılamaz ve ticari olarak kullanılamaz. Ayrıntı: LISANS.txt
// =====================================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
[assembly: System.Reflection.AssemblyTitle("Nebim Asistanı")]
[assembly: System.Reflection.AssemblyProduct("Nebim Asistanı")]
[assembly: System.Reflection.AssemblyCompany("Ahmet Aksoy")]
[assembly: System.Reflection.AssemblyCopyright("Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.")]
[assembly: System.Reflection.AssemblyTrademark("Nebim Asistanı — Ahmet Aksoy")]

// Nebim Asistanı — Editorial Calm görev menüsü, canlı 4.8 pencere davranışları korunur.
// Asistan ve sunucu yardımcısı Nebim'e VERİ YAZMAZ; Kaydet/Onayla/Sil'e basmaz; POS'a dokunmaz.
// Bu menü ekran açma/okumayı doğrulanmış yetenek saymaz. Rakam kontrolü ortak dosya akışına gider.
public class Assistant : Form {
 public const string Surum="4.9";
 const string Origin="http://127.0.0.1:3033";
 const string PanelOrigin="http://127.0.0.1:3032";
 readonly HttpClient http=new HttpClient(new HttpClientHandler { AllowAutoRedirect=false, UseProxy=false });
 readonly HttpClient panelHttp=new HttpClient(new HttpClientHandler { AllowAutoRedirect=false, UseProxy=false });
 readonly JavaScriptSerializer json=new JavaScriptSerializer{MaxJsonLength=4*1024*1024};
 readonly FlowLayoutPanel body=new FlowLayoutPanel();
 FlowLayoutPanel toolbar;
 readonly Label identity=new Label(), step=new Label(), notice=new Label();
 readonly ComboBox procedures=new ComboBox(), files=new ComboBox();
 readonly TextBox command=new TextBox(), note=new TextBox();
 readonly TextBox chatMessage=new TextBox(), chatHistory=new TextBox();
 readonly Label chatInfo=new Label();
 readonly Button next=new Button(), verify=new Button(), transfer=new Button(), mini=new Button(), reconnect=new Button();
 readonly Panel light=new Panel();
 Color lightColor=Color.Gray;
 readonly NotifyIcon tray=new NotifyIcon();
 readonly ToolTip hints=new ToolTip {InitialDelay=350,ReshowDelay=100,AutoPopDelay=12000,ShowAlways=true};
 readonly List<Control> actions=new List<Control>();
 Dictionary<string,object> active;
 bool busy,compact,dark;
 readonly Button resumeTask=new Button();
 bool exitRequested,startInTray,closingService;
 System.Diagnostics.Process service;
 readonly System.Windows.Forms.Timer serviceMonitor=new System.Windows.Forms.Timer {Interval=15000};
 readonly System.Windows.Forms.Timer showMonitor=new System.Windows.Forms.Timer {Interval=400};
 readonly EventWaitHandle showRequest=new EventWaitHandle(false,EventResetMode.AutoReset,"Local\\NebimAssistantShowV1");
 readonly string serviceRoot=System.IO.Path.GetFullPath(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,".."));
 Size expanded;
 FlowLayoutPanel drawer;
 [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr hWnd,IntPtr after,int x,int y,int cx,int cy,uint flags);
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
 [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
 [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd,int cmd);
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint vk);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 // ---------- Ekran kataloğu ----------
 // 22.10.2026: şube ayarı. Kurulum klasöründeki sube.json'dan okunur; dosya yoksa Mahmutbey (PM3401, 3033 beyni açık).
class SubeAyar {
 public string Kod="PM3401",Ad="Mahmutbey",Sunucu="172.22.16.98";public bool Mcp=true;
 public static SubeAyar Parse(string text){
  var s=new SubeAyar();if(string.IsNullOrWhiteSpace(text))return s;
  try{var d=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(text.TrimStart('\uFEFF'));
   object v;
   if(d.TryGetValue("kod",out v)&&v!=null&&Regex.IsMatch(Convert.ToString(v),"^[A-Za-z]{2}[0-9]{3,5}$"))s.Kod=Convert.ToString(v).ToUpperInvariant();
   if(d.TryGetValue("ad",out v)&&v!=null&&Convert.ToString(v).Trim().Length>0)s.Ad=Convert.ToString(v).Trim();
   if(d.TryGetValue("sunucu",out v)&&v!=null&&Convert.ToString(v).Trim().Length>0)s.Sunucu=Convert.ToString(v).Trim();
   if(d.TryGetValue("mcp",out v)&&v is bool)s.Mcp=(bool)v;
  }catch{}
  return s;
 }
 // Kod ve adı kaydeder; dosyadaki diğer alanlar (sunucu, mcp, merkez...) korunur. Yeni dosyada mevcut değerler yazılır.
 public static string Save(string path,string kod,string ad,SubeAyar mevcut){
  kod=(kod??"").Trim().ToUpperInvariant();ad=(ad??"").Trim();
  if(!Regex.IsMatch(kod,"^[A-Z]{2}[0-9]{3,5}$"))return "Şube kodu iki harf ve 3-5 rakam olmalı (örn. PM3402).";
  if(ad.Length<2||ad.Length>40)return "Şube adı 2-40 karakter olmalı.";
  var js=new System.Web.Script.Serialization.JavaScriptSerializer();
  Dictionary<string,object> d=null;
  try{if(System.IO.File.Exists(path))d=js.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(path,Encoding.UTF8).TrimStart('\uFEFF'));}catch{d=null;}
  if(d==null)d=new Dictionary<string,object>{{"sunucu",mevcut.Sunucu},{"mcp",mevcut.Mcp}};
  d["kod"]=kod;d["ad"]=ad;d["degisti"]=DateTime.Now.ToString("s");
  try{string tmp=path+".yaz";System.IO.File.WriteAllText(tmp,js.Serialize(d),new UTF8Encoding(false));
   if(System.IO.File.Exists(path))System.IO.File.Replace(tmp,path,null);else System.IO.File.Move(tmp,path);}
  catch(Exception e){return "Kaydedilemedi: "+e.Message;}
  return null;
 }
 public static SubeAyar Load(string path){try{return System.IO.File.Exists(path)?Parse(System.IO.File.ReadAllText(path,Encoding.UTF8)):new SubeAyar();}catch{return new SubeAyar();}}
}
class NebimScreen {public string Id,Ad,Grup,Yol,Tur,Onay;public string Etiket="";public string[] Anahtar=new string[0],Adimlar=new string[0];public override string ToString(){return Etiket+Ad+(Tur=="kayit"?"  · kayıt":Tur=="okuma"?"  · bakış":"  · öğrenildi");}}
 readonly List<NebimScreen> catalog=new List<NebimScreen>();
 readonly ListBox screens=new ListBox();
 readonly TextBox screenFilter=new TextBox();
 readonly TextBox guide=new TextBox();
 readonly CheckedListBox guideSteps=new CheckedListBox();
 readonly Label guideFocus=new Label(), stepText=new Label(), warn=new Label();
 readonly TextBox screenNote=new TextBox();
 readonly Button readReport=new Button();
 readonly Label helperState=new Label();
 FlowLayoutPanel screenDrawer;
 NebimScreen guideScreen;
 int helperTick,fieldCycle;
 readonly Dictionary<string,int> usage=new Dictionary<string,int>();
 readonly List<string> recent=new List<string>();
 static string Araclar{get{return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Parfum Mutfagi","veri","nebim-gelen","araclar");}}
 static string Gelen{get{return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Parfum Mutfagi","veri","nebim-gelen");}}
 static string SubeDosyasi{get{return System.IO.Path.Combine(System.IO.Path.GetFullPath(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"..")),"sube.json");}}
 static SubeAyar Sube=SubeAyar.Load(SubeDosyasi);
 static string Veri{get{return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Parfum Mutfagi","veri");}}
 string StateFile(string name){return System.IO.Path.Combine(serviceRoot,"state",name);}
 public static string Norm(string s){
  var sb=new StringBuilder();
  foreach(char ch in (s??"").Trim()){
   char c=ch;
   switch(c){case 'İ':case 'I':case 'ı':c='i';break;case 'Ş':case 'ş':c='s';break;case 'Ğ':case 'ğ':c='g';break;case 'Ü':case 'ü':c='u';break;case 'Ö':case 'ö':c='o';break;case 'Ç':case 'ç':c='c';break;case 'â':c='a';break;case 'î':c='i';break;case 'û':c='u';break;default:c=char.ToLowerInvariant(c);break;}
   sb.Append(char.IsLetterOrDigit(c)?c:' ');
  }
  return " "+string.Join(" ",sb.ToString().Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries))+" ";
 }
 static readonly HashSet<string> StopWords=new HashSet<string>{"ac","acar","acin","ekran","ekrani","ekranini","ekranina","menu","menusu","menuyu","nebim","lutfen","bana","icin","nerede","nasil","istiyorum","goster","bir","bu","ve","ile","yapacagim","yapmak","yap","yapalim","nereden","hangi","ekranda","bakmak","bakacagim","olan","gerek","lazim"};
 public static int Lev(string a,string b){
  int n=a.Length,m=b.Length;if(n==0)return m;if(m==0)return n;
  var d=new int[n+1,m+1];
  for(int i=0;i<=n;i++)d[i,0]=i;for(int j=0;j<=m;j++)d[0,j]=j;
  for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
   int cost=a[i-1]==b[j-1]?0:1;
   d[i,j]=Math.Min(Math.Min(d[i-1,j]+1,d[i,j-1]+1),d[i-1,j-1]+cost);
   if(i>1&&j>1&&a[i-1]==b[j-2]&&a[i-2]==b[j-1])d[i,j]=Math.Min(d[i,j],d[i-2,j-2]+1);
  }
  return d[n,m];
 }
 static List<string> QueryTokens(string query){
  var tokens=new List<string>();
  foreach(string t in Norm(query).Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries))if(t.Length>=2&&!StopWords.Contains(t))tokens.Add(t);
  return tokens;
 }
 // Bir sorgu kelimesinin ekran metnine benzerliği: 1 tam kelime, 0.8 parça, 0.5–0.85 yazım hatalı.
 static double TokenScore(string t,string hay,string[] words){
  if(hay.Contains(" "+t))return 1.0;
  if(t.Length>=3&&hay.Contains(t))return 0.8;
  if(t.Length<4)return 0;
  double best=0;int allow=t.Length>=7?2:1;
  foreach(string w in words){
   if(w.Length<3)continue;
   if(Math.Abs(w.Length-t.Length)<=allow){int d=Lev(t,w);if(d<=allow){double s=0.85-0.15*(d-1);if(s>best)best=s;}}
   // Kelimenin başı yazılmış olabilir (ör. "irsalye" → "irsaliyeyi"): aynı uzunluktaki öneklerle kıyasla.
   for(int len=t.Length-1;len<=t.Length+1;len++){
    if(len<3||len>=w.Length)continue;
    int d=Lev(t,w.Substring(0,len));if(d<=allow&&0.6>best)best=0.6;
   }
   if(t.Length>w.Length&&w.Length>=4){int d=Lev(t.Substring(0,w.Length),w);if(d==0&&0.6>best)best=0.6;}
  }
  return best;
 }
 static double Score(NebimScreen sc,string query,List<string> tokens,out int matched){
  matched=0;
  string q=Norm(query);
  string hay=Norm(sc.Ad+" "+string.Join(" ",sc.Anahtar));
  string[] words=hay.Split(new[]{' '},StringSplitOptions.RemoveEmptyEntries);
  double score=0;
  foreach(string t in tokens){double s=TokenScore(t,hay,words);if(s>0)matched++;score+=s;}
  foreach(string p in sc.Anahtar){string np=Norm(p);if(np.Trim().Length>0&&q.Contains(np))score+=3;}
  string nad=Norm(sc.Ad);if(nad==q)score+=10;else if(q.Trim().Length>=4&&nad.Contains(q))score+=2;
  // Eşitlikte daha kısa (daha özel) ekran adı öne geçsin: "sayım fişi" → Mağaza Sayım Fişi.
  if(score>0)score-=0.02*nad.Trim().Split(' ').Length;
  return score;
 }
 static List<NebimScreen> Match(IList<NebimScreen> list,string query){
  var tokens=QueryTokens(query);
  var result=new List<NebimScreen>();if(tokens.Count==0)return result;
  string q=Norm(query);
  foreach(var sc in list)if(Norm(sc.Ad)==q){result.Add(sc);return result;}
  double best=0;var scores=new Dictionary<NebimScreen,double>();
  foreach(var sc in list){int m;double s=Score(sc,query,tokens,out m);scores[sc]=s;if(s>best)best=s;}
  if(best<0.6)return result;
  foreach(var sc in list)if(scores[sc]>=best-0.001)result.Add(sc);
  return result;
 }
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd,out uint pid);
 static readonly IntPtr HWND_TOPMOST=new IntPtr(-1);
 const uint SWP_NOSIZE=0x1,SWP_NOMOVE=0x2,SWP_NOACTIVATE=0x10;
 static readonly Size CompactSize=new Size(380,100);
 static readonly Size PosSize=new Size(300,60);
 readonly System.Windows.Forms.Timer remoteMonitor=new System.Windows.Forms.Timer {Interval=1000};
 readonly HashSet<uint> remotePids=new HashSet<uint>();
 readonly CheckBox pin=new CheckBox();
 bool keepOnTop=true,remoteOpen,userHidden,posMode,posWasExpanded,hotkeyOk;
 Point compactLocation;
 string SettingsFile{get{return StateFile("asistan-pencere.txt");}}
 protected override bool ShowWithoutActivation{get{return true;}}
 public static bool IsRemoteTitle(string title){
  if(string.IsNullOrEmpty(title))return false;
  string t=title.ToLower(new CultureInfo("tr-TR"));
  string srv=(Sube.Sunucu??"").ToLower(new CultureInfo("tr-TR"));
  return t.Contains("nebim")||t.Contains("172.22.16.98")||t.Contains("istgbzpmdsql")||(srv.Length>0&&t.Contains(srv))||title.Contains(" - ");
 }
 readonly List<FlowLayoutPanel> drawers=new List<FlowLayoutPanel>();
 public static string Intent(string text) {
  string s=text.Trim().ToLower(new CultureInfo("tr-TR"));
  switch(s) {
   case "satış":case "satis":case "satış raporu":return "satis";
   case "stok":case "stok raporu":return "stok";
   case "sayım":case "sayim":return "sayim";
   case "transfer":case "stok transferi":return "transfer";
   case "kampanya":case "personel":case "masraf":return s;
   case "kapanış":case "kapanis":return "kapanis";
   case "devam":case "geri":return s;
   case "durum":case "yenile":case "kaldığım yer":return "durum";
   default:return "";
  }
 }
 public static double ParseNumber(string v){
  string s=(v??"").Replace("₺","").Replace("TL","").Replace("tl","").Replace(" ","").Replace("\u00a0","").Trim();
  if(s.Length==0)return double.NaN;
  if(s.Contains(",")){s=s.Replace(".","").Replace(",",".");}
  else if(Regex.IsMatch(s,@"^-?\d{1,3}(\.\d{3})+$"))s=s.Replace(".","");
  double d;return double.TryParse(s,NumberStyles.Float,CultureInfo.InvariantCulture,out d)?d:double.NaN;
 }
 public static string[] Quoted(string text){
  var l=new List<string>();
  foreach(Match m in Regex.Matches(text??"","[\"“”«]([^\"“”«»]{2,60})[\"“”»]")){string v=m.Groups[1].Value.Trim();if(v.Length>=2&&!l.Contains(v))l.Add(v);}
  return l.ToArray();
 }
 [STAThread] public static int Main(string[] args) {
  if(args.Length==1 && args[0]=="--self-test") {
   if(Intent(" SATIŞ ")!="satis" || Intent("stok transferi")!="transfer" || Intent("şunu sil")!="" || Intent("panele aktar")!="")return 1;
   if(Norm("Ürün Girişi!")!=" urun girisi ")return 3;
   var t1=new NebimScreen {Id="a",Ad="Mağaza Sayım Fişi",Anahtar=new[]{"sayim","sayim fisi"}};var t2=new NebimScreen {Id="b",Ad="Envanter ve Sayım Fark Raporu",Anahtar=new[]{"sayim farki"}};
   var t3=new NebimScreen {Id="c",Ad="Mağazaya Gelen İrsaliyeyi Onayla - Fiş Bazında",Anahtar=new[]{"mal kabul","urun girisi"}};
   var t4=new NebimScreen {Id="d",Ad="Mağaza Hareket Özeti",Anahtar=new[]{"ciro","gunsonu","kasa"}};
   var tl=new List<NebimScreen>{t1,t2,t3,t4};
   if(Match(tl,"sayım")[0]!=t1||Match(tl,"sayım farkı")[0]!=t2||Match(tl,"merhaba").Count!=0||Match(tl,"Envanter ve Sayım Fark Raporu").Count!=1)return 4;
   if(Match(tl,"sayın fişi")[0]!=t1||Match(tl,"mal kabl")[0]!=t3||Match(tl,"gün sonu")[0]!=t4||Match(tl,"cirro")[0]!=t4||Match(tl,"irsalye onay")[0]!=t3)return 6;
   if(Lev("sayim","sayin")!=1||Lev("kabul","kabl")!=1)return 7;
   if(Math.Abs(ParseNumber("12.345,67")-12345.67)>0.001||Math.Abs(ParseNumber("1.234")-1234)>0.001||!double.IsNaN(ParseNumber("")))return 8;
   if(Math.Abs(ParseNumber("-194.300,00")+194300)>0.001||Math.Abs(ParseNumber("9.900,00")-9900)>0.001||Math.Abs(ParseNumber("₺5.700,00")-5700)>0.001)return 21;
   var sb1=SubeAyar.Parse("{\"kod\":\"pm3402\",\"ad\":\"Bakırköy\",\"mcp\":false,\"sunucu\":\"10.0.0.5\"}");
   if(sb1.Kod!="PM3402"||sb1.Ad!="Bakırköy"||sb1.Mcp||sb1.Sunucu!="10.0.0.5")return 22;
   var sb2=SubeAyar.Parse("bozuk {");if(sb2.Kod!="PM3401"||!sb2.Mcp)return 23;
   var sb3=SubeAyar.Parse("{\"kod\":\"../x\"}");if(sb3.Kod!="PM3401")return 24;
   if(!IsRemoteTitle("PM - 172.22.16.98 - Uzak Masaüstü Bağlantısı")||IsRemoteTitle("Not Defteri"))return 25;
   { var trT0=new CultureInfo("tr-TR");Func<string,string> bas=x=>trT0.TextInfo.ToTitleCase(x.ToLower(trT0));
     if(bas("SİPARİŞ VER")!="Sipariş Ver"||bas("Merkeze iadeler")!="Merkeze İadeler"||bas("Ürün iade al")!="Ürün İade Al"||bas("Stok sayımı yap")!="Stok Sayımı Yap"||bas("Şirkete para gönder")!="Şirkete Para Gönder")return 29; }
   // Şube kaydı: diğer alanlar korunur, hatalı kod reddedilir
   string tf=System.IO.Path.Combine(System.IO.Path.GetTempPath(),"nebim-sube-test-"+Guid.NewGuid().ToString("N")+".json");
   try{
    System.IO.File.WriteAllText(tf,"{\"kod\":\"PM3402\",\"ad\":\"Eski\",\"mcp\":false,\"merkez\":{\"etkin\":false,\"port\":3443}}",new UTF8Encoding(false));
    if(SubeAyar.Save(tf,"pm3403","Bakırköy",new SubeAyar())!=null)return 26;
    var y2=SubeAyar.Load(tf);string raw2=System.IO.File.ReadAllText(tf,Encoding.UTF8);
    if(y2.Kod!="PM3403"||y2.Ad!="Bakırköy"||y2.Mcp||!raw2.Contains("merkez")||!raw2.Contains("3443"))return 27;
    if(SubeAyar.Save(tf,"X1","Ad",new SubeAyar())==null||SubeAyar.Save(tf,"PM3404","A",new SubeAyar())==null)return 28;
   }finally{try{System.IO.File.Delete(tf);}catch{}}
   if(Quoted("Alttaki \"Çalıştır\" düğmesi ve “Zorunlu Filtreler”").Length!=2)return 9;
   if(!IsRemoteTitle("172.22.16.98 - Uzak Masaüstü Bağlantısı") || !IsRemoteTitle("Nebim - 172.22.16.98 - Remote Desktop Connection") || IsRemoteTitle("Uzak Masaüstü Bağlantısı") || IsRemoteTitle(""))return 2;
   return 0;
  }
  bool created;using(var mutex=new Mutex(true,"Local\\NebimFloatingAssistantV1",out created)) {
   if(!created){using(var signal=new EventWaitHandle(false,EventResetMode.AutoReset,"Local\\NebimAssistantShowV1"))signal.Set();return 0;}
   Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
   Application.ThreadException+=(s,e)=>Crash(e.Exception,false);
   AppDomain.CurrentDomain.UnhandledException+=(s,e)=>Crash(e.ExceptionObject as Exception,true);
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   Assistant form;
   try{form=new Assistant(Array.IndexOf(args,"--tray")>=0);}catch(Exception e){Crash(e,true);return 5;}
   Application.Run(form);
  }return 0;
 }
 static void Crash(Exception e,bool fatal){
  string text=DateTime.Now.ToString("s")+(fatal?" KAPANDI ":" HATA ")+(e==null?"(bilinmeyen)":e.ToString());
  try{System.IO.File.AppendAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"asistan-hata.log"),text+Environment.NewLine+Environment.NewLine,new UTF8Encoding(false));}catch{}
  if(!fatal)return; // Arka plandaki küçük hatalar kayda yazılır; kullanıcıyı pencereyle bölmez.
  try{MessageBox.Show("Nebim Asistanı bir hatayla karşılaştı ve kapanıyor.\n\n"+(e==null?"":e.Message)+"\n\nAyrıntı: desktop\\asistan-hata.log","Nebim Asistanı",MessageBoxButtons.OK,MessageBoxIcon.Error);}catch{}
 }
 public Assistant(bool trayOnly=false) {
  startInTray=trayOnly;
  LoadSettings();
  Text="Nebim Asistanı";TopMost=keepOnTop;ShowInTaskbar=false;MaximizeBox=false;MinimizeBox=false;Size=new Size(420,640);MinimumSize=new Size(360,300);
  StartPosition=FormStartPosition.Manual;
  Location=compactLocation;Font=new Font("Segoe UI",12);BackColor=Color.FromArgb(240,240,240);ForeColor=Color.FromArgb(30,30,30);
  http.Timeout=TimeSpan.FromSeconds(40);http.DefaultRequestHeaders.Add("Origin",Origin);panelHttp.Timeout=TimeSpan.FromSeconds(20);
  toolbar=new FlowLayoutPanel {Dock=DockStyle.Top,Height=54,Padding=new Padding(5)};
  light.Size=new Size(18,18);light.Margin=new Padding(4,9,2,3);light.Paint+=(s,e)=>{e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;using(var b=new SolidBrush(lightColor))e.Graphics.FillEllipse(b,1,1,15,15);using(var p=new Pen(Color.FromArgb(90,90,90)))e.Graphics.DrawEllipse(p,1,1,15,15);};
  toolbar.Controls.Add(light);
  mini.Text="Küçült";mini.AutoSize=true;mini.MinimumSize=new Size(60,44);mini.Click+=(s,e)=>Toggle();toolbar.Controls.Add(mini);
  pin.Text="Üstte";pin.Checked=keepOnTop;pin.AutoSize=true;pin.Margin=new Padding(3,10,3,3);pin.CheckedChanged+=(s,e)=>{keepOnTop=pin.Checked;TopMost=keepOnTop;SaveSettings();};toolbar.Controls.Add(pin);
  hints.SetToolTip(pin,"Açıkken asistan Uzak Masaüstü / Nebim penceresinin üstünde görünür kalır. Ayar hatırlanır.");
  reconnect.Text="Bağlan";reconnect.AutoSize=true;reconnect.MinimumSize=new Size(70,44);reconnect.FlatStyle=FlatStyle.Flat;reconnect.FlatAppearance.BorderColor=Color.FromArgb(150,150,150);reconnect.Click+=async(s,e)=>await Reconnect();toolbar.Controls.Add(reconnect);
  var themeBtn=new Button{Text="Tema",AutoSize=true,MinimumSize=new Size(60,44),FlatStyle=FlatStyle.Flat};themeBtn.FlatAppearance.BorderColor=Color.FromArgb(150,150,150);
  themeBtn.Click+=(s,e)=>{dark=!dark;ApplyTheme(this);};toolbar.Controls.Add(themeBtn);hints.SetToolTip(themeBtn,"Açık / koyu tema");
  hints.SetToolTip(reconnect,"Yeniden bağlan: sunucu yardımcısını, MCP hizmetini ve ekran listesini yeniden kontrol eder.");
  body.Dock=DockStyle.Fill;body.FlowDirection=FlowDirection.TopDown;body.WrapContents=false;body.AutoScroll=true;body.Padding=new Padding(8);
  Controls.Add(body);Controls.Add(toolbar);
  identity.Text="Merkeze bağlantı bekleniyor…";Add(identity,48);
  // 22.10: mağaza (şube) adını girip kaydetme düğmesi — görünür yerde
  var magazaBtn=new Button{Text="✎  Mağaza adını gir / değiştir",FlatStyle=FlatStyle.Flat,TextAlign=ContentAlignment.MiddleCenter,Font=new Font("Segoe UI",9,FontStyle.Bold)};
  magazaBtn.FlatAppearance.BorderColor=Color.FromArgb(150,150,150);magazaBtn.Click+=(s0,e0)=>SubeDuzenle();
  hints.SetToolTip(magazaBtn,"Şube (mağaza) kodunu ve adını kaydeder. Bu ad asistanın üstünde ve Ankara'ya giden özette görünür.");
  Add(magazaBtn,32);
  warn.ForeColor=Color.FromArgb(150,60,0);warn.BackColor=Color.FromArgb(255,243,224);warn.Padding=new Padding(4);Add(warn,150);warn.Visible=false;
  // Nebim POS ekranındaki renkli karolar gibi hızlı düğmeler.
  // Nebim Mağaza Hareket Özeti'nin canlı görünümü (açık raporu okur; Nebim'e yazmaz).
  liveTitle.Text="Mağaza Hareket Özeti · henüz okunmadı";liveTitle.BackColor=Color.FromArgb(255,140,0);liveTitle.ForeColor=Color.White;liveTitle.Font=new Font("Segoe UI",10,FontStyle.Bold);liveTitle.AutoEllipsis=true;liveTitle.TextAlign=ContentAlignment.MiddleCenter;liveTitle.Padding=new Padding(0);liveTitle.Tag="tile";
  Add(liveTitle,38);liveTitle.TextChanged+=(s0,e0)=>{liveTitle.Height=38;FitOneLine(liveTitle);};liveTitle.SizeChanged+=(s0,e0)=>{if(liveTitle.Height!=38)liveTitle.Height=38;};
  foreach(var lv in new[]{salesView,payView}){lv.View=View.Details;lv.FullRowSelect=true;lv.GridLines=true;lv.HeaderStyle=ColumnHeaderStyle.Nonclickable;lv.BackColor=Color.White;lv.ForeColor=Color.Black;lv.Tag="tile";lv.Font=new Font("Segoe UI",9);lv.Scrollable=false;}
  salesView.Columns.Add("Satış (Süreç)",140);salesView.Columns.Add("Miktar",60);salesView.Columns.Add("Net Tutar",90);
  payView.Columns.Add("Ödeme tipi",120);payView.Columns.Add("Peşinat",85);payView.Columns.Add("Toplam",85);
  Add(salesView,92);Add(payView,72);salesView.Visible=false;payView.Visible=false; // 22.10: özet tek satırda (turuncu başlıkta) gösterilir
  Action fitCols=()=>{int w=salesView.ClientSize.Width;if(w<120)return;salesView.Columns[2].Width=(int)(w*0.32);salesView.Columns[1].Width=(int)(w*0.2);salesView.Columns[0].Width=w-salesView.Columns[1].Width-salesView.Columns[2].Width-2;int p=payView.ClientSize.Width;payView.Columns[1].Width=(int)(p*0.3);payView.Columns[2].Width=(int)(p*0.3);payView.Columns[0].Width=p-payView.Columns[1].Width-payView.Columns[2].Width-2;};
  salesView.SizeChanged+=(s0,e0)=>fitCols();payView.SizeChanged+=(s0,e0)=>fitCols();
  var liveBtn=new Button{Text="Yenile",Tag="tile",FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(0,114,198),ForeColor=Color.White,Font=new Font("Segoe UI",10,FontStyle.Bold)};liveBtn.FlatAppearance.BorderSize=0;
  AddAction(liveBtn,RefreshLive);liveBtn.BackColor=Color.FromArgb(0,122,230);liveBtn.ForeColor=Color.White;liveBtn.FlatAppearance.BorderSize=0;liveBtn.FlatAppearance.MouseOverBackColor=Color.FromArgb(0,90,160);liveBtn.Text="⟳  Yenile";hints.SetToolTip(liveBtn,"Mağaza Hareket Özeti'ni açar, Çalıştır'a basar ve sonucu turuncu satıra yazar. Nebim'e veri yazmaz.");
  // 22.10.2026: 9 renkli karo (3x3). Karo yalnız ekranı açar; Kaydet/Onayla kullanıcıdadır.
  var tileRow=new Panel{Tag="satir"};Add(tileRow,186);
  var tiles=new List<Control>();
  tiles.Add(Tile("SİPARİŞ VER",Color.FromArgb(46,170,40),"Nebim'de Verilen Siparişler - Toptan Alış ekranını açar. Siparişi siz girip kaydedersiniz.",()=>OpenById("verilen-siparisler")));
  tiles.Add(Tile("Masraf ekle",Color.FromArgb(232,48,48),"Nebim'de Mağaza Masraf Girişi ekranını açar. Masrafı siz girip kaydedersiniz.",()=>OpenById("magaza-masraf-girisi")));
  tiles.Add(Tile("Stok sayımı yap",Color.FromArgb(0,122,230),"Nebim'de Mağaza Sayım Fişi ekranını açar. Sayımı siz girip kaydedersiniz.",()=>OpenById("magaza-sayim-fisi")));
  tiles.Add(Tile("Tüm envanter",Color.FromArgb(255,140,0),"Nebim'de Ürün Envanter Sorgula ekranını açar (yalnız bakış).",()=>OpenById("urun-envanter-sorgula")));
  tiles.Add(Tile("Gelen ürünleri onayla",Color.FromArgb(0,172,150),"Merkezden gelen mal için Nebim'de Gelen İrsaliyeyi Onayla - Ürün Detaylı ekranını açar. Onayı siz verirsiniz.",()=>OpenById("irsaliye-onay-urun")));
  tiles.Add(Tile("Merkeze iadeler",Color.FromArgb(142,60,200),"Nebim'de Merkeze İade ekranını açar. İadeyi siz girip kaydedersiniz.",()=>OpenById("merkeze-iade")));
  tiles.Add(Tile("Şirkete para gönder",Color.FromArgb(20,140,50),"Nebim'de Merkezin Banka Hesabına Nakit Çıkış ekranını açar. Tutarı siz girip kaydedersiniz.",()=>OpenById("merkez-banka-nakit-cikisi")));
  tiles.Add(Tile("Satış sorumlusu",Color.FromArgb(0,160,220),"Nebim'de Satış Sorumlusu ekranını açar. Yeni kişiyi siz girip kaydedersiniz.",()=>OpenById("satis-sorumlusu")));
  tiles.Add(Tile("Ürün iade al",Color.FromArgb(224,24,110),"Müşteri iadesi POS'ta yapılır: Peşin Satış İade → Ürün İade Al. İadeyi siz yaparsınız.",()=>{notice.Text="Müşteri iadesi POS'ta: Nebim V3 POS → Peşin Satış İade → Ürün İade Al. Asistan kasa (POS) ekranına henüz dokunmuyor; iadeyi siz yapın.";return Task.FromResult(0);}));
  tileRow.Controls.AddRange(tiles.ToArray());
  Action lay=()=>{int g=6,w=Math.Max(60,(tileRow.Width-2*g)/3),h=Math.Max(40,(tileRow.Height-2*g)/3);for(int k=0;k<tileRow.Controls.Count;k++){tileRow.Controls[k].SetBounds((k%3)*(w+g),(k/3)*(h+g),w,h);}};
  tileRow.Resize+=(s0,e0)=>lay();lay();
  resumeTask.Text="Kaldığın yer";AddAction(resumeTask,()=>{OpenDrawer(stepDrawer);return Task.FromResult(0);});resumeTask.Visible=false;
  Drawer("Ekran veya işlem ara · Ctrl+Boşluk");screenDrawer=drawer;((Button)drawer.Tag).Visible=false; // 22.10: menü kaldırıldı (karo basınca rehber yine açılır)
  LabelText("Katalogda arayın; listeden ekrana çift tıklayın (veya seçip Enter'a basın). Adımı seçip 'Alanı göster'e basınca Nebim'de ilgili alan renkli çerçeveyle işaretlenir; tıklamaz, yazmaz. Kaydet/Onayla/Sil size aittir.",100);
  Add(screenFilter,44);screenFilter.AccessibleName="Ekran veya işlem ara";
  screenFilter.TextChanged+=(s,e)=>ApplyFilter();
  screenFilter.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Down&&screens.Items.Count>0){e.SuppressKeyPress=true;screens.Focus();screens.SelectedIndex=0;}};
  screens.IntegralHeight=false;Add(screens,150);screens.AccessibleName="Katalogdaki ekranlar";
  screens.SelectedIndexChanged+=(s,e)=>ShowGuide(screens.SelectedItem as NebimScreen);
  screens.DoubleClick+=async(s,e)=>{if(screens.SelectedItem!=null&&!busy)await OpenSelected();};
  screens.KeyDown+=async(s,e)=>{if(e.KeyCode==Keys.Enter&&screens.SelectedItem!=null&&!busy){e.SuppressKeyPress=true;await OpenSelected();}};
  guide.Multiline=true;guide.ReadOnly=true;guide.ScrollBars=ScrollBars.Vertical;Add(guide,130);
  guideFocus.ForeColor=Color.FromArgb(150,60,0);Add(guideFocus,40);
  guideSteps.IntegralHeight=false;guideSteps.CheckOnClick=true;guideSteps.AccessibleName="Adımlar";Add(guideSteps,150);
  guideSteps.ItemCheck+=(s,e)=>{if(restoringSteps)return;BeginInvoke(new Action(()=>SaveStepProgress()));};
  ActionButton("Alanı Nebim'de göster (renkli çerçeve)",ShowField);
  ActionButton("Seçilen ekranı Nebim'de aç",OpenSelected);
  ActionButton("Nebim'in Ara kutusunda ara (açmaz)",async()=>await SearchInNebim(screenFilter.Text));
  LabelText("Katalog yolu öneridir; kendi Nebim ekranınızda kontrol edin. Notlar ve öğrenilen eşleşmeler doğrulanmamıştır.",90);
  screenNote.Multiline=true;screenNote.MaxLength=1500;Add(screenNote,70);
  ActionButton("Doğrulanmamış notu kaydet",async()=>{SaveScreenNote(false);await Task.FromResult(0);});
  Drawer("Mal geldi (merkezden)");((Button)drawer.Tag).Visible=false; // 22.10: yerini "Gelen ürünleri onayla" karosu aldı
  LabelText("Merkezden gelen irsaliye için. Ekranı açar; irsaliyeyi kontrol edip onayı siz verirsiniz, asistan hiçbir şey kaydetmez.",80);
  ActionButton("Gelen irsaliyeyi aç (fiş bazında)",()=>OpenById("irsaliye-onay-fis"));
  ActionButton("Gelen irsaliyeyi aç (ürün detaylı)",()=>OpenById("irsaliye-onay-urun"));
  ActionButton("Transfer irsaliyesi kontrol listesi",()=>OpenById("transfer-irsaliye-kontrol"));
  Drawer("Stok ve sayım");((Button)drawer.Tag).Visible=false; // 22.10: yerini "Stok sayımı yap" ve "Tüm envanter" karoları aldı
  LabelText("Ekranı açar; veri girişi ve kaydetme size aittir.",40);
  ActionButton("Ürünün stokuna bak",()=>OpenById("urun-envanter-sorgula"));
  ActionButton("Sayım fişi",()=>OpenById("magaza-sayim-fisi"));
  ActionButton("Sayım eşitleme fişi",()=>OpenById("magaza-sayim-esitleme-fisi"));
  ActionButton("Stok rakamlarını Nebim ekranından oku",()=>{OpenDrawer(numbersDrawer);numbersInfo.Text="Nebim'de Mağaza Satış ve Envanter Raporu'nu açıp Çalıştır'a basın; sonuç görününce 'Ekrandaki rakamları oku'ya basın.";return Task.FromResult(0);});
  Drawer("Açılış / kapanış");checklistDrawer=drawer;
  LabelText("Hazırlık listesi. İşaretler bağımsız doğrulama veya kesin kapanış değildir.",60);
  Add(checklistInfo,70);
  checklist.IntegralHeight=false;checklist.CheckOnClick=true;Add(checklist,200);
  checklist.ItemCheck+=(s,e)=>{if(loadingChecklist)return;BeginInvoke(new Action(()=>ChecklistChanged()));};
  checklist.DoubleClick+=async(s,e)=>{if(checklist.SelectedItem!=null&&!busy)await OpenChecklistScreen();};
  ActionButton("Seçili maddenin ekranını Nebim'de aç",OpenChecklistScreen);
  ActionButton("Günlük rakamları kontrol et",()=>{OpenDrawer(numbersDrawer);return Task.FromResult(0);});
  ((Button)checklistDrawer.Tag).Visible=false; // Açılış / kapanış menüsü iptal: düğmesi gizli.
  Drawer("Günlük rakamlar");numbersDrawer=drawer;((Button)numbersDrawer.Tag).Visible=false; // menü iptal: ciro karosu kullanılır
  LabelText("Nebim'de Hareket Özeti, Ciro veya Envanter raporunu açıp Çalıştır'a basın; sonuç görünürken aşağıdan okutun. Panel ve dosya kullanılmaz; Nebim'e hiçbir şey yazılmaz.",80);
  numbersInfo.AutoSize=false;numbersInfo.Text="Henüz okunmadı.";Add(numbersInfo,260);
  ActionButton("Ekrandaki rakamları oku",ReadNebimNumbers);
  ActionButton("Mağaza Hareket Özeti'ni aç",async()=>{foreach(var sc0 in catalog)if(sc0.Id=="magaza-hareket-ozeti"){SelectScreen(sc0);OpenScreenDrawer();await OpenSelected();return;}notice.Text="Hareket Özeti katalogda yok.";});
  drawer=null;
  // ----- Eski bölümler -----
  Drawer("Kısa komut");((Button)drawer.Tag).Visible=false; // 22.10: menü kaldırıldıAdd(command,44);command.AccessibleName="Kısa komut";
  ActionButton("Komutu çalıştır",RunCommand);
  command.KeyDown+=async(s,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;await RunCommand();}};
  LabelText("Örnek: sayım, mal kabul, gün sonu, merkeze iade, devam, geri, durum. Yazım hatası olsa da anlaşılır.",58);
  Drawer("Asistana sor");((Button)drawer.Tag).Visible=false; // 22.10: menü kaldırıldıAdd(chatInfo,60);
  chatHistory.Multiline=true;chatHistory.ReadOnly=true;chatHistory.ScrollBars=ScrollBars.Vertical;Add(chatHistory,150);
  chatMessage.Multiline=true;chatMessage.MaxLength=2000;chatMessage.AccessibleName="Asistana soru";Add(chatMessage,65);
  chatMessage.KeyDown+=async(s,e)=>{if(e.KeyCode==Keys.Enter&&!e.Shift){e.SuppressKeyPress=true;if(chatMessage.Text.Trim().Length>0&&!busy)await SendChat();}};
  LabelText("Gönderdiğiniz metin ve son sohbet mesajları yapay zekâ sağlayıcısına gider. Raporlar ve işlem notları otomatik gönderilmez. Yanıtlar işlem yapmaz. Enter gönderir, Shift+Enter yeni satır açar.",90);
  Drawer("Dosya işlemleri");procDrawer=drawer;
  procInfo.ForeColor=Color.FromArgb(150,60,0);Add(procInfo,44);
  procedures.DropDownStyle=ComboBoxStyle.DropDownList;Add(procedures,44);
  ActionButton("Seçilen işlemi aç / devam et",StartProcedure);
  Drawer("Kaldığınız adım / dosya kontrolü");stepDrawer=drawer;((Button)stepDrawer.Tag).Visible=false;Add(step,90);
  next.Text="Bu adımı yaptım, devam et";AddAction(next,async()=>await Send(new {action="step",step="devam"}));
  files.DropDownStyle=ComboBoxStyle.DropDownList;Add(files,44);
  verify.Text="Seçilen dosyayı doğrula";AddAction(verify,async()=> {if(files.SelectedItem!=null)await Send(new {action="verify",file=files.SelectedItem.ToString()});});
  transfer.Text="Rakamları kontrol et ve aktar";AddAction(transfer,ConfirmTransfer);
  ActionButton("Yarım kalan işlemi iptal et",async()=>{if(active==null){notice.Text="İptal edilecek açık işlem yok.";return;}if(MessageBox.Show(this,Str(active,"ad")+" işlemi iptal edilsin mi? Nebim'e ve panele hiçbir şey yazılmaz; işlem geçmişe 'iptal' olarak kaydedilir.","İşlemi iptal et",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)await Send(new {action="step",step="iptal"});});
  Drawer("İşlem notu / yardım");((Button)drawer.Tag).Visible=false; // 22.10: menü kaldırıldınote.Multiline=true;note.MaxLength=2000;note.ScrollBars=ScrollBars.Vertical;Add(note,65);
  ActionButton("Takıldım — bu adımı hatırla",async()=>await Send(new {action="step",step="takildim",note=note.Text}));
  ActionButton("Notu kaydet",async()=>await Send(new {action="step",step="not",note=note.Text}));
  ((Button)procDrawer.Tag).Visible=false;
  drawer=null;
  notice.ForeColor=Color.FromArgb(31,87,153);Add(notice,130);
  ActionButton("Yardım",()=>{keepOpen=true;try{MessageBox.Show(this,"Ekran listesinde ekrana çift tıklayınca Nebim'de açılır; üstteki renkli karolar sık kullanılan ekranları açar.\n\nAsistan yalnız ekranı açar ve alanı çerçeveler. Kaydet, Onayla, Sil ve bilgi girişi size aittir.\n\nMenüyü Geri düğmesi veya Esc ile kapatırsınız; asistan Küçült düğmesine basana kadar açık kalır.\n\nSorularınız için 'Asistana sor' menüsünü kullanın (Enter gönderir).","Yardım",MessageBoxButtons.OK,MessageBoxIcon.Information);}finally{keepOpen=false;}return Task.FromResult(0);});
  body.SizeChanged+=(s,e)=>ResizeRows();body.ClientSizeChanged+=(s,e)=>ResizeRows();
  Padding=new Padding(3);Paint+=(s,e)=>{using(var pen=new Pen(Color.FromArgb(235,150,40),3))e.Graphics.DrawRectangle(pen,1,1,ClientSize.Width-3,ClientSize.Height-3);};
  // 22.10: programa gömülü asistan simgesi (karolar + turuncu satır) pencerede ve bildirim alanında da görünür.
  Icon appIcon=null;try{appIcon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);}catch{}
  if(appIcon!=null)Icon=appIcon;
  tray.Icon=appIcon??SystemIcons.Information;tray.Text="Nebim Asistanı";tray.Visible=true;tray.DoubleClick+=(s,e)=>ShowByUser();
  var menu=new ContextMenuStrip();menu.Items.Add("Asistanı göster",null,(s,e)=>ShowByUser());menu.Items.Add("Ekran ara (Ctrl+Boşluk)",null,(s,e)=>FocusSearch());menu.Items.Add("Asistanı gizle",null,(s,e)=>HideByUser());menu.Items.Add("Güncelle",null,(s,e)=>GuncelleBaslat());menu.Items.Add("Hakkında",null,(s,e)=>Hakkinda());menu.Items.Add(new ToolStripSeparator());menu.Items.Add("Asistandan çık",null,(s,e)=>{if(busy){tray.ShowBalloonTip(4000,"İşlem sürüyor","İşlem bittikten sonra çıkış yapın.",ToolTipIcon.Info);return;}CloseApplication();});tray.ContextMenuStrip=menu;
  FormClosing+=(s,e)=>{if(!exitRequested&&e.CloseReason==CloseReason.UserClosing){e.Cancel=true;HideByUser();}};
  ContextMenuStrip=menu;
  showMonitor.Tick+=(s,e)=>{if(showRequest.WaitOne(0))ShowByUser();CheckRemoteHotkey();};showMonitor.Start();
  FormClosed+=(s,e)=>{try{UnregisterHotKey(Handle,1);}catch{}showMonitor.Stop();remoteMonitor.Stop();showRequest.Dispose();serviceMonitor.Stop();tray.Dispose();hints.Dispose();http.Dispose();panelHttp.Dispose();};
  // Başka pencereye (ör. Nebim) geçilince küçük çubuğa iner; gizlenmez, menüleri örtmez.
  // Menü, yalnızca "Küçült" düğmesine basılınca küçülür (başka pencereye geçmek küçültmez).
  KeyPreview=true;KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Escape){bool any=false;foreach(var d in drawers)if(d.Visible)any=true;if(any){e.SuppressKeyPress=true;CloseDrawers();}}};
  ResizeEnd+=(s,e)=>{if(compact&&!posMode){compactLocation=Location;SaveSettings();}};
  Resize+=(s,e)=>{if(WindowState!=FormWindowState.Normal)WindowState=FormWindowState.Normal;};
  serviceMonitor.Tick+=(s,e)=>{if(!exitRequested&&(service==null||service.HasExited))StartService();};
  remoteMonitor.Tick+=(s,e)=>{WatchRemote();ReadBeat();UpdateLight();if(++helperTick%5==1)UpdateHelperState();};
  try{kisayolStamp=new System.IO.FileInfo(System.IO.Path.Combine(Araclar,"kisayol.txt")).LastWriteTimeUtc;}catch{}
  LoadCatalog();
  identity.Cursor=Cursors.Hand;hints.SetToolTip(identity,"Şube adını ve kodunu değiştirmek için tıklayın.");identity.Click+=(s0,e0)=>SubeDuzenle();
  Shown+=async(s,e)=>{Raise3D(this);Toggle();if(startInTray)Hide();StartService();serviceMonitor.Start();remoteMonitor.Start();WatchRemote();await Task.Delay(1200);await RefreshStatus();GuncellemeHaberi();if(System.IO.File.Exists(SubeDosyasi)&&!SubeAdiGirildi())SubeDuzenle();};
 }
 Task OpenTask(string view){System.Diagnostics.Process.Start(Origin+"/#"+view);return Task.FromResult(0);}
 // 22.10: tüm düğmeler (karolar dahil) kabartmalı görünür; basılınca içeri çöker. Sonradan eklenen düğmeler de yakalanır.
 readonly HashSet<Control> raisedSet=new HashSet<Control>();readonly HashSet<Control> pressedSet=new HashSet<Control>();
 void Raise3D(Control root){
  if(root==null||raisedSet.Contains(root))return;raisedSet.Add(root);root.Disposed+=(s,e)=>{raisedSet.Remove(root);pressedSet.Remove(root);};
  var b=root as Button;
  if(b!=null){
   b.MouseDown+=(s,e)=>{if(e.Button==MouseButtons.Left){pressedSet.Add(b);b.Invalidate();}};
   b.MouseUp+=(s,e)=>{pressedSet.Remove(b);b.Invalidate();};
   b.MouseLeave+=(s,e)=>{if(pressedSet.Remove(b))b.Invalidate();};
   b.EnabledChanged+=(s,e)=>b.Invalidate();
   b.Paint+=(s,e)=>{
    try{
     var g=e.Graphics;var r=b.ClientRectangle;if(r.Width<6||r.Height<6)return;
     bool down=pressedSet.Contains(b);int a1=b.Enabled?70:30,a2=b.Enabled?140:50; // 22.10: canlı renk için parlaklık azaltıldı
     using(var hi=new Pen(Color.FromArgb(a1,255,255,255),2))using(var lo=new Pen(Color.FromArgb(a2,0,0,0),2))using(var lo2=new Pen(Color.FromArgb(b.Enabled?60:25,0,0,0),1)){
      var top=down?lo:hi;var bot=down?hi:lo;
      g.DrawLine(top,1,1,r.Width-2,1);g.DrawLine(top,1,1,1,r.Height-2);
      g.DrawLine(bot,1,r.Height-2,r.Width-2,r.Height-2);g.DrawLine(bot,r.Width-2,1,r.Width-2,r.Height-2);
      if(!down){g.DrawLine(lo2,2,r.Height-4,r.Width-3,r.Height-4);}
     }
    }catch{}
   };
   b.Invalidate();
  }
  root.ControlAdded+=(s,e)=>Raise3D(e.Control);
  foreach(Control c in root.Controls)Raise3D(c);
 }
 // Turuncu satır tek satırda kalsın: sığmazsa yazıyı 10'dan 8 puntoya kadar küçült.
 void FitOneLine(Label l){try{float sz=10f;while(sz>8f){using(var f=new Font("Segoe UI",sz,FontStyle.Bold)){if(TextRenderer.MeasureText(l.Text??"",f).Width<=l.Width-8)break;}sz-=0.5f;}if(Math.Abs(l.Font.Size-sz)>0.01f)l.Font=new Font("Segoe UI",sz,FontStyle.Bold);}catch{}}
 // 22.10: şube adı/kodu asistandan girilip kaydedilir (sube.json). Diğer ayarlar korunur.
 static bool SubeAdiGirildi(){try{var d=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(SubeDosyasi,Encoding.UTF8).TrimStart('\uFEFF'));object v;return d.TryGetValue("ad",out v)&&v!=null&&Convert.ToString(v).Trim().Length>=2;}catch{return false;}}
 void SubeDuzenle(){
  if(busy)return;
  using(var f=new Form{Text="Şube bilgisi",FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false,StartPosition=FormStartPosition.CenterParent,ClientSize=new Size(300,168),TopMost=true,Font=new Font("Segoe UI",9)}){
   var l1=new Label{Text="Şube kodu (Nebim mağaza kodu)",Left=12,Top=10,Width=276};var kod=new TextBox{Left=12,Top=30,Width=276,Text=Sube.Kod,MaxLength=7,CharacterCasing=CharacterCasing.Upper};
   var l2=new Label{Text="Şube adı",Left=12,Top=60,Width=276};var ad=new TextBox{Left=12,Top=80,Width=276,Text=Sube.Ad,MaxLength=40};
   var hata=new Label{Left=12,Top=106,Width=276,Height=20,ForeColor=Color.FromArgb(198,40,40)};
   var ok=new Button{Text="Kaydet",Left=132,Top=130,Width=75};var no=new Button{Text="Vazgeç",DialogResult=DialogResult.Cancel,Left=213,Top=130,Width=75};
   ok.Click+=(s1,e1)=>{string err=SubeAyar.Save(SubeDosyasi,kod.Text,ad.Text,Sube);if(err!=null){hata.Text=err;return;}f.DialogResult=DialogResult.OK;f.Close();};
   f.Controls.AddRange(new Control[]{l1,kod,l2,ad,hata,ok,no});f.AcceptButton=ok;f.CancelButton=no;
   keepOpen=true;DialogResult dr;try{dr=f.ShowDialog(this);}finally{keepOpen=false;}
   if(dr!=DialogResult.OK)return;
  }
  Sube=SubeAyar.Load(SubeDosyasi);tray.Text="Nebim Asistanı · "+Sube.Ad;
  if(!Sube.Mcp)identity.Text="✎ "+Sube.Ad+" şubesi · "+Sube.Kod;else identity.Text="✎ "+Sube.Ad+" · "+Sube.Kod;
  notice.Text="✔ Şube bilgisi kaydedildi: "+Sube.Ad+" ("+Sube.Kod+").";
 }
 // 22.10: açılışta güncelleyicinin bıraktığı haber (state\guncelleme.json) varsa gösterilir; asistan kendisi kurmaz.
 void GuncellemeHaberi(){
  try{string f=StateFile("guncelleme.json");if(!System.IO.File.Exists(f))return;
   var d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(f,Encoding.UTF8).TrimStart('\uFEFF'));
   object v;if(d.TryGetValue("var",out v)&&v is bool&&(bool)v){string yeni=d.ContainsKey("yeni")?Convert.ToString(d["yeni"]):"";
    notice.Text="⬆ Yeni sürüm var ("+yeni+"). Bildirim alanındaki asistan simgesine sağ tıklayıp \"Güncelle\"yi seçin.";
    tray.ShowBalloonTip(6000,"Nebim Asistanı","Yeni sürüm var ("+yeni+"). Simgeye sağ tıklayıp Güncelle'yi seçin.",ToolTipIcon.Info);}
  }catch{}
 }
 // 22.10: tepsi menüsünden güncelleme. Şube kurulumunda GUNCELLE.cmd (GitHub'dan indirir, doğrular, kurar),
 // Mahmutbey'de desktop\9-KARO-KUR.cmd (yerel kaynağı derler) çalıştırılır. Asistan kurulum sırasında kapanıp yeniden açılır.
 void GuncelleBaslat(){
  if(busy){tray.ShowBalloonTip(4000,"İşlem sürüyor","İşlem bittikten sonra güncelleyin.",ToolTipIcon.Info);return;}
  string sube=System.IO.Path.Combine(serviceRoot,"GUNCELLE.cmd"),mahmutbey=System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"9-KARO-KUR.cmd");
  string hedef=System.IO.File.Exists(sube)?sube:(System.IO.File.Exists(mahmutbey)?mahmutbey:null);
  if(hedef==null){ShowByUser();notice.Text="✖ Güncelleme dosyası bulunamadı (GUNCELLE.cmd). Kurulum paketini yeniden kurun.";return;}
  ShowByUser();keepOpen=true;DialogResult dr;
  try{dr=MessageBox.Show(this,"Asistan güncellenecek. Kurulum sırasında birkaç saniye kapanıp yeniden açılır; Nebim'e hiçbir şey yazılmaz.\n\nDevam edilsin mi?","Nebim Asistanı · Güncelle",MessageBoxButtons.YesNo,MessageBoxIcon.Question);}finally{keepOpen=false;}
  if(dr!=DialogResult.Yes)return;
  try{System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("cmd.exe","/c \""+hedef+"\""){WorkingDirectory=System.IO.Path.GetDirectoryName(hedef),UseShellExecute=true});
   notice.Text="⟳ Güncelleme penceresi açıldı. Bitince asistan kendiliğinden yeniden açılır.";}
  catch(Exception ex){notice.Text="✖ Güncelleme başlatılamadı: "+ex.Message;}
 }
 // 22.10: telif ve kullanım koşulları (Ahmet Aksoy).
 void Hakkinda(){
  string surum="";try{var sj=System.IO.Path.Combine(serviceRoot,"surum.json");if(System.IO.File.Exists(sj)){var d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(sj,Encoding.UTF8).TrimStart('\uFEFF'));if(d.ContainsKey("surum"))surum=" · sürüm "+Convert.ToString(d["surum"]);}}catch{}
  ShowByUser();keepOpen=true;
  try{MessageBox.Show(this,"Nebim Asistanı"+surum+"\n\nTasarım ve geliştirme: Ahmet Aksoy\nCopyright © 2026 Ahmet Aksoy. Tüm hakları saklıdır.\n\nFikri ve ticari haklar Ahmet Aksoy'a aittir. Ahmet Aksoy'un yazılı izni olmadan değiştirilemez, kopyalanamaz, dağıtılamaz, satılamaz ve ticari olarak kullanılamaz. Kullanım izni Ahmet Aksoy tarafından verilir.\n\nŞube: "+Sube.Ad+" ("+Sube.Kod+")","Hakkında · Nebim Asistanı",MessageBoxButtons.OK,MessageBoxIcon.Information);}
  finally{keepOpen=false;}
 }
 void ApplyTheme(Control root){if(root.Tag as string=="tile")return;root.BackColor=dark?Color.FromArgb(11,29,72):Color.FromArgb(240,240,240);root.ForeColor=dark?Color.FromArgb(240,240,240):Color.FromArgb(30,30,30);foreach(Control c in root.Controls)ApplyTheme(c);}
 bool keepOpen; // iletişim penceresi açıkken küçülmesin
 FlowLayoutPanel procDrawer,stepDrawer,numbersDrawer;
 readonly ComboBox goodsSource=new ComboBox();
 readonly Label goodsHelp=new Label(), numbersInfo=new Label();
 readonly Label procInfo=new Label();
 // Açık menünün düğmesi renk değiştirir (turuncu zemin + çerçeve).
 readonly Label liveTitle=new Label();
 readonly ListView salesView=new ListView(),payView=new ListView();
 static string CellOf(Dictionary<string,string> d,string key){string v;return d.TryGetValue(key,out v)?v:"";}
 async Task RefreshLive(){
  if(!await EnsureHelper())return;
  Busy(true);
  try{
   notice.Text="Hareket Özeti okunuyor (STORE'da açılıp çalıştırılır; POS öndeyse yalnız okunur)… Birkaç saniye fareye ve klavyeye dokunmayın.";
   var r=await HelperCall(new Dictionary<string,object>{{"islem","ozet"}},"Hareket Özeti çalıştırılıyor",60);
   if(!Bool(r,"ok")){
    liveTitle.Text="Mağaza Hareket Özeti · okunamadı";notice.Text="✖ "+Str(r,"mesaj");
    return;
   }
   salesView.Items.Clear();payView.Items.Clear();
   foreach(object o in Arr(r,"satirlar")){
    var row=Obj(o);if(row==null)continue;
    var c=new Dictionary<string,string>();foreach(object h in Arr(row,"hucreler")){var hc=Obj(h);c[Norm(Str(hc,"kolon")).Trim()]=Str(hc,"deger");}
    string net=CellOf(c,"net tutar"),mik=CellOf(c,"miktar"),sur=CellOf(c,"surec aciklamasi"),ia=CellOf(c,"iade");
    string od=CellOf(c,"odeme tipi aciklamasi"),pes=CellOf(c,"pesinat"),top=CellOf(c,"toplam");
    if(net.Length>0||mik.Length>0){var it=salesView.Items.Add((sur.Length>0?sur:Str(row,"satir"))+(ia.Length>0&&ia!="Toplam"&&!Norm(ia).Contains("secili degil")?" ("+ia+")":""));it.SubItems.Add(mik);it.SubItems.Add(net);if(Norm(ia).Trim()=="toplam")it.Tag="ara";}
    else if(od.Length>0||top.Length>0){var it=payView.Items.Add(od.Length>0?od:Str(row,"satir"));it.SubItems.Add(pes);it.SubItems.Add(top);}
   }
   // 22.10 hata önleme: tablo satırı okunamadıysa tahmini/yanlış rakam gösterme.
   if(salesView.Items.Count==0&&payView.Items.Count==0){liveTitle.Text="Mağaza Hareket Özeti · rakam okunamadı";notice.Text="✖ Rapor açık ama satış satırı okunamadı. Raporun çalıştırıldığından emin olup Yenile'ye tekrar basın.";return;}
   // Tek satır: saat · adet · net ciro · nakit · kart
   double gNet=double.NaN,gQty=double.NaN,sNet=0,sQty=0,ozNakit=0,ozKart=0;
   foreach(ListViewItem it in salesView.Items){
    string lb=Norm(it.Text);double n0=ParseNumber(it.SubItems.Count>2?it.SubItems[2].Text:""),q0=ParseNumber(it.SubItems.Count>1?it.SubItems[1].Text:"");
    if(lb.Contains("genel toplam")){gNet=n0;gQty=q0;}
    else if(!lb.Contains("toplam")&&(it.Tag as string)!="ara"){if(!double.IsNaN(n0))sNet+=n0;if(!double.IsNaN(q0))sQty+=q0;}
   }
   foreach(ListViewItem it in payView.Items){
    // 22.10: satıştan gelen ödeme "Peşinat" sütunudur (Toplam, merkeze gönderilen nakdi de içerir).
    string lb=Norm(it.Text);double t0=ParseNumber(it.SubItems.Count>1?it.SubItems[1].Text:"");if(double.IsNaN(t0))t0=ParseNumber(it.SubItems.Count>2?it.SubItems[2].Text:"");if(double.IsNaN(t0)||lb.Contains("toplam"))continue;
    if(lb.Contains("nakit"))ozNakit+=t0;else if(lb.Contains("kart")||lb.Contains("kredi"))ozKart+=t0;
   }
   double ozNet=double.IsNaN(gNet)?sNet:gNet,ozQty=double.IsNaN(gQty)?sQty:gQty;
   var trK=new CultureInfo("tr-TR");
   // 22.10: tutar en sonda; nakit/kart yalnız okunduysa gösterilir. POS'tan okunduysa başta "POS" yazar.
   string kay=Str(r,"kaynak")=="pos"?"POS · ":"";
   string odm=(ozNakit>0?" · Nakit "+ozNakit.ToString("N0",trK):"")+(ozKart>0?" · Kart "+ozKart.ToString("N0",trK):"");
   liveTitle.Text=kay+DateTime.Now.ToString("HH:mm")+" · "+ozQty.ToString("0",trK)+" adet"+odm+" · ₺"+ozNet.ToString("N0",trK);
   hints.SetToolTip(liveTitle,"Mağaza Hareket Özeti (Nebim'den okundu, "+DateTime.Now.ToString("HH:mm:ss")+"). Adet ve net tutar satış satırlarından, nakit ve kart ödeme satırlarından toplanır.");
   notice.Text="✔ Rakamlar Nebim ekranından okundu; Nebim'e hiçbir şey yazılmadı.";
   MerkezKutusunaYaz(Str(r,"kaynak")=="pos"?"pos":"store",ozQty,ozNet,ozNakit,ozKart);
  }finally{Busy(false);}
 }
 // 22.10: Ankara merkez paneli için yerel kutu. Ağa hiçbir şey göndermez; merkez ucu (merkez\merkez-ucu.mjs)
 // etkinleştirilince Ankara yalnız bu son özeti okur. Dosya: <kurulum>\state\merkez-kutusu\son.json + gün dosyası.
 void MerkezKutusunaYaz(string kaynak,double adet,double net,double nakit,double kart){
  try{
   string dir=System.IO.Path.Combine(serviceRoot,"state","merkez-kutusu");System.IO.Directory.CreateDirectory(dir);
   Func<double,object> n=v=>double.IsNaN(v)||double.IsInfinity(v)?(object)null:Math.Round(v,2);
   var kayit=new Dictionary<string,object>{{"version",1},{"branch",Sube.Kod},{"ad",Sube.Ad},{"readAt",DateTime.Now.ToString("yyyy-MM-ddTHH:mm:sszzz")},{"source",kaynak},
    {"summary",new Dictionary<string,object>{{"quantity",n(adet)},{"net",n(net)},{"cash",n(nakit)},{"card",n(kart)},{"currency","TRY"}}}};
   string text=json.Serialize(kayit);
   foreach(var name in new[]{"son.json","ozet-"+DateTime.Now.ToString("yyyyMMdd")+".json"}){
    string path=System.IO.Path.Combine(dir,name),tmp=path+".yaz";
    System.IO.File.WriteAllText(tmp,text,new UTF8Encoding(false));
    if(System.IO.File.Exists(path))System.IO.File.Replace(tmp,path,null);else System.IO.File.Move(tmp,path);
   }
   // 40 günden eski gün dosyalarını temizle (kutu büyümesin).
   foreach(var f in System.IO.Directory.GetFiles(dir,"ozet-*.json")){try{if((DateTime.Now-System.IO.File.GetLastWriteTime(f)).TotalDays>40)System.IO.File.Delete(f);}catch{}}
  }catch{}
 }
 Button Tile(string text,Color c,string tip,Func<Task> act){
  // 22.10: karo yazısı her kelimenin baş harfi büyük, diğerleri küçük (Türkçe: i→İ, I→ı) ve ortalı.
  var trT=new CultureInfo("tr-TR");
  var b=new Button{Text=trT.TextInfo.ToTitleCase(text.ToLower(trT)),Tag="tile",FlatStyle=FlatStyle.Flat,BackColor=c,ForeColor=Color.White,TextAlign=ContentAlignment.MiddleCenter,Font=new Font("Segoe UI",9,FontStyle.Bold),Padding=new Padding(3,2,3,4)};
  b.FlatAppearance.BorderSize=0;b.FlatAppearance.MouseOverBackColor=ControlPaint.Light(c,0.25f);
  hints.SetToolTip(b,tip);b.AccessibleDescription=tip;b.Click+=async(s,e)=>{if(!busy)await act();};
  return b;
 }
 void CloseDrawers(){foreach(var d in drawers)d.Visible=false;SyncHeadings();ResizeRows();foreach(var d in drawers)((Button)d.Tag).Invalidate();}
 void SyncHeadings(){foreach(var d in drawers){var b=d.Tag as Button;if(b==null)continue;bool on=d.Visible;b.BackColor=on?Color.FromArgb(205,230,247):Color.FromArgb(255,255,255);b.FlatAppearance.BorderColor=on?Color.FromArgb(58,139,227):Color.FromArgb(186,209,234);b.FlatAppearance.BorderSize=on?2:1;b.Font=new Font(b.Font,on?FontStyle.Bold:FontStyle.Regular);}}
 void OpenDrawer(FlowLayoutPanel target){
  foreach(var d in drawers){d.Visible=d==target;((Button)d.Tag).Invalidate();}
  SyncHeadings();
  ResizeRows();if(target!=null)body.ScrollControlIntoView(target);
 }
 // Yarım kalan başka bir işlem varsa MCP yenisini başlatmaz: kullanıcıya sor, isterse yarım kalanı iptal edip yenisini başlat.
 async Task OpenById(string id){
  if(busy)return;NebimScreen t=null;foreach(var c0 in catalog)if(c0.Id==id)t=c0;
  if(t==null){notice.Text="Ekran katalogda yok: "+id;return;}
  // 22.10: karo yalnız o ekranı açar; alttaki liste/rehber açılmaz.
  SelectScreen(t);CloseDrawers();tileOpen=true;try{await OpenSelected();}finally{tileOpen=false;}
 }
 bool tileOpen=false;
 async Task StartProcedure(){var c=procedures.SelectedItem as Choice;if(c==null)return;await StartById(c.Id,c.Name);}
 async Task StartById(string procId,string procName){
  if(busy)return;
  if(active!=null){
   string cur=Str(active,"prosedur");
   if(cur==procId){OpenDrawer(stepDrawer);notice.Text="Bu işlem zaten açık; kaldığınız adım aşağıda.";return;}
   keepOpen=true;DialogResult ans;
   try{ans=MessageBox.Show(this,"Yarım kalan bir işlem var: "+Str(active,"ad")+" (adım "+(Convert.ToInt32(active["adim"])+1)+"/"+Str(active,"toplam")+").\n\nEvet: yarım kalanı iptal et ve '"+procName+"' işlemini başlat.\nHayır: yarım kalan işleme devam et.\n\nNebim'e ve panele hiçbir şey yazılmaz; iptal geçmişe kaydedilir.","İşlem seç",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);}finally{keepOpen=false;}
   if(ans==DialogResult.No){OpenDrawer(stepDrawer);return;}
   if(ans!=DialogResult.Yes)return;
   if(busy)return;Busy(true);
   try{await Request(new {action="step",step="iptal"});}catch(Exception e){Busy(false);notice.Text="Yarım kalan işlem iptal edilemedi: "+e.Message;return;}
   Busy(false);
  }
  await Send(new {action="start",id=procId});
  if(active!=null&&Str(active,"prosedur")==procId)OpenDrawer(stepDrawer);
 }
 protected override void OnHandleCreated(EventArgs e){
  base.OnHandleCreated(e);
  hotkeyOk=RegisterHotKey(Handle,1,0x0002|0x4000,0x20);
 }
 protected override void WndProc(ref Message m){
  if(m.Msg==0x0312&&m.WParam.ToInt32()==1){FocusSearch();return;}
  base.WndProc(ref m);
 }
 // ---------- Kısayol: Ctrl+Boşluk (Lenovo'da ya da uzak masaüstü tam ekranken sunucu yardımcısı üzerinden) ----------
 DateTime kisayolStamp=DateTime.MinValue;
 void CheckRemoteHotkey(){
  try{
   var f=new System.IO.FileInfo(System.IO.Path.Combine(Araclar,"kisayol.txt"));
   if(f.Exists&&f.LastWriteTimeUtc!=kisayolStamp){bool first=kisayolStamp==DateTime.MinValue;kisayolStamp=f.LastWriteTimeUtc;if(!first)FocusSearch();}
   else if(!f.Exists&&kisayolStamp==DateTime.MinValue)kisayolStamp=new DateTime(1,1,2);
  }catch{}
 }
 void ForceForeground(){
  try{
   IntPtr fg=GetForegroundWindow();uint pid;uint fgThread=GetWindowThreadProcessId(fg,out pid),me=GetCurrentThreadId();
   bool attached=fgThread!=0&&fgThread!=me&&AttachThreadInput(fgThread,me,true);
   // Alt tuşu hilesi kullanılmaz: uzak masaüstü öndeyken Nebim'e gider ve şerit kısayollarını açar.
   try{SetWindowPos(Handle,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);SetForegroundWindow(Handle);}finally{if(attached)AttachThreadInput(fgThread,me,false);}
  }catch{}
  Activate();
 }
 void FocusSearch(){
  if(exitRequested)return;
  if(posMode)ExitPos(false);
  userHidden=false;if(!Visible)Show();WindowState=FormWindowState.Normal;
  if(compact)Toggle();
  OpenScreenDrawer();
  ForceForeground();
  screenFilter.Focus();screenFilter.SelectAll();
  body.ScrollControlIntoView(screenFilter);
 }
 void ShowByUser(){userHidden=false;Show();WindowState=FormWindowState.Normal;Activate();}
 void HideByUser(){userHidden=true;if(posMode)ExitPos(false);if(!compact)Toggle();Hide();}
 bool FindRemote(){
  remotePids.Clear();bool found=false;
  foreach(string name in new[]{"mstsc","msrdc","NebimV3ERP","NebimV3POS"}){
   System.Diagnostics.Process[] list;try{list=System.Diagnostics.Process.GetProcessesByName(name);}catch{continue;}
   foreach(var p in list){
    try{
     bool local=name.StartsWith("NebimV3",StringComparison.OrdinalIgnoreCase);
     if(p.MainWindowHandle!=IntPtr.Zero&&(local||IsRemoteTitle(p.MainWindowTitle))){found=true;remotePids.Add((uint)p.Id);}
    }catch{}
    finally{p.Dispose();}
   }
  }
  return found;
 }
 void WatchRemote(){
  if(exitRequested)return;
  bool open;try{open=FindRemote();}catch{return;}
  if(open&&!remoteOpen){remoteOpen=true;userHidden=false;if(!Visible){if(!compact)Toggle();Show();}tray.Text="Nebim Asistanı · Nebim açık";}
  else if(!open&&remoteOpen){remoteOpen=false;if(posMode)ExitPos(false);if(Visible&&compact&&!busy)Hide();tray.Text="Nebim Asistanı · Nebim kapalı";}
  if(!open||!Visible||!keepOnTop||userHidden)return;
  // Tam ekran Uzak Masaüstü öne geldiğinde asistanı odak çalmadan yeniden en üste al.
  try{uint pid;GetWindowThreadProcessId(GetForegroundWindow(),out pid);if(remotePids.Contains(pid))SetWindowPos(Handle,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);}catch{}
 }
 void LoadSettings(){
  bool haveLocation=false;
  try{
   if(System.IO.File.Exists(SettingsFile))foreach(string line in System.IO.File.ReadAllLines(SettingsFile)){
    string[] kv=line.Split(new[]{'='},2);if(kv.Length!=2)continue;
    if(kv[0]=="ustte")keepOnTop=kv[1].Trim()!="0";
    else if(kv[0]=="konum"){string[] xy=kv[1].Split(',');int x,y;if(xy.Length==2&&int.TryParse(xy[0],out x)&&int.TryParse(xy[1],out y)){var r=new Rectangle(x,y,CompactSize.Width,CompactSize.Height);foreach(var sc in Screen.AllScreens)if(sc.WorkingArea.IntersectsWith(r)){compactLocation=new Point(x,y);haveLocation=true;break;}}}
   }
  }catch{}
  if(!haveLocation){var a=Screen.PrimaryScreen.WorkingArea;compactLocation=new Point(a.Right-CompactSize.Width-12,a.Top+(int)(a.Height*0.45));}
 }
 void SaveSettings(){
  try{System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(SettingsFile));System.IO.File.WriteAllText(SettingsFile,"ustte="+(keepOnTop?"1":"0")+"\r\nkonum="+compactLocation.X+","+compactLocation.Y+"\r\n");}catch{}
 }
 bool ExternalServiceRunning(){
  try{foreach(string p in System.IO.Directory.GetFiles(@"\\.\pipe\"))if(System.IO.Path.GetFileName(p).StartsWith("NebimMCP-",StringComparison.OrdinalIgnoreCase))return true;}catch{}
  try{var f=new System.IO.FileInfo(StateFile("service-status.json"));if(f.Exists&&(DateTime.Now-f.LastWriteTime).TotalSeconds<75)return true;}catch{}
  return false;
 }
 void StartService(){
  try{
   if(!Sube.Mcp){tray.Text="Nebim Asistanı · "+Sube.Ad;return;} // şube kurulumu: 3033 beyni yok
   if(service!=null&&!service.HasExited)return;
   if(service!=null){service.Dispose();service=null;}
   if(ExternalServiceRunning()){tray.Text="Nebim Asistanı · MCP çalışıyor";return;}
   var node=System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"nodejs","node.exe");
   var info=new System.Diagnostics.ProcessStartInfo(node,"\""+System.IO.Path.Combine(serviceRoot,"src","service.mjs")+"\" \""+System.IO.Path.Combine(serviceRoot,"config.json")+"\"") {WorkingDirectory=serviceRoot,UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
   service=new System.Diagnostics.Process {StartInfo=info};
   service.OutputDataReceived+=(s,e)=>ServiceLog("service.log",e.Data);
   service.ErrorDataReceived+=(s,e)=>ServiceLog("service-error.log",e.Data);
   service.Start();service.BeginOutputReadLine();service.BeginErrorReadLine();
   tray.Text="Nebim Asistanı · MCP çalışıyor";
  }catch{tray.Text="Nebim Asistanı · MCP başlatılamadı";notice.Text="MCP başlatılamadı. Kurulum dosyalarını kontrol edin.";}
 }
 void ServiceLog(string file,string line){if(line==null)return;try{lock(json){System.IO.File.AppendAllText(System.IO.Path.Combine(serviceRoot,file),line+Environment.NewLine);}}catch{}}
 async void CloseApplication(){
  if(closingService)return;closingService=true;serviceMonitor.Stop();Busy(true);
  tray.Text="Nebim Asistanı · işlemler bitiriliyor";
  bool stopped=await Task.Run(()=>StopService());
  closingService=false;
  if(stopped){exitRequested=true;Close();}
  else {Busy(false);serviceMonitor.Start();tray.Text="Nebim Asistanı · kapanış bekliyor";tray.ShowBalloonTip(6000,"İşlem devam ediyor","Hizmet zorla kesilmedi. Biraz sonra tekrar çıkış yapın.",ToolTipIcon.Info);}
 }
 bool StopService(){
  if(service==null)return true;
  try{if(!service.HasExited){service.StandardInput.WriteLine("shutdown");service.StandardInput.Flush();if(!service.WaitForExit(60000))return false;}service.Dispose();service=null;return true;}
  catch{return false;}
 }
 void Drawer(string title){
  drawer=null;var heading=new Button {Text=title,TextAlign=ContentAlignment.MiddleLeft,Padding=new Padding(30,0,0,0),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(255,255,255)};heading.FlatAppearance.BorderColor=Color.FromArgb(186,209,234);Add(heading,38);
  var panel=new FlowLayoutPanel {FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Visible=false,Margin=new Padding(0)};
  heading.Tag=panel;panel.Tag=heading;body.Controls.Add(panel);drawers.Add(panel);drawer=panel;
  var back=new Button {Text="← Geri",TextAlign=ContentAlignment.MiddleCenter,FlatStyle=FlatStyle.Flat,Tag="kucuk",BackColor=Color.FromArgb(205,230,247)};back.FlatAppearance.BorderColor=Color.FromArgb(58,139,227);Add(back,28);back.Width=84;hints.SetToolTip(back,"Menüyü kapat (Esc)");
  back.Click+=(s,e)=>CloseDrawers();
  string help=title=="Kısa komut"?"Ekran adı ya da günlük dil (sayım, mal kabul, gün sonu) yazarak ilgili ekranı açın.":title=="Asistana sor"?"Sorunuzu yazıp açıklama alın. Yanıtlar kendiliğinden işlem yapmaz.":title=="İşlem seç"?"Satış, stok ve diğer işlemler için adım adım rehber seçin.":title=="Kaldığınız adım / dosya kontrolü"?"Yarım kalan adıma dönün; raporu doğrulayın ve hazırsa panele aktarın.":title=="Nebim ekranı aç"?"Nebim'de ekran açar, adımları gösterir, alanı çerçeveler, rapor toplamını okur.":title=="Günlük kontrol listesi"?"Açılış ve kapanış maddeleri; bitince panelde 'bugün yapıldı' olarak işaretlenir.":"Takıldığınız noktayı veya işlem notunu kaydedin; sonra devam edin.";
  hints.SetToolTip(heading,help);heading.AccessibleDescription=help;
  heading.Paint+=(s,e)=>{e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;int y=heading.Height/2;var points=panel.Visible?new[]{new Point(10,y-5),new Point(26,y-5),new Point(18,y+6)}:new[]{new Point(12,y-8),new Point(12,y+8),new Point(24,y)};using(var brush=new SolidBrush(panel.Visible?Color.FromArgb(58,139,227):Color.FromArgb(58,139,227)))e.Graphics.FillPolygon(brush,points);};
  heading.Click+=(s,e)=>{bool open=!panel.Visible;foreach(var d in drawers){d.Visible=false;((Button)d.Tag).Invalidate();}panel.Visible=open;SyncHeadings();heading.Invalidate();ResizeRows();if(open&&panel==checklistDrawer)LoadChecklist();};
 }
 void Add(Control c,int height){c.Height=height;c.Width=290;c.Margin=new Padding(0,2,0,3);(drawer??body).Controls.Add(c);var lb=c as Label;if(lb!=null)lb.TextChanged+=(s,e)=>FitLabel(lb);}
 // Etiket yüksekliği metne göre ayarlanır; gereksiz boşluk kalmaz.
 void FitLabel(Label l){try{if(l==liveTitle){l.Height=38;return;}if(l.Width<50)return;int pad=l.Padding.Vertical+4;string t=l.Text??"";if(t.Length==0){l.Height=2;return;}var sz=TextRenderer.MeasureText(t,l.Font,new Size(l.Width-l.Padding.Horizontal,0),TextFormatFlags.WordBreak|TextFormatFlags.NoPadding);l.Height=Math.Max(20,sz.Height+pad);}catch{}}
 // Menü içindeki açıklamalar ekranda yer kaplamaz: menü düğmesinin üzerine gelince kısa açıklama olarak görünür.
 // Gizlilik bildirimi (yapay zekâya gidecek metin) görünür kalır.
 readonly HashSet<Button> tipSet=new HashSet<Button>();
 void LabelText(string text,int h=25){
  var hb=drawer==null?null:drawer.Tag as Button;
  if(hb!=null&&!text.StartsWith("Gönderdiğiniz metin")){
   string cur=tipSet.Add(hb)?"":hints.GetToolTip(hb);string nt=cur.Length==0?text:cur+"\n"+text;hints.SetToolTip(hb,nt);hb.AccessibleDescription=nt;
   return;
  }
  Add(new Label {Text=text},h);
 }
 void ResizeRows(){int width=Math.Max(240,body.ClientSize.Width-body.Padding.Horizontal-6);foreach(Control c in body.Controls){c.Width=width;var cl=c as Label;if(cl!=null)FitLabel(cl);if(c is FlowLayoutPanel)foreach(Control child in c.Controls){if(child.Tag as string=="kucuk")continue;child.Width=width;var l2=child as Label;if(l2!=null)FitLabel(l2);}}}
 void AddAction(Button b,Func<Task> action){Add(b,38);b.FlatStyle=FlatStyle.Flat;b.FlatAppearance.BorderColor=Color.FromArgb(186,209,234);b.BackColor=Color.FromArgb(255,255,255);actions.Add(b);b.Click+=async(s,e)=>{if(!busy)await action();};}
 void ActionButton(string text,Func<Task> action){AddAction(new Button {Text=text},action);}
 void Toggle(){
  if(posMode)return;
  if(!compact){expanded=Size;body.Hide();MinimumSize=CompactSize;Size=CompactSize;Location=compactLocation;mini.Text="Aç";compact=true;}
  else {compactLocation=Location;var a=Screen.FromControl(this).WorkingArea;var e0=expanded.Width>0?expanded:new Size(370,560);Size=new Size(e0.Width,Math.Max(e0.Height,Math.Min(780,a.Height-30)));MinimumSize=new Size(340,280);body.Show();mini.Text="Küçült";compact=false;Location=new Point(Math.Max(a.Left,Math.Min(Left,a.Right-Width)),Math.Max(a.Top,Math.Min(Top,a.Bottom-Height)));}
 }
 // ---------- POS önde: ince şerit ----------
 void EnterPos(){
  if(posMode)return;
  posWasExpanded=!compact;
  if(!compact)Toggle();
  posMode=true;toolbar.Visible=false;MinimumSize=PosSize;Size=PosSize;Text="Kasa açık · asistan bekliyor";
  tray.Text="Nebim Asistanı · kasa (POS) önde";
 }
 void ExitPos(bool restore){
  if(!posMode)return;
  posMode=false;toolbar.Visible=true;Text="Nebim Asistanı";MinimumSize=CompactSize;Size=CompactSize;Location=compactLocation;
  tray.Text="Nebim Asistanı · Nebim açık";
  if(restore&&posWasExpanded&&compact)Toggle();
 }
 void Busy(bool value){busy=value;foreach(var c in actions)c.Enabled=!value;command.Enabled=!value;procedures.Enabled=!value;files.Enabled=!value;reconnect.Enabled=!value;UpdateActions();}
 static Dictionary<string,object> Obj(object o){return o as Dictionary<string,object>;}
 static string Str(Dictionary<string,object> o,string key){return o!=null&&o.ContainsKey(key)&&o[key]!=null?Convert.ToString(o[key],CultureInfo.InvariantCulture):"";}
 static bool Bool(Dictionary<string,object> o,string key){try{return o!=null&&o.ContainsKey(key)&&o[key]!=null&&Convert.ToBoolean(o[key]);}catch{return false;}}
 static List<object> Arr(Dictionary<string,object> o,string key){var l=new List<object>();if(o!=null&&o.ContainsKey(key)&&o[key] is System.Collections.IEnumerable&&!(o[key] is string))foreach(object x in (System.Collections.IEnumerable)o[key])l.Add(x);return l;}
 StringContent Content(object payload){var c=new StringContent(json.Serialize(payload),Encoding.UTF8);c.Headers.ContentType=new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");return c;}
 async Task<Dictionary<string,object>> Request(object payload,string route="/api/status"){
  using(var response=payload==null?await http.GetAsync(Origin+route):await http.PostAsync(Origin+"/api/action",Content(payload))) {
   string raw=await response.Content.ReadAsStringAsync();var result=json.Deserialize<Dictionary<string,object>>(raw);
   if(!response.IsSuccessStatusCode)throw new Exception(Str(result,"error"));return result;
  }
 }
 // Panel (3032) isteği: MCP bağlantı dosyasındaki yerel anahtarla. Nebim'e değil yalnız panele.
 async Task<string> PanelPost(string route,object payload){
  var req=new HttpRequestMessage(HttpMethod.Post,PanelOrigin+route){Content=Content(payload)};
  try{
   var link=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(System.IO.Path.Combine(serviceRoot,"baglanti.json"),Encoding.UTF8));
   string token=Str(link,"token");
   if(Regex.IsMatch(token,"^[A-Za-z0-9_-]{43}$"))req.Headers.Authorization=new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer","nebim_mcp_"+token);
  }catch{}
  using(var res=await panelHttp.SendAsync(req)){
   string raw=await res.Content.ReadAsStringAsync();
   if((int)res.StatusCode==401||(int)res.StatusCode==403)throw new PanelAuthException("Panel bu işlem için oturum istiyor (HTTP "+(int)res.StatusCode+").");
   if(!res.IsSuccessStatusCode){string err="";try{err=Str(json.Deserialize<Dictionary<string,object>>(raw),"error");}catch{}throw new Exception("Panel yanıtı HTTP "+(int)res.StatusCode+(err.Length>0?": "+err:""));}
   return raw;
  }
 }
 static string ErrChain(Exception e){var sb=new StringBuilder();int n=0;while(e!=null&&n++<4){if(sb.Length>0)sb.Append(" → ");sb.Append(e.Message);e=e.InnerException;}return sb.ToString();}
 int statusRetries=0;
 async Task RefreshStatus(){if(!Sube.Mcp){identity.Text="✎ "+Sube.Ad+" şubesi · "+Sube.Kod;notice.Text="Asistan hazır. Karolar Nebim ekranlarını açar; Yenile rakamları okur.";return;}if(busy)return;Busy(true);try{Render(await Request(null));RenderChat(await Request(null,"/api/chat"));notice.Text="MCP yanıt verdi.";statusRetries=0;}catch(Exception e){identity.Text="Merkeze bağlantı bekleniyor…";notice.Text="MCP bağlantısı kurulamadı. 'Bağlan' düğmesine basın. "+ErrChain(e);if(statusRetries<8){statusRetries++;var rt=new System.Windows.Forms.Timer{Interval=3000};rt.Tick+=(s2,e2)=>{rt.Stop();rt.Dispose();var ignore=RefreshStatus();};rt.Start();}}finally{Busy(false);}}
 void RenderChat(Dictionary<string,object> value){chatInfo.Text=value.ContainsKey("configured")&&Convert.ToBoolean(value["configured"])?Str(value,"provider")+" · Yanıtlar öneridir; işlem yapmaz.":"Serbest sohbet bağlantısı henüz yapılandırılmadı. Kısa komutlar çalışır.";var lines=new StringBuilder();if(value.ContainsKey("messages"))foreach(object m in (System.Collections.IEnumerable)value["messages"]){var d=Obj(m);lines.AppendLine((Str(d,"role")=="user"?"Siz: ":"Asistan: ")+Str(d,"content"));lines.AppendLine();}chatHistory.Text=lines.ToString();chatHistory.SelectionStart=chatHistory.TextLength;chatHistory.ScrollToCaret();}
 async Task SendChat(){if(busy)return;Busy(true);chatInfo.Text="Yanıt bekleniyor…";try{await Request(new {action="chat",message=chatMessage.Text});chatMessage.Clear();RenderChat(await Request(null,"/api/chat"));}catch(Exception e){chatInfo.Text=e.Message;}finally{Busy(false);body.ScrollControlIntoView(chatHistory);}}
 async Task Send(object payload){if(busy)return;Busy(true);notice.Text="İşlem sürüyor…";try{await Request(payload);Render(await Request(null));notice.Text="İşlem sonucu alındı; güncel adım yukarıda.";}catch(Exception e){notice.Text="İşlem tamamlanamadı: "+e.Message;}finally{Busy(false);}}
 // ---------- Katalog, kullanım sayıları ve kendiliğinden yenileme ----------
 readonly Dictionary<string,DateTime> watched=new Dictionary<string,DateTime>();
 string[] WatchedFiles{get{return new[]{System.IO.Path.Combine(Araclar,"ekranlar.json"),System.IO.Path.Combine(Araclar,"ogrenilen-ekranlar.json"),System.IO.Path.Combine(Veri,"docs","NEBIM-KILAVUZ.md"),System.IO.Path.Combine(Veri,"data","nebim-rehber","kullanim.json"),StateFile("ekran-notlari.json")};}}
 bool WatchedChanged(){
  bool changed=false;
  foreach(string f in WatchedFiles){DateTime t=DateTime.MinValue;try{var fi=new System.IO.FileInfo(f);if(fi.Exists)t=fi.LastWriteTimeUtc;}catch{}DateTime old;if(!watched.TryGetValue(f,out old)||old!=t){watched[f]=t;changed=true;}}
  return changed;
 }
 void LoadCatalog(){
  WatchedChanged();
  var oldSelected=screens.SelectedItem as NebimScreen;
  catalog.Clear();
  try{
   var doc=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(System.IO.Path.Combine(Araclar,"ekranlar.json"),Encoding.UTF8));
   foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
    var d=Obj(o);var sc=new NebimScreen {Id=Str(d,"id"),Ad=Str(d,"ad"),Grup=Str(d,"grup"),Yol=Str(d,"yol"),Tur=Str(d,"tur"),Onay=Str(d,"onay")};
    var a=new List<string>();foreach(object x in Arr(d,"anahtar"))a.Add(Convert.ToString(x));sc.Anahtar=a.ToArray();
    var st=new List<string>();foreach(object x in Arr(d,"adimlar"))st.Add(Convert.ToString(x));sc.Adimlar=st.ToArray();
    if(sc.Id.Length>0&&sc.Ad.Length>0)catalog.Add(sc);
   }
  }catch(Exception e){helperState.Text="Ekran listesi okunamadı: "+e.Message;}
  try{
   var lf=new System.IO.FileInfo(System.IO.Path.Combine(Araclar,"ogrenilen-ekranlar.json"));
   if(lf.Exists){
    var known=new HashSet<string>();foreach(var c in catalog)known.Add(c.Ad);
    var ld=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(lf.FullName,Encoding.UTF8));
    foreach(object o in Arr(ld,"ekranlar")){
     var d=Obj(o);string ad=Str(d,"ad");if(ad.Length==0||known.Contains(ad))continue;known.Add(ad);
     catalog.Add(new NebimScreen {Id="ogr:"+ad,Ad=ad,Grup="Doğrulanmamış gözlem",Yol="(Nebim'de "+Str(d,"sayac")+" kez açıldığı görüldü; menü yolu kayıtlı değil)",Tur="bilinmiyor",
      Adimlar=new[]{"Bu ekranı asistan, sizin Nebim'de açmanızdan öğrendi. Henüz kılavuz açıklaması yok.","Kayıt oluşturabilir: bilgileri siz girin, Kaydet/Onayla'ya siz basın.","Kullanımını aşağıdaki 'Bu ekran için notum' alanına yazıp kılavuza ekleyebilirsiniz."}});
    }
   }
  }catch{}
  LoadUsage();LoadNotes();
  ApplyFilter();
  if(oldSelected!=null)foreach(var sc in catalog)if(sc.Id==oldSelected.Id){if(screens.Items.Contains(sc))screens.SelectedItem=sc;break;}
 }
 static readonly HashSet<string> OkStates=new HashSet<string>{"acildi","zaten-acik","acildi-uyari"};
 void LoadUsage(){
  usage.Clear();recent.Clear();
  try{
   string f=StateFile("ekran-gecmisi.txt");
   if(System.IO.File.Exists(f))foreach(string line in System.IO.File.ReadAllLines(f,Encoding.UTF8)){string[] p=line.Split('\t');if(p.Length>=3&&OkStates.Contains(p[2].Trim())){int c;usage.TryGetValue(p[1],out c);usage[p[1]]=c+1;recent.Remove(p[1]);recent.Add(p[1]);}}
  }catch{}
  try{
   var k=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(System.IO.Path.Combine(Veri,"data","nebim-rehber","kullanim.json"),Encoding.UTF8));
   var ek=Obj(k["ekranlar"]);
   if(ek!=null)foreach(var kv in ek){int s=0;try{s=Convert.ToInt32(Obj(kv.Value)["sayac"]);}catch{}if(s>0){int c;usage.TryGetValue(kv.Key,out c);usage[kv.Key]=c+s;}}
  }catch{}
 }
 static string[] TimeSuggestions(int hour){
  if(hour<12)return new[]{"magaza-sayim-fisi","irsaliye-onay-fis","transfer-irsaliye-kontrol","diger-magazaya-sevk"};
  if(hour>=18)return new[]{"magaza-hareket-ozeti","magaza-ciro-raporu","perakende-satislar-listesi"};
  return new[]{"urun-envanter-sorgula","urun-sorgula","merkeze-eksik-siparis"};
 }
 void ApplyFilter(){
  string selected=screens.SelectedItem is NebimScreen?((NebimScreen)screens.SelectedItem).Id:"";
  var tokens=QueryTokens(screenFilter.Text);
  bool empty=screenFilter.Text.Trim().Length==0;
  foreach(var sc in catalog)sc.Etiket="";
  var ranked=new List<KeyValuePair<double,NebimScreen>>();
  if(empty){
   // Boş arama: yalnız en son kullanılan 3 ekran. Diğerleri harf/rakam yazınca çıkar.
   int pos=0;
   for(int i=recent.Count-1;i>=0&&pos<3;i--)foreach(var sc in catalog)if(sc.Id==recent[i]){sc.Etiket="↺ ";ranked.Add(new KeyValuePair<double,NebimScreen>(-(pos++),sc));break;}
  } else {
   bool any=false;
   for(int pass=0;pass<2&&!any;pass++){
    foreach(var sc in catalog){
     int m;double s=Score(sc,screenFilter.Text,tokens,out m);
     bool ok=tokens.Count==0?Norm(sc.Ad).Contains(Norm(screenFilter.Text).Trim()):(pass==0?m==tokens.Count&&s>=0.6:s>=0.6);
     if(!ok)continue;
     int u;usage.TryGetValue(sc.Id,out u);
     ranked.Add(new KeyValuePair<double,NebimScreen>(s+Math.Min(u,20)*0.01,sc));any=true;
    }
   }
  }
  ranked.Sort((a,b)=>b.Key.CompareTo(a.Key));
  screens.BeginUpdate();screens.Items.Clear();
  foreach(var kv in ranked){screens.Items.Add(kv.Value);if(empty&&kv.Value.Id==selected)screens.SelectedItem=kv.Value;}
  screens.EndUpdate();
  if(screens.SelectedIndex<0&&screens.Items.Count>0)screens.SelectedIndex=0;
  if(screens.Items.Count==0)guide.Text=empty?"Henüz kullanılan ekran yok. Aramak için ekran adından birkaç harf yazın (ör. irsaliye, sayım, ciro).":"Listede '"+screenFilter.Text.Trim()+"' ile eşleşen ekran yok. Enter'a basarsanız Nebim'in kendi Ara listesinde aranır; açtığınız ekran öğrenilir.";
 }
 void SelectScreen(NebimScreen sc){
  if(!screens.Items.Contains(sc))screenFilter.Text="";
  if(!screens.Items.Contains(sc))screens.Items.Add(sc);
  screens.SelectedItem=sc;
 }
 // ---------- Rehberlik: adım listesi, odak takibi ----------
 readonly Dictionary<string,Dictionary<string,object>> notes=new Dictionary<string,Dictionary<string,object>>();
 void LoadNotes(){
  notes.Clear();
  try{var d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(StateFile("ekran-notlari.json"),Encoding.UTF8));foreach(var kv in d)if(Obj(kv.Value)!=null)notes[kv.Key]=Obj(kv.Value);}catch{}
 }
 string NoteOf(NebimScreen sc){Dictionary<string,object> n;return sc!=null&&notes.TryGetValue(sc.Id,out n)?Str(n,"not"):"";}
 void ShowGuide(NebimScreen sc){
  guideScreen=sc;fieldCycle=0;
  if(sc==null){guide.Text="";guideSteps.Items.Clear();screenNote.Text="";UpdateReadButton();return;}
  var b=new StringBuilder();
  b.AppendLine(sc.Ad);b.AppendLine("Katalog önerisi · canlı doğrulanmadı");b.AppendLine("Yol: Nebim V3 STORE → "+sc.Yol);
  b.AppendLine(sc.Tur=="kayit"?"Tür: KAYIT oluşturur — bilgileri siz girip kaydedersiniz.":sc.Tur=="okuma"?"Tür: yalnız bakılır, kayıt oluşturmaz.":"Tür: bilinmiyor (öğrenilen ekran) — veri girmeden önce ekranı inceleyin.");
  string n=NoteOf(sc);if(n.Length>0)b.AppendLine("Notunuz (doğrulanmadı): "+n);
  guide.Text=b.ToString();
  guideSteps.BeginUpdate();guideSteps.Items.Clear();
  int i=1;foreach(string s in sc.Adimlar){guideSteps.Items.Add(i+". "+s);i++;}
  if(n.Length>0)guideSteps.Items.Add("Not: "+n);
  guideSteps.EndUpdate();
  RestoreStepProgress();
  if(guideSteps.Items.Count>0&&guideSteps.SelectedIndex<0)SelectFirstUnchecked();
  screenNote.Text=n;guideFocus.Text="";
  UpdateReadButton();
 }
 void UpdateReadButton(){readReport.Enabled=!busy;readReport.Text=guideScreen!=null&&(guideScreen.Id=="magaza-hareket-ozeti"||guideScreen.Id=="magaza-ciro-raporu")?"Açık rapordan oku → panele aktar":"Açık rapordan oku → panele aktar (Ciro/Hareket Özeti)";}
 void SelectFirstUnchecked(){for(int i=0;i<guideSteps.Items.Count;i++)if(!guideSteps.GetItemChecked(i)){guideSteps.SelectedIndex=i;return;}}
 string ProgressFile{get{return StateFile("adim-ilerleme.json");}}
 void SaveStepProgress(){
  if(guideScreen==null)return;
  try{
   Dictionary<string,object> all=null;try{all=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(ProgressFile,Encoding.UTF8));}catch{}
   if(all==null)all=new Dictionary<string,object>();
   var done=new List<int>();for(int i=0;i<guideSteps.Items.Count;i++)if(guideSteps.GetItemChecked(i))done.Add(i);
   all[guideScreen.Id]=new Dictionary<string,object>{{"tarih",DateTime.Now.ToString("yyyy-MM-dd")},{"adimlar",done}};
   System.IO.File.WriteAllText(ProgressFile,json.Serialize(all),new UTF8Encoding(false));
  }catch{}
  if(guideSteps.SelectedIndex>=0&&guideSteps.GetItemChecked(guideSteps.SelectedIndex))SelectFirstUnchecked();
 }
 bool restoringSteps;
 void RestoreStepProgress(){
  restoringSteps=true;
  try{
   var all=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(ProgressFile,Encoding.UTF8));
   var p=Obj(all[guideScreen.Id]);
   if(Str(p,"tarih")!=DateTime.Now.ToString("yyyy-MM-dd"))return;
   foreach(object o in Arr(p,"adimlar")){int i=Convert.ToInt32(o);if(i<guideSteps.Items.Count)guideSteps.SetItemChecked(i,true);}
  }catch{}
  finally{restoringSteps=false;}
 }
 // Nabızdaki "odak" bilgisiyle (alan adı/üst bölüm) adımı eşleştirip sıradaki adımı seçer.
 string lastFocusKey="";
 void TrackFocus(){
  if(guideScreen==null||beat==null||guideSteps.Items.Count==0)return;
  if(Str(beat,"ekran")!=guideScreen.Ad){guideFocus.Text="";return;}
  var f=Obj(beat.ContainsKey("odak")?beat["odak"]:null);if(f==null)return;
  var cands=new List<string>();
  string alan=Str(f,"alan"),ad=Str(f,"ad");
  if(alan.Length>=3)cands.Add(alan);if(ad.Length>=3)cands.Add(ad);
  foreach(object o in Arr(f,"ust")){string u=Convert.ToString(o);if(u.Length>=3&&u!=guideScreen.Ad)cands.Add(u);}
  string key=string.Join("|",cands.ToArray());if(key==lastFocusKey)return;lastFocusKey=key;
  int hit=-1;string hitName="";
  foreach(string c in cands){string nc=Norm(c);for(int i=0;i<guideSteps.Items.Count&&hit<0;i++)if(Norm(Convert.ToString(guideSteps.Items[i])).Contains(nc)){hit=i;hitName=c;}if(hit>=0)break;}
  if(hit>=0){
   for(int i=0;i<hit;i++)if(!guideSteps.GetItemChecked(i))guideSteps.SetItemChecked(i,true);
   guideSteps.SelectedIndex=hit;
   guideFocus.Text="Nebim'de şu an: "+hitName+" → "+(hit+1)+". adım";
  } else {
   SelectFirstUnchecked();
   guideFocus.Text=cands.Count>0?"Nebim'de şu an: "+cands[0]:"";
  }
 }
 // ---------- Alan gösterici ----------
 async Task ShowField(){
  if(busy)return;
  string text=guideSteps.SelectedItem==null?"":Convert.ToString(guideSteps.SelectedItem);
  string[] names=Quoted(text);
  string alan;
  if(names.Length>0){alan=names[fieldCycle%names.Length];fieldCycle++;}
  else{keepOpen=true;try{alan=Ask("Alanı göster","Nebim'de hangi alanı göstereyim? (ör. Çalıştır, Başlangıç Tarihi)","");}finally{keepOpen=false;}}
  if(string.IsNullOrEmpty(alan))return;
  if(!await EnsureHelper())return;
  Busy(true);
  try{
   var r=await HelperCall(new Dictionary<string,object>{{"islem","goster"},{"alan",alan}},"'"+alan+"' gösteriliyor");
   notice.Text=(Bool(r,"ok")?"✔ ":"✖ ")+Str(r,"mesaj");
  }finally{Busy(false);}
 }
 string Ask(string title,string label,string def){
  using(var f=new Form{Text=title,FormBorderStyle=FormBorderStyle.FixedDialog,StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false,ClientSize=new Size(360,120),TopMost=true,Font=Font}){
   var l=new Label{Text=label,Left=10,Top=8,Width=340,Height=36};var t=new TextBox{Text=def,Left=10,Top=46,Width=340};
   var ok=new Button{Text="Tamam",DialogResult=DialogResult.OK,Left=190,Top=80,Width=75};var no=new Button{Text="Vazgeç",DialogResult=DialogResult.Cancel,Left=275,Top=80,Width=75};
   f.Controls.AddRange(new Control[]{l,t,ok,no});f.AcceptButton=ok;f.CancelButton=no;
   return f.ShowDialog(this)==DialogResult.OK?t.Text.Trim():null;
  }
 }
 // ---------- Uyarı açıklayıcı ----------
 class ErrorEntry{public string[] Anahtar;public string Baslik,Aciklama,Yapilacak;}
 readonly List<ErrorEntry> errorDict=new List<ErrorEntry>();
 DateTime errorStamp=DateTime.MinValue;string lastWarning="";
 void LoadErrors(){
  try{
   var f=new System.IO.FileInfo(System.IO.Path.Combine(Araclar,"hata-sozlugu.json"));
   if(!f.Exists||f.LastWriteTimeUtc==errorStamp)return;errorStamp=f.LastWriteTimeUtc;
   errorDict.Clear();
   var d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(f.FullName,Encoding.UTF8));
   foreach(object o in Arr(d,"hatalar")){var e=Obj(o);var a=new List<string>();foreach(object x in Arr(e,"anahtar"))a.Add(Norm(Convert.ToString(x)).Trim());errorDict.Add(new ErrorEntry{Anahtar=a.ToArray(),Baslik=Str(e,"baslik"),Aciklama=Str(e,"aciklama"),Yapilacak=Str(e,"yapilacak")});}
  }catch{}
 }
 ErrorEntry Explain(string text){
  string n=Norm(text);ErrorEntry best=null;int bestLen=0;
  foreach(var e in errorDict)foreach(string a in e.Anahtar)if(a.Length>0&&n.Contains(a)&&a.Length>bestLen){best=e;bestLen=a.Length;}
  return best;
 }
 void CheckWarning(){
  var w=Obj(beat!=null&&beat.ContainsKey("uyari")?beat["uyari"]:null);
  if(w==null){if(lastWarning.Length>0){lastWarning="";warn.Visible=false;}return;}
  string baslik=Str(w,"baslik"),metin=Str(w,"metin");
  string key=baslik+"|"+metin;if(key==lastWarning)return;
  if(metin.Length==0&&lastWarning.Length==0&&(DateTime.Now-warnFirstSeen).TotalSeconds>4){warnFirstSeen=DateTime.Now;}
  if(metin.Length==0&&(DateTime.Now-warnFirstSeen).TotalSeconds<3)return; // metin birkaç saniye içinde okunabilir; bekle
  lastWarning=key;
  string all=(baslik+" "+metin).Trim();
  var e=Explain(all);
  string msg;
  if(e!=null){
   msg="⚠ Nebim uyarısı: "+(metin.Length>0?metin:baslik)+"\n→ "+e.Baslik+": "+e.Aciklama+"\nNe yapmalı: "+e.Yapilacak;
   tray.ShowBalloonTip(9000,"Nebim: "+e.Baslik,e.Aciklama+" "+e.Yapilacak,ToolTipIcon.Info);
  } else {
   msg="⚠ Nebim uyarısı: "+(all.Length>0?all:"(metin okunamadı)")+"\nBu uyarıyı henüz tanımıyorum; kaydettim. Mesajı okuyup uygun düğmeye siz basın.";
   if(all.Length>0)RecordUnknownWarning(baslik,metin);
   tray.ShowBalloonTip(7000,"Nebim uyarısı",all.Length>0?all:"Nebim bir soru/uyarı gösteriyor.",ToolTipIcon.Warning);
  }
  notice.Text=msg;warn.Text=msg;warn.Visible=true;
 }
 DateTime warnFirstSeen=DateTime.MinValue;
 void RecordUnknownWarning(string baslik,string metin){
  try{
   string f=System.IO.Path.Combine(Araclar,"hata-bilinmeyen.json");
   Dictionary<string,object> d=null;try{d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(f,Encoding.UTF8));}catch{}
   var list=d==null?new List<object>():Arr(d,"uyarilar");
   foreach(object o in list){var x=Obj(o);if(Str(x,"metin")==metin&&Str(x,"baslik")==baslik){x["sayac"]=Convert.ToInt32(x.ContainsKey("sayac")?x["sayac"]:1)+1;x["son"]=DateTime.Now.ToString("s");System.IO.File.WriteAllText(f,json.Serialize(new Dictionary<string,object>{{"not","Asistanın tanımadığı Nebim uyarıları. Açıklaması yazılanlar hata-sozlugu.json'a eklenmeli."},{"uyarilar",list}}),new UTF8Encoding(false));return;}}
   list.Add(new Dictionary<string,object>{{"zaman",DateTime.Now.ToString("s")},{"son",DateTime.Now.ToString("s")},{"ekran",Str(beat,"ekran")},{"baslik",baslik},{"metin",metin},{"sayac",1}});
   if(list.Count>200)list.RemoveAt(0);
   System.IO.File.WriteAllText(f,json.Serialize(new Dictionary<string,object>{{"not","Asistanın tanımadığı Nebim uyarıları. Açıklaması yazılanlar hata-sozlugu.json'a eklenmeli."},{"uyarilar",list}}),new UTF8Encoding(false));
  }catch{}
 }
 // ---------- Sunucu yardımcısı nabzı ----------
 // Sunucu saati Lenovo'dan farklı olabildiği için dosya zamanını "şimdi" ile kıyaslamıyoruz; dosyanın DEĞİŞTİĞİNİ görmek yeterli.
 DateTime beatStamp=DateTime.MinValue,beatSeen=DateTime.MinValue;
 Dictionary<string,object> beat;bool beatAlive;
 void ReadBeat(){
  try{
   var f=new System.IO.FileInfo(System.IO.Path.Combine(Araclar,"yardimci-durum.json"));
   if(!f.Exists){beatAlive=false;beat=null;return;}
   if(f.LastWriteTimeUtc!=beatStamp){
    beatStamp=f.LastWriteTimeUtc;beatSeen=DateTime.Now;
    try{beat=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(f.FullName,Encoding.UTF8));}catch{}
   }
   beatAlive=beatSeen!=DateTime.MinValue&&(DateTime.Now-beatSeen).TotalSeconds<=15;
  }catch{beatAlive=false;}
 }
 bool HelperAlive(out bool storeOpen){ReadBeat();storeOpen=beatAlive&&Bool(beat,"store");return beatAlive;}
 void ApplyBeat(){
  if(!beatAlive)return;
  bool pos=Bool(beat,"pos");
  if(pos&&!posMode&&Visible&&!busy)EnterPos();else if(!pos&&posMode)ExitPos(true);
  try{CheckWarning();}catch{}
  try{if(!compact)TrackFocus();}catch{}
 }
 void UpdateLight(){
  bool mcp=service!=null&&!service.HasExited||ExternalServiceRunningCached();
  lightColor=mcp?Color.FromArgb(31,87,153):Color.Gray;light.Invalidate();
  reconnect.Text=mcp?"MCP açık":"Bağlan";
  hints.SetToolTip(reconnect,"MCP hizmet durumu. Raporun güncel olduğunu göstermez; basınca bağlantıyı yeniden kontrol eder.");
 }
 DateTime mcpCheck=DateTime.MinValue;bool mcpCached;
 bool ExternalServiceRunningCached(){if((DateTime.Now-mcpCheck).TotalSeconds>=10){mcpCheck=DateTime.Now;mcpCached=ExternalServiceRunning();}return mcpCached;}
 async Task<bool> ProbeHelper(){
  for(int i=0;i<8;i++){ReadBeat();if(beatAlive&&(DateTime.Now-beatSeen).TotalSeconds<8)return true;await Task.Delay(1000);}
  ReadBeat();return beatAlive;
 }
 void UpdateHelperState(){
  if(catalog.Count==0||!busy&&!screenFilter.Focused&&WatchedChanged())LoadCatalog();
 }
 // Güncelleme isteği: state\kurulum-istegi.txt bırakılırsa kurulum betiği gizli pencerede çalıştırılır (derler, test eder, yedekler).
 void CheckInstallRequest(){
  try{
   string f=StateFile("kurulum-istegi.txt");if(!System.IO.File.Exists(f)||busy)return;
   System.IO.File.Delete(f);
   string ps=System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"nebim-ekran-ac-kur.ps1");
   if(!System.IO.File.Exists(ps))return;
   var psi=new System.Diagnostics.ProcessStartInfo("powershell.exe","-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \""+ps+"\""){UseShellExecute=false,CreateNoWindow=true,WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory};
   System.Diagnostics.Process.Start(psi);
   tray.ShowBalloonTip(4000,"Nebim Asistanı","Güncelleme kuruluyor; asistan birkaç saniye kapanıp açılacak.",ToolTipIcon.Info);
  }catch{}
 }
 void OpenScreenDrawer(){
  foreach(var d in drawers){d.Visible=d==screenDrawer;((Button)d.Tag).Invalidate();}
  ResizeRows();
 }
 void FocusRemote(){
  foreach(string name in new[]{"mstsc","msrdc"}){
   System.Diagnostics.Process[] list;try{list=System.Diagnostics.Process.GetProcessesByName(name);}catch{continue;}
   foreach(var p in list){
    try{if(p.MainWindowHandle!=IntPtr.Zero&&IsRemoteTitle(p.MainWindowTitle)){if(IsIconic(p.MainWindowHandle))ShowWindow(p.MainWindowHandle,9);SetForegroundWindow(p.MainWindowHandle);return;}}
    catch{}finally{p.Dispose();}
   }
  }
 }
 // Sunucu yardımcısına istek gönderir, sonucu bekler (en fazla 20 sn). Busy durumu çağırana aittir.
 async Task<Dictionary<string,object>> HelperCall(Dictionary<string,object> payload,string label,int seconds=20){
  string q=System.IO.Path.Combine(Araclar,"kuyruk");
  string id=DateTime.Now.ToString("yyyyMMddHHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6);
  string req=System.IO.Path.Combine(q,"istek-"+id+".json"),res=System.IO.Path.Combine(q,"sonuc-"+id+".json");
  payload["id"]=id;payload["zaman"]=DateTime.Now.ToString("s");
  try{
   System.IO.Directory.CreateDirectory(q);
   string tmp=System.IO.Path.Combine(q,"yaz-"+id+".tmp");
   System.IO.File.WriteAllText(tmp,json.Serialize(payload),new UTF8Encoding(false));
   System.IO.File.Move(tmp,req);
   tray.ShowBalloonTip(3000,"Nebim",label+" — birkaç saniye fareye/klavyeye dokunmayın.",ToolTipIcon.Info);
   FocusRemote();
   for(int i=0;i<seconds*2;i++){
    await Task.Delay(500);
    if(!System.IO.File.Exists(res))continue;
    Dictionary<string,object> r=null;
    for(int k=0;k<6&&r==null;k++){await Task.Delay(200);try{r=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(res,Encoding.UTF8));}catch{r=null;}}
    if(r==null)continue;
    try{System.IO.File.Delete(res);}catch{}
    return r;
   }
   try{if(System.IO.File.Exists(req))System.IO.File.Delete(req);}catch{}
   return new Dictionary<string,object>{{"ok",false},{"durum","zaman-asimi"},{"mesaj","Sunucu yardımcısı "+seconds+" saniyede yanıt vermedi; istek iptal edildi. Uzak masaüstü bağlı mı?"}};
  }catch(Exception e){
   try{if(System.IO.File.Exists(req))System.IO.File.Delete(req);}catch{}
   return new Dictionary<string,object>{{"ok",false},{"durum","hata"},{"mesaj","İstek gönderilemedi: "+e.Message}};
  }
 }
 async Task<bool> EnsureHelper(){
  notice.Text="Sunucu yardımcısı kontrol ediliyor…";
  if(await ProbeHelper())return true;
  UpdateHelperState();notice.Text="Sunucu yardımcısı çalışmıyor. 'Bağlan'a basın; açılmazsa uzak masaüstünde \\\\tsclient\\N\\araclar\\NebimYardimci.exe'yi bir kez açın.";return false;
 }
 // ---------- Yeniden bağlan ----------
 async Task Reconnect(){StartService();LoadCatalog();await RefreshStatus();}
 async Task OpenSelected(){
  var sc=screens.SelectedItem as NebimScreen;
  if(sc==null){notice.Text="Önce açılacak ekranı seçin.";return;}
  if(busy)return;
  if(!string.IsNullOrEmpty(sc.Onay)){keepOpen=true;bool yes;try{yes=MessageBox.Show(this,sc.Onay,sc.Ad,MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes;}finally{keepOpen=false;}if(!yes){notice.Text="Açılmadı.";return;}}
  if(!await EnsureHelper())return;
  Busy(true);bool opened=false;
  try{
   notice.Text="Nebim'de '"+sc.Ad+"' açılıyor… Birkaç saniye fareye ve klavyeye dokunmayın.";
   var r=await HelperCall(new Dictionary<string,object>{{"islem","ac"},{"ekran",sc.Id},{"ad",sc.Ad}},sc.Ad+" açılıyor",45); // 22.10: çok pencere açıkken yardımcı 20 sn'yi aşabiliyor
   bool ok=Bool(r,"ok");
   string msg=Str(r,"mesaj");
   notice.Text=(ok?"✔ ":"✖ ")+sc.Ad+": "+msg;
   tray.ShowBalloonTip(5000,ok?"Nebim ekranı açıldı":"Ekran açılamadı",sc.Ad+": "+msg,ok?ToolTipIcon.Info:ToolTipIcon.Warning);
   History(sc,Str(r,"durum"));LoadUsage();
   if(ok){opened=true;ShowGuide(sc);if(!tileOpen)OpenScreenDrawer();if(!sc.Id.StartsWith("ogr:"))ReportUsage(sc);}
  }finally{Busy(false);}
  if(opened){if(screenFilter.Text.Trim().Length==0){var keep=screens.SelectedItem;ApplyFilter();if(keep!=null&&screens.Items.Contains(keep))screens.SelectedItem=keep;}await AutoShowField();}
 }
 // Ekran açılınca doldurulacak ilk alanı renkli çerçeveyle işaretler (yalnız gösterir; tıklamaz, yazmaz).
 async Task AutoShowField(){
  try{
   string text=guideSteps.SelectedItem==null?"":Convert.ToString(guideSteps.SelectedItem);
   string[] names=Quoted(text);
   if(names.Length==0)return;
   fieldCycle=1;
   Busy(true);
   try{
    var r=await HelperCall(new Dictionary<string,object>{{"islem","goster"},{"alan",names[0]}},"'"+names[0]+"' işaretleniyor");
    if(Bool(r,"ok"))notice.Text+="  ▸ İlk alan işaretlendi: "+names[0];
   }finally{Busy(false);}
  }catch{}
 }
 async void ReportUsage(NebimScreen sc){try{await PanelPost("/api/nebim/rehber/kullanim",new Dictionary<string,object>{{"ekran",sc.Id},{"ad",sc.Ad},{"kaynak","ajan"}});}catch{}}
 // Listede olmayan istek: Nebim'in Ara kutusunda arat, sonuç listesini kullanıcıya bırak (hiçbir ekran açmaz).
 async Task SearchInNebim(string text){
  string t=(text??"").Trim();
  if(t.Length<2||t.Length>60){notice.Text="Aranacak metin 2–60 karakter olmalı.";return;}
  if(!await EnsureHelper())return;
  Busy(true);
  try{
   notice.Text="Nebim'in Ara kutusunda '"+t+"' aranıyor…";
   var r=await HelperCall(new Dictionary<string,object>{{"islem","ara"},{"metin",t}},"'"+t+"' aranıyor");
   notice.Text=(Bool(r,"ok")?"Arandı: ":"✖ ")+Str(r,"mesaj");
  }finally{Busy(false);}
 }
 void History(NebimScreen sc,string durum){
  try{System.IO.File.AppendAllText(StateFile("ekran-gecmisi.txt"),DateTime.Now.ToString("s")+"\t"+sc.Id+"\t"+durum+Environment.NewLine,new UTF8Encoding(false));}catch{}
  if(OkStates.Contains(durum)){int c;usage.TryGetValue(sc.Id,out c);usage[sc.Id]=c+1;}
 }
 string lastQuery="";
 string LearnedFile{get{return StateFile("ogrenilen-komutlar.txt");}}
 NebimScreen Learned(string query){return null;} // Doğrulanmamış eski eşleşmeler yönlendirme yapmaz.
 async Task LearnAndOpen(){notice.Text="Düzeltmeyi not olarak kaydedin. Doğrulanmadan arama eşleşmesi değiştirilmez.";await Task.FromResult(0);}
 async Task RunCommand(){
  if(busy)return;
  string pre=Intent(command.Text);
  if(pre!="durum"&&pre!="devam"&&pre!="geri"){
   if(catalog.Count==0)LoadCatalog();
   lastQuery=command.Text;
   var learned=Learned(command.Text);
   if(learned!=null){SelectScreen(learned);OpenScreenDrawer();await OpenSelected();return;}
   var m=Match(catalog,command.Text);
   if(m.Count==1){SelectScreen(m[0]);OpenScreenDrawer();await OpenSelected();return;}
   if(m.Count>1){
    screenFilter.Text=command.Text;if(screens.Items.Count==0)screenFilter.Text="";SelectScreen(m[0]);OpenScreenDrawer();
    var names=new List<string>();foreach(var x in m)names.Add(x.Ad);
    notice.Text="Birden çok ekran uyuyor: "+string.Join(" · ",names.ToArray())+". Listeden seçip katalog yolunu inceleyin.";
    return;
   }
  }
  if(pre!=""){await RunProcedureCommand();return;}
  if(command.Text.Trim().Length>=2)await SearchInNebim(command.Text);
  else notice.Text="Komut yazın: ekran adı (ör. sayım, ciro, merkeze iade) ya da devam/geri/durum.";
 }
 async Task RunProcedureCommand(){if(busy)return;string id=Intent(command.Text);if(id==""){notice.Text="Komut tanınmadı. Satış, stok, sayım, transfer, devam, geri veya durum yazın. Aktarım için ayrı doğrulama düğmelerini kullanın.";return;}if(id=="durum")await RefreshStatus();else if(id=="devam"||id=="geri")await Send(new {action="step",step=id});else await Send(new {action="start",id=id});}
 // ---------- Ekran notları ----------
 bool SaveScreenNote(bool forGuide){
  if(guideScreen==null){notice.Text="Önce listeden bir ekran seçin.";return false;}
  string text=screenNote.Text.Trim();
  if(forGuide&&text.Length<5){notice.Text="Kılavuza eklemek için en az birkaç kelimelik not yazın.";return false;}
  try{
   LoadNotes();
   if(text.Length==0)notes.Remove(guideScreen.Id);else notes[guideScreen.Id]=new Dictionary<string,object>{{"ad",guideScreen.Ad},{"not",text},{"zaman",DateTime.Now.ToString("s")}};
   var all=new Dictionary<string,object>();foreach(var kv in notes)all[kv.Key]=kv.Value;
   System.IO.File.WriteAllText(StateFile("ekran-notlari.json"),json.Serialize(all),new UTF8Encoding(false));
   notice.Text=text.Length==0?"Not silindi: "+guideScreen.Ad:"Not kaydedildi: "+guideScreen.Ad;
   var keep=guideScreen;WatchedChanged();ShowGuide(keep);
   return true;
  }catch(Exception e){notice.Text="Not kaydedilemedi: "+e.Message;return false;}
 }
 async Task AddNoteToGuide(){
  if(guideScreen==null)return;
  Busy(true);
  try{
   try{await PanelPost("/api/nebim/rehber/takilma",new Dictionary<string,object>{{"soru","Ekran notu: "+guideScreen.Ad},{"cevap",screenNote.Text.Trim()},{"kisi","Nebim Asistanı"},{"kilavuzaEkle",true}});}
   catch(PanelAuthException){DirectGuideNote("Ekran notu: "+guideScreen.Ad,screenNote.Text.Trim());}
   notice.Text="Not panel kılavuzuna eklendi (NEBIM-KILAVUZ.md · Takılmalar bölümü).";
  }catch(Exception e){notice.Text="Not kaydedildi ama kılavuza eklenemedi: "+e.Message;}
  finally{Busy(false);}
 }
 // ---------- Açık rapordan okuma ve panele aktarma ----------
 async Task ReadAndTransfer(){OpenDrawer(numbersDrawer);await Task.FromResult(0);} // Ekran okuma yerine ortak dosya akışı.

 static Dictionary<string,double> GuessTotals(List<object> rows,List<object> loose){
  var g=new Dictionary<string,double>();double kart=0;bool anyKart=false;double netSum=0,qtySum=0;int netRows=0;
  foreach(object o in rows){
   var row=Obj(o);var cells=new Dictionary<string,string>();var labels=new StringBuilder(Str(row,"satir")+" ");
   foreach(object c in Arr(row,"hucreler")){var cell=Obj(c);string k=Norm(Str(cell,"kolon")).Trim(),v=Str(cell,"deger");if(!cells.ContainsKey(k))cells[k]=v;if(double.IsNaN(ParseNumber(v)))labels.Append(v).Append(' ');}
   string label=Norm(labels.ToString());
   Func<string[],double> pick=(keys)=>{foreach(string key in keys)foreach(var kv in cells)if(kv.Key.Contains(key)){double d=ParseNumber(kv.Value);if(!double.IsNaN(d))return d;}return double.NaN;};
   if(label.Contains("devir")||label.Contains("bakiye"))continue;
   if(label.Contains("toplam")&&!label.Contains("nakit")&&!label.Contains("kart")){
    double ciro=pick(new[]{"net tutar","satis vd","net satis","tutar"});if(!double.IsNaN(ciro)&&(!g.ContainsKey("ciro")||label.Contains("genel")))g["ciro"]=ciro;
    double fis=pick(new[]{"fis sayisi","fatura sayisi","fis"});if(!double.IsNaN(fis)&&!g.ContainsKey("fis"))g["fis"]=fis;
    double adet=pick(new[]{"miktar","adet"});if(!double.IsNaN(adet)&&!g.ContainsKey("adet"))g["adet"]=adet;
   }
   if(!label.Contains("toplam")&&!label.Contains("nakit")&&!label.Contains("kart")){
    double net=pick(new[]{"net tutar"});if(!double.IsNaN(net)){netSum+=net;netRows++;}
    double q=pick(new[]{"miktar"});if(!double.IsNaN(q))qtySum+=q;
   }
   if(label.Contains("nakit")){double n=pick(new[]{"toplam","alinan odeme","tutar"});if(!double.IsNaN(n))g["nakit"]=n;}
   if(label.Contains("kredi kart")||(label.Contains("kart")&&!label.Contains("hediye"))){double k=pick(new[]{"toplam","alinan odeme","tutar"});if(!double.IsNaN(k)){kart+=k;anyKart=true;}}
  }
  if(anyKart)g["kart"]=kart;
  if(!g.ContainsKey("ciro")&&netRows>0)g["ciro"]=netSum;
  if(!g.ContainsKey("adet")&&netRows>0&&qtySum>0)g["adet"]=qtySum;
  foreach(object o in loose){
   var x=Obj(o);string n=Norm(Str(x,"ad"));double v=ParseNumber(Str(x,"deger"));if(double.IsNaN(v))v=ParseNumber(Str(x,"sonraki"));
   if(double.IsNaN(v))continue;
   if(!g.ContainsKey("ciro")&&(n.Contains("net tutar")||n.Contains("genel toplam")))g["ciro"]=v;
   if(!g.ContainsKey("nakit")&&n.Contains("nakit")&&!n.Contains("bakiye")&&!n.Contains("devir"))g["nakit"]=v;
  }
  return g;
 }
 class SalesEntry{public DateTime Tarih;public double Ciro,Nakit,Kart,Fis,Adet;}
 SalesEntry TransferDialog(string rapor,string raw,Dictionary<string,double> g){
  var tr=new CultureInfo("tr-TR");
  using(var f=new Form{Text="Panele aktar · "+rapor,FormBorderStyle=FormBorderStyle.FixedDialog,StartPosition=FormStartPosition.CenterScreen,MinimizeBox=false,MaximizeBox=false,ClientSize=new Size(440,470),TopMost=true,Font=Font}){
   var info=new Label{Left=10,Top=8,Width=420,Height=48,Text="Nebim'den okunan toplamlar aşağıda. Kontrol edip gerekirse düzeltin. 'Panele aktar' yalnız panele yazar; Nebim'e hiçbir şey yazılmaz."};
   var rawBox=new TextBox{Left=10,Top=58,Width=420,Height=120,Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Both,WordWrap=false,Text=raw.Length>0?raw:"(okunan satır yok)"};
   f.Controls.Add(info);f.Controls.Add(rawBox);
   var date=new DateTimePicker{Left=150,Top=188,Width=180,Format=DateTimePickerFormat.Short,Value=DateTime.Today};
   f.Controls.Add(new Label{Left=10,Top=191,Width=135,Text="Satış günü"});f.Controls.Add(date);
   string[] keys={"ciro","nakit","kart","fis","adet"};string[] labels={"Ciro (Net tutar, KDV dahil)","Nakit","Kredi kartı","Fiş sayısı","Satış adedi"};
   var boxes=new TextBox[keys.Length];
   for(int i=0;i<keys.Length;i++){
    int y=224+i*34;f.Controls.Add(new Label{Left=10,Top=y+3,Width=135,Text=labels[i]});
    double v;boxes[i]=new TextBox{Left=150,Top=y,Width=180,Text=g.TryGetValue(keys[i],out v)?v.ToString(i>=3?"0":"0.00",tr):""};f.Controls.Add(boxes[i]);
   }
   var warn=new Label{Left=10,Top=396,Width=420,Height=30,ForeColor=Color.FromArgb(160,60,0),Text="Nakit/kart boşsa raporda 'Ödemeler' sekmesine geçip yeniden okuyun (değerler birleştirilir). Gün içinde aktarılan ciro akşam yeniden aktarılabilir."};
   var ok=new Button{Text="Panele aktar",Left=230,Top=432,Width=110};var no=new Button{Text="Vazgeç",DialogResult=DialogResult.Cancel,Left=345,Top=432,Width=85};
   f.Controls.Add(warn);f.Controls.Add(ok);f.Controls.Add(no);f.CancelButton=no;
   SalesEntry result=null;
   ok.Click+=(s,e)=>{
    double ciro=ParseNumber(boxes[0].Text);
    if(double.IsNaN(ciro)||ciro<0){MessageBox.Show(f,"Ciro sayı olmalı (ör. 12345,67).","Panele aktar",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
    if(date.Value.Date>DateTime.Today){MessageBox.Show(f,"Gelecek tarihe aktarılamaz.","Panele aktar");return;}
    result=new SalesEntry{Tarih=date.Value.Date,Ciro=ciro,Nakit=ParseNumber(boxes[1].Text),Kart=ParseNumber(boxes[2].Text),Fis=ParseNumber(boxes[3].Text),Adet=ParseNumber(boxes[4].Text)};
    f.DialogResult=DialogResult.OK;f.Close();
   };
   return f.ShowDialog(this)==DialogResult.OK?result:null;
  }
 }
 // MCP hizmetinin beklediği biçim: satis-*.csv, sütunlar Mağaza Kodu;Tarih;Ciro;Nakit;Kart;Adet;Fiş (src/reader.mjs parseTable).
 string WriteSalesFile(SalesEntry s){
  var tr=new CultureInfo("tr-TR");
  Func<double,string> num=(v)=>double.IsNaN(v)?"":v.ToString("0.##",tr);
  string name="satis-ekran-"+s.Tarih.ToString("yyyyMMdd")+"-"+DateTime.Now.ToString("HHmmss")+".csv";
  string path=System.IO.Path.Combine(Gelen,name),tmp=path+".yaz";
  string text="Mağaza Kodu;Tarih;Ciro;Nakit;Kart;Adet;Fiş\r\n"+Sube.Kod+";"+s.Tarih.ToString("yyyy-MM-dd")+";"+num(s.Ciro)+";"+num(s.Nakit)+";"+num(s.Kart)+";"+num(s.Adet)+";"+num(s.Fis)+"\r\n";
  System.IO.File.WriteAllText(tmp,text,new UTF8Encoding(true));
  // MCP hizmeti 20 sn'den yeni dosyayı "kararlı değil" sayıp uyarı bildirimi gösteriyor; yazma bittiği için zamanı geriye al.
  System.IO.File.SetLastWriteTime(tmp,DateTime.Now.AddSeconds(-25));
  System.IO.File.Move(tmp,path);
  return path;
 }
 async Task<string> WaitImport(string file){
  string f=StateFile(System.IO.Path.Combine("dosya-okuma","otomatik-aktarim.json"));
  for(int i=0;i<45;i++){
   await Task.Delay(2000);
   try{
    var d=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(f,Encoding.UTF8));
    foreach(object o in Arr(d,"sonuclar")){
     var x=Obj(o);if(Str(x,"dosya")!=file)continue;
     if(x.ContainsKey("hata")){string h=Str(x,"hata");if(h.Contains("kararlı değil"))continue;return "✖ Panele aktarılamadı: "+h;}
     var s=Obj(x["sonuc"]);
     if(Bool(s,"atlandi"))return "✔ Aynı değerler daha önce aktarılmıştı; panel güncel.";
     return "✔ Panele aktarıldı: "+file+" ("+Str(s,"guncellenen")+" gün). Nebim'e hiçbir şey yazılmadı.";
    }
   }catch{}
  }
  return "Aktarım dosyası hazır ("+file+") ama MCP hizmeti 90 sn içinde sonuç yazmadı. 'Bağlan' ile hizmeti kontrol edin; dosya klasörde bekler.";
 }
 // ---------- Günlük kontrol listesi ----------
 readonly CheckedListBox checklist=new CheckedListBox();
 readonly Label checklistInfo=new Label();
 FlowLayoutPanel checklistDrawer;
 class CheckItem{public string Id,Metin,Ekran,Bolum,Is;public override string ToString(){return Bolum+": "+Metin+(Ekran.Length>0?"  ↗":"");}}
 readonly List<CheckItem> checkItems=new List<CheckItem>();
 string checklistDate="";bool loadingChecklist;
 string ChecklistFile{get{return StateFile("gunluk-kontrol-"+DateTime.Now.ToString("yyyyMMdd")+".json");}}
 void LoadChecklist(){
  loadingChecklist=true;
  try{
   checklistDate=DateTime.Now.ToString("yyyy-MM-dd");
   checkItems.Clear();
   string[,] liste={
    {"Açılış","j-1","a1","Kasa açılış parasını say",""},
    {"Açılış","j-1","a2","Merkezden gelen irsaliyeleri kontrol et","transfer-irsaliye-kontrol"},
    {"Açılış","j-1","a3","Gelen malı kabul et (irsaliye onayı)","irsaliye-onay-fis"},
    {"Açılış","j-1","a4","Fiyat değişikliklerine bak, etiketleri güncelle","fiyat-listesi"},
    {"Açılış","j-1","a5","Dünkü cirodan emin ol (Mağaza Ciro Raporu)","magaza-ciro-raporu"},
    {"Kapanış","j-4","k1","Günün cirosuna bak (Mağaza Hareket Özeti)","magaza-hareket-ozeti"},
    {"Kapanış","j-4","k2","Ciro, nakit ve kartı not et (Günlük rakamlar > Ekrandaki rakamları oku)","magaza-hareket-ozeti"},
    {"Kapanış","j-4","k3","Nakit ve kartı kasa ile karşılaştır",""},
    {"Kapanış","j-4","k4","Bekleyen transfer/iade kalmadığını kontrol et","transfer-irsaliye-kontrol"},
    {"Kapanış","j-4","k5","Kasa gün sonu mutabakatı",""}};
   for(int li=0;li<liste.GetLength(0);li++)checkItems.Add(new CheckItem{Bolum=liste[li,0],Is=liste[li,1],Id=liste[li,2],Metin=liste[li,3],Ekran=liste[li,4]});
   var done=new HashSet<string>();
   try{var s=json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(ChecklistFile,Encoding.UTF8));foreach(object o in Arr(s,"yapilan"))done.Add(Convert.ToString(o));}catch{}
   checklist.BeginUpdate();checklist.Items.Clear();
   foreach(var it in checkItems)checklist.Items.Add(it,done.Contains(it.Id));
   checklist.EndUpdate();
   UpdateChecklistInfo();
  }finally{loadingChecklist=false;}
 }
 Dictionary<string,object> ChecklistState(){try{return json.Deserialize<Dictionary<string,object>>(System.IO.File.ReadAllText(ChecklistFile,Encoding.UTF8));}catch{return new Dictionary<string,object>();}}
 void UpdateChecklistInfo(){
  var st=ChecklistState();var sent=new HashSet<string>();foreach(object o in Arr(st,"panele"))sent.Add(Convert.ToString(o));
  var parts=new List<string>();
  foreach(string bolum in Sections()){int total=0,ok=0;string isId="";for(int i=0;i<checkItems.Count;i++)if(checkItems[i].Bolum==bolum){total++;isId=checkItems[i].Is;if(checklist.GetItemChecked(i))ok++;}parts.Add(bolum+" "+ok+"/"+total+(ok==total&&total>0?" ✔":""));}
  checklistInfo.Text="Bugün ("+DateTime.Now.ToString("dd.MM.yyyy")+"): "+string.Join(" · ",parts.ToArray());
 }
 List<string> Sections(){var l=new List<string>();foreach(var it in checkItems)if(!l.Contains(it.Bolum))l.Add(it.Bolum);return l;}
 async void ChecklistChanged(){
  var st=ChecklistState();
  var done=new List<object>();for(int i=0;i<checkItems.Count;i++)if(checklist.GetItemChecked(i))done.Add(checkItems[i].Id);
  var sent=new List<object>(Arr(st,"panele"));
  st["tarih"]=checklistDate;st["yapilan"]=done;st["panele"]=sent;
  try{System.IO.File.WriteAllText(ChecklistFile,json.Serialize(st),new UTF8Encoding(false));}catch{}
  st["panele"]=sent;
  try{System.IO.File.WriteAllText(ChecklistFile,json.Serialize(st),new UTF8Encoding(false));}catch{}
  UpdateChecklistInfo();
 }
 async Task OpenChecklistScreen(){
  var it=checklist.SelectedItem as CheckItem;
  if(it==null){notice.Text="Önce listeden bir madde seçin.";return;}
  if(it.Ekran.Length==0){notice.Text="'"+it.Metin+"' maddesinin Nebim ekranı yok; yapınca işaretleyin.";return;}
  NebimScreen target=null;foreach(var sc in catalog)if(sc.Id==it.Ekran)target=sc;
  if(target==null){notice.Text="Ekran listede yok: "+it.Ekran;return;}
  SelectScreen(target);OpenScreenDrawer();await OpenSelected();
 }
 static string Para(object o){try{if(o==null)return "Okunamadı";return Convert.ToDouble(o,CultureInfo.InvariantCulture).ToString("N2",new CultureInfo("tr-TR"))+" TL";}catch{return "Okunamadı";}}
 static string ZamanMetni(string v){DateTime d;return DateTime.TryParse(v,CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal|DateTimeStyles.AssumeUniversal,out d)?d.ToLocalTime().ToString("dd.MM.yyyy HH:mm"):"Bilinmiyor";}
 string OnizlemeMetni(Dictionary<string,object> p){
  var sb=new StringBuilder();
  var tarihler=new List<string>();foreach(object t in Arr(p,"kaynakTarihleri"))tarihler.Add(Convert.ToString(t));
  sb.AppendLine("Kaynak dosya: "+(Str(p,"dosya")==""?"Bilinmiyor":Str(p,"dosya")));
  sb.AppendLine("Şube: "+(Str(p,"sube")==""?"Bilinmiyor":Str(p,"sube")));
  sb.AppendLine("Kaynak rapor tarihi: "+(tarihler.Count==0?"Bilinmiyor":string.Join(", ",tarihler.ToArray())));
  sb.AppendLine("Dosya zamanı: "+ZamanMetni(Str(p,"dosyaZamani")));
  sb.AppendLine("Aktarım zamanı: "+ZamanMetni(Str(p,"aktarimZamani")));
  var gunler=Arr(p,"gunler");int from=Math.Max(0,gunler.Count-7);
  for(int i=from;i<gunler.Count;i++){
   var r=Obj(gunler[i]);if(r==null)continue;
   if(Str(r,"kod")!="")sb.AppendLine("Ürün "+Str(r,"kod")+" · stok "+Str(r,"miktar"));
   else sb.AppendLine((Str(r,"tarih")==""?"Tarih okunamadı":Str(r,"tarih"))+" · Ciro "+Para(r.ContainsKey("ciro")?r["ciro"]:null)+" · Nakit "+Para(r.ContainsKey("nakit")?r["nakit"]:null)+" · Kart "+Para(r.ContainsKey("kart")?r["kart"]:null)+" · Adet "+(r.ContainsKey("adet")&&r["adet"]!=null?Convert.ToString(r["adet"],CultureInfo.InvariantCulture):"Okunamadı"));
  }
  if(gunler.Count>7)sb.AppendLine("Son 7 kayıt gösteriliyor; toplam "+gunler.Count+" kayıt.");
  return sb.ToString();
 }
 void RenderNumbers(Dictionary<string,object> status){
  var v=status.ContainsKey("veri")?Obj(status["veri"]):null;
  string d=Str(v,"durum");
  if(v==null||d==""){numbersInfo.Text="Son aktarımın kaynağı doğrulanamadı.";return;}
  if(d!="aktarim-kaydi-eslesti"){numbersInfo.Text=d=="aktarim-kaydi-yok"?"Aktarım kaydı bulunamadı.":d=="kaynak-degisti"?"Aktarımdan sonra kaynak dosya değişmiş; rakamlar doğrulanamadı.":"Son aktarımın kaynağı okunamadı.";return;}
  string uyari="";var gl=Arr(v,"gunler");
  if(gl.Count>0){var son=Obj(gl[gl.Count-1]);string st=son==null?"":Str(son,"tarih");string bugun=DateTime.Now.ToString("yyyy-MM-dd");
   if(st!=bugun)uyari="⚠ BUGÜNE (" + DateTime.Now.ToString("dd.MM.yyyy") + ") AİT AKTARIM YOK. Aşağıdaki rakamlar eski bir rapordan (" + (st==""?"tarih okunamadı":st) + "); bugünün satışı olarak kullanmayın.\n\n";}
  numbersInfo.Text=uyari+OnizlemeMetni(v)+"Bu bir anlık görüntüdür; sonraki satışları içerdiği doğrulanmadı.";
 }

 // Açık Nebim raporunun toplam satırlarını sunucu yardımcısıyla okur; panele/dosyaya yazmaz.
 async Task ReadNebimNumbers(){
  if(busy)return;
  if(!await EnsureHelper())return;
  Busy(true);
  try{
   var r=await HelperCall(new Dictionary<string,object>{{"islem","oku"}},"Rapor okunuyor");
   if(!Bool(r,"ok")){numbersInfo.Text="✖ "+Str(r,"mesaj");notice.Text=numbersInfo.Text;return;}
   var sb=new StringBuilder();
   sb.AppendLine("Kaynak: Nebim ekranı · "+Str(r,"rapor"));
   sb.AppendLine("Okunma: "+DateTime.Now.ToString("dd.MM.yyyy HH:mm")+" (ekranda görünen filtre/tarih geçerlidir)");
   sb.AppendLine();
   int n=0;
   foreach(object o in Arr(r,"satirlar")){
    var row=Obj(o);if(row==null)continue;if(++n>14){sb.AppendLine("… (devamı için raporun kendisine bakın)");break;}
    var parts=new List<string>();
    foreach(object c in Arr(row,"hucreler")){var cc=Obj(c);string k=Str(cc,"kolon"),v=Str(cc,"deger");if(v.Length==0)continue;parts.Add((k.Length>0?k+": ":"")+v);}
    sb.AppendLine(parts.Count>0?string.Join(" · ",parts.ToArray()):Str(row,"satir"));
   }
   if(n==0)foreach(object o in Arr(r,"ogeler")){var g=Obj(o);string v=Str(g,"deger");if(v.Length==0)v=Str(g,"sonraki");sb.AppendLine(Str(g,"ad")+(v.Length>0?": "+v:""));if(++n>14)break;}
   numbersInfo.Text=sb.ToString();
   notice.Text="✔ Rakamlar Nebim ekranından okundu; hiçbir yere yazılmadı.";
   keepOpen=true;try{MessageBox.Show(this,numbersInfo.Text+"\nNebim ekranından okundu; hiçbir yere yazılmadı.","Ciro (Nebim ekranı)",MessageBoxButtons.OK,MessageBoxIcon.Information);}finally{keepOpen=false;}
  }finally{Busy(false);}
 }
 async Task ConfirmTransfer(){
  if(busy||active==null||!active.ContainsKey("dogrulama")){notice.Text="Önce rapor dosyasını doğrulayın.";return;}
  var dg=Obj(active["dogrulama"]);var on=dg!=null&&dg.ContainsKey("onizleme")?Obj(dg["onizleme"]):null;
  if(on==null){notice.Text="Eski doğrulama kaydında rakam önizlemesi yok. Geri dönüp dosyayı yeniden doğrulayın.";return;}
  bool yes;keepOpen=true;try{yes=MessageBox.Show(this,OnizlemeMetni(on)+"\nBu rakamlar panele aktarılsın mı? (Nebim'e yazılmaz.)","Panele aktar",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes;}finally{keepOpen=false;}
  if(!yes){notice.Text="Aktarılmadı.";return;}
  await Send(new {action="transfer"});
 }
 void UpdateActions(){int n=active==null?-1:Convert.ToInt32(active["adim"]);string kind=Str(active,"prosedur");bool report=kind=="satis"||kind=="stok";
  next.Visible=active!=null&&n<Convert.ToInt32(active["toplam"])-1&&!(report&&n==2);
  files.Visible=verify.Visible=report&&n==2;transfer.Visible=report&&n==3&&active.ContainsKey("dogrulama");
 }
 void Render(Dictionary<string,object> status){
  var memory=Obj(status["hafiza"]);identity.Text=Str(memory,"sube")+" · "+Str(memory,"kullanici")+"\nYerel şube asistanı "+Surum;active=Obj(memory["aktif"]);
  resumeTask.Visible=false;
  if(stepDrawer!=null){((Button)stepDrawer.Tag).Visible=false;if(active==null)stepDrawer.Visible=false;}
  var connection=Obj(status["baglanti"]);identity.Text="✎ "+Sube.Ad+" · Merkeze bağlandı";
  string selected=procedures.SelectedItem==null?"":((Choice)procedures.SelectedItem).Id;
  procedures.Items.Clear();foreach(object p in (System.Collections.IEnumerable)status["prosedurler"]){var d=Obj(p);if(Str(d,"id")!="satis"&&Str(d,"id")!="stok")continue;var c=new Choice {Id=Str(d,"id"),Name=Str(d,"ad")};procedures.Items.Add(c);if(c.Id==selected)procedures.SelectedItem=c;}if(procedures.SelectedIndex<0&&procedures.Items.Count>0)procedures.SelectedIndex=0;
  string file=files.SelectedItem as string;files.Items.Clear();foreach(object f in (System.Collections.IEnumerable)Obj(status["raporlar"])["dosyalar"])files.Items.Add(f.ToString());if(file!=null&&files.Items.Contains(file))files.SelectedItem=file;else if(files.Items.Count>0)files.SelectedIndex=0;
  procInfo.Text=active==null?"Açık işlem yok. Listeden seçip başlatın.":"Yarım kalan: "+Str(active,"ad")+" · adım "+(Convert.ToInt32(active["adim"])+1)+"/"+Str(active,"toplam");
  if(active==null){step.Text="Bir işlem seçin veya kısa komut yazın. Yarım kalan işleminiz burada açılır.";foreach(object h in (System.Collections.IEnumerable)memory["gecmis"]){step.Text+="\nSon sonuç: "+Str(Obj(h),"prosedur")+" · "+Str(Obj(h),"durum");break;}}
  else {step.Text=Str(active,"ad")+" · "+(Convert.ToInt32(active["adim"])+1)+"/"+Str(active,"toplam")+"\n"+Str(active,"aciklama");if(active.ContainsKey("dogrulama"))step.Text+="\nDosya: "+Str(Obj(active["dogrulama"]),"dosya");}
  UpdateActions();
 }
 class Choice {public string Id,Name;public override string ToString(){return Name;}}
 class PanelAuthException:Exception{public PanelAuthException(string m):base(m){}}
 // Panel API'si MCP anahtarına yalnız Nebim aktarım yollarını açıyor. "Bugün yapıldı" işareti ve kılavuz notu için
 // panelin kendi dosyalarına, panelin yazdığı biçimde ve atomik olarak yazılır (panel her istekte dosyayı yeniden okur).
 static void AtomicWrite(string path,string text,bool bom){
  string tmp=path+"."+Guid.NewGuid().ToString("N").Substring(0,8)+".tmp";
  System.IO.File.WriteAllText(tmp,text,new UTF8Encoding(bom));
  if(System.IO.File.Exists(path))System.IO.File.Replace(tmp,path,null);else System.IO.File.Move(tmp,path);
 }
 void DirectTask(string isId,string tarih,bool done){
  string f=System.IO.Path.Combine(Veri,"data","sube","is-tamamlamalari.json");
  var list=new List<object>();
  try{var raw=json.Deserialize<object[]>(System.IO.File.ReadAllText(f,Encoding.UTF8));if(raw!=null)list.AddRange(raw);}catch(Exception e){if(System.IO.File.Exists(f))throw new Exception("Panel iş dosyası okunamadı: "+e.Message);}
  int idx=-1;for(int i=0;i<list.Count;i++){var x=Obj(list[i]);if(Str(x,"isId")==isId&&Str(x,"tarih")==tarih){idx=i;break;}}
  if(done&&idx<0)list.Add(new Dictionary<string,object>{{"isId",isId},{"tarih",tarih},{"kisi","Nebim Asistanı"},{"saat",DateTime.Now.ToString("HH:mm")}});
  else if(!done&&idx>=0)list.RemoveAt(idx);
  else return;
  if(list.Count>5000)list.RemoveRange(0,list.Count-5000);
  AtomicWrite(f,json.Serialize(list),false);
 }
 void DirectGuideNote(string soru,string cevap){
  string f=System.IO.Path.Combine(Veri,"docs","NEBIM-KILAVUZ.md");
  string m=System.IO.File.ReadAllText(f,Encoding.UTF8);
  const string A="<!-- TAKILMALAR:BASLA -->",B="<!-- TAKILMALAR:BITIS -->";
  int a=m.IndexOf(A,StringComparison.Ordinal),b=m.IndexOf(B,StringComparison.Ordinal);
  if(a<0||b<a)throw new Exception("Kılavuzda not bölümü bulunamadı.");
  string once=m.Substring(0,a+A.Length),blok=m.Substring(a+A.Length,b-a-A.Length),sonra=m.Substring(b);
  string icerik="\n### ❓ "+soru+"\n_"+DateTime.Now.ToString("d.MM.yyyy")+" · Nebim Asistanı_\n\n"+cevap+"\n";
  AtomicWrite(f,once+blok.TrimEnd('\n','\r')+"\n"+icerik+"\n"+sonra,false);
 }
}
