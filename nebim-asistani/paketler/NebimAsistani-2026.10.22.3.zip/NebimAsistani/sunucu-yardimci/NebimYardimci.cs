﻿// Nebim Yardımcı (sunucu tarafı) — Parfüm Mutfağı Mahmutbey — sürüm 3
// Görevi: Lenovo'daki Nebim Asistanı'ndan gelen istekleri Nebim V3 STORE'da yerine getirmek:
//  - "ac": ekranı sol üstteki "Ara…" kutusuyla açar ve başlıktan doğrular.
//  - "ara": Ara listesinde yalnız arar (hiçbir ekran açmaz).
//  - "goster": hedef alanın etrafına tıklamadan geçici renkli çerçeve çizer.
//  - "oku": açık Ciro / Hareket Özeti raporunun yalnız toplam satırlarını UIA ile okur.
// Ayrıca nabız dosyasına (yardimci-durum.json) STORE/POS durumu, açık ekran adı, odaktaki alanın ADI
// (değeri değil) ve açık uyarı penceresinin metnini yazar; Ctrl+Boşluk kısayolunu asistana iletir.
// KESİN SINIRLAR:
//  - Hiçbir veri alanına yazmaz; yalnız "Ara…" kutusuna katalogdaki ekran adını yazar.
//  - Kaydet / Onayla / Sil / Çalıştır / Tamam gibi hiçbir düğmeye basmaz.
//  - POS (kasa) penceresine dokunmaz; kasa ekranı öndeyse işlem yapmaz.
//  - Yalnız ekranlar.json katalogundaki (ve öğrenilen) ekranları açar.
//  - Başlarken bekleyen eski istekleri çalıştırmadan siler.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using System.Windows.Forms;

public class NebimYardimci : ApplicationContext {
 public const string Surum="4.2";
 static readonly string Root=@"\\tsclient\N\araclar";
 static string Kuyruk{get{return Path.Combine(Root,"kuyruk");}}
 static string Yerel{get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NebimYardimci");}}
 static string DurdurDosyasi{get{return Path.Combine(Root,"yardimci-durdur.txt");}}
 static readonly object logLock=new object();
 readonly NotifyIcon tray=new NotifyIcon();
 readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=500};
 readonly Control invoker=new Control();
 HotkeyWindow hotkey;
 volatile bool busy;
 DateTime lastBeat=DateTime.MinValue,lastMaint=DateTime.MinValue;
 string lastResult="Henüz istek gelmedi.";
 static volatile string lastScreen="";

 // ---------- Win32 ----------
 [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT{public int dx;public int dy;public uint mouseData;public uint dwFlags;public uint time;public IntPtr dwExtraInfo;}
 [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT{public ushort wVk;public ushort wScan;public uint dwFlags;public uint time;public IntPtr dwExtraInfo;}
 [StructLayout(LayoutKind.Explicit)] struct InputUnion{[FieldOffset(0)]public MOUSEINPUT mi;[FieldOffset(0)]public KEYBDINPUT ki;}
 [StructLayout(LayoutKind.Sequential)] struct INPUT{public uint type;public InputUnion u;}
 [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint n,INPUT[] inputs,int size);
 [DllImport("user32.dll")] static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint vk);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
 delegate bool EnumProc(IntPtr h,IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent,EnumProc cb,IntPtr l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder sb,int max);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder sb,int max);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 const uint KEYEVENTF_KEYUP=0x2,KEYEVENTF_UNICODE=0x4,MOUSEEVENTF_LEFTDOWN=0x2,MOUSEEVENTF_LEFTUP=0x4;
 const ushort VK_CONTROL=0x11,VK_A=0x41,VK_DOWN=0x28,VK_RETURN=0x0D;
 static int InputSize{get{return Marshal.SizeOf(typeof(INPUT));}}
 static void Key(ushort vk,bool up){var i=new INPUT{type=1};i.u.ki=new KEYBDINPUT{wVk=vk,dwFlags=up?KEYEVENTF_KEYUP:0};SendInput(1,new[]{i},InputSize);}
 static void Press(ushort vk){Key(vk,false);Thread.Sleep(30);Key(vk,true);Thread.Sleep(30);}
 static void TypeText(string s){
  foreach(char c in s){
   var d=new INPUT{type=1};d.u.ki=new KEYBDINPUT{wScan=c,dwFlags=KEYEVENTF_UNICODE};
   var u=new INPUT{type=1};u.u.ki=new KEYBDINPUT{wScan=c,dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP};
   SendInput(2,new[]{d,u},InputSize);Thread.Sleep(12);
  }
 }
 static void Mouse(uint flags){var i=new INPUT{type=0};i.u.mi=new MOUSEINPUT{dwFlags=flags};SendInput(1,new[]{i},InputSize);}
 static void DoubleClick(int x,int y){SetCursorPos(x,y);Thread.Sleep(60);for(int k=0;k<2;k++){Mouse(MOUSEEVENTF_LEFTDOWN);Thread.Sleep(25);Mouse(MOUSEEVENTF_LEFTUP);Thread.Sleep(70);}}
 static string ProcessNameOf(IntPtr h){try{uint pid;GetWindowThreadProcessId(h,out pid);return Process.GetProcessById((int)pid).ProcessName;}catch{return "";}}
 static bool PosInFront(){return ProcessNameOf(GetForegroundWindow()).Equals("NebimV3POS",StringComparison.OrdinalIgnoreCase);}

 // ---------- Başlangıç ----------
 [STAThread] public static int Main(string[] args){
  if(args.Length==1&&args[0]=="--self-test")return SelfTest();
  try{SetProcessDPIAware();}catch{}
  // Uzak masaüstü sürücüsünden (\\tsclient) elle başlatıldıysa: durdurma işaretini kaldır, izleyiciyi başlat ve çık.
  // İzleyici yardımcının yerel kopyasını çalıştırır; böylece Lenovo'daki dosya kilitlenmez ve güncelleme kendiliğinden olur.
  try{
   if(File.Exists(DurdurDosyasi)&&!RunningLocal()){File.Delete(DurdurDosyasi);Log("Durdurma işareti kaldırıldı (elle başlatıldı).");}
   if(!RunningLocal()&&File.Exists(Path.Combine(Root,"NebimYardimci-Baslat.cmd"))){
    UpdateStartup();
    if(StartWatcher("elle başlatma")){Log("Elle başlatıldı: izleyici yerel kopyayı başlatacak.");return 0;}
   }
  }catch(Exception e){Log("Başlatıcı hatası: "+e.Message);}
  bool created;
  using(var m=new Mutex(true,"Local\\NebimYardimciV1",out created)){
   if(!created){if(!RunningLocal())MessageBox.Show("Nebim Yardımcı zaten çalışıyor (saatin yanındaki simge).","Nebim Yardımcı");return 0;}
   Application.EnableVisualStyles();Application.Run(new NebimYardimci());
  }
  return 0;
 }
 static bool RunningLocal(){
  try{return Path.GetFullPath(Application.ExecutablePath).StartsWith(Path.GetFullPath(Yerel),StringComparison.OrdinalIgnoreCase);}catch{return false;}
 }
 static int SelfTest(){
  if(InputSize!=(IntPtr.Size==8?40:28))return 3;
  if(Norm("Mağaza Sayım Fişi")!="magaza sayim fisi")return 4;
  if(!IsTotalLike("Genel Toplam")||!IsTotalLike("Kredi Kartı (Garanti)")||IsTotalLike("Ahmet Yılmaz"))return 5;
  if(Bracket("[Başlangıç Tarihi]")!="Başlangıç Tarihi"||Bracket("Bugün")!="")return 6;
  // 22.10: POS okuyucu — gerçek POS dökümünden kesit (başlık satırı + 1 px kaymış Genel Toplam satırı)
  Func<string,int,int,int,object> T=(t,x,yy,w)=>new Dictionary<string,object>{{"t",t},{"x",x},{"y",yy},{"w",w}};
  var pm=new List<object>{T("Satış",151,291,736),
   T("Süreç Açıklaması",151,310,184),T("İade",336,310,60),T("Miktar",396,310,70),T("Tutar (VD)",466,310,88),T("Net Tutar",796,310,92),
   T("Genel Toplam",151,341,244),T("9,00",396,342,70),T("10.500,00",463,341,88),T("9.900,00",796,342,92),
   T("Önceki Günden Devir",151,467,627),T("210.494,11",778,467,110)};
  var pr=PosRows(pm);
  if(pr.Count!=1)return 7;
  var hc=new Dictionary<string,string>();foreach(object o in (List<object>)((Dictionary<string,object>)pr[0])["hucreler"]){var d=(Dictionary<string,object>)o;hc[Convert.ToString(d["kolon"])]=Convert.ToString(d["deger"]);}
  string v1,v2,v3;
  if(!hc.TryGetValue("Miktar",out v1)||v1!="9,00"||!hc.TryGetValue("Net Tutar",out v2)||v2!="9.900,00"||!hc.TryGetValue("Tutar (VD)",out v3)||v3!="10.500,00")return 8;
  return 0;
 }
 public static string Norm(string s){
  var sb=new StringBuilder();
  foreach(char ch in (s??"").Trim()){
   char c=ch;
   switch(c){case 'İ':case 'I':case 'ı':c='i';break;case 'Ş':case 'ş':c='s';break;case 'Ğ':case 'ğ':c='g';break;case 'Ü':case 'ü':c='u';break;case 'Ö':case 'ö':c='o';break;case 'Ç':case 'ç':c='c';break;default:c=char.ToLowerInvariant(c);break;}
   sb.Append(c);
  }
  return sb.ToString();
 }
 static string Bracket(string n){n=(n??"").Trim();return n.Length>2&&n[0]=='['&&n[n.Length-1]==']'?n.Substring(1,n.Length-2):"";}
 public NebimYardimci(){
  invoker.CreateControl();var forceHandle=invoker.Handle;
  tray.Icon=SystemIcons.Information;tray.Text="Nebim Yardımcı "+Surum;tray.Visible=true;
  var menu=new ContextMenuStrip();
  menu.Items.Add("Durum",null,(s,e)=>tray.ShowBalloonTip(6000,"Nebim Yardımcı "+Surum,lastResult,ToolTipIcon.Info));
  menu.Items.Add("Yeniden başlat",null,(s,e)=>{Log("Tepsiden yeniden başlatıldı.");Quit();});
  menu.Items.Add("Çıkış (kendiliğinden açılmaz)",null,(s,e)=>{try{File.WriteAllText(DurdurDosyasi,DateTime.Now.ToString("s")+" tepsiden çıkış",new UTF8Encoding(false));}catch{}Log("Tepsiden çıkış: izleyici yeniden başlatmayacak.");Quit();});
  tray.ContextMenuStrip=menu;
  try{Directory.CreateDirectory(Kuyruk);foreach(string f in Directory.GetFiles(Kuyruk,"istek-*.json")){try{File.Delete(f);Log("Eski istek çalıştırılmadan silindi: "+Path.GetFileName(f));}catch{}}}
  catch(Exception e){Log("Kuyruk klasörü açılamadı: "+e.Message);}
  Log("Başladı. Sürüm "+Surum+", kullanıcı "+Environment.UserName+(RunningLocal()?" (yerel kopya, izleyicili)":" (uzak sürücüden)"));
  if(!File.Exists(Path.Combine(Root,"kisayol-kapali.txt"))){
   hotkey=new HotkeyWindow();
   hotkey.Pressed+=()=>{try{File.WriteAllText(Path.Combine(Root,"kisayol.txt"),DateTime.Now.Ticks.ToString(),new UTF8Encoding(false));}catch{}};
   if(!RegisterHotKey(hotkey.Handle,1,0x0002|0x4000,0x20)){Log("Ctrl+Boşluk kısayolu alınamadı (başka program kullanıyor olabilir).");hotkey.DestroyHandle();hotkey=null;}
  }
  UpdateStartup();
  timer.Tick+=(s,e)=>Tick();timer.Start();
  tray.ShowBalloonTip(4000,"Nebim Yardımcı "+Surum+" hazır","Ekran açma, alan gösterme ve rapor toplamı okuma istekleri bekleniyor. Veri girmez, kaydetmez.",ToolTipIcon.Info);
 }
 void Quit(){timer.Stop();if(hotkey!=null){try{UnregisterHotKey(hotkey.Handle,1);hotkey.DestroyHandle();}catch{}}tray.Visible=false;ExitThread();}
 class HotkeyWindow:NativeWindow{
  public event Action Pressed;
  public HotkeyWindow(){CreateHandle(new CreateParams());}
  protected override void WndProc(ref Message m){if(m.Msg==0x0312&&Pressed!=null)Pressed();base.WndProc(ref m);}
 }
 static void Log(string line){
  lock(logLock){
   try{
    string p=Path.Combine(Root,"yardimci-log.txt");
    var fi=new FileInfo(p);if(fi.Exists&&fi.Length>400000){File.Delete(p);}
    File.AppendAllText(p,DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+line+Environment.NewLine,new UTF8Encoding(false));
   }catch{}
  }
 }
 // ---------- İzleyici / güncelleme ----------
 static bool StartWatcher(string why){
  try{
   string cmd=Path.Combine(Root,"NebimYardimci-Baslat.cmd");if(!File.Exists(cmd))return false;
   Directory.CreateDirectory(Yerel);
   string local=Path.Combine(Yerel,"NebimYardimci-Baslat.cmd");File.Copy(cmd,local,true);
   var psi=new ProcessStartInfo("cmd.exe","/c \""+local+"\"") {UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=Yerel};
   Process.Start(psi);Log("İzleyici başlatıldı ("+why+").");return true;
  }catch(Exception e){Log("İzleyici başlatılamadı: "+e.Message);return false;}
 }
 // Windows açılışındaki başlatıcıyı güncel sürümle değiştirir (yalnız bu kullanıcının Başlangıç klasöründe, aynı ad).
 static void UpdateStartup(){
  try{
   string src=Path.Combine(Root,"NebimYardimci-Baslat.cmd");if(!File.Exists(src))return;
   string text=File.ReadAllText(src,Encoding.Default);
   string startup=Environment.GetFolderPath(Environment.SpecialFolder.Startup);
   string target=Path.Combine(startup,"NebimYardimci-Baslat.cmd");
   foreach(string f in Directory.GetFiles(startup,"*.cmd")){try{if(File.ReadAllText(f,Encoding.Default).IndexOf("NebimYardimci",StringComparison.OrdinalIgnoreCase)>=0){target=f;break;}}catch{}}
   if(File.Exists(target)&&File.ReadAllText(target,Encoding.Default)==text)return;
   File.WriteAllText(target,text,Encoding.Default);Log("Açılış başlatıcısı güncellendi: "+target);
  }catch(Exception e){Log("Açılış başlatıcısı güncellenemedi: "+e.Message);}
 }
 void Maintenance(){
  if(!RunningLocal())return;
  try{
   var share=new FileInfo(Path.Combine(Root,"NebimYardimci.exe"));var me=new FileInfo(Application.ExecutablePath);
   if(share.Exists&&!busy&&(share.Length!=me.Length||share.LastWriteTimeUtc>me.LastWriteTimeUtc.AddSeconds(2))){Log("Yeni sürüm bulundu; izleyici güncel kopyayla yeniden başlatacak.");Quit();return;}
  }catch{}
  try{
   var beat=new FileInfo(Path.Combine(Yerel,"izleyici-nabiz.txt"));
   if(!beat.Exists||(DateTime.Now-beat.LastWriteTime).TotalSeconds>90)StartWatcher("izleyici nabzı yok");
  }catch{}
 }
 static bool StoreOpen(){return FindStore()!=null;}
 void Tick(){
  if((DateTime.Now-lastMaint).TotalSeconds>=15){lastMaint=DateTime.Now;Maintenance();}
  if((DateTime.Now-lastBeat).TotalSeconds>=1.5){
   lastBeat=DateTime.Now;
   bool store=false,pos=false;AutomationElement mainNow=null;try{mainNow=FindStore();store=mainNow!=null;}catch{}
   try{pos=PosInFront();}catch{}
   var beat=new Dictionary<string,object>{{"surum",Surum},{"zaman",DateTime.Now.ToString("s")},{"store",store},{"mesgul",busy},{"pos",pos},{"kullanici",Environment.UserName},{"kisayol",hotkey!=null}};
   if(mainNow!=null&&!busy){
    try{ObserveScreens(mainNow);}catch(Exception e){Log("Ekran izleme hatası: "+e.Message);}
    try{beat["ekran"]=ActiveName(mainNow);}catch{}
    try{var f=FocusDescription(mainNow);if(f!=null)beat["odak"]=f;}catch{}
    try{var w=ModalWarning(mainNow);if(w!=null)beat["uyari"]=w;}catch{}
   }
   try{File.WriteAllText(Path.Combine(Root,"yardimci-durum.json"),new JavaScriptSerializer().Serialize(beat),new UTF8Encoding(false));}catch{}
  }
  if(busy)return;
  string[] files;try{files=Directory.GetFiles(Kuyruk,"istek-*.json");}catch{return;}
  if(files.Length==0)return;
  Array.Sort(files);
  string file=files[0];
  string raw;try{raw=File.ReadAllText(file,Encoding.UTF8);File.Delete(file);}catch{return;}
  busy=true;
  var t2=new Thread(()=>{try{Handle(raw);}finally{busy=false;}});
  t2.SetApartmentState(ApartmentState.STA);t2.IsBackground=true;t2.Start();
 }
 // Odaktaki alanın yalnız adı/kimliği ve üst bölümlerinin başlıkları. Metin kutusu değerleri yazılmaz.
 static Dictionary<string,object> FocusDescription(AutomationElement main){
  var f=AutomationElement.FocusedElement;if(f==null)return null;
  if(f.Current.ProcessId!=main.Current.ProcessId)return null;
  var t=f.Current.ControlType;
  bool valueLike=t==ControlType.Edit||t==ControlType.ComboBox||t==ControlType.Document||t==ControlType.DataItem||t==ControlType.Custom||t==ControlType.Text||t==ControlType.ListItem||t==ControlType.TreeItem;
  var d=new Dictionary<string,object>{{"tur",t.ProgrammaticName.Replace("ControlType.","")},{"id",f.Current.AutomationId??""}};
  if(!valueLike)d["ad"]=Short(f.Current.Name);
  var walker=TreeWalker.ControlViewWalker;
  try{
   AutomationElement p=walker.GetPreviousSibling(f);
   for(int i=0;i<4&&p!=null;i++){string b=Bracket(p.Current.Name);if(b.Length>0){d["alan"]=Short(b);break;}p=walker.GetPreviousSibling(p);}
  }catch{}
  var up=new List<string>();
  try{
   AutomationElement a=walker.GetParent(f);
   for(int i=0;i<6&&a!=null;i++){
    var at=a.Current.ControlType;string n=(a.Current.Name??"").Trim();
    if(n.Length>0&&n.Length<=60&&(at==ControlType.Pane||at==ControlType.Group||at==ControlType.Tab||at==ControlType.TabItem||at==ControlType.Window)&&!Automation.Compare(a,main))up.Add(n);
    if(Automation.Compare(a,main))break;a=walker.GetParent(a);
   }
  }catch{}
  d["ust"]=up;
  return d;
 }
 static string Short(string s){s=(s??"").Replace("\r"," ").Replace("\n"," ").Trim();return s.Length>80?s.Substring(0,80):s;}
 static string lastWarnDump="";
 static IntPtr lastDlgHandle=IntPtr.Zero;static string lastDlgText="";
 static bool HasInputs(AutomationElement dlg){
  try{foreach(AutomationElement e in dlg.FindAll(TreeScope.Descendants,Condition.TrueCondition)){var t=e.Current.ControlType;if(t==ControlType.Edit||t==ControlType.ComboBox||t==ControlType.Document||t==ControlType.List||t==ControlType.DataGrid)return true;}}catch{return true;}
  return false;
 }
 static string CopyDialogText(string title){
  string old=null;bool hadText=false;
  try{if(Clipboard.ContainsText()){old=Clipboard.GetText();hadText=true;}}catch{}
  string got="";
  try{
   try{Clipboard.Clear();}catch{}
   Key(VK_CONTROL,false);Press(0x43);Key(VK_CONTROL,true);
   for(int i=0;i<8&&got.Length==0;i++){Thread.Sleep(80);try{if(Clipboard.ContainsText())got=Clipboard.GetText();}catch{}}
  }finally{
   try{if(hadText)Clipboard.SetText(old);else Clipboard.Clear();}catch{}
  }
  var lines=new List<string>();
  foreach(string l in got.Replace("\r","").Split('\n')){string x=l.Trim().Trim('-').Trim();if(x.Length>0&&x!=title&&x!="Tamam"&&x!="OK"&&x!="Evet"&&x!="Hayır"&&x!="İptal")lines.Add(x);}
  string r=string.Join(" ",lines.ToArray());return r.Length>400?r.Substring(0,400):r;
 }
 // STORE bir soru/uyarı penceresiyle kilitliyse pencerenin başlığını ve metnini okur (düğmeye basmaz).
 static Dictionary<string,object> ModalWarning(AutomationElement main){
  object wp;if(!main.TryGetCurrentPattern(WindowPattern.Pattern,out wp))return null;
  if(((WindowPattern)wp).Current.WindowInteractionState!=WindowInteractionState.BlockedByModalWindow){lastWarnDump="";lastDlgHandle=IntPtr.Zero;return null;}
  int pid=main.Current.ProcessId;AutomationElement dlg=null;
  foreach(AutomationElement w in AutomationElement.RootElement.FindAll(TreeScope.Children,new PropertyCondition(AutomationElement.ProcessIdProperty,pid)))if(!Automation.Compare(w,main)){dlg=w;break;}
  if(dlg==null){try{dlg=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Window));}catch{}}
  if(dlg==null){lastWarnDump="";lastDlgHandle=IntPtr.Zero;return new Dictionary<string,object>{{"baslik",""},{"metin",""},{"dugmeler",new List<string>()}};}
  var texts=new List<string>();var buttons=new List<string>();int len=0;
  string title="";try{title=(dlg.Current.Name??"").Trim();}catch{}
  var diag=new StringBuilder();bool dump=title!=lastWarnDump;
  foreach(AutomationElement e in dlg.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
   try{
    var t=e.Current.ControlType;string n=(e.Current.Name??"").Trim(),v="";
    try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=(((ValuePattern)vp).Current.Value??"").Trim();}catch{}
    if(dump&&diag.Length<6000)diag.AppendLine("  "+t.ProgrammaticName.Replace("ControlType.","")+" ["+Short(n)+"] <"+Short(v)+"> sinif="+e.Current.ClassName+" id="+e.Current.AutomationId);
    if(t==ControlType.Button){if(buttons.Count<6&&n.Length>0&&n.Length<30)buttons.Add(n);continue;}
    if(t==ControlType.TitleBar||t==ControlType.MenuBar||t==ControlType.MenuItem||t==ControlType.ScrollBar)continue;
    foreach(string x in new[]{n,v})if(x.Length>0&&x!=title&&len<400&&!texts.Contains(x)){texts.Add(x);len+=x.Length;}
   }catch{}
  }
  // Bazı Nebim mesaj kutuları metni UIA'ya vermez: Win32 alt pencere metinlerini de oku (düğmeler hariç).
  try{
   IntPtr h=new IntPtr(dlg.Current.NativeWindowHandle);
   if(h!=IntPtr.Zero)EnumChildWindows(h,(c,l)=>{
    try{
     if(!IsWindowVisible(c))return true;
     var sb=new StringBuilder(512);GetWindowText(c,sb,512);string x=sb.ToString().Trim();
     var cn=new StringBuilder(128);GetClassName(c,cn,128);
     if(dump&&diag.Length<8000)diag.AppendLine("  win32 sinif="+cn+" ["+Short(x)+"]");
     if(x.Length>0&&x!=title&&!buttons.Contains(x)&&cn.ToString().IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0&&len<400&&!texts.Contains(x)){texts.Add(x);len+=x.Length;}
    }catch{}
    return true;
   },IntPtr.Zero);
  }catch{}
  // Nebim'in mesaj kutusu metni çizerek gösteriyor (UIA/Win32'de yok). Yalnız düğmeli bir mesaj kutusu öndeyse
  // bir kez Ctrl+C ile metni kopyalar ve panoyu eski haline döndürür. Hiçbir düğmeye basmaz.
  if(texts.Count==0){
   try{
    IntPtr dh=new IntPtr(dlg.Current.NativeWindowHandle);
    if(dh==lastDlgHandle)texts.Add(lastDlgText);
    else if(dh!=IntPtr.Zero&&GetForegroundWindow()==dh&&!HasInputs(dlg)&&buttons.Count<=4){
     lastDlgHandle=dh;lastDlgText=CopyDialogText(title);
     if(lastDlgText.Length>0)texts.Add(lastDlgText);
     if(dump&&diag.Length<9000)diag.AppendLine("  ctrl+c metni: ["+Short(lastDlgText)+"]");
    }
   }catch{}
  }
  if(dump){lastWarnDump=title;try{File.WriteAllText(Path.Combine(Root,"uyari-tani.txt"),"Uyarı penceresi tanısı "+DateTime.Now.ToString("s")+" başlık=["+title+"]"+Environment.NewLine+diag.ToString(),new UTF8Encoding(false));}catch{}}
  string metin=string.Join(" ",texts.ToArray());if(metin.Length>400)metin=metin.Substring(0,400);
  return new Dictionary<string,object>{{"baslik",Short(dlg.Current.Name)},{"metin",metin},{"dugmeler",buttons}};
 }

 // ---------- İstek işleme ----------
 void Handle(string raw){
  var js=new JavaScriptSerializer{MaxJsonLength=4*1024*1024};
  string id="",ad="";
  Dictionary<string,object> result;
  try{
   var req=js.Deserialize<Dictionary<string,object>>(raw);
   id=Convert.ToString(req.ContainsKey("id")?req["id"]:"");
   string ekranId=Convert.ToString(req.ContainsKey("ekran")?req["ekran"]:"");
   if(id.Length==0||id.Length>64||id.IndexOfAny(Path.GetInvalidFileNameChars())>=0)throw new Exception("Geçersiz istek kimliği.");
   string islem=Convert.ToString(req.ContainsKey("islem")?req["islem"]:"ac");
   if(islem=="dogrula"){Log("İstek "+id+": katalog doğrulama");result=VerifyCatalog();}
   else if(islem=="ara"){string metin=Convert.ToString(req.ContainsKey("metin")?req["metin"]:"");Log("İstek "+id+": Ara listesinde arama '"+metin+"'");result=SearchOnly(metin);}
   else if(islem=="goster"){string alan=Convert.ToString(req.ContainsKey("alan")?req["alan"]:"");Log("İstek "+id+": alan göster '"+alan+"'");result=ShowField(alan);}
   else if(islem=="oku"){Log("İstek "+id+": açık rapordan toplam okuma");result=ReadReport();}
   else if(islem=="ozet"){Log("İstek "+id+": Hareket Özeti aç + Çalıştır + oku");result=RunSummary();}
   else if(islem=="nabiz"){result=Result("acildi","Yardımcı çalışıyor (sürüm "+Surum+").",null);}
   else{
    ad=CatalogName(ekranId);
    int sira=CatalogSira(ekranId);
    Log("İstek "+id+": "+ad+(sira>1?" (listede "+sira+". satır)":""));
    result=OpenScreen(ad,sira);
   }
  }catch(Exception e){result=Result("hata",e.Message,null);}
  result["id"]=id;result["ekran"]=ad;result["zaman"]=DateTime.Now.ToString("s");result["surum"]=Surum;
  lastResult=(ad.Length>0?ad+": ":"")+Convert.ToString(result["mesaj"]);
  Log("Sonuç "+id+": "+result["durum"]+" — "+result["mesaj"]);
  if(id.Length>0){
   try{
    File.WriteAllText(Path.Combine(Kuyruk,"sonuc-"+id+".json"),js.Serialize(result),new UTF8Encoding(false));
   }catch(Exception e){Log("Sonuç yazılamadı: "+e.Message);}
  }
 }
 static Dictionary<string,object> Result(string durum,string mesaj,string baslik){
  return new Dictionary<string,object>{{"ok",durum=="acildi"||durum=="zaten-acik"||durum=="acildi-uyari"||durum=="liste-acik"||durum=="okundu"||durum=="gosterildi"},{"durum",durum},{"mesaj",mesaj},{"baslik",baslik??""}};
 }
 // 22.10: Ara listesinde tam adlı satır ilk sırada değilse (ör. "Satış Sorumlusu" aramasında önce "Hatalı Girilmiş Satış Sorumlusu…" gelir) katalogdaki "sira" kullanılır.
 static int CatalogSira(string ekranId){
  try{
   var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
   foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){var d=(Dictionary<string,object>)o;if(Convert.ToString(d["id"])==ekranId&&d.ContainsKey("sira")){int n=Convert.ToInt32(d["sira"]);return n<1?1:(n>15?15:n);}}
  }catch{}
  return 1;
 }
 static string CatalogName(string ekranId){
  var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
  foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
   var d=(Dictionary<string,object>)o;
   if(Convert.ToString(d["id"])==ekranId)return Convert.ToString(d["ad"]);
  }
  if(ekranId.StartsWith("ogr:",StringComparison.Ordinal)){
   string ad=ekranId.Substring(4);
   lock(learnLock){LoadLearned();if(learned.ContainsKey(ad))return ad;}
   throw new Exception("Bu ekran öğrenilenler listesinde yok; açılmadı.");
  }
  throw new Exception("Bu ekran katalogda yok; açılmadı.");
 }
 // ---------- Öğrenme: kullanıcının Nebim'de açtığı ekranları kaydet (yalnız okuma) ----------
 static readonly object learnLock=new object();
 static Dictionary<string,Dictionary<string,object>> learned;
 static HashSet<string> openBefore=new HashSet<string>();
 static string LearnedFile{get{return Path.Combine(Root,"ogrenilen-ekranlar.json");}}
 static void LoadLearned(){
  if(learned!=null)return;
  learned=new Dictionary<string,Dictionary<string,object>>();
  try{
   if(!File.Exists(LearnedFile))return;
   var d=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(LearnedFile,Encoding.UTF8));
   foreach(object o in (System.Collections.IEnumerable)d["ekranlar"]){var e=(Dictionary<string,object>)o;string ad=Convert.ToString(e["ad"]);if(ad.Length>0)learned[ad]=e;}
  }catch(Exception e){Log("Öğrenilen ekranlar okunamadı: "+e.Message);}
 }
 static HashSet<string> catalogNames;static DateTime catalogStamp;
 static HashSet<string> CatalogNames(){
  try{
   var f=new FileInfo(Path.Combine(Root,"ekranlar.json"));
   if(catalogNames==null||f.LastWriteTimeUtc!=catalogStamp){
    var set=new HashSet<string>();
    var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(f.FullName,Encoding.UTF8));
    foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"])set.Add(Convert.ToString(((Dictionary<string,object>)o)["ad"]));
    catalogNames=set;catalogStamp=f.LastWriteTimeUtc;
   }
  }catch{if(catalogNames==null)catalogNames=new HashSet<string>();}
  return catalogNames;
 }
 static void ObserveScreens(AutomationElement main){
  var mdi=FindMdi(main);if(mdi==null)return;
  var now=new HashSet<string>();
  var walker=TreeWalker.ControlViewWalker;AutomationElement c=null;
  try{c=walker.GetFirstChild(mdi);}catch{}
  while(c!=null){
   try{if(c.Current.ControlType==ControlType.Window){string n=(c.Current.Name??"").Trim();if(n.Length>=2&&n.Length<=120&&n.IndexOfAny(new[]{'\r','\n'})<0)now.Add(n);}}catch{}
   try{c=walker.GetNextSibling(c);}catch{c=null;}
  }
  bool changed=false;
  lock(learnLock){
   LoadLearned();
   foreach(string n in now){
    if(openBefore.Contains(n))continue;
    Dictionary<string,object> e;
    if(CatalogNames().Contains(n))continue;
    if(!learned.TryGetValue(n,out e)){e=new Dictionary<string,object>{{"ad",n},{"ilk",DateTime.Now.ToString("s")},{"sayac",0}};learned[n]=e;Log("Yeni ekran öğrenildi: "+n);}
    e["sayac"]=Convert.ToInt32(e["sayac"])+1;e["son"]=DateTime.Now.ToString("s");changed=true;
   }
   openBefore=now;
   if(changed){
    var list=new List<object>(learned.Values);
    File.WriteAllText(LearnedFile,new JavaScriptSerializer().Serialize(new Dictionary<string,object>{{"surum",1},{"not","Sunucu yardımcısının Nebim STORE'da açık gördüğü ekranlar. Yalnız ekran adları; veri yok."},{"ekranlar",list}}),new UTF8Encoding(false));
   }
  }
 }
 // ---------- Alan gösterici: tıklamadan geçici çerçeve ----------
 Dictionary<string,object> ShowField(string alan){
  alan=(alan??"").Trim();
  if(alan.Length<2||alan.Length>80)return Result("hata","Gösterilecek alan adı 2–80 karakter olmalı.",null);
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE açık değil.",null);
  string q=Norm(alan);
  AutomationElement scope=ActiveChild(main)??main;
  AutomationElement best=null;int bestScore=0;
  // Önce adı birebir eşleşen öğeyi hızlı arama ile bul.
  try{
   var cond=new OrCondition(new PropertyCondition(AutomationElement.NameProperty,alan),new PropertyCondition(AutomationElement.NameProperty,"["+alan+"]"));
   foreach(var root in new[]{scope,main}){
    foreach(AutomationElement e in root.FindAll(TreeScope.Descendants,cond)){
     try{var r0=e.Current.BoundingRectangle;if(!e.Current.IsOffscreen&&!r0.IsEmpty&&r0.Width>=4&&r0.Height>=4){best=e;bestScore=100;break;}}catch{}
    }
    if(best!=null)break;
   }
  }catch{}
  if(best==null)foreach(var root in new[]{scope,main}){
   AutomationElementCollection all;try{all=root.FindAll(TreeScope.Descendants,Condition.TrueCondition);}catch{continue;}
   int n=0;
   foreach(AutomationElement e in all){
    if(++n>6000)break;
    string name;System.Windows.Rect r;
    try{name=(e.Current.Name??"").Trim();r=e.Current.BoundingRectangle;if(e.Current.IsOffscreen)continue;}catch{continue;}
    if(name.Length==0||r.IsEmpty||r.Width<4||r.Height<4)continue;
    string nn=Norm(name),nb=Norm(Bracket(name));
    int score=nn==q||nb==q?100:(q.Length>=4&&(nn.StartsWith(q)||nb.StartsWith(q)))?60:(q.Length>=5&&nn.Contains(q))?40:0;
    if(score>bestScore){bestScore=score;best=e;if(score==100)break;}
   }
   if(bestScore==100)break;
  }
  if(best==null)return Result("bulunamadi","'"+alan+"' alanı açık ekranda bulunamadı. Ekranı kaydırmanız ya da ilgili sekmeyi açmanız gerekebilir.",null);
  var rect=best.Current.BoundingRectangle;
  var bounds=new Rectangle((int)rect.X-6,(int)rect.Y-6,(int)rect.Width+12,(int)rect.Height+12);
  invoker.BeginInvoke(new Action(()=>{try{new Highlight(bounds).Show();}catch(Exception e){Log("Çerçeve çizilemedi: "+e.Message);}}));
  return Result("gosterildi","'"+best.Current.Name+"' turuncu çerçeveyle gösterildi (6 sn). Asistan tıklamadı; değeri siz girin.",null);
 }
 class Highlight:Form{
  readonly System.Windows.Forms.Timer close=new System.Windows.Forms.Timer {Interval=6000};
  int blink;
  public Highlight(Rectangle r){
   FormBorderStyle=FormBorderStyle.None;ShowInTaskbar=false;TopMost=true;StartPosition=FormStartPosition.Manual;
   BackColor=Color.Magenta;TransparencyKey=Color.Magenta;Bounds=r;
   close.Tick+=(s,e)=>{close.Stop();Close();};close.Start();
   var flash=new System.Windows.Forms.Timer {Interval=500};flash.Tick+=(s,e)=>{blink++;Invalidate();if(blink>11)flash.Stop();};flash.Start();
   FormClosed+=(s,e)=>{close.Dispose();flash.Dispose();};
  }
  protected override bool ShowWithoutActivation{get{return true;}}
  protected override CreateParams CreateParams{get{var p=base.CreateParams;p.ExStyle|=0x80000|0x20|0x8000000|0x80|0x8;return p;}}
  protected override void OnPaint(PaintEventArgs e){
   using(var pen=new Pen(blink%2==0?Color.FromArgb(255,120,0):Color.FromArgb(255,200,0),5))e.Graphics.DrawRectangle(pen,2,2,Width-5,Height-5);
  }
 }
 // Öndeki ekranın adı: başlık "Nebim V3 STORE - X", "X - Nebim V3 STORE" ya da "Nebim V3 STORE - [X]" olabilir;
 // olmazsa MDI alanındaki en üstteki pencere.
 static string ActiveName(AutomationElement main){
  string title="";try{title=(main.Current.Name??"").Trim();}catch{}
  string ad="";
  if(title.StartsWith("Nebim V3 STORE - ",StringComparison.Ordinal))ad=title.Substring(17);
  else if(title.EndsWith(" - Nebim V3 STORE",StringComparison.Ordinal))ad=title.Substring(0,title.Length-17);
  ad=ad.Trim().TrimStart('[').TrimEnd(']').Trim();
  if(ad.Length==0){
   try{var mdi=FindMdi(main);if(mdi!=null){var c=Child(mdi,x=>x.Current.ControlType==ControlType.Window);if(c!=null)ad=(c.Current.Name??"").Trim();}}catch{}
  }
  return ad;
 }
 static AutomationElement ActiveChild(AutomationElement main){
  string ad=ActiveName(main);
  var mdi=FindMdi(main);if(mdi==null)return null;
  var hit=ad.Length>0?Child(mdi,c=>c.Current.ControlType==ControlType.Window&&c.Current.Name==ad):null;
  return hit??Child(mdi,c=>c.Current.ControlType==ControlType.Window);
 }
 // 22.10: Mağaza Hareket Özeti'ni açar, rapor filtresindeki "Çalıştır"a basar (rapor çalıştırma; veri yazmaz) ve toplamları okur.
 Dictionary<string,object> RunSummary(){
  const string ad="Mağaza Hareket Özeti";
  if(PosInFront())return ReadPos();
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE açık değil.",null);
  var o=OpenScreen(ad);
  if(!(o.ContainsKey("ok")&&(bool)o["ok"]))return o;
  Thread.Sleep(800);
  AutomationElement child=null;
  try{var mdi=FindMdi(main);if(mdi!=null)child=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&((c.Current.Name??"")==ad||(c.Current.Name??"").StartsWith(ad+" - ",StringComparison.Ordinal)));}catch{}
  if(child==null)return Result("hata","Hareket Özeti penceresi bulunamadı.",null);
  // 22.10 (2): Çalıştır rapor penceresinde ya da STORE'un üst şeridinde (ribbon) olabilir; adı "Çalıştır (F5)" gibi ek alabilir.
  AutomationElement btn=null;
  // Rapor penceresi geç yüklenebilir: 8 saniyeye kadar yeniden ara. STORE genelinde ararken yalnız
  // üst şeritteki ya da bu rapor penceresinin içindeki düğme kabul edilir (başka açık raporu çalıştırmasın).
  System.Windows.Rect childRect=System.Windows.Rect.Empty,mdiRect=System.Windows.Rect.Empty;
  try{childRect=child.Current.BoundingRectangle;var mdi0=FindMdi(main);if(mdi0!=null)mdiRect=mdi0.Current.BoundingRectangle;}catch{}
  var sw=Stopwatch.StartNew();
  while(btn==null&&sw.ElapsedMilliseconds<8000){
   btn=FindRunButton(child);
   if(btn==null){var cand=FindRunButton(main);if(cand!=null&&RunButtonAllowed(cand,childRect,mdiRect))btn=cand;}
   if(btn==null)Thread.Sleep(500);
  }
  if(btn==null){DumpButtons(child,main);return Result("hata","Hareket Özeti açıldı ama 'Çalıştır' düğmesi bulunamadı. Nebim'de Çalıştır'a siz basıp Yenile'ye tekrar basın. Tanı: araclar\\calistir-tani.txt",null);}
  if(PosInFront())return Result("hata","Kasa (POS) ekranı öne geçti; satış bölünmesin diye Çalıştır'a basmadım. STORE'a geçip Yenile'ye tekrar basın.",null);
  try{
   object ip;
   if(btn.TryGetCurrentPattern(InvokePattern.Pattern,out ip))((InvokePattern)ip).Invoke();
   else{var r=btn.Current.BoundingRectangle;if(r.IsEmpty)throw new Exception("düğme görünmüyor");ClickAt((int)(r.X+r.Width/2),(int)(r.Y+r.Height/2));}
   Log("Hareket Özeti: Çalıştır'a basıldı (yalnız rapor çalıştırma).");
  }catch(Exception e){return Result("hata","'Çalıştır'a basılamadı: "+e.Message+". Nebim'de Çalıştır'a siz basın.",null);}
  Dictionary<string,object> last=null;
  for(int i=0;i<20;i++){
   Thread.Sleep(1000);
   try{
    last=ReadReport();
    var col=last.ContainsKey("satirlar")?last["satirlar"] as System.Collections.ICollection:null;
    if(last.ContainsKey("ok")&&(bool)last["ok"]&&col!=null&&col.Count>0)return last;
   }catch{}
  }
  return last??Result("hata","Rapor 20 saniyede sonuç vermedi.",null);
 }
 // Çalıştır düğmesini adına göre arar (Button, MenuItem, ListItem, Custom; yalnız görünür ve etkin olanlar).
 static AutomationElement FindRunButton(AutomationElement root){
  if(root==null)return null;AutomationElement best=null;
  try{foreach(AutomationElement e in root.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
   string n="";ControlType t=null;bool on=true,off=false;
   try{n=e.Current.Name??"";t=e.Current.ControlType;on=e.Current.IsEnabled;off=e.Current.IsOffscreen;}catch{continue;}
   if(!on||off)continue;
   if(t!=ControlType.Button&&t!=ControlType.MenuItem&&t!=ControlType.ListItem&&t!=ControlType.Custom&&t!=ControlType.SplitButton)continue;
   string k=Norm(n).Trim();
   if(k=="calistir"||k.StartsWith("calistir ")||k.StartsWith("calistir(")){if(t==ControlType.Button)return e;if(best==null)best=e;}
  }}catch{}
  return best;
 }
 static bool RunButtonAllowed(AutomationElement b,System.Windows.Rect childRect,System.Windows.Rect mdiRect){
  try{var r=b.Current.BoundingRectangle;if(r.IsEmpty)return false;
   if(!childRect.IsEmpty&&childRect.Contains(new System.Windows.Point(r.X+r.Width/2,r.Y+r.Height/2)))return true;
   if(!mdiRect.IsEmpty&&r.Bottom<=mdiRect.Top+2)return true; // üst şerit (ribbon)
  }catch{}
  return false;
 }
 static void DumpButtons(AutomationElement child,AutomationElement main){
  var sb=new StringBuilder();sb.AppendLine("Çalıştır tanısı "+DateTime.Now.ToString("s"));
  foreach(var pair in new[]{new KeyValuePair<string,AutomationElement>("rapor",child),new KeyValuePair<string,AutomationElement>("store",main)}){
   if(pair.Value==null)continue;int c=0;
   try{foreach(AutomationElement e in pair.Value.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
    string n="",t="";try{n=e.Current.Name??"";t=e.Current.ControlType.ProgrammaticName;}catch{continue;}
    if(n.Length==0||!(t.Contains("Button")||t.Contains("MenuItem")||t.Contains("ListItem")||t.Contains("Custom")))continue;
    sb.AppendLine("  "+pair.Key+" | "+t.Replace("ControlType.","")+" | "+n);if(++c>=150)break;
   }}catch{}
  }
  try{File.WriteAllText(Path.Combine(Root,"calistir-tani.txt"),sb.ToString(),new UTF8Encoding(false));}catch{}
 }
 // ---------- Açık rapordan yalnız toplam satırlarını oku ----------
 static readonly string[] ReadableReports={"Mağaza Hareket Özeti","Mağaza Ciro Raporu","Mağaza Satış ve Envanter Raporu"};
 static readonly string[] TotalWords={"toplam","genel toplam","nakit","kredi kart","kart","banka","hediye","iade","iskonto","net tutar","brut","fis sayisi","adet"};
 static bool IsTotalLike(string s){string n=Norm(s);foreach(string w in TotalWords)if(n.Contains(w))return true;return false;}
 Dictionary<string,object> ReadReport(){
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE açık değil.",null);
  var child=ActiveChild(main);
  string ad="";try{ad=child==null?"":child.Current.Name;}catch{}
  if(Array.IndexOf(ReadableReports,ad)<0){
   // Rapor önde değilse açık pencereler arasında okunabilir rapor ara.
   var mdi=FindMdi(main);
   if(mdi!=null){var r2=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&Array.IndexOf(ReadableReports,c.Current.Name)>=0);if(r2!=null){child=r2;try{ad=r2.Current.Name;}catch{}}}
  }
  if(Array.IndexOf(ReadableReports,ad)<0)return Result("hata","Önde okunabilir bir rapor yok"+(ad.Length>0?" (önde: "+ad+")":"")+". Mağaza Hareket Özeti veya Mağaza Ciro Raporu'nu açıp Çalıştır'a basın, sonuç görünürken tekrar deneyin.",null);
  // Müşteriler sekmesi kişisel veri içerir: o sekme seçiliyken okuma yapılmaz.
  try{
   foreach(AutomationElement ti in child.FindAll(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TabItem))){
    object sp;if(Norm(ti.Current.Name).Contains("musteri")&&ti.TryGetCurrentPattern(SelectionItemPattern.Pattern,out sp)&&((SelectionItemPattern)sp).Current.IsSelected)
     return Result("hata","Raporda 'Müşteriler' sekmesi açık; kişisel veri olduğu için okumadım. 'Satış' ya da 'Ödemeler' sekmesine geçip tekrar deneyin.",null);
   }
  }catch{}
  return ReadElement(child,ad,"okuma-tani.txt");
 }
 // Verilen pencerenin (STORE raporu ya da POS ekranı) toplam satırlarını okur. Hiçbir yere tıklamaz.
 Dictionary<string,object> ReadElement(AutomationElement child,string ad,string taniDosya){
  var tani=new StringBuilder();tani.AppendLine("Okuma tanısı "+DateTime.Now.ToString("s")+" rapor="+ad);
  AutomationElementCollection all;try{all=child.FindAll(TreeScope.Descendants,Condition.TrueCondition);}catch(Exception e){return Result("hata","Rapor okunamadı: "+e.Message,null);}
  var rows=new List<object>();var loose=new List<object>();var headers=new List<string>();var counts=new Dictionary<string,int>();
  int seen=0;var walker=TreeWalker.ControlViewWalker;
  foreach(AutomationElement e in all){
   if(++seen>25000)break;
   ControlType t;string n="";try{t=e.Current.ControlType;n=(e.Current.Name??"").Trim();}catch{continue;}
   string tn=t.ProgrammaticName.Replace("ControlType.","");
   int c;counts.TryGetValue(tn,out c);counts[tn]=c+1;
   if(t==ControlType.Header||t==ControlType.HeaderItem){if(n.Length>0&&n.Length<60&&headers.Count<80&&!headers.Contains(n))headers.Add(n);continue;}
   if(t==ControlType.DataItem||t==ControlType.ListItem||t==ControlType.TreeItem){
    var cells=new List<object>();bool interesting=IsTotalLike(n);
    AutomationElement k=null;try{k=walker.GetFirstChild(e);}catch{}
    int kc=0;
    bool gridRow=false;
    while(k!=null&&kc<60){
     string kn="",kv="";try{kn=(k.Current.Name??"").Trim();object vp;if(k.TryGetCurrentPattern(ValuePattern.Pattern,out vp))kv=((ValuePattern)vp).Current.Value??"";}catch{}
     // DevExpress tablo hücresi adı "Kolon satır N": kolon adını sadeleştir. Özet raporun tüm satırları toplam niteliğindedir.
     var mm=System.Text.RegularExpressions.Regex.Match(kn,@"^(.*?)\s+satır\s+\d+$");if(mm.Success){kn=mm.Groups[1].Value;gridRow=true;}
     if(IsTotalLike(kv))interesting=true;
     cells.Add(new Dictionary<string,object>{{"kolon",Short(kn)},{"deger",Short(kv)}});kc++;
     try{k=walker.GetNextSibling(k);}catch{k=null;}
    }
    if(gridRow&&(ad=="Mağaza Hareket Özeti"||ad=="Mağaza Ciro Raporu"))interesting=true;
    if(interesting&&rows.Count<80)rows.Add(new Dictionary<string,object>{{"satir",Short(n)},{"hucreler",cells}});
    if(rows.Count<3&&tani.Length<20000){tani.Append("  satir ").Append(tn).Append(" hucre=").Append(kc).Append(" kolonlar: ");foreach(object o in cells)tani.Append(((Dictionary<string,object>)o)["kolon"]).Append(" | ");tani.AppendLine(interesting?" (toplam benzeri)":"");}
    continue;
   }
   // Satır dışındaki adı/değeri toplam benzeri öğeler (alt toplam alanları, rapor önizleme metinleri)
   if(loose.Count<120){
    string v="";try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=((ValuePattern)vp).Current.Value??"";}catch{}
    if(t!=ControlType.Edit&&(IsTotalLike(n)||IsTotalLike(v))){
     string next="";
     try{var s=walker.GetNextSibling(e);if(s!=null){next=(s.Current.Name??"").Trim();object vp2;if(next.Length==0&&s.TryGetCurrentPattern(ValuePattern.Pattern,out vp2))next=((ValuePattern)vp2).Current.Value??"";}}catch{}
     loose.Add(new Dictionary<string,object>{{"tur",tn},{"ad",Short(n)},{"deger",Short(v)},{"sonraki",Short(next)}});
    }
   }
  }
  tani.AppendLine("  oge sayilari: "+string.Join(", ",ListCounts(counts)));
  tani.AppendLine("  basliklar: "+string.Join(" | ",headers.ToArray()));
  tani.AppendLine("  toplam benzeri satir: "+rows.Count+", serbest oge: "+loose.Count);
  try{File.WriteAllText(Path.Combine(Root,taniDosya),tani.ToString(),new UTF8Encoding(false));}catch{}
  if(rows.Count==0&&loose.Count==0)return Result("bulunamadi","'"+ad+"' açık ama toplam satırı okunamadı (rapor henüz çalıştırılmamış olabilir). Tanı: araclar\\"+taniDosya,null);
  var r=Result("okundu","'"+ad+"' raporundan "+rows.Count+" toplam satırı okundu. Nebim'e hiçbir şey yazılmadı.",null);
  r["rapor"]=ad;r["satirlar"]=rows;r["ogeler"]=loose;r["basliklar"]=headers;
  return r;
 }
 // 22.10: POS önde iken YALNIZ OKUR. Tıklamaz, tuşa basmaz, ekran açmaz; satış bölünmez.
 // POS'ta Mağaza Hareket Özeti kullanıcı tarafından açılmış olmalı.
 Dictionary<string,object> ReadPos(){
  AutomationElement pw=null;
  try{IntPtr h=GetForegroundWindow();if(ProcessNameOf(h).Equals("NebimV3POS",StringComparison.OrdinalIgnoreCase))pw=AutomationElement.FromHandle(h);}catch{}
  if(pw==null)return Result("hata","POS penceresi okunamadı.",null);
  AutomationElement hedef=null;string wn="";
  try{wn=pw.Current.Name??"";}catch{}
  if(Norm(wn).Contains("hareket ozeti"))hedef=pw;
  if(hedef==null){
   try{foreach(AutomationElement e in pw.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
    string n="";ControlType t=null;bool off=false;try{n=e.Current.Name??"";t=e.Current.ControlType;off=e.Current.IsOffscreen;}catch{continue;}
    if(off)continue;
    if((t==ControlType.Window||t==ControlType.Pane||t==ControlType.Group||t==ControlType.TabItem||t==ControlType.Text||t==ControlType.TitleBar)&&Norm(n).Contains("hareket ozeti")){
     hedef=(t==ControlType.Text||t==ControlType.TitleBar||t==ControlType.TabItem)?pw:e;break;}
   }}catch{}
  }
  if(hedef==null){DumpPos(pw);return Result("hata","POS önde ama Mağaza Hareket Özeti açık değil. POS'ta Hareket Özeti'ni siz açın, Yenile'ye basın; asistan yalnız okur. Tanı: araclar\\pos-tani.txt",null);}
  Log("POS: Hareket Özeti yalnız okunuyor (tıklama yok).");
  var r=ReadElement(hedef,"Mağaza Hareket Özeti","okuma-tani-pos.txt");
  r["kaynak"]="pos";
  // POS raporu yazı öğelerinden oluşur: tüm yazıları ekrandaki konumuyla sırayla al (satır satır çözmek için).
  var metin=new List<object>();var sb=new StringBuilder();sb.AppendLine("POS yazı dökümü "+DateTime.Now.ToString("s"));
  try{foreach(AutomationElement e in hedef.FindAll(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Text))){
   string n="";System.Windows.Rect b=System.Windows.Rect.Empty;try{n=(e.Current.Name??"").Trim();b=e.Current.BoundingRectangle;}catch{continue;}
   if(n.Length==0||b.IsEmpty)continue;
   metin.Add(new Dictionary<string,object>{{"t",Short(n)},{"x",(int)b.X},{"y",(int)b.Y},{"w",(int)b.Width}});
   sb.AppendLine("  y="+(int)b.Y+" x="+(int)b.X+" w="+(int)b.Width+" | "+n);
   if(metin.Count>=400)break;
  }}catch{}
  r["metinler"]=metin;
  // POS yazılarını STORE tablosuyla aynı biçimde satır/hücreye çevir (asistan ikisini aynı okur).
  try{var pr=PosRows(metin);if(pr.Count>0){r["satirlar"]=pr;r["mesaj"]="POS'taki Mağaza Hareket Özeti'nden "+pr.Count+" satır okundu (tıklama yok). Nebim'e hiçbir şey yazılmadı.";}}catch(Exception ex){Log("POS satır çözme hatası: "+ex.Message);}
  try{File.WriteAllText(Path.Combine(Root,"pos-metin.txt"),sb.ToString(),new UTF8Encoding(false));}catch{}
  return r;
 }
 // Aynı y'deki yazılar bir satırdır. 4+ yazılı ve sayı içermeyen satır başlıktır; altındaki satırların yazıları
 // x konumuna göre başlığın sütununa yerleşir. Başlık, tek yazılı bölüm adında (Satış, Ödemeler) ya da büyük boşlukta sıfırlanır.
 static readonly System.Text.RegularExpressions.Regex PosNum=new System.Text.RegularExpressions.Regex(@"^-?[0-9.]+(,[0-9]+)?$");
 static List<object> PosRows(List<object> metin){
  // 22.10 hata önleme: aynı satırdaki yazılar 1-3 px farklı y'de olabilir (tolerans 3 px);
  // değer, en çok örtüştüğü başlığın sütununa yazılır (birkaç px kayma yanlış sütuna düşürmez).
  var items=new List<Dictionary<string,object>>();foreach(object o in metin){var d=o as Dictionary<string,object>;if(d!=null)items.Add(d);}
  items.Sort((p,q)=>{int c1=Convert.ToInt32(p["y"]).CompareTo(Convert.ToInt32(q["y"]));return c1!=0?c1:Convert.ToInt32(p["x"]).CompareTo(Convert.ToInt32(q["x"]));});
  var lines=new List<KeyValuePair<int,List<Dictionary<string,object>>>>();
  foreach(var d in items){int yy=Convert.ToInt32(d["y"]);
   if(lines.Count>0&&Math.Abs(yy-lines[lines.Count-1].Key)<=3)lines[lines.Count-1].Value.Add(d);
   else lines.Add(new KeyValuePair<int,List<Dictionary<string,object>>>(yy,new List<Dictionary<string,object>>{d}));}
  var rows=new List<object>();List<Dictionary<string,object>> head=null;int prevY=-1000;
  foreach(var kv in lines){
   var line=kv.Value;line.Sort((p,q)=>Convert.ToInt32(p["x"]).CompareTo(Convert.ToInt32(q["x"])));
   if(kv.Key-prevY>50)head=null;prevY=kv.Key;
   bool anyNum=false;foreach(var t in line)if(PosNum.IsMatch(Convert.ToString(t["t"])))anyNum=true;
   if(line.Count==1){head=null;continue;}
   if(line.Count>=4&&!anyNum){head=line;continue;}
   if(head==null||!anyNum)continue;
   var cells=new List<object>();
   foreach(var t in line){
    int x=Convert.ToInt32(t["x"]),w=Math.Max(Convert.ToInt32(t["w"]),1);string kol="";int bestOv=0;
    foreach(var h in head){int hx=Convert.ToInt32(h["x"]),hw=Math.Max(Convert.ToInt32(h["w"]),1);int ov=Math.Min(x+w,hx+hw)-Math.Max(x,hx);if(ov>bestOv){bestOv=ov;kol=Convert.ToString(h["t"]);}}
    if(kol.Length==0){double cx=x+w/2.0,bd=double.MaxValue;string bk="";int bw=1;
     foreach(var h in head){int hx=Convert.ToInt32(h["x"]),hw=Math.Max(Convert.ToInt32(h["w"]),1);double dd=Math.Abs(hx+hw/2.0-cx);if(dd<bd){bd=dd;bk=Convert.ToString(h["t"]);bw=hw;}}
     if(bd<=Math.Max(bw,w))kol=bk;}
    if(kol.Length>0)cells.Add(new Dictionary<string,object>{{"kolon",kol},{"deger",Convert.ToString(t["t"])}});
   }
   if(cells.Count>0)rows.Add(new Dictionary<string,object>{{"satir",Convert.ToString(line[0]["t"])},{"hucreler",cells}});
  }
  return rows;
 }
 static void DumpPos(AutomationElement pw){
  var sb=new StringBuilder();sb.AppendLine("POS tanısı "+DateTime.Now.ToString("s"));int c=0;
  try{foreach(AutomationElement e in pw.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
   string n="",t="";try{n=e.Current.Name??"";t=e.Current.ControlType.ProgrammaticName.Replace("ControlType.","");}catch{continue;}
   if(n.Length==0)continue;sb.AppendLine("  "+t+" | "+(n.Length>80?n.Substring(0,80):n));if(++c>=200)break;
  }}catch{}
  try{File.WriteAllText(Path.Combine(Root,"pos-tani.txt"),sb.ToString(),new UTF8Encoding(false));}catch{}
 }
 static string[] ListCounts(Dictionary<string,int> d){var l=new List<string>();foreach(var kv in d)l.Add(kv.Key+"="+kv.Value);return l.ToArray();}
 // ---------- Ara listesinde yalnız arama (hiçbir ekran açmaz) ----------
 Dictionary<string,object> SearchOnly(string text){
  text=(text??"").Trim();
  if(text.Length<2||text.Length>60)return Result("hata","Aranacak metin 2–60 karakter olmalı.",null);
  foreach(char ch in text)if(!(char.IsLetterOrDigit(ch)||" -/().,&".IndexOf(ch)>=0))return Result("hata","Aranacak metinde desteklenmeyen karakter var.",null);
  if(PosInFront())return Result("hata","Kasa (POS) ekranı önde. Satış bölünmesin diye arama yapmadım.",null);
  var main=FindStore();
  if(main==null)return Result("hata","Nebim V3 STORE açık değil.",null);
  object wp;
  if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)){
   var w=(WindowPattern)wp;
   if(w.Current.WindowInteractionState==WindowInteractionState.BlockedByModalWindow)return Result("hata","STORE'da açık bir soru/uyarı penceresi var; önce onu kapatın.",null);
   if(w.Current.WindowVisualState==WindowVisualState.Minimized){w.SetWindowVisualState(WindowVisualState.Maximized);Thread.Sleep(600);}
  }
  var box=FindSearchBox(main);if(box==null)return Result("hata","Ara kutusu bulunamadı.",null);
  IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
  if(!FocusBox(box,mainH))return Result("hata","Nebim'in Ara kutusuna odaklanılamadı.",null);
  Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(60);
  TypeText(text);Thread.Sleep(1000);
  if(PopupShown(main,mainH))return Result("liste-acik","Nebim'in Ara listesinde '"+text+"' sonuçları açık. İstediğiniz ekrana çift tıklayın; açtığınız ekran asistanın hafızasına eklenir.",null);
  return Result("bulunamadi","'"+text+"' için Nebim menüsünde sonuç çıkmadı. Daha kısa bir kelime deneyin (ör. 'sayım', 'iade', 'kasa').",null);
 }
 static DateTime lastDiag=DateTime.MinValue;
 static AutomationElement FindStore(){
  var diag=new StringBuilder();
  // 1) Süreç üzerinden (en güvenilir)
  foreach(string pn in new[]{"NebimV3ERP","NebimV3STORE"}){
   Process[] ps;try{ps=Process.GetProcessesByName(pn);}catch(Exception e){diag.AppendLine("  süreç listesi hatası: "+e.Message);continue;}
   foreach(var p in ps){
    try{
     IntPtr h=p.MainWindowHandle;diag.AppendLine("  süreç "+pn+" pid="+p.Id+" ana pencere="+h+" başlık=["+p.MainWindowTitle+"]");
     if(h!=IntPtr.Zero&&(p.MainWindowTitle??"").IndexOf("Nebim V3 STORE",StringComparison.Ordinal)>=0)return AutomationElement.FromHandle(h);
    }catch(Exception e){diag.AppendLine("  süreç okunamadı: "+e.Message);}
    finally{p.Dispose();}
   }
  }
  // 2) Masaüstündeki üst pencereler
  try{
   var wins=AutomationElement.RootElement.FindAll(TreeScope.Children,Condition.TrueCondition);
   diag.AppendLine("  üst pencere sayısı: "+wins.Count);
   foreach(AutomationElement w in wins){
    string name="";int pid=0;
    try{name=w.Current.Name??"";pid=w.Current.ProcessId;}catch(Exception e){diag.AppendLine("  pencere okunamadı: "+e.Message);continue;}
    if(name.IndexOf("Nebim",StringComparison.OrdinalIgnoreCase)>=0)diag.AppendLine("  pencere ["+name+"] pid="+pid);
    if(name.IndexOf("Nebim V3 STORE",StringComparison.Ordinal)>=0)return w;
   }
  }catch(Exception e){diag.AppendLine("  üst pencereler okunamadı: "+e.GetType().Name+": "+e.Message);}
  if((DateTime.Now-lastDiag).TotalMinutes>=10){lastDiag=DateTime.Now;Log("STORE bulunamadı. Tanı:"+Environment.NewLine+diag.ToString().TrimEnd());}
  return null;
 }
 static AutomationElement Child(AutomationElement parent,Func<AutomationElement,bool> match){
  var walker=TreeWalker.ControlViewWalker;AutomationElement c=null;
  try{c=walker.GetFirstChild(parent);}catch{}
  while(c!=null){try{if(match(c))return c;}catch{}try{c=walker.GetNextSibling(c);}catch{c=null;}}
  return null;
 }
 static AutomationElement FindMdi(AutomationElement main){return Child(main,c=>(c.Current.ClassName??"").IndexOf("MDICLIENT",StringComparison.OrdinalIgnoreCase)>=0);}
 static bool ScreenOpen(AutomationElement main,string ad,out AutomationElement child){
  child=null;
  var mdi=FindMdi(main);
  if(mdi!=null)child=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&((c.Current.Name??"")==ad||(c.Current.Name??"").StartsWith(ad+" - ",StringComparison.Ordinal)));
  string title="";try{title=main.Current.Name??"";}catch{}
  return child!=null||title.EndsWith(" - "+ad,StringComparison.Ordinal)||title.IndexOf(" - "+ad+" - ",StringComparison.Ordinal)>=0;
 }
 static AutomationElement FindSearchBox(AutomationElement main){
  var nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));
  if(nav==null)return null;
  var combo=Child(nav,c=>c.Current.ControlType==ControlType.ComboBox);
  if(combo==null)return null;
  return combo.FindFirst(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Edit));
 }
 static bool IsFocused(AutomationElement el){
  try{
   var f=AutomationElement.FocusedElement;if(f==null)return false;
   if(Automation.Compare(f,el))return true;
   // Ara kutusu yeniden oluşturulmuş olabilir: odaktaki öğe aynı yerde duran bir metin kutusuysa kabul et.
   if(f.Current.ControlType!=ControlType.Edit)return false;
   var a=f.Current.BoundingRectangle;var b=el.Current.BoundingRectangle;
   return !a.IsEmpty&&!b.IsEmpty&&Math.Abs(a.X-b.X)<4&&Math.Abs(a.Y-b.Y)<4;
  }catch{return false;}
 }
 static void BringToFront(IntPtr h){
  IntPtr fg=GetForegroundWindow();uint pid;
  uint fgThread=GetWindowThreadProcessId(fg,out pid),me=GetCurrentThreadId();
  bool attached=fgThread!=0&&fgThread!=me&&AttachThreadInput(fgThread,me,true);
  try{SetForegroundWindow(h);}finally{if(attached)AttachThreadInput(fgThread,me,false);}
 }
 Dictionary<string,object> OpenScreen(string ad,int sira=1){
  // 1) Kasa (POS) öndeyse dokunma
  if(PosInFront())
   return Result("hata","Kasa (POS) ekranı önde. Satış bölünmesin diye hiçbir şey yapmadım. STORE'a geçip tekrar deneyin.",null);
  // 2) STORE açık mı
  var main=FindStore();
  if(main==null)return Result("hata","Nebim V3 STORE açık değil. Uzak masaüstünde V3 ERP kısayolundan açıp tekrar deneyin.",null);
  object wp;
  if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)){
   var w=(WindowPattern)wp;
   if(w.Current.WindowInteractionState==WindowInteractionState.BlockedByModalWindow)
    return Result("hata","STORE'da açık bir soru/uyarı penceresi var. Önce onu kapatın (bir şey girmediyseniz 'Hayır').",main.Current.Name);
   if(w.Current.WindowVisualState==WindowVisualState.Minimized){w.SetWindowVisualState(WindowVisualState.Maximized);Thread.Sleep(600);}
  }
  // 3) Zaten açıksa yalnız öne getir
  AutomationElement child;
  if(ScreenOpen(main,ad,out child)&&child!=null){
   BringToFront(new IntPtr(main.Current.NativeWindowHandle));
   try{child.SetFocus();}catch{}
   return Result("zaten-acik","Ekran zaten açıktı; öne getirildi.",main.Current.Name);
  }
  // 4) Ara kutusu
  var box=FindSearchBox(main);
  if(box==null)return Result("hata","STORE'un 'Ara…' kutusu bulunamadı. Sol menü kapalı olabilir.",main.Current.Name);
  if(!box.Current.IsEnabled)return Result("hata","'Ara…' kutusu şu an kullanılamıyor. STORE'da açık bir pencere işlem bekliyor olabilir.",main.Current.Name);
  if(!FocusBox(box,new IntPtr(main.Current.NativeWindowHandle)))return Result("hata","Nebim'e odaklanılamadı. Uzak masaüstündeki STORE penceresine bir kez tıklayıp tekrar deneyin.",main.Current.Name);
  // 5) Ekran adını yaz (yalnız Ara kutusuna)
  Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(60);
  if(!IsFocused(box))return Result("hata","Odak Ara kutusundan çıktı; yazmayı durdurdum.",main.Current.Name);
  string titleBefore="";try{titleBefore=main.Current.Name??"";}catch{}
  TypeText(ad);
  Thread.Sleep(900);
  IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
  if(!PopupShown(main,mainH))
   return Result("bulunamadi","'"+ad+"' Nebim'in Ara listesinde çıkmadı (bu kullanıcıda menü adı farklı olabilir). Hiçbir şey açılmadı.",titleBefore);
  // 6) Sonuç listesinden tam eşleşen satırı aç
  string how="";
  var item=FindResultItem(main,ad,box);
  if(item!=null){
   var r=item.Current.BoundingRectangle;
   if(!r.IsEmpty){DoubleClick((int)(r.X+Math.Min(r.Width/2,120)),(int)(r.Y+r.Height/2));how="liste-cift-tik";
    AutomationElement c1;bool acik=false;
    for(int i=0;i<8&&!acik;i++){Thread.Sleep(250);try{acik=ScreenOpen(main,ad,out c1);}catch{}}
    if(!acik&&PopupShown(main,mainH)){uint p1;GetWindowThreadProcessId(GetForegroundWindow(),out p1);if((int)p1==main.Current.ProcessId){Press(VK_RETURN);how="liste-tik-enter";Log("Çift tık açmadı; seçili satır Enter ile açıldı.");}}
   }
  }
  if(how==""){
   // Nebim tam adla yazınca listede satır seçili gelmiyor: Aşağı ile ilk (tam eşleşen) satırı seç, Enter ile aç.
   uint fgPid;GetWindowThreadProcessId(GetForegroundWindow(),out fgPid);
   if((int)fgPid!=main.Current.ProcessId)return Result("hata","Nebim penceresi önde değil (başka bir pencereye tıklanmış olabilir); durdum.",main.Current.Name);
   for(int k=0;k<sira;k++){Press(VK_DOWN);Thread.Sleep(200);}Thread.Sleep(100);
   Press(VK_RETURN);how=sira>1?"asagi-"+sira+"-enter":"asagi-enter";
  }
  // 7) Doğrula
  for(int i=0;i<30;i++){
   Thread.Sleep(250);
   AutomationElement c2;
   try{if(ScreenOpen(main,ad,out c2))return Result("acildi","Ekran açıldı ("+how+"). Bilgileri siz girin; kaydetme ve onay size ait.",main.Current.Name);}catch{}
   try{if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)&&((WindowPattern)wp).Current.WindowInteractionState==WindowInteractionState.BlockedByModalWindow)
    return Result("acildi-uyari","Ekran açılırken Nebim bir mesaj gösterdi (ör. 'Kayıt Bulunamadı'). Mesajı okuyup Tamam'a siz basın.",main.Current.Name);}catch{}
  }
  string title="";try{title=main.Current.Name;}catch{}
  if(title!=titleBefore&&title.StartsWith("Nebim V3 STORE - ",StringComparison.Ordinal)&&!title.EndsWith(" - "+ad,StringComparison.Ordinal)&&title.IndexOf(" - "+ad+" - ",StringComparison.Ordinal)<0)
   return Result("hata","Beklenmeyen ekran öne geldi: "+title.Substring(17)+". Hiçbir şey girmeden kapatabilirsiniz.",title);
  return Result("hata","Ekran 7 saniyede açılmadı. Ara kutusunda '"+ad+"' yazılı; listeden kendiniz çift tıklayabilirsiniz.",title);
 }
 static string FocusInfo(){try{var f=AutomationElement.FocusedElement;return f==null?"yok":f.Current.ControlType.ProgrammaticName+" ["+f.Current.Name+"] "+f.Current.BoundingRectangle;}catch(Exception e){return "okunamadı: "+e.Message;}}
 static void ClickAt(int x,int y){SetCursorPos(x,y);Thread.Sleep(60);Mouse(MOUSEEVENTF_LEFTDOWN);Thread.Sleep(30);Mouse(MOUSEEVENTF_LEFTUP);}
 // Ara kutusuna odaklan: önce UIA ile, olmazsa kutunun ortasına tek tık (yalnız Ara kutusuna).
 static bool FocusBox(AutomationElement box,IntPtr mainH){
  for(int k=0;k<4;k++){
   BringToFront(mainH);Thread.Sleep(120);
   try{box.SetFocus();}catch{}
   Thread.Sleep(200);if(IsFocused(box))return true;
   try{var r=box.Current.BoundingRectangle;if(!r.IsEmpty){ClickAt((int)(r.X+r.Width/2),(int)(r.Y+r.Height/2));Thread.Sleep(250);if(IsFocused(box))return true;}}catch{}
  }
  return false;
 }
 static bool PopupShown(AutomationElement main,IntPtr mainH){
  // Nebim'in Ara sonuç listesi STORE sürecine ait ayrı bir açılır pencere olarak öne gelir.
  IntPtr fg=GetForegroundWindow();uint pid;GetWindowThreadProcessId(fg,out pid);
  return fg!=mainH&&(int)pid==main.Current.ProcessId;
 }
 const ushort VK_ESCAPE=0x1B,VK_DELETE=0x2E;
 Dictionary<string,object> VerifyCatalog(){
  var main=FindStore();
  if(main==null)return Result("hata","Nebim V3 STORE açık değil.",null);
  if(PosInFront())return Result("hata","Kasa (POS) önde; doğrulama yapılmadı.",null);
  var box=FindSearchBox(main);if(box==null)return Result("hata","Ara kutusu bulunamadı.",null);
  IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
  var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
  var found=new List<string>();var missing=new List<string>();
  foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
   string name=Convert.ToString(((Dictionary<string,object>)o)["ad"]);
   var b2=FindSearchBox(main);if(b2!=null)box=b2;
   if(!FocusBox(box,mainH)){Log("Doğrulama durdu: odak Ara kutusunda değil. Odaktaki: "+FocusInfo());break;}
   Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(50);
   TypeText(name);Thread.Sleep(900);
   bool ok=PopupShown(main,mainH);
   (ok?found:missing).Add(name);
   Log("  doğrulama: "+(ok?"VAR  ":"YOK  ")+name);
   if(ok){Press(VK_ESCAPE);Thread.Sleep(250);}
   var b3=FindSearchBox(main);if(b3!=null)box=b3;
   if(FocusBox(box,mainH)){Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Press(VK_DELETE);}
   Thread.Sleep(200);
  }
  var r=Result(missing.Count==0?"acildi":"hata","Doğrulama bitti: "+found.Count+" ekran bulundu, "+missing.Count+" ekran bulunamadı"+(missing.Count>0?": "+string.Join(" · ",missing.ToArray()):"")+". Hiçbir ekran açılmadı.",null);
  r["bulunan"]=found;r["bulunamayan"]=missing;
  return r;
 }
 static AutomationElement FindResultItem(AutomationElement main,string ad,AutomationElement box){
  var sb=new StringBuilder();AutomationElement found=null;
  System.Windows.Rect br=System.Windows.Rect.Empty;try{br=box.Current.BoundingRectangle;}catch{}
  var roots=new List<AutomationElement>();
  try{
   int pid=main.Current.ProcessId;
   foreach(AutomationElement w in AutomationElement.RootElement.FindAll(TreeScope.Children,new PropertyCondition(AutomationElement.ProcessIdProperty,pid)))if(!Automation.Compare(w,main))roots.Add(w);
  }catch{}
  roots.Add(main); // 22.10: açılır sonuç listesi önce aranır; büyük ana pencere en son (yavaşlığı önler)
  int logged=0;
  foreach(var root in roots){
   AutomationElementCollection all;try{all=root.FindAll(TreeScope.Descendants,Condition.TrueCondition);}catch{continue;}
   foreach(AutomationElement e in all){
    System.Windows.Rect r;ControlType t;string n="",v="";
    try{r=e.Current.BoundingRectangle;t=e.Current.ControlType;}catch{continue;}
    if(r.IsEmpty||t==ControlType.Edit||t==ControlType.Window)continue;
    // Yalnız Ara kutusunun hemen altındaki sonuç listesi bölgesi
    bool near=!br.IsEmpty&&r.Top>=br.Bottom-2&&r.Top<=br.Bottom+600&&r.Left<br.Left+700;
    if(!near&&root==main)continue;
    try{n=e.Current.Name??"";}catch{}
    try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=((ValuePattern)vp).Current.Value??"";}catch{}
    if(logged<50){sb.AppendLine("  liste: "+t.ProgrammaticName.Replace("ControlType.","")+" ["+n+"] <"+v+"> "+(int)r.X+","+(int)r.Y+" "+(int)r.Width+"x"+(int)r.Height);logged++;}
    if(found==null&&(n==ad||v==ad))found=e;
    if(found!=null)break;
   }
   if(found!=null)break;
  }
  Log("Sonuç listesi ("+(found!=null?"eşleşme bulundu":"eşleşme yok")+"):"+Environment.NewLine+sb.ToString().TrimEnd());
  return found;
 }
}
