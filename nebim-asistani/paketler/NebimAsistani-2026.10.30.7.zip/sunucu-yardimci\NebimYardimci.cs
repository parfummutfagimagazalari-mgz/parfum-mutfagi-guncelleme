// =====================================================================================
// Nebim Asistanı — Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.
// Tasarım ve geliştirme: Ahmet Aksoy. Fikri ve ticari haklar Ahmet Aksoy'a aittir.
// Ahmet Aksoy'un yazılı izni olmadan değiştirilemez, kopyalanamaz, çoğaltılamaz,
// dağıtılamaz, satılamaz ve ticari olarak kullanılamaz. Ayrıntı: LISANS.txt
// =====================================================================================
// Nebim Yardımcı (sunucu tarafı v5.6 / v4.6) — Nebim V3 ERP ve Nebim V3 STORE'da:
//   1. Doğru Modül Seçimi + "Ara..." Kutusuna Yazma + Yaprak (Leaf) Menüye Çift Tıklama
//   2. Orta MDI Çalışma Alanında (relX > 320, relY > 145) 5 Saniye Akıllı Ekran/Kontrol Bekleme
//   3. Gürültü Filtresi ("Filtreler", "Ve" Yasağı) + İlk Veri Alanına Otomatik Odaklama (Auto-Focus)
//   4. RDP İçinde Doğrudan Tıklama-Geçirgen Renkli Çerçeve (RdpRenkliCerceveForm)
// KESİN SINIRLAR: veri alanına metin yazmaz; Kaydet / Onayla / Sil / Tamam'a basmaz;
//   POS (kasa) öndeyken tıklamaz, tuşa basmaz, ekran açmaz.
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows.Automation;
using System.Windows.Forms;
using Microsoft.Win32;
[assembly: System.Reflection.AssemblyTitle("Nebim Yardımcı (Nebim Asistanı)")]
[assembly: System.Reflection.AssemblyProduct("Nebim Asistanı")]
[assembly: System.Reflection.AssemblyCompany("Ahmet Aksoy")]
[assembly: System.Reflection.AssemblyCopyright("Copyright (c) 2026 Ahmet Aksoy. Tüm hakları saklıdır.")]
[assembly: System.Reflection.AssemblyTrademark("Nebim Asistanı — Ahmet Aksoy")]

public class NebimYardimci : ApplicationContext {
 public const string Surum="8.0";
 static DateTime lastZeroErrorSync=DateTime.MinValue;
 static string _cachedRoot=null;
 static string ResolveRoot(){
  if(!string.IsNullOrEmpty(_cachedRoot))return _cachedRoot;
  string ts=@"\\tsclient\N\araclar";
  try{if(Directory.Exists(ts)){_cachedRoot=ts;return _cachedRoot;}}catch{}
  string ad=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),@"Parfum Mutfagi\veri\nebim-gelen\araclar");
  try{if(Directory.Exists(ad)){_cachedRoot=ad;return _cachedRoot;}}catch{}
  _cachedRoot=ts;
  return _cachedRoot;
 }
 static string Root{get{return ResolveRoot();}}
 static string Kuyruk{get{return Path.Combine(Root,"kuyruk");}}
 static string Yerel{get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NebimYardimci");}}
 static string DurdurDosyasi{get{return Path.Combine(Root,"yardimci-durdur.txt");}}
 static readonly object logLock=new object();
 readonly NotifyIcon tray=new NotifyIcon();
 readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer {Interval=300};
 readonly Control invoker=new Control();
 RdpRenkliCerceveForm rdpOverlay;
 string rdpOverlayScreen="";
 HotkeyWindow hotkey;
 volatile bool busy;
 DateTime lastBeat=DateTime.MinValue,lastMaint=DateTime.MinValue;
 string lastResult="Henüz istek gelmedi.";

 // ---------- Win32 ----------
 [StructLayout(LayoutKind.Sequential)] struct MOUSEINPUT{public int dx;public int dy;public uint mouseData;public uint dwFlags;public uint time;public IntPtr dwExtraInfo;}
 [StructLayout(LayoutKind.Sequential)] struct KEYBDINPUT{public ushort wVk;public ushort wScan;public uint dwFlags;public uint time;public IntPtr dwExtraInfo;}
 [StructLayout(LayoutKind.Explicit)] struct InputUnion{[FieldOffset(0)]public MOUSEINPUT mi;[FieldOffset(0)]public KEYBDINPUT ki;}
 [StructLayout(LayoutKind.Sequential)] struct INPUT{public uint type;public InputUnion u;}
 [StructLayout(LayoutKind.Sequential)] struct WIN32_RECT{public int Left;public int Top;public int Right;public int Bottom;}
 [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint n,INPUT[] inputs,int size);
 [DllImport("user32.dll")] static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] static extern void mouse_event(uint dwFlags,uint dx,uint dy,uint dwData,UIntPtr dwExtraInfo);
 [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h,out uint pid);
 [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
 [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h,int id,uint mods,uint vk);
 [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h,int id);
 delegate bool EnumProc(IntPtr h,IntPtr l);
 [DllImport("user32.dll")] static extern bool EnumChildWindows(IntPtr parent,EnumProc cb,IntPtr l);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr h,StringBuilder sb,int max);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetClassName(IntPtr h,StringBuilder sb,int max);
 [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
 [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
 [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h,int cmd);
 [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h,out WIN32_RECT r);
 [DllImport("user32.dll")] static extern short GetAsyncKeyState(int vKey);
 const int SW_RESTORE=9,SW_SHOWMAXIMIZED=3;
 const uint KEYEVENTF_KEYUP=0x2,KEYEVENTF_UNICODE=0x4,MOUSEEVENTF_LEFTDOWN=0x2,MOUSEEVENTF_LEFTUP=0x4;
 const ushort VK_BACK=0x08,VK_TAB=0x09,VK_CONTROL=0x11,VK_A=0x41,VK_V=0x56,VK_DOWN=0x28,VK_RETURN=0x0D,VK_ESCAPE=0x1B,VK_DELETE=0x2E,VK_F5=0x74;
 static int InputSize{get{return Marshal.SizeOf(typeof(INPUT));}}
 static void Key(ushort vk,bool up){var i=new INPUT{type=1};i.u.ki=new KEYBDINPUT{wVk=vk,dwFlags=up?KEYEVENTF_KEYUP:0};SendInput(1,new[]{i},InputSize);}
 static void Press(ushort vk){Key(vk,false);Thread.Sleep(30);Key(vk,true);Thread.Sleep(30);}
 static void TypeText(string s){
  if(string.IsNullOrEmpty(s))return;
  foreach(char c in s){
   var d=new INPUT{type=1};d.u.ki=new KEYBDINPUT{wScan=c,dwFlags=KEYEVENTF_UNICODE};
   var u=new INPUT{type=1};u.u.ki=new KEYBDINPUT{wScan=c,dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP};
   SendInput(2,new[]{d,u},InputSize);Thread.Sleep(14);
  }
 }
 static void Mouse(uint flags){var i=new INPUT{type=0};i.u.mi=new MOUSEINPUT{dwFlags=flags};SendInput(1,new[]{i},InputSize);}
 static void PhysicalClick(int x,int y){
  SetCursorPos(x,y);Thread.Sleep(45);
  try{mouse_event(MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_LEFTUP,0,0,0,UIntPtr.Zero);}
  catch{Mouse(MOUSEEVENTF_LEFTDOWN);Thread.Sleep(25);Mouse(MOUSEEVENTF_LEFTUP);}
 }
 // ADIM 1.3: 80 ms arayla fiziksel çift sol tık
 static void PhysicalDoubleClick80ms(int x,int y){
  SetCursorPos(x,y);Thread.Sleep(45);
  for(int k=0;k<2;k++){
   try{mouse_event(MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_LEFTUP,0,0,0,UIntPtr.Zero);}
   catch{Mouse(MOUSEEVENTF_LEFTDOWN);Thread.Sleep(25);Mouse(MOUSEEVENTF_LEFTUP);}
   if(k==0)Thread.Sleep(80);
  }
 }
 static void DoubleClick(int x,int y){PhysicalDoubleClick80ms(x,y);}
 static string ProcessNameOf(IntPtr h){try{uint pid;GetWindowThreadProcessId(h,out pid);return Process.GetProcessById((int)pid).ProcessName;}catch{return "";}}
 static bool IsPosWindowTitle(string title){
  if(string.IsNullOrEmpty(title))return false;
  if(title.IndexOf("Nebim V3 POS",StringComparison.OrdinalIgnoreCase)>=0)return true;
  if(title.IndexOf("NebimV3POS",StringComparison.OrdinalIgnoreCase)>=0)return true;
  return false;
 }
 static bool PosInFront(){
  try{
   IntPtr fg=GetForegroundWindow();if(fg==IntPtr.Zero)return false;
   if(ProcessNameOf(fg).Equals("NebimV3POS",StringComparison.OrdinalIgnoreCase))return true;
   var sb=new StringBuilder(256);GetWindowText(fg,sb,256);
   return IsPosWindowTitle(sb.ToString());
  }catch{return false;}
 }

 // ---------- ADIM 4: RDP İçinde Doğrudan Çizilen Renkli Çerçeve (RdpRenkliCerceveForm) ----------
 public class RdpRenkliCerceveForm : Form {
  private Rectangle _lastRect=Rectangle.Empty;
  private string _lastStepText="";
  private bool _lastActionMode=false;

  public RdpRenkliCerceveForm(){
   FormBorderStyle=FormBorderStyle.None;
   ShowInTaskbar=false;
   TopMost=true;
   StartPosition=FormStartPosition.Manual;
   BackColor=Color.Magenta;
   TransparencyKey=Color.Magenta;
   DoubleBuffered=true;
   Bounds=new Rectangle(-2000,-2000,10,10);
  }
  protected override bool ShowWithoutActivation{get{return true;}}
  protected override CreateParams CreateParams{
   get{
    CreateParams p=base.CreateParams;
    p.ExStyle|=0x80000|0x20|0x08000000|0x80|0x8;
    return p;
   }
  }
  public void HideFrame(){
   if(Visible)Visible=false;
   _lastRect=Rectangle.Empty;
  }
  public void UpdateFrameTarget(Rectangle targetRect,string stepBadge,bool actionMode){
   if(targetRect.IsEmpty||targetRect.Width<=30||targetRect.Height<14||targetRect.Left<0||targetRect.Top<0){
    HideFrame();
    return;
   }
   string badge=stepBadge??"";
   bool posChanged=_lastRect.IsEmpty||
    Math.Abs(targetRect.Left-_lastRect.Left)>2||
    Math.Abs(targetRect.Top-_lastRect.Top)>2||
    Math.Abs(targetRect.Width-_lastRect.Width)>2||
    Math.Abs(targetRect.Height-_lastRect.Height)>2;
   bool stepChanged=!string.Equals(badge,_lastStepText,StringComparison.Ordinal)||(actionMode!=_lastActionMode);
   if(!posChanged&&!stepChanged&&Visible)return;

   _lastRect=targetRect;
   _lastStepText=badge;
   _lastActionMode=actionMode;

   int pad=5;
   int topBannerHeight=25;
   int x=Math.Max(0,targetRect.Left-pad);
   int y=Math.Max(0,targetRect.Top-pad-topBannerHeight);
   int w=Math.Max(230,targetRect.Width+pad*2);
   int h=targetRect.Height+pad*2+topBannerHeight;

   SetBounds(x,y,w,h);
   if(!Visible)Visible=true;
   Invalidate();
  }
  protected override void OnPaint(PaintEventArgs e){
   base.OnPaint(e);
   int topBannerHeight=25;
   Color primaryColor=_lastActionMode?Color.FromArgb(0,230,118):Color.FromArgb(255,140,0);
   if(!string.IsNullOrEmpty(_lastStepText)){
    Rectangle bannerRect=new Rectangle(0,0,Math.Min(Width-2,370),topBannerHeight-2);
    using(SolidBrush bgBrush=new SolidBrush(Color.FromArgb(22,28,40)))e.Graphics.FillRectangle(bgBrush,bannerRect);
    using(Pen borderPen=new Pen(primaryColor,2))e.Graphics.DrawRectangle(borderPen,bannerRect);
    using(Font f=new Font("Segoe UI",8.8f,FontStyle.Bold))
    using(SolidBrush textBrush=new SolidBrush(Color.White))e.Graphics.DrawString(_lastStepText,f,textBrush,new PointF(6,2));
   }
   Rectangle fieldBox=new Rectangle(2,topBannerHeight,Width-5,Height-topBannerHeight-3);
   if(fieldBox.Width>4&&fieldBox.Height>4){
    using(Pen framePen=new Pen(primaryColor,3))e.Graphics.DrawRectangle(framePen,fieldBox);
   }
  }
 }

 void ShowRdpFrameSafe(Rectangle r,string badge,bool isAction,string screenName){
  rdpOverlayScreen=screenName??"";
  try{
   invoker.BeginInvoke(new Action(()=>{
    try{
     if(rdpOverlay==null||rdpOverlay.IsDisposed)rdpOverlay=new RdpRenkliCerceveForm();
     rdpOverlay.UpdateFrameTarget(r,badge,isAction);
    }catch{}
   }));
  }catch{}
 }

 void HideRdpFrameSafe(){
  rdpOverlayScreen="";
  try{
   invoker.BeginInvoke(new Action(()=>{
    try{if(rdpOverlay!=null&&!rdpOverlay.IsDisposed)rdpOverlay.HideFrame();}catch{}
   }));
  }catch{}
 }

 // ---------- Başlangıç ----------
 [STAThread] public static int Main(string[] args){
  if(args.Length==1&&args[0]=="--self-test")return SelfTest();
  try{SetProcessDPIAware();}catch{}
  try{
   if(File.Exists(DurdurDosyasi)&&!RunningLocal()){File.Delete(DurdurDosyasi);Log("Durdurma işareti kaldırıldı (elle başlatıldı).");}
   if(!RunningLocal()&&File.Exists(Path.Combine(Root,"NebimYardimci-Baslat.cmd"))&&Directory.Exists(@"\\tsclient\N\araclar")){
    UpdateStartup();
    if(StartWatcher("elle başlatma")){Log("Elle başlatıldı: izleyici yerel kopyayı başlatacak.");return 0;}
   }
  }catch(Exception e){Log("Başlatıcı hatası: "+e.Message);}
  bool created;
  using(var m=new Mutex(true,"Local\\NebimYardimciV1",out created)){
   if(!created){if(!RunningLocal())MessageBox.Show("Nebim Yardımcı zaten çalışıyor (saatin yanındaki simge).","Nebim Yardımcı");return 0;}
   Application.EnableVisualStyles();Application.Run(new NebimYardimci());
  }
  return 0;
 }
 static bool RunningLocal(){
  try{
   string exe=Path.GetFullPath(Application.ExecutablePath);
   string tmp=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"NebimMCP"));
   return exe.StartsWith(Path.GetFullPath(Yerel),StringComparison.OrdinalIgnoreCase)||exe.StartsWith(tmp,StringComparison.OrdinalIgnoreCase);
  }catch{return false;}
 }
 static bool IsNebimTitle(string t){
  if(string.IsNullOrEmpty(t))return false;
  return t.IndexOf("Nebim V3 STORE",StringComparison.OrdinalIgnoreCase)>=0||t.IndexOf("Nebim V3 ERP",StringComparison.OrdinalIgnoreCase)>=0;
 }
 static string StripNebimTitle(string title){
  title=(title??"").Trim();
  string ad="";
  if(title.StartsWith("Nebim V3 STORE - ",StringComparison.OrdinalIgnoreCase))ad=title.Substring(17);
  else if(title.EndsWith(" - Nebim V3 STORE",StringComparison.OrdinalIgnoreCase))ad=title.Substring(0,title.Length-17);
  else if(title.StartsWith("Nebim V3 ERP - ",StringComparison.OrdinalIgnoreCase))ad=title.Substring(15);
  else if(title.EndsWith(" - Nebim V3 ERP",StringComparison.OrdinalIgnoreCase))ad=title.Substring(0,title.Length-15);
  else ad=title;
  return ad.Trim().TrimStart('[').TrimEnd(']').Trim();
 }
 static int SelfTest(){
  if(InputSize!=(IntPtr.Size==8?40:28))return 3;
  if(Norm("Mağaza Sayım Fişi")!="magaza sayim fisi")return 4;
  if(!IsTotalLike("Genel Toplam")||!IsTotalLike("Kredi Kartı (Garanti)")||IsTotalLike("Ahmet Yılmaz"))return 5;
  if(Bracket("[Başlangıç Tarihi]")!="Başlangıç Tarihi"||Bracket("Bugün")!="")return 6;
  if(!IsNebimTitle("Nebim V3 STORE - Mağaza")||!IsNebimTitle("Nebim V3 ERP - Merkez")||IsNebimTitle("Not Defteri"))return 9;
  if(StripNebimTitle("Nebim V3 ERP - [Madde Kartları]")!="Madde Kartları"||StripNebimTitle("Nebim V3 STORE - Mağaza Sayım Fişi")!="Mağaza Sayım Fişi")return 10;
  return 0;
 }
 public static string Norm(string s){
  var sb=new StringBuilder();
  foreach(char ch in (s??"").Trim()){
   char c=ch;
   switch(c){case 'İ':case 'I':case 'ı':c='i';break;case 'Ş':case 'ş':c='s';break;case 'Ğ':case 'ğ':c='g';break;case 'Ü':case 'ü':c='u';break;case 'Ö':case 'ö':c='o';break;case 'Ç':case 'ç':c='c';break;default:c=char.ToLowerInvariant(c);break;}
   sb.Append(c);
  }
  return sb.ToString();
 }
 static string Bracket(string n){n=(n??"").Trim();return n.Length>2&&n[0]=='['&&n[n.Length-1]==']'?n.Substring(1,n.Length-2):"";}
 public NebimYardimci(){
  invoker.CreateControl();var forceHandle=invoker.Handle;
  rdpOverlay=new RdpRenkliCerceveForm();
  tray.Icon=SystemIcons.Information;tray.Text="Nebim Yardımcı "+Surum;tray.Visible=true;
  var menu=new ContextMenuStrip();
  menu.Items.Add("Durum",null,(s,e)=>tray.ShowBalloonTip(6000,"Nebim Yardımcı "+Surum,lastResult,ToolTipIcon.Info));
  menu.Items.Add("Güncelle",null,(s,e)=>GuncelleYardimciSimdi());
  menu.Items.Add("Çerçeveyi Gizle",null,(s,e)=>HideRdpFrameSafe());
  menu.Items.Add("Yeniden başlat",null,(s,e)=>{Log("Tepsiden yeniden başlatıldı.");Quit();});
  menu.Items.Add("Çıkış (kendiliğinden açılmaz)",null,(s,e)=>{try{File.WriteAllText(DurdurDosyasi,DateTime.Now.ToString("s")+" tepsiden çıkış",new UTF8Encoding(false));}catch{}Log("Tepsiden çıkış: izleyici yeniden başlatmayacak.");Quit();});
  tray.ContextMenuStrip=menu;
  try{Directory.CreateDirectory(Kuyruk);foreach(string f in Directory.GetFiles(Kuyruk,"istek-*.json")){try{if((DateTime.UtcNow-File.GetLastWriteTimeUtc(f)).TotalSeconds>120){File.Delete(f);Log("Eski istek çalıştırılmadan silindi: "+Path.GetFileName(f));}}catch{}}}
  catch(Exception e){Log("Kuyruk klasörü açılamadı: "+e.Message);}
  Log("Başladı. Sürüm "+Surum+", kullanıcı "+Environment.UserName+(RunningLocal()?" (yerel/gölge kopya, izleyicili)":" (uzak sürücüden)"));
  if(!File.Exists(Path.Combine(Root,"kisayol-kapali.txt"))){
   hotkey=new HotkeyWindow();
   hotkey.Pressed+=()=>{try{File.WriteAllText(Path.Combine(Root,"kisayol.txt"),DateTime.Now.Ticks.ToString(),new UTF8Encoding(false));}catch{}};
   if(!RegisterHotKey(hotkey.Handle,1,0x0002|0x4000,0x20)){Log("Ctrl+Boşluk kısayolu alınamadı (başka program kullanıyor olabilir).");hotkey.DestroyHandle();hotkey=null;}
  }
  UpdateStartup();
  lastBeat=DateTime.Now;
  timer.Tick+=(s,e)=>Tick();timer.Start();
  var wd=new Thread(WatchdogLoop){IsBackground=true};wd.Start();
  tray.ShowBalloonTip(4000,"Nebim Yardımcı "+Surum+" hazır","Modül seçimi, yaprak menü açma, 5 sn MDI bekleme, oto-odak ve RDP çerçevesi hazır.",ToolTipIcon.Info);
 }
 void GuncelleYardimciSimdi(){
  try{
   string srcExe=Path.Combine(Root,"NebimYardimci.exe");
   string localDir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"NebimYardimci");
   Directory.CreateDirectory(localDir);
   string cmdSrc=Path.Combine(Root,"NebimYardimci-Baslat.cmd");
   if(File.Exists(cmdSrc)){try{File.Copy(cmdSrc,Path.Combine(localDir,"izleyici.cmd"),true);}catch{}}
   ThreadPool.QueueUserWorkItem(_=>{try{RunSqlReadAndDiagnostics(new Dictionary<string,object>{{"islem","sql-oku"}});}catch{}});
   if(File.Exists(srcExe)&&RunningLocal()){
    var a=new FileInfo(srcExe);var b=new FileInfo(Application.ExecutablePath);
    if(a.Length!=b.Length||Math.Abs((a.LastWriteTimeUtc-b.LastWriteTimeUtc).TotalSeconds)>2){
     tray.ShowBalloonTip(4000,"Nebim Yardımcı · Güncelle","Yeni sürüm bulundu; yardımcı birkaç saniye içinde güncellenip yeniden açılacak.",ToolTipIcon.Info);
     Log("Tepsiden Güncelle seçildi: yeni sürüm için kapanıyor.");
     Quit();
     return;
    }
   }
   tray.ShowBalloonTip(4000,"Nebim Yardımcı "+Surum,"Yardımcı güncel (sürüm "+Surum+"). SQL (PM_V3) verileri yenileniyor.",ToolTipIcon.Info);
  }catch(Exception ex){
   tray.ShowBalloonTip(4000,"Güncelleme Uyarısı",ex.Message,ToolTipIcon.Warning);
  }
 }
 void WatchdogLoop(){
  while(true){
   Thread.Sleep(6000);
   try{
    if(!busy&&(DateTime.Now-lastBeat).TotalSeconds>28){
     Log("[WATCHDOG] Ana UI/UIA döngüsü 28 sn yanıt vermedi; gölge kopyadan otomatik yeniden başlatılıyor.");
     SpawnSelfUpdateAndExit();
     return;
    }
   }catch{}
  }
 }
 static void SpawnSelfUpdateAndExit(){
  try{
   string src=Path.Combine(Root,"NebimYardimci.exe");
   string dstDir=Path.Combine(Path.GetTempPath(),"NebimMCP");
   Directory.CreateDirectory(dstDir);
   string dst=Path.Combine(dstDir,"NebimYardimci.exe");
   if(!File.Exists(src))src=Application.ExecutablePath;
   string cmdArgs="/c ping 127.0.0.1 -n 2 >nul & copy /Y \""+src+"\" \""+dst+"\" >nul 2>&1 & start \"\" \""+dst+"\"";
   var psi=new ProcessStartInfo("cmd.exe",cmdArgs){UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden};
   Process.Start(psi);
  }catch{}
  try{Environment.Exit(0);}catch{}
 }
 void Quit(){
  timer.Stop();
  try{if(rdpOverlay!=null&&!rdpOverlay.IsDisposed)rdpOverlay.Close();}catch{}
  if(hotkey!=null){try{UnregisterHotKey(hotkey.Handle,1);hotkey.DestroyHandle();}catch{}}
  tray.Visible=false;ExitThread();
 }
 class HotkeyWindow:NativeWindow{
  public event Action Pressed;
  public HotkeyWindow(){CreateHandle(new CreateParams());}
  protected override void WndProc(ref Message m){if(m.Msg==0x0312&&Pressed!=null)Pressed();base.WndProc(ref m);}
 }
 static void Log(string line){
  lock(logLock){
   try{
    string p=Path.Combine(Root,"yardimci-log.txt");
    var fi=new FileInfo(p);if(fi.Exists&&fi.Length>400000){File.Delete(p);}
    File.AppendAllText(p,DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+line+Environment.NewLine,new UTF8Encoding(false));
   }catch{}
  }
 }
 // ---------- İzleyici / güncelleme ----------
 static bool StartWatcher(string why){
  try{
   string cmd=Path.Combine(Root,"NebimYardimci-Baslat.cmd");if(!File.Exists(cmd))return false;
   Directory.CreateDirectory(Yerel);
   string local=Path.Combine(Yerel,"NebimYardimci-Baslat.cmd");File.Copy(cmd,local,true);
   var psi=new ProcessStartInfo("cmd.exe","/c \""+local+"\"") {UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=Yerel};
   Process.Start(psi);Log("İzleyici başlatıldı ("+why+").");return true;
  }catch(Exception e){Log("İzleyici başlatılamadı: "+e.Message);return false;}
 }
 static void UpdateStartup(){
  try{
   string src=Path.Combine(Root,"NebimYardimci-Baslat.cmd");if(!File.Exists(src))return;
   string text=File.ReadAllText(src,Encoding.Default);
   string startup=Environment.GetFolderPath(Environment.SpecialFolder.Startup);
   string target=Path.Combine(startup,"NebimYardimci-Baslat.cmd");
   foreach(string f in Directory.GetFiles(startup,"*.cmd")){try{if(File.ReadAllText(f,Encoding.Default).IndexOf("NebimYardimci",StringComparison.OrdinalIgnoreCase)>=0){target=f;break;}}catch{}}
   if(File.Exists(target)&&File.ReadAllText(target,Encoding.Default)==text)return;
   File.WriteAllText(target,text,Encoding.Default);Log("Açılış başlatıcısı güncellendi: "+target);
  }catch(Exception e){Log("Açılış başlatıcısı güncellenemedi: "+e.Message);}
 }
 void Maintenance(){
  if(!RunningLocal())return;
  try{
   var share=new FileInfo(Path.Combine(Root,"NebimYardimci.exe"));var me=new FileInfo(Application.ExecutablePath);
   if(share.Exists&&!busy&&(share.Length!=me.Length||share.LastWriteTimeUtc>me.LastWriteTimeUtc.AddSeconds(2))){Log("Yeni sürüm bulundu; gölge kopya kendi kendini yeniden başlatıyor.");SpawnSelfUpdateAndExit();Quit();return;}
  }catch{}
  try{
   var beat=new FileInfo(Path.Combine(Yerel,"izleyici-nabiz.txt"));
   if(!beat.Exists||(DateTime.Now-beat.LastWriteTime).TotalSeconds>90)StartWatcher("izleyici nabzı yok");
  }catch{}
 }
 static bool StoreOpen(){return FindStore()!=null;}
 void Tick(){
  if((DateTime.Now-lastMaint).TotalSeconds>=12){lastMaint=DateTime.Now;Maintenance();}

  // ADIM 4: POS öndeyse veya Escape/F5 basıldıysa çerçeveyi anında gizle
  if(PosInFront()){
   if(rdpOverlay!=null&&rdpOverlay.Visible)rdpOverlay.HideFrame();
  }

  if((DateTime.Now-lastBeat).TotalSeconds>=1.5){
   lastBeat=DateTime.Now;
   bool store=false,pos=false;AutomationElement mainNow=null;try{mainNow=FindStore();store=mainNow!=null;}catch{}
   try{pos=PosInFront();}catch{}
   bool sqlReady=!string.IsNullOrEmpty(CachedWorkingConnString);
    var beat=new Dictionary<string,object>{{"surum",Surum},{"zaman",DateTime.Now.ToString("s")},{"store",store},{"erp",store},{"sql",sqlReady},{"mesgul",busy},{"pos",pos},{"kullanici",Environment.UserName},{"kisayol",hotkey!=null}};
   if(mainNow!=null&&!busy){
    try{ObserveScreens(mainNow);}catch(Exception e){Log("Ekran izleme hatası: "+e.Message);}
    string curScr="";
    try{curScr=ActiveName(mainNow);}catch{curScr="";}
    beat["ekran"]=curScr;
    // ADIM 2 & ADIM 4: Orta MDI çalışma alanında gerçek açık ekran yoksa çerçeveyi anında gizle
    if(string.IsNullOrEmpty(curScr)){
     if(rdpOverlay!=null&&rdpOverlay.Visible)rdpOverlay.HideFrame();
    }else{
     try{
      IntPtr mh=new IntPtr(mainNow.Current.NativeWindowHandle);
      if(mh!=IntPtr.Zero&&IsIconic(mh)&&rdpOverlay!=null&&rdpOverlay.Visible)rdpOverlay.HideFrame();
     }catch{}
    }
    try{var f=FocusDescription(mainNow);if(f!=null)beat["odak"]=f;}catch{}
    try{var w=ModalWarning(mainNow);if(w!=null)beat["uyari"]=w;}catch{}
   } else if(mainNow==null){
    beat["ekran"]="";
    if(rdpOverlay!=null&&rdpOverlay.Visible)rdpOverlay.HideFrame();
   }
   try{File.WriteAllText(Path.Combine(Root,"yardimci-durum.json"),new JavaScriptSerializer().Serialize(beat),new UTF8Encoding(false));}catch{}
   if(!busy&&(DateTime.Now-lastZeroErrorSync).TotalMinutes>=10){
    lastZeroErrorSync=DateTime.Now;
    // Arka planda UIA ağacına dokunmadan yalnızca durum raporunu güncelle
    ThreadPool.QueueUserWorkItem(delegate{RunPeriodicZeroErrorMaintenance(false);});
   }
  }
  if(busy)return;
  string[] files;try{files=Directory.GetFiles(Kuyruk,"istek-*.json");}catch{return;}
  if(files.Length==0)return;
  Array.Sort(files);
  string file=files[0];
  string raw;try{raw=File.ReadAllText(file,Encoding.UTF8);File.Delete(file);}catch{return;}
  busy=true;
  var t2=new Thread(()=>{try{Handle(raw);}finally{busy=false;}});
  t2.SetApartmentState(ApartmentState.STA);t2.IsBackground=true;t2.Start();
 }
 static Dictionary<string,object> FocusDescription(AutomationElement main){
  var f=AutomationElement.FocusedElement;if(f==null)return null;
  if(f.Current.ProcessId!=main.Current.ProcessId)return null;
  var t=f.Current.ControlType;
  bool valueLike=t==ControlType.Edit||t==ControlType.ComboBox||t==ControlType.Document||t==ControlType.DataItem||t==ControlType.Custom||t==ControlType.Text||t==ControlType.ListItem||t==ControlType.TreeItem;
  var d=new Dictionary<string,object>{{"tur",t.ProgrammaticName.Replace("ControlType.","")},{"id",f.Current.AutomationId??""}};
  if(!valueLike)d["ad"]=Short(f.Current.Name);
  var walker=TreeWalker.ControlViewWalker;
  try{
   AutomationElement p=walker.GetPreviousSibling(f);
   for(int i=0;i<4&&p!=null;i++){string b=Bracket(p.Current.Name);if(b.Length>0){d["alan"]=Short(b);break;}p=walker.GetPreviousSibling(p);}
  }catch{}
  var up=new List<string>();
  try{
   AutomationElement a=walker.GetParent(f);
   for(int i=0;i<6&&a!=null;i++){
    var at=a.Current.ControlType;string n=(a.Current.Name??"").Trim();
    if(n.Length>0&&n.Length<=60&&(at==ControlType.Pane||at==ControlType.Group||at==ControlType.Tab||at==ControlType.TabItem||at==ControlType.Window)&&!Automation.Compare(a,main))up.Add(n);
    if(Automation.Compare(a,main))break;a=walker.GetParent(a);
   }
  }catch{}
  d["ust"]=up;
  return d;
 }
 static string Short(string s){s=(s??"").Replace("\r"," ").Replace("\n"," ").Trim();return s.Length>80?s.Substring(0,80):s;}
 static string lastWarnDump="";
 static IntPtr lastDlgHandle=IntPtr.Zero;static string lastDlgText="";
 static bool HasInputs(AutomationElement dlg){
  try{foreach(AutomationElement e in dlg.FindAll(TreeScope.Descendants,Condition.TrueCondition)){var t=e.Current.ControlType;if(t==ControlType.Edit||t==ControlType.ComboBox||t==ControlType.Document||t==ControlType.List||t==ControlType.DataGrid)return true;}}catch{return true;}
  return false;
 }
 static string CopyDialogText(string title){
  string old=null;bool hadText=false;
  try{if(Clipboard.ContainsText()){old=Clipboard.GetText();hadText=true;}}catch{}
  string got="";
  try{
   try{Clipboard.Clear();}catch{}
   Key(VK_CONTROL,false);Press(0x43);Key(VK_CONTROL,true);
   for(int i=0;i<8&&got.Length==0;i++){Thread.Sleep(80);try{if(Clipboard.ContainsText())got=Clipboard.GetText();}catch{}}
  }finally{
   try{if(hadText)Clipboard.SetText(old);else Clipboard.Clear();}catch{}
  }
  var lines=new List<string>();
  foreach(string l in got.Replace("\r","").Split('\n')){string x=l.Trim().Trim('-').Trim();if(x.Length>0&&x!=title&&x!="Tamam"&&x!="OK"&&x!="Evet"&&x!="Hayır"&&x!="İptal")lines.Add(x);}
  string r=string.Join(" ",lines.ToArray());return r.Length>400?r.Substring(0,400):r;
 }
 static Dictionary<string,object> ModalWarning(AutomationElement main){
  object wp;if(!main.TryGetCurrentPattern(WindowPattern.Pattern,out wp))return null;
  if(((WindowPattern)wp).Current.WindowInteractionState!=WindowInteractionState.BlockedByModalWindow){lastWarnDump="";lastDlgHandle=IntPtr.Zero;return null;}
  int pid=main.Current.ProcessId;AutomationElement dlg=null;
  foreach(AutomationElement w in AutomationElement.RootElement.FindAll(TreeScope.Children,new PropertyCondition(AutomationElement.ProcessIdProperty,pid)))if(!Automation.Compare(w,main)){dlg=w;break;}
  if(dlg==null){try{dlg=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Window));}catch{}}
  if(dlg==null){lastWarnDump="";lastDlgHandle=IntPtr.Zero;return new Dictionary<string,object>{{"baslik",""},{"metin",""},{"dugmeler",new List<string>()}};}
  var texts=new List<string>();var buttons=new List<string>();int len=0;
  string title="";try{title=(dlg.Current.Name??"").Trim();}catch{}
  var diag=new StringBuilder();bool dump=title!=lastWarnDump;
  foreach(AutomationElement e in dlg.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
   try{
    var t=e.Current.ControlType;string n=(e.Current.Name??"").Trim(),v="";
    try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=(((ValuePattern)vp).Current.Value??"").Trim();}catch{}
    if(dump&&diag.Length<6000)diag.AppendLine("  "+t.ProgrammaticName.Replace("ControlType.","")+" ["+Short(n)+"] <"+Short(v)+"> sinif="+e.Current.ClassName+" id="+e.Current.AutomationId);
    if(t==ControlType.Button){if(buttons.Count<6&&n.Length>0&&n.Length<30)buttons.Add(n);continue;}
    if(t==ControlType.TitleBar||t==ControlType.MenuBar||t==ControlType.MenuItem||t==ControlType.ScrollBar)continue;
    foreach(string x in new[]{n,v})if(x.Length>0&&x!=title&&len<400&&!texts.Contains(x)){texts.Add(x);len+=x.Length;}
   }catch{}
  }
  try{
   IntPtr h=new IntPtr(dlg.Current.NativeWindowHandle);
   if(h!=IntPtr.Zero)EnumChildWindows(h,(c,l)=>{
    try{
     if(!IsWindowVisible(c))return true;
     var sb=new StringBuilder(512);GetWindowText(c,sb,512);string x=sb.ToString().Trim();
     var cn=new StringBuilder(128);GetClassName(c,cn,128);
     if(dump&&diag.Length<8000)diag.AppendLine("  win32 sinif="+cn+" ["+Short(x)+"]");
     if(x.Length>0&&x!=title&&!buttons.Contains(x)&&cn.ToString().IndexOf("BUTTON",StringComparison.OrdinalIgnoreCase)<0&&len<400&&!texts.Contains(x)){texts.Add(x);len+=x.Length;}
    }catch{}
    return true;
   },IntPtr.Zero);
  }catch{}
  if(texts.Count==0){
   try{
    IntPtr dh=new IntPtr(dlg.Current.NativeWindowHandle);
    if(dh==lastDlgHandle)texts.Add(lastDlgText);
    else if(dh!=IntPtr.Zero&&GetForegroundWindow()==dh&&!HasInputs(dlg)&&buttons.Count<=4){
     lastDlgHandle=dh;lastDlgText=CopyDialogText(title);
     if(lastDlgText.Length>0)texts.Add(lastDlgText);
     if(dump&&diag.Length<9000)diag.AppendLine("  ctrl+c metni: ["+Short(lastDlgText)+"]");
    }
   }catch{}
  }
  if(dump){lastWarnDump=title;try{File.WriteAllText(Path.Combine(Root,"uyari-tani.txt"),"Uyarı penceresi tanısı "+DateTime.Now.ToString("s")+" başlık=["+title+"]"+Environment.NewLine+diag.ToString(),new UTF8Encoding(false));}catch{}}
  string metin=string.Join(" ",texts.ToArray());if(metin.Length>400)metin=metin.Substring(0,400);
  return new Dictionary<string,object>{{"baslik",Short(dlg.Current.Name)},{"metin",metin},{"dugmeler",buttons}};
 }

 // ---------- İstek işleme ----------
 void Handle(string raw){
  var js=new JavaScriptSerializer{MaxJsonLength=4*1024*1024};
  string id="",ad="";
  Dictionary<string,object> result;
  try{
   var req=js.Deserialize<Dictionary<string,object>>(raw);
   id=Convert.ToString(req.ContainsKey("id")?req["id"]:"");
   string ekranId=Convert.ToString(req.ContainsKey("ekran")?req["ekran"]:"");
   if(id.Length==0||id.Length>64||id.IndexOfAny(Path.GetInvalidFileNameChars())>=0)throw new Exception("Geçersiz istek kimliği.");
   string islem=Convert.ToString(req.ContainsKey("islem")?req["islem"]:"ac");
   if(islem=="merkez-ekran-ac"){
    ad=Convert.ToString(req.ContainsKey("baslik")?req["baslik"]:(req.ContainsKey("ad")?req["ad"]:ekranId));
    Log("İstek "+id+" [merkez-ekran-ac]: '"+ad+"'");
    result=OpenMerkezScreen(req);
   }
   else if(islem=="cerceve-gizle"){
    HideRdpFrameSafe();
    result=Result("acildi","RDP çerçevesi gizlendi.",null);
   }
   else if(islem=="cerceve-adim"){
    int sol=req.ContainsKey("sol")?Convert.ToInt32(req["sol"]):0;
    int ust=req.ContainsKey("ust")?Convert.ToInt32(req["ust"]):0;
    int gen=req.ContainsKey("genislik")?Convert.ToInt32(req["genislik"]):0;
    int yuk=req.ContainsKey("yukseklik")?Convert.ToInt32(req["yukseklik"]):0;
    string etiket=Convert.ToString(req.ContainsKey("etiket")?req["etiket"]:(req.ContainsKey("rozet")?req["rozet"]:""));
    bool aks=req.ContainsKey("aksiyonMu")&&Convert.ToBoolean(req["aksiyonMu"]);
    if(gen>30&&yuk>=14){
     ShowRdpFrameSafe(new Rectangle(sol,ust,gen,yuk),etiket,aks,rdpOverlayScreen);
     if(!aks){PhysicalClick(sol+Math.Min(25,gen/2),ust+yuk/2);}
    }else{
     HideRdpFrameSafe();
    }
    result=Result("gosterildi","RDP çerçevesi güncellendi.",null);
   }
   else if(islem=="dogrula"){Log("İstek "+id+": katalog doğrulama");result=VerifyCatalog();}
   else if(islem=="ara"){string metin=Convert.ToString(req.ContainsKey("metin")?req["metin"]:"");Log("İstek "+id+": Ara listesinde arama '"+metin+"'");result=SearchOnly(metin);}
   else if(islem=="goster"){string alan=Convert.ToString(req.ContainsKey("alan")?req["alan"]:"");Log("İstek "+id+": alan göster '"+alan+"'");result=ShowField(alan);}
   else if(islem=="oku"){Log("İstek "+id+": açık rapordan toplam okuma");result=ReadReport();}
   else if(islem=="personel-oku"){Log("İstek "+id+": personel/prim okuma bu sürümde devre dışı");result=Result("devre-disi","Personel ve prim aktarımı bu sürümden kaldırılmıştır.",null);}
   else if(islem=="ozet"){Log("İstek "+id+": SQL / Hareket Özeti oku");result=RunSummary(req);}
   else if(islem=="kesfet"){Log("İstek "+id+": sol menü ağacı keşfi");result=ExploreMenus();}
   else if(islem=="ekran-analiz"){Log("İstek "+id+": açık ekran alan/sekme analizi");result=InspectOpenScreen();}
   else if(islem=="sistem-onar"){Log("İstek "+id+": sistem bütünlüğü onarım ve önbellek temizliği");result=RunHelperSystemRestore();}
    else if(islem=="sql-oku"||islem=="sql-tani"){Log("Istek "+id+": ["+islem+"] dogrudan SQL salt-okunur veri ve baglanti analizi");result=RunSqlReadAndDiagnostics(req);}
   else if(islem=="nabiz"){result=Result("acildi","Yardımcı çalışıyor (sürüm "+Surum+").",null);}
   else{
    if(req.ContainsKey("baslik")||req.ContainsKey("araMetni")){
     ad=Convert.ToString(req.ContainsKey("baslik")?req["baslik"]:(req.ContainsKey("ad")?req["ad"]:ekranId));
     Log("İstek "+id+" [ac->merkez]: '"+ad+"'");
     result=OpenMerkezScreen(req);
    }else{
     try{ad=CatalogName(ekranId);}
     catch{
      string fallbackAd=Convert.ToString(req.ContainsKey("ad")?req["ad"]:"");
      if(fallbackAd.Length>=2){req["baslik"]=fallbackAd;ad=fallbackAd;result=OpenMerkezScreen(req);goto DoneHandle;}
      throw;
     }
     int sira=CatalogSira(ekranId);
     Log("İstek "+id+": "+ad+(sira>1?" (listede "+sira+". satır)":""));
     result=OpenScreen(ad,sira);
    }
   }
  }catch(Exception e){HideRdpFrameSafe();result=Result("hata",e.Message,null);result["ekranAcildi"]=false;}
  DoneHandle:
  result["id"]=id;if(!result.ContainsKey("ekran")||Convert.ToString(result["ekran"]).Length==0)result["ekran"]=ad;
  result["zaman"]=DateTime.Now.ToString("s");result["surum"]=Surum;
  lastResult=(ad.Length>0?ad+": ":"")+Convert.ToString(result["mesaj"]);
  Log("Sonuç "+id+": "+result["durum"]+" — "+result["mesaj"]);
  if(id.Length>0){
   try{
    string tmpRes=Path.Combine(Kuyruk,"sonuc-"+id+".tmp");
    string finalRes=Path.Combine(Kuyruk,"sonuc-"+id+".json");
    File.WriteAllText(tmpRes,js.Serialize(result),new UTF8Encoding(false));
    if(File.Exists(finalRes))File.Delete(finalRes);
    File.Move(tmpRes,finalRes);
   }catch(Exception e){Log("Sonuç yazılamadı: "+e.Message);}
  }
 }
 static Dictionary<string,object> Result(string durum,string mesaj,string baslik){
  return new Dictionary<string,object>{{"ok",durum=="acildi"||durum=="zaten-acik"||durum=="acildi-uyari"||durum=="liste-acik"||durum=="okundu"||durum=="gosterildi"||durum=="kesfedildi"},{"durum",durum},{"mesaj",mesaj},{"baslik",baslik??""}};
 }

 // =====================================================================================
 // ADIM 1, ADIM 2, ADIM 3, ADIM 4: v4.6 KESİN MERKEZ EKRAN AÇMA VE OTO-ODAKLAMA MOTORU
 // =====================================================================================
 Dictionary<string,object> MerkezFail(string mesaj,string hedefBaslik){
  HideRdpFrameSafe();
  var r=Result("hata",mesaj,hedefBaslik);
  r["ekranAcildi"]=false;
  r["rdpCerceveAktif"]=false;
  r["acilanEkran"]="";
  r["ilkAlanAdi"]="";
  r["alanSol"]=0;r["alanUst"]=0;r["alanGenislik"]=0;r["alanYukseklik"]=0;
  r["relLeft"]=0;r["relTop"]=0;
  return r;
 }

 static AutomationElement FindErpOrStoreWindow(bool preferErp){
  return FindStoreInternal(preferErp);
 }

 Dictionary<string,object> OpenMerkezScreen(Dictionary<string,object> req){
  HideRdpFrameSafe();
  string baslik=Convert.ToString(req.ContainsKey("baslik")?req["baslik"]:(req.ContainsKey("ad")?req["ad"]:(req.ContainsKey("ekran")?req["ekran"]:""))).Trim();
  string araMetni=Convert.ToString(req.ContainsKey("araMetni")?req["araMetni"]:"").Trim();
  string kategori=Convert.ToString(req.ContainsKey("kategori")?req["kategori"]:"").Trim();
  string menuYolu=Convert.ToString(req.ContainsKey("menuYolu")?req["menuYolu"]:"").Trim();
  string ilkVeriAlani=Convert.ToString(req.ContainsKey("ilkVeriAlani")?req["ilkVeriAlani"]:"").Trim();
  int sira=1;
  try{if(req.ContainsKey("sira"))sira=Math.Max(1,Math.Min(12,Convert.ToInt32(req["sira"])));}catch{sira=1;}

  if(baslik.Length==0&&araMetni.Length>0)baslik=araMetni;
  if(araMetni.Length==0)araMetni=baslik;
  if(kategori.Length==0&&menuYolu.IndexOf('>')>0){
   kategori=menuYolu.Substring(0,menuYolu.IndexOf('>')).Trim();
  }
  if(baslik.Length<2)return MerkezFail("Açılacak ekran başlığı en az 2 karakter olmalıdır.",baslik);

  // Kasa (POS) öndeyse kesinlikle dokunma
  if(PosInFront())return MerkezFail("Kasa (NebimV3POS) ekranı önde; güvenlik nedeniyle işlem yapılmadı.",baslik);

  bool preferErp=!req.ContainsKey("ekran")||string.IsNullOrEmpty(Convert.ToString(req["ekran"]).Trim());
  var main=FindErpOrStoreWindow(preferErp);
  if(main==null)main=FindErpOrStoreWindow(!preferErp);
  if(main==null){
   LogMissingErpDiagnostics();
   return MerkezFail("RDP içinde 'Nebim V3 ERP' veya 'Nebim V3 STORE' penceresi açık değil.",baslik);
  }

  IntPtr mainH=IntPtr.Zero;
  try{mainH=new IntPtr(main.Current.NativeWindowHandle);}catch{}
  if(mainH!=IntPtr.Zero&&IsIconic(mainH)){
   ShowWindow(mainH,SW_RESTORE);
   Thread.Sleep(250);
  }
  object wp;
  if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)){
   var w=(WindowPattern)wp;
   if(w.Current.WindowInteractionState==WindowInteractionState.BlockedByModalWindow)
    return MerkezFail("Nebim V3 ERP'de açık bir soru/uyarı penceresi var; önce onu kapatın.",baslik);
   if(w.Current.WindowVisualState==WindowVisualState.Minimized){
    try{w.SetWindowVisualState(WindowVisualState.Maximized);Thread.Sleep(350);}catch{}
   }
  }
  if(mainH!=IntPtr.Zero){BringToFront(mainH);Thread.Sleep(150);}

  System.Windows.Rect erpWinRect=GetElementOrWindowRect(main,mainH);
  if(erpWinRect.IsEmpty||erpWinRect.Width<300){
   erpWinRect=new System.Windows.Rect(0,0,1920,1040);
  }

  // Eğer hedef ekran orta çalışma alanında (relX > 320, relY > 145) gerçekten açık ve kontrolleri yüklüyse öne getir
  AutomationElement existingChild=null;
  if(ScreenOpen(main,baslik,out existingChild)||(araMetni!=baslik&&ScreenOpen(main,araMetni,out existingChild))){
   var preRes=BuildVerifiedScreenResult(main,mainH,existingChild,baslik,ilkVeriAlani,"zaten-acik",true);
   if(preRes.ContainsKey("ekranAcildi")&&(bool)preRes["ekranAcildi"]){
    Log("[MERKEZ-AÇ] '"+baslik+"' orta MDI çalışma alanında zaten açık ve kontrolleri doğrulandı.");
    return preRes;
   }
  }

  HashSet<string> winsBefore=GetOpenMdiWindowNames(main);
  string activeBefore=ActiveName(main);

  // Klasör başlıklarını ve Merkez ERP <-> Mahmutbey Şube (STORE) çapraz harita karşılıklarını çöz
  bool isStoreSession=false;
  try{
   string winTitle=main.Current.Name??"";
   if(winTitle.IndexOf("STORE",StringComparison.OrdinalIgnoreCase)>=0||ProcessNameOf(mainH).IndexOf("STORE",StringComparison.OrdinalIgnoreCase)>=0||string.Equals(Environment.UserName,"mahmutbeymgz",StringComparison.OrdinalIgnoreCase)){
    isStoreSession=true;
   }
  }catch{}
  string origBaslik=baslik;
  string crossMapNote="";
  ResolveCrossAtlasTarget(baslik,araMetni,sira,isStoreSession,out baslik,out araMetni,out sira,out crossMapNote);
  if(!string.IsNullOrEmpty(crossMapNote)){
   Log("[ÇAPRAZ-HARİTA EŞLEME] "+crossMapNote);
  }

  // Eğer çapraz eşlenen ekran orta çalışma alanında zaten açıksa öne getir
  if(!string.Equals(baslik,origBaslik,StringComparison.OrdinalIgnoreCase)){
   AutomationElement existingCross=null;
   if(ScreenOpen(main,baslik,out existingCross)||(araMetni!=baslik&&ScreenOpen(main,araMetni,out existingCross))){
    var preCross=BuildVerifiedScreenResult(main,mainH,existingCross,baslik,ilkVeriAlani,"zaten-acik",true);
    if(preCross.ContainsKey("ekranAcildi")&&(bool)preCross["ekranAcildi"]){
     preCross["caprazTest"]="DOGRULANDI";
     preCross["caprazTestDetay"]=crossMapNote;
     Log("[MERKEZ-AÇ] Çapraz eşlenen '"+baslik+"' zaten açık ve doğrulandı.");
     return preCross;
    }
   }
  }

  // =========================================================================
  // ADIM 1: SOL ÜSTTEKİ "Ara..." KUTUSUNA TIKLA, TEMİZLE, YAZ VE AŞAĞI OK + ENTER GÖNDER
  //         ('Ara...' kutusu tüm modüllerde global arama yapar; modül başlığına tıklanmaz!)
  // =========================================================================
  AutomationElement searchBox=FindSearchBoxMerkez(main,erpWinRect);
  int searchClickX=(int)(erpWinRect.Left+75);
  int searchClickY=(int)(erpWinRect.Top+158);
  if(searchBox!=null){
   try{
    var br=searchBox.Current.BoundingRectangle;
    if(!br.IsEmpty&&br.Width>=10&&br.Height>=8){
     searchClickX=(int)(br.Left+Math.Min(65.0,br.Width/2.0));
     searchClickY=(int)(br.Top+br.Height/2.0);
     Log("[MERKEZ-AÇ] UIA ile 'Ara...' kutusu bulundu: ("+searchClickX+","+searchClickY+") rect="+br);
    }
   }catch{}
  }else{
   Log("[MERKEZ-AÇ] UIA ile 'Ara...' kutusu bulunamadı; varsayılan sol üst koordinat kullanılıyor: ("+searchClickX+","+searchClickY+")");
  }

  if(mainH!=IntPtr.Zero)BringToFront(mainH);
  // Açık kalan arama açılır listesi varsa önce Escape ile temizle
  if(PopupShown(main,mainH)){
   Press(VK_ESCAPE);
   Thread.Sleep(110);
  }
  if(searchBox!=null){try{searchBox.SetFocus();}catch{}}
  PhysicalClick(searchClickX,searchClickY);
  Thread.Sleep(120);

  if(searchBox!=null&&!IsFocused(searchBox)){
   try{searchBox.SetFocus();}catch{}
   PhysicalClick(searchClickX,searchClickY);
   Thread.Sleep(120);
  }

  // Ctrl+A + Delete + BackSpace ile temizle
  Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(40);
  Press(VK_DELETE);Press(VK_BACK);
  Thread.Sleep(40);
  Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(30);
  Press(VK_DELETE);
  Thread.Sleep(60);

  if(PosInFront())return MerkezFail("Kasa (POS) ekranı öne geçtiği için işlem durduruldu.",baslik);

  string searchToType=araMetni;
  int learnedSira=GetLearnedSira(baslik,searchToType);
  if(learnedSira>=1&&learnedSira<=8){
   sira=learnedSira;
   Log("[ÇAPRAZ-TEST HAFIZA] sira-hafiza.json'dan doğrulanmış sıra yüklendi: '"+baslik+"' -> Sıra "+sira);
  }else if(sira<=1&&(Norm(searchToType)=="satinalma"||Norm(searchToType)=="satin alma")){sira=2;}else if(sira<=1&&string.Equals(searchToType,"Satış Sorumlusu",StringComparison.OrdinalIgnoreCase)){
   sira=4;
  }

  // Kanıtlanmış v6.2 hızlı açılış: 'Ara...' odaklandıktan sonra araya hiçbir UIA taraması sokmadan anında yaz ve seç!
  TypeText(searchToType);
  Log("[MERKEZ-AÇ] 'Ara...' kutusuna yazılıyor: '"+searchToType+"' (Hedef: '"+baslik+"', Sıra: "+sira+")");
  Thread.Sleep(500);

  // Kanıtlanmış v6.2 Popup Satır Koordinatı: Satır 1 = Y+41 (199), Satır k = Y+41+(k-1)*20
  int popupClickX=searchClickX+18;
  int popupClickY=searchClickY+41+(sira-1)*20;
  for(int d=0;d<sira;d++){
   Press(VK_DOWN);
   Thread.Sleep(120);
  }
  Thread.Sleep(70);
  PhysicalDoubleClick80ms(popupClickX,popupClickY);
  Thread.Sleep(60);
  if(PopupShown(main,mainH))Press(VK_RETURN);
  Log("[MERKEZ-AÇ] 'Ara...' açılır listesinden seçiliyor -> Down x"+sira+" + Çift Tık ("+popupClickX+","+popupClickY+") + Enter");
  string triggerHow="asagi-"+sira+"-cift-tik-enter";

  // =========================================================================
  // ADIM 2: GERÇEK MDI EKRAN AÇILIŞINI BEKLEME VE HARİTA ÇAPRAZ TESTİ (MAKS 6500 MS)
  // =========================================================================
  Stopwatch swPoll=Stopwatch.StartNew();
  int pollIter=0;
  bool retriedPopupEnter=false;
  var triedSiras=new HashSet<int>{sira};

  while(swPoll.ElapsedMilliseconds<10000){
   Thread.Sleep(260);
   pollIter++;

   if(PosInFront())return MerkezFail("Kasa (POS) ekranı öne geçtiği için işlem durduruldu.",baslik);

   // Modal uyarı penceresi kontrolü
   try{
    if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)&&((WindowPattern)wp).Current.WindowInteractionState==WindowInteractionState.BlockedByModalWindow){
     var warnRes=Result("acildi-uyari","Ekran açılırken Nebim bir mesaj gösterdi. Mesajı okuyup uygun düğmeye siz basın.",main.Current.Name);
     warnRes["ekranAcildi"]=false;
     return warnRes;
    }
   }catch{}

   // Eğer 1.1 sn sonunda yeni MDI penceresi oluşmadıysa yedek olarak Down x sira + Çift Tık + Enter gönder
   if(!retriedPopupEnter&&pollIter==6&&PopupShown(main,mainH)){
    AutomationElement checkChild=null;
    bool anyNewWin=GetOpenMdiWindowNames(main).Count>winsBefore.Count||ScreenOpen(main,baslik,out checkChild);
    if(!anyNewWin){
     retriedPopupEnter=true;
     Log("[MERKEZ-AÇ] Yedek tetikleme -> ("+popupClickX+","+popupClickY+") çift tık + Enter gönderiliyor.");
     PhysicalDoubleClick80ms(popupClickX,popupClickY);
     Thread.Sleep(80);
     if(PopupShown(main,mainH))Press(VK_RETURN);
     Thread.Sleep(180);
    }
   }
   if(pollIter==7&&triedSiras.Count<2&&sira>1){
    AutomationElement checkChild2=null;
    bool anyNewWin2=GetOpenMdiWindowNames(main).Count>winsBefore.Count||ScreenOpen(main,baslik,out checkChild2);
    if(!anyNewWin2){
     int nextSira0=1;
     for(int candS=1;candS<=4;candS++){if(!triedSiras.Contains(candS)){nextSira0=candS;break;}}
     triedSiras.Add(nextSira0);
     sira=nextSira0;
     popupClickY=searchClickY+41+(sira-1)*20;
     Log("[ÇAPRAZ-TEST SIRA GEÇİŞİ] Sıra "+sira+" deneniyor (önceki sırada MDI ekran açılmadı): '"+baslik+"'");
     PhysicalClick(searchClickX,searchClickY);
     Thread.Sleep(90);
     Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(30);
     Press(VK_DELETE);Press(VK_BACK);Thread.Sleep(40);
     TypeText(searchToType);
     Thread.Sleep(500);
     for(int d=0;d<sira;d++){Press(VK_DOWN);Thread.Sleep(120);}
     Thread.Sleep(60);
     PhysicalDoubleClick80ms(popupClickX,popupClickY);
     Thread.Sleep(60);
     if(PopupShown(main,mainH))Press(VK_RETURN);
     triggerHow="sira-gecisi-"+sira;
     retriedPopupEnter=false;
     swPoll.Restart();
     pollIter=0;
     continue;
    }
   }

   // Orta çalışma alanında (relX > 320, relY > 145) yeni ekran ve gerçek kontrol oluştu mu kontrol et
   AutomationElement cNow=null;
   string candidateScreenName="";
   if(ScreenOpen(main,baslik,out cNow)||(araMetni!=baslik&&ScreenOpen(main,araMetni,out cNow))){
    candidateScreenName=cNow!=null?StripNebimTitle(cNow.Current.Name):ActiveName(main);
    if(string.IsNullOrEmpty(candidateScreenName))candidateScreenName=baslik;
   }else{
    HashSet<string> winsNow=GetOpenMdiWindowNames(main);
    foreach(string wn in winsNow){
     if(!winsBefore.Contains(wn)){
      candidateScreenName=StripNebimTitle(wn);
      var mdi=FindMdi(main);
      if(mdi!=null)cNow=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&(c.Current.Name??"").Trim()==wn);
      break;
     }
    }
    if(string.IsNullOrEmpty(candidateScreenName)){
     string actNow=ActiveName(main);
     if(actNow.Length>0&&!string.Equals(actNow,activeBefore,StringComparison.OrdinalIgnoreCase)){
      candidateScreenName=actNow;
      cNow=ActiveChild(main);
     }
    }
   }

   if(!string.IsNullOrEmpty(candidateScreenName)||cNow!=null){
    var primaryCheck=new List<RealFieldCandidate>();
    var secondaryCheck=new List<RealFieldCandidate>();
    var actionCheck=new List<RealFieldCandidate>();
    AutomationElement scopeCheck=cNow??ActiveChild(main);
    if(scopeCheck!=null&&!Automation.Compare(scopeCheck,main)){
     CollectRealWorkspaceFields(scopeCheck,main,erpWinRect,primaryCheck,secondaryCheck,actionCheck);
    }

    // =========================================================================
    // ADIM 2.5: KAYDEDİLMİŞ NEBİM HARİTASIYLA ÇAPRAZ TEST (CROSS-CHECK)
    // =========================================================================
    string crossTestDetail="";
    bool crossTestPassed=CrossVerifyOpenedScreenWithAtlas(candidateScreenName,baslik,araMetni,ilkVeriAlani,primaryCheck,secondaryCheck,out crossTestDetail);

    if(false&&!crossTestPassed&&triedSiras.Count<3){
     int nextSira=1;
     for(int candS=1;candS<=4;candS++){if(!triedSiras.Contains(candS)){nextSira=candS;break;}}
     triedSiras.Add(nextSira);
     Log("[ÇAPRAZ-TEST RED] Açılan ekran ('"+candidateScreenName+"') haritadaki hedef ('"+baslik+"') ile uyuşmadı ("+crossTestDetail+"). Yanlış pencere kapatılıp Sıra "+nextSira+" deneniyor...");
     try{
      object wpc;
      if(cNow!=null&&cNow.TryGetCurrentPattern(WindowPattern.Pattern,out wpc))((WindowPattern)wpc).Close();
     }catch{}
     Thread.Sleep(220);
     sira=nextSira;
     popupClickY=searchClickY+41+(sira-1)*20;
     PhysicalClick(searchClickX,searchClickY);
     Thread.Sleep(90);
     Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(30);
     Press(VK_DELETE);Press(VK_BACK);Thread.Sleep(40);
     TypeText(searchToType);
     Thread.Sleep(480);
     for(int d=0;d<sira;d++){Press(VK_DOWN);Thread.Sleep(120);}
     Thread.Sleep(60);
     PhysicalDoubleClick80ms(popupClickX,popupClickY);
     Thread.Sleep(60);
     if(PopupShown(main,mainH))Press(VK_RETURN);
     triggerHow="capraz-test-duzeltme-sira-"+sira;
     swPoll.Restart();
     pollIter=0;
     continue;
    }

    if(primaryCheck.Count>0||secondaryCheck.Count>0||actionCheck.Count>0||cNow!=null||pollIter>=1){
     if(crossTestPassed&&sira>=1&&sira<=10){
      SaveLearnedSira(baslik,searchToType,sira);
     }
     Log("[ÇAPRAZ-TEST SONUCU] "+(crossTestPassed?"DOĞRULANDI":"UYARI")+": "+crossTestDetail);
     Thread.Sleep(140);
     var finalRes=BuildVerifiedScreenResultWithFields(main,mainH,cNow??ActiveChild(main),candidateScreenName.Length>0?candidateScreenName:baslik,ilkVeriAlani,"acildi ("+triggerHow+", "+swPoll.ElapsedMilliseconds+"ms)",true,primaryCheck,secondaryCheck,actionCheck);
     finalRes["caprazTest"]=crossTestPassed?"DOGRULANDI":"UYARI";
     finalRes["caprazTestDetay"]=crossTestDetail;
     return finalRes;
    }
   }
  }

  // ADIM 2.2: 5 saniye sonunda orta alanda (relX > 320, relY > 145) hala hiçbir gerçek kontrol yoksa ekranAcildi: false döndür!
  Log("[MERKEZ-AÇ] BAŞARISIZ (5000ms): '"+baslik+"' için orta çalışma alanında (relX>320, relY>145) ekran/kontrol oluşmadı.");
  return MerkezFail("Ekran henüz açılmadı ('"+baslik+"' için 5 saniye beklendi fakat orta çalışma alanında ekran oluşmadı).",baslik);
 }

 static System.Windows.Rect GetElementOrWindowRect(AutomationElement el,IntPtr hWnd){
  try{
   if(el!=null){
    var r=el.Current.BoundingRectangle;
    if(!r.IsEmpty&&r.Width>=100&&r.Height>=100)return r;
   }
  }catch{}
  if(hWnd!=IntPtr.Zero){
   WIN32_RECT wr;
   if(GetWindowRect(hWnd,out wr)&&(wr.Right-wr.Left)>=100){
    return new System.Windows.Rect(wr.Left,wr.Top,wr.Right-wr.Left,wr.Bottom-wr.Top);
   }
  }
  return System.Windows.Rect.Empty;
 }

 static HashSet<string> GetOpenMdiWindowNames(AutomationElement main){
  var set=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  try{
   var mdi=FindMdi(main);
   if(mdi!=null){
    var walker=TreeWalker.ControlViewWalker;
    AutomationElement c=walker.GetFirstChild(mdi);
    int guard=0;
    while(c!=null&&++guard<60){
     try{
      if(c.Current.ControlType==ControlType.Window&&!c.Current.IsOffscreen){
       var r=c.Current.BoundingRectangle;
       if(!r.IsEmpty&&r.Width>200&&r.Height>120){
        string n=(c.Current.Name??"").Trim();
        if(n.Length>0)set.Add(n);
       }
      }
     }catch{}
     try{c=walker.GetNextSibling(c);}catch{c=null;}
    }
   }
  }catch{}
  return set;
 }

 static readonly string[] KnownModules=new string[]{
  "Benim Menüm","Genel Muhasebe","Finansman Yönetimi","Satın Alma","Satış & Pazarlama","Toptan Satış",
  "Perakende Satış","Üretim","Üretim Yönetimi","Ürün Yönetimi","Depo Yönetimi","Depo / Envanter",
  "Mağazaların Yönetimi","Mağaza Yönetimi","Dış Ticaret","İnsan Kaynakları","Servis ve Destek","Ayarlar"
 };

 static bool IsModuleMatch(string candidateName,string requestedKategori){
  string cn=Norm(candidateName);
  string rk=Norm(requestedKategori);
  if(cn.Length==0||rk.Length==0)return false;
  if(cn==rk)return true;
  if(rk.Contains("depo")&&cn.Contains("depo"))return true;
  if(rk.Contains("magaza")&&cn.Contains("magaza"))return true;
  if(rk.Contains("uretim")&&cn.Contains("uretim"))return true;
  if(rk.Contains("satis")&&rk.Contains("pazarlama")&&(cn.Contains("satis")&&cn.Contains("pazarlama")))return true;
  if(rk.Contains("finans")&&cn.Contains("finans"))return true;
  if(rk.Contains("muhasebe")&&cn.Contains("muhasebe"))return true;
  if(rk.Contains("satin")&&cn.Contains("satin"))return true;
  return false;
 }

 // ADIM 1.1: Sol paneldeki (relX < 310) ilgili modül başlığını UIA ile bulup fiziksel sol tık yap ve 350 ms bekle
 static void TryClickModuleHeaderInNavBar(AutomationElement main,System.Windows.Rect erpWinRect,string kategori){
  if(main==null||string.IsNullOrEmpty(kategori))return;
  try{
   AutomationElement nav=null;
   try{nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));}catch{}
   AutomationElement scope=nav??main;

   var cond=new OrCondition(
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Group),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Button),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Header),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.ListItem),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Pane),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Text)
   );
   AutomationElementCollection all;
   using(QuickCache().Activate()){all=scope.FindAll(TreeScope.Descendants,cond);}

   // Üstte (relY 125..195 arası, relX < 310) o an açık olan aktif modül başlığını kontrol et
   foreach(AutomationElement el in all){
    string n="";System.Windows.Rect r=System.Windows.Rect.Empty;bool off=false;
    try{n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;off=el.Cached.IsOffscreen;}catch{continue;}
    if(off||r.IsEmpty||n.Length<2)continue;
    double relX=r.Left-erpWinRect.Left;
    double relY=r.Top-erpWinRect.Top;
    if(relX>=0&&relX<310&&relY>=125&&relY<=195&&IsModuleMatch(n,kategori)){
     Log("[MERKEZ-AÇ] Sol menüde '"+n+"' modülü zaten aktif.");
     return;
    }
   }

   // Sol paneldeki (relX < 310) hedef modül butonunu bul (alttaki NavBar modül butonlarına öncelik ver: relY > 195)
   System.Windows.Rect bestModRect=System.Windows.Rect.Empty;
   string bestModName="";
   foreach(AutomationElement el in all){
    string n="";System.Windows.Rect r=System.Windows.Rect.Empty;bool off=false;ControlType ct=null;
    try{n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;off=el.Cached.IsOffscreen;ct=el.Cached.ControlType;}catch{continue;}
    if(off||r.IsEmpty||r.Width<24||r.Height<14)continue;
    double relX=r.Left-erpWinRect.Left;
    double relY=r.Top-erpWinRect.Top;
    if(relX<0||relX>=310||relY<110)continue;
    if(IsModuleMatch(n,kategori)){
     bestModRect=r;
     bestModName=n;
     if(relY>450||(ct==ControlType.Button||ct==ControlType.Group))break;
    }
   }

   if(!bestModRect.IsEmpty){
    int cx=(int)(bestModRect.Left+Math.Min(90.0,bestModRect.Width/2.0));
    int cy=(int)(bestModRect.Top+bestModRect.Height/2.0);
    Log("[MERKEZ-AÇ] Sol menü modül başlığına fiziksel sol tık yapılıyor: '"+bestModName+"' ("+cx+","+cy+")");
    PhysicalClick(cx,cy);
    Thread.Sleep(350);
   }
  }catch(Exception e){Log("[MERKEZ-AÇ] Modül başlığı seçimi uyarısı: "+e.Message);}
 }

 static AutomationElement FindSearchBoxMerkez(AutomationElement main,System.Windows.Rect erpWinRect){
  if(main==null)return null;
  try{
   var b0=FindSearchBox(main);
   if(b0!=null)return b0;
  }catch{}
  try{
   AutomationElement nav=null;
   try{nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));}catch{}
   AutomationElement scope=nav??main;
   var cond=new OrCondition(
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Edit),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.ComboBox)
   );
   AutomationElementCollection edits;
   using(QuickCache().Activate()){edits=scope.FindAll(TreeScope.Descendants,cond);}
   AutomationElement comboFallback=null;
   foreach(AutomationElement el in edits){
    System.Windows.Rect r=System.Windows.Rect.Empty;ControlType ct=null;bool off=false;
    try{r=el.Cached.BoundingRectangle;ct=el.Cached.ControlType;off=el.Cached.IsOffscreen;}catch{continue;}
    if(off||r.IsEmpty||r.Width<20||r.Height<10)continue;
    double relX=r.Left-erpWinRect.Left;
    double relY=r.Top-erpWinRect.Top;
    if(relX>=0&&relX<310&&relY>=60&&relY<195){
     if(ct==ControlType.Edit)return el;
     if(comboFallback==null)comboFallback=el;
    }
   }
   return comboFallback;
  }catch{}
  return null;
 }

 static readonly HashSet<string> PureFolderNames=new HashSet<string>(StringComparer.OrdinalIgnoreCase){
  "Kayıtlar","Fişler","Raporlar","Listeler","Sihirbazlar","İşlemler","Tanımlar","Parametreler",
  "Kontrol Listeleri","Onaylama İşlemleri","Hareketler","Analizler","Faturalar","Siparişler","İrsaliyeler"
 };

 class SolMenuRowCandidate{
  public string text;
  public string normText;
  public System.Windows.Rect rect;
  public bool isFolder;
  public int score;
 }

 // ADIM 1.3: Sol menü ağacında (relX < 310, relY > 155) veya Ara açılır listesinde klasörleri atlayarak YAPRAK (LEAF) menü öğesini bul
 static System.Windows.Rect FindLeafMenuTreeItemInSolMenu(AutomationElement main,System.Windows.Rect erpWinRect,string baslik,string araMetni,int minScreenY,out string matchedText,out bool isFolder){
  matchedText="";
  isFolder=false;
  if(main==null)return System.Windows.Rect.Empty;
  try{
   AutomationElement nav=null;
   try{nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));}catch{}
   AutomationElement scope=nav??main;
   var cond=new OrCondition(
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TreeItem),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.DataItem),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Custom),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.ListItem),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.MenuItem),
    new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Hyperlink)
   );
   var allList=new List<AutomationElement>();
   try{
    IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
    IntPtr fg=GetForegroundWindow();
    uint fgPid;GetWindowThreadProcessId(fg,out fgPid);
    if(fg!=IntPtr.Zero&&fg!=mainH&&(int)fgPid==main.Current.ProcessId){
     AutomationElement popupEl=AutomationElement.FromHandle(fg);
     if(popupEl!=null){
      AutomationElementCollection popItems;
      using(QuickCache().Activate()){popItems=popupEl.FindAll(TreeScope.Descendants,cond);}
      if(popItems!=null){foreach(AutomationElement pe in popItems)allList.Add(pe);}
     }
    }
   }catch{}
   try{
    AutomationElementCollection navItems;
    using(QuickCache().Activate()){navItems=scope.FindAll(TreeScope.Descendants,cond);}
    if(navItems!=null){foreach(AutomationElement ne in navItems)allList.Add(ne);}
   }catch{}

   string qBaslik=Norm(baslik);
   string qAra=Norm(araMetni);
   var rows=new List<SolMenuRowCandidate>();
   var walker=TreeWalker.ControlViewWalker;

   foreach(AutomationElement el in allList){
    string n="";System.Windows.Rect r=System.Windows.Rect.Empty;bool off=false;ControlType ct=null;
    try{n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;off=el.Cached.IsOffscreen;ct=el.Cached.ControlType;}catch{continue;}
    bool isTreeCell=n.StartsWith("TreeListColumn",StringComparison.OrdinalIgnoreCase)||n.StartsWith("Düğüm",StringComparison.OrdinalIgnoreCase)||ct==ControlType.Custom||ct==ControlType.DataItem;
    if(!isTreeCell&&off)continue;

    AutomationElement parentRow=null;
    if(r.IsEmpty||r.Width<14||r.Height<10){
     try{parentRow=walker.GetParent(el);if(parentRow!=null)r=parentRow.Current.BoundingRectangle;}catch{}
    }
    if(r.IsEmpty||r.Width<14||r.Height<10)continue;

    double relX=r.Left-erpWinRect.Left;
    double relY=r.Top-erpWinRect.Top;
    // ADIM 1.3: relX < 310, relY > 155
    if(relX<-10||relX>=315||relY<=155||relY>erpWinRect.Height-20)continue;
    if(minScreenY>0&&r.Top<=minScreenY+6)continue;

    if(isTreeCell){
     string v="";try{object vp;if(el.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=(((ValuePattern)vp).Current.Value??"").Trim();}catch{}
     if(v.Length>0)n=v;
    }
    if(n.Length<2||n.Length>130)continue;
    if(n.StartsWith("Düğüm",StringComparison.OrdinalIgnoreCase)||n.StartsWith("TreeListColumn",StringComparison.OrdinalIgnoreCase))continue;

    // Modül başlığı butonlarını ağaç öğesi sanma
    bool isModBtn=false;
    for(int m=0;m<KnownModules.Length;m++){
     if(string.Equals(n,KnownModules[m],StringComparison.OrdinalIgnoreCase)){isModBtn=true;break;}
    }
    if(isModBtn)continue;

    bool nodeIsFolder=PureFolderNames.Contains(n);
    if(!nodeIsFolder){
     try{
      object ecp;
      AutomationElement ecpTarget=el;
      if(!ecpTarget.TryGetCurrentPattern(ExpandCollapsePattern.Pattern,out ecp)){
       if(parentRow==null)parentRow=walker.GetParent(el);
       if(parentRow!=null)parentRow.TryGetCurrentPattern(ExpandCollapsePattern.Pattern,out ecp);
      }
      if(ecp!=null){
       var st=((ExpandCollapsePattern)ecp).Current.ExpandCollapseState;
       if(st!=ExpandCollapseState.LeafNode)nodeIsFolder=true;
      }
     }catch{}
    }

    string nn=Norm(n);
    int score=0;
    if(nn==qBaslik)score=100;
    else if(qBaslik.Length>=4&&nn.StartsWith(qBaslik+" - ",StringComparison.Ordinal))score=96;
    else if(qBaslik.Length>=4&&nn.StartsWith(qBaslik,StringComparison.Ordinal))score=92;
    else if(qBaslik.Length>=4&&nn.Contains(qBaslik))score=84;
    else if(qAra.Length>=3&&nn==qAra)score=88;
    else if(qAra.Length>=3&&nn.Contains(qAra))score=76;
    else if(minScreenY>0&&!nodeIsFolder)score=68; // Klasör açıldıktan sonra altındaki ilk yaprak öğe

    if(score>0){
     rows.Add(new SolMenuRowCandidate{text=n,normText=nn,rect=r,isFolder=nodeIsFolder,score=score});
    }
   }

   if(rows.Count==0)return System.Windows.Rect.Empty;

   // Y koordinatına göre yukarıdan aşağıya sırala
   rows.Sort((a,b)=>a.rect.Top.CompareTo(b.rect.Top));

   // Eğer bir satırın hemen altında (y farkı <= 36px) başka bir eşleşen satır varsa ve üstteki satır
   // kısa/genel bir klasör adıysa (veya aynı isimdeyse), alttaki satır yaprak (leaf) ekrandır!
   for(int i=0;i<rows.Count-1;i++){
    var cur=rows[i];
    var nxt=rows[i+1];
    double dy=nxt.rect.Top-cur.rect.Top;
    if(dy>=12&&dy<=38){
     if(cur.normText==nxt.normText||nxt.normText.Contains(cur.normText)||cur.isFolder){
      cur.isFolder=true;
      if(cur.score>=80)cur.score-=18;
     }
    }
   }

   SolMenuRowCandidate best=null;
   for(int i=0;i<rows.Count;i++){
    var cand=rows[i];
    int effScore=cand.score-(cand.isFolder?25:0);
    int bestEff=best!=null?(best.score-(best.isFolder?25:0)):-999;
    // Eşit puanda ağaçta daha aşağıda (yaprak seviyesinde) olan öğeyi tercih et
    if(effScore>bestEff||(effScore==bestEff&&best!=null&&cand.rect.Top>best.rect.Top)){
     best=cand;
    }
   }

   if(best!=null){
    matchedText=best.text;
    isFolder=best.isFolder;
    return best.rect;
   }
  }catch{}
  return System.Windows.Rect.Empty;
 }

 class RealFieldCandidate{
  public AutomationElement element;
  public string label;
  public string automationId;
  public string className;
  public System.Windows.Rect rect;
  public int relLeft;
  public int relTop;
  public bool isAction;
 }

 // ADIM 3.1: Kesinlikle seçilmeyecek gürültü ve sabit etiket isimleri
 static readonly HashSet<string> ForbiddenFieldNames=new HashSet<string>(StringComparer.OrdinalIgnoreCase){
  "Filtreler","Filtre","Ve","Veya","Seçim","Kriter","Kriterler","Grup","Gruplar","Detay","Genel","Özet",
  "Tablo","Liste","Sıralama","Kolonlar","Alanlar","Değer","Eşittir","İçerir","Büyüktür","Küçüktür",
  "Arasında","Boş","Dolu","And","Or","Filter","Filters","Close","Minimize","Maximize","Restore","Kapat",
  "Küçült","Ekranı Kapla","Ara…","Ara","Sistem","System","Yardım","Window","Pencere","Expand",
  "Expand Collapse","Expand collapse button","Butonları konfigüre et!","Standart Sürüm","Soldaki Sütun",
  "Sağdaki Sütun","Veri Paneli","Başlık Paneli","Footer Panel","Tıkla","Aç","Application",
  "Ribbon Display Options","lc","dataLayoutControl1","Görünüm","Font","Touch/fare modu","The Ribbon","Status Bar"
 };

 Dictionary<string,object> BuildVerifiedScreenResult(AutomationElement main,IntPtr mainH,AutomationElement childWin,string openedScreenName,string expectedFirstField,string statusNote,bool autoFocusFirstField){
  return BuildVerifiedScreenResultWithFields(main,mainH,childWin,openedScreenName,expectedFirstField,statusNote,autoFocusFirstField,null,null,null);
 }

 Dictionary<string,object> BuildVerifiedScreenResultWithFields(AutomationElement main,IntPtr mainH,AutomationElement childWin,string openedScreenName,string expectedFirstField,string statusNote,bool autoFocusFirstField,List<RealFieldCandidate> prePrimary,List<RealFieldCandidate> preSecondary,List<RealFieldCandidate> preActions){
  System.Windows.Rect erpWinRect=GetElementOrWindowRect(main,mainH);
  if(erpWinRect.IsEmpty||erpWinRect.Width<300)erpWinRect=new System.Windows.Rect(0,0,1920,1040);

  AutomationElement scope=childWin??ActiveChild(main)??main;
  string realScreenName=openedScreenName;
  if(childWin!=null){
   try{
    string cn=StripNebimTitle((childWin.Current.Name??"").Trim());
    if(cn.Length>0)realScreenName=cn;
   }catch{}
  }
  if(string.IsNullOrEmpty(realScreenName))realScreenName=ActiveName(main);

  List<RealFieldCandidate> primaryInputs=prePrimary??new List<RealFieldCandidate>();
  List<RealFieldCandidate> secondaryInputs=preSecondary??new List<RealFieldCandidate>();
  List<RealFieldCandidate> actionButtons=preActions??new List<RealFieldCandidate>();

  if(prePrimary==null&&primaryInputs.Count==0&&secondaryInputs.Count==0&&actionButtons.Count==0&&scope!=null&&!Automation.Compare(scope,main)){
   CollectRealWorkspaceFields(scope,main,erpWinRect,primaryInputs,secondaryInputs,actionButtons);
  }

  List<RealFieldCandidate> inputs=primaryInputs.Count>0?primaryInputs:secondaryInputs;
  inputs.Sort((a,b)=>{
   int ra=a.relTop/18;int rb=b.relTop/18;
   int c=ra.CompareTo(rb);
   return c!=0?c:a.relLeft.CompareTo(b.relLeft);
  });

  if(inputs.Count>0&&!string.IsNullOrEmpty(expectedFirstField)&&!ForbiddenFieldNames.Contains(expectedFirstField)){
   string qExp=Norm(expectedFirstField);
   int matchIdx=-1;
   for(int i=0;i<inputs.Count;i++){
    string nl=Norm(inputs[i].label);
    if(nl==qExp||(qExp.Length>=3&&nl.Contains(qExp))||(nl.Length>=3&&qExp.Contains(nl))){
     matchIdx=i;break;
    }
   }
   if(matchIdx>0){
    var item=inputs[matchIdx];
    inputs.RemoveAt(matchIdx);
    inputs.Insert(0,item);
   }
  }

  // SIFIR-HATA ÇÖZÜM-4: alan-haritasi.json içinde bu ekran için kayıtlı AutomationId parmak izi varsa öncelik ver
  string prefAid=GetPreferredAutomationIdForScreen(realScreenName);
  if(inputs.Count>1&&!string.IsNullOrEmpty(prefAid)){
   for(int i=1;i<inputs.Count;i++){
    if(string.Equals(inputs[i].automationId,prefAid,StringComparison.OrdinalIgnoreCase)){
     var aidItem=inputs[i];
     inputs.RemoveAt(i);
     inputs.Insert(0,aidItem);
     break;
    }
   }
  }
  SaveScreenFieldFingerprint(realScreenName,inputs,actionButtons);

  // ADIM 2.2: Eğer MDI penceresi açıldıysa fakat standart edit kontrolü algılanamadıysa çalışma alanı içinde güvenli bir başlangıç koordinatı üret
  if(inputs.Count==0&&actionButtons.Count==0){
   if(childWin!=null||!string.IsNullOrEmpty(realScreenName)){
    inputs.Add(new RealFieldCandidate{
     element=childWin,
     label=!string.IsNullOrEmpty(expectedFirstField)?expectedFirstField:"İlk Veri Giriş Alanı",
     rect=new System.Windows.Rect(erpWinRect.Left+460,erpWinRect.Top+260,180,24),
     relLeft=460,
     relTop=260,
     isAction=false
    });
   }else{
    return MerkezFail("Orta çalışma alanında (relX>320, relY>145) aktif veri alanı bulunamadı.",openedScreenName);
   }
  }

  var stepsOut=new List<object>();
  var seenLabels=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  for(int i=0;i<inputs.Count&&stepsOut.Count<2;i++){
   var f=inputs[i];
   if(!seenLabels.Add(f.label))continue;
   stepsOut.Add(new Dictionary<string,object>{
    {"ad",f.label},
    {"sol",(int)f.rect.Left},
    {"ust",(int)f.rect.Top},
    {"genislik",(int)f.rect.Width},
    {"yukseklik",(int)f.rect.Height},
    {"relLeft",f.relLeft},
    {"relTop",f.relTop},
    {"aksiyonMu",false},
    {"automationId",f.automationId??""}
   });
  }
  if(actionButtons.Count>0){
   var act=actionButtons[0];
   stepsOut.Add(new Dictionary<string,object>{
    {"ad",act.label},
    {"sol",(int)act.rect.Left},
    {"ust",(int)act.rect.Top},
    {"genislik",(int)act.rect.Width},
    {"yukseklik",(int)act.rect.Height},
    {"relLeft",act.relLeft},
    {"relTop",act.relTop},
    {"aksiyonMu",true},
    {"automationId",act.automationId??""}
   });
  }

  RealFieldCandidate firstTarget=inputs.Count>0?inputs[0]:actionButtons[0];

  // =========================================================================
  // ADIM 3.2: OTOMATİK ODAKLAMA (İmlecı İlk Veri Giriş Kutusunun İçine Sokma)
  // =========================================================================
  if(autoFocusFirstField&&primaryInputs.Count>0&&!firstTarget.isAction&&firstTarget.element!=null&&!Automation.Compare(firstTarget.element,childWin)&&!PosInFront()){
   try{
    int focusX=(int)(firstTarget.rect.Left+Math.Min(25.0,Math.Max(8.0,firstTarget.rect.Width/3.0)));
    int focusY=(int)(firstTarget.rect.Top+(firstTarget.rect.Height/2.0));
    PhysicalClick(focusX,focusY);
    Thread.Sleep(60);
    if(firstTarget.element!=null){
     try{firstTarget.element.SetFocus();}catch{}
    }
    Log("[OTO-ODAK] İlk veri alanı ('"+firstTarget.label+"') koordinatına ("+focusX+","+focusY+") tıklandı ve imleç odaklandı.");
   }catch(Exception ex){
    Log("[OTO-ODAK] Odaklama uyarısı: "+ex.Message);
   }
  }

  // =========================================================================
  // ADIM 4: ÇERÇEVEYİ DOĞRUDAN RDP İÇİNDE ÇİZ (RdpRenkliCerceveForm)
  // =========================================================================
  int totalSteps=Math.Max(1,stepsOut.Count);
  string badgeText="ADIM 1/"+totalSteps+": "+firstTarget.label;
  Rectangle targetRectInt=new Rectangle((int)firstTarget.rect.Left,(int)firstTarget.rect.Top,(int)firstTarget.rect.Width,(int)firstTarget.rect.Height);
  ShowRdpFrameSafe(targetRectInt,badgeText,firstTarget.isAction,realScreenName);

  var res=Result("acildi","'"+realScreenName+"' ekranı açıldı ("+statusNote+").",realScreenName);
  res["ok"]=true;
  res["ekranAcildi"]=true;
  res["rdpCerceveAktif"]=true;
  res["acilanEkran"]=realScreenName;
  res["erpSol"]=(int)erpWinRect.Left;
  res["erpUst"]=(int)erpWinRect.Top;
  res["erpGenislik"]=(int)erpWinRect.Width;
  res["erpYukseklik"]=(int)erpWinRect.Height;
  res["adimlar"]=stepsOut;
  res["ilkAlanAdi"]=firstTarget.label;
  res["alanSol"]=(int)firstTarget.rect.Left;
  res["alanUst"]=(int)firstTarget.rect.Top;
  res["alanGenislik"]=(int)firstTarget.rect.Width;
  res["alanYukseklik"]=(int)firstTarget.rect.Height;
  res["relLeft"]=firstTarget.relLeft;
  res["relTop"]=firstTarget.relTop;
  res["mesaj"]="✅ '"+realScreenName+"' açıldı; '"+firstTarget.label+"' alanına odaklandı ve çerçevelendi.";
  Log("[MERKEZ-AÇ] DOĞRULANDI: Ekran='"+realScreenName+"' | İlkAlan='"+firstTarget.label+"' | rel=("+firstTarget.relLeft+","+firstTarget.relTop+") size="+(int)firstTarget.rect.Width+"x"+(int)firstTarget.rect.Height);
  return res;
 }

 // ADIM 2.1 & ADIM 3.1: Kesin Bölge Kuralı (relX > 320, relY > 145) ve Gürültü Filtresi
 static void CollectRealWorkspaceFields(AutomationElement scope,AutomationElement main,System.Windows.Rect erpWinRect,List<RealFieldCandidate> primary,List<RealFieldCandidate> secondary,List<RealFieldCandidate> actions){
  if(scope==null)return;
  System.Windows.Rect navRect=System.Windows.Rect.Empty;
  try{var nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));if(nav!=null)navRect=nav.Current.BoundingRectangle;}catch{}

  var cr=new CacheRequest();
  cr.Add(AutomationElement.NameProperty);
  cr.Add(AutomationElement.AutomationIdProperty);
  cr.Add(AutomationElement.ClassNameProperty);
  cr.Add(AutomationElement.ControlTypeProperty);
  cr.Add(AutomationElement.IsOffscreenProperty);
  cr.Add(AutomationElement.IsEnabledProperty);
  cr.Add(AutomationElement.BoundingRectangleProperty);

  AutomationElementCollection all;
  try{using(cr.Activate()){all=scope.FindAll(TreeScope.Descendants,Condition.TrueCondition);}}catch{return;}
  if(all==null)return;

  int count=0;
  var walker=TreeWalker.ControlViewWalker;
  foreach(AutomationElement el in all){
   if(++count>2000)break;
   ControlType ct=null;string name="",aid="",cls="";System.Windows.Rect r=System.Windows.Rect.Empty;bool off=false,en=true;
   try{
    ct=el.Cached.ControlType;
    name=(el.Cached.Name??"").Trim();
    aid=(el.Cached.AutomationId??"").Trim();
    cls=(el.Cached.ClassName??"").Trim();
    r=el.Cached.BoundingRectangle;
    off=el.Cached.IsOffscreen;
    en=el.Cached.IsEnabled;
   }catch{continue;}

   if(off||!en||r.IsEmpty)continue;
   if(!navRect.IsEmpty&&navRect.Contains(new System.Windows.Point(r.X+4,r.Y+4)))continue;

   int relX=(int)(r.Left-erpWinRect.Left);
   int relY=(int)(r.Top-erpWinRect.Top);

   // ADIM 2.1 KESİN BÖLGE KURALI: relX > 320 ve relY > 145
   if(relX<=320||relY<=145)continue;

   if(aid.IndexOf("MenuNavBar",StringComparison.OrdinalIgnoreCase)>=0||
      aid.IndexOf("Ribbon",StringComparison.OrdinalIgnoreCase)>=0||
      aid.IndexOf("FilterControl",StringComparison.OrdinalIgnoreCase)>=0||
      aid.IndexOf("ParameteredField",StringComparison.OrdinalIgnoreCase)>=0||
      cls.IndexOf("NavBar",StringComparison.OrdinalIgnoreCase)>=0||
      cls.IndexOf("Ribbon",StringComparison.OrdinalIgnoreCase)>=0||
      cls.IndexOf("FilterControl",StringComparison.OrdinalIgnoreCase)>=0||
      cls.IndexOf("ParameteredField",StringComparison.OrdinalIgnoreCase)>=0){
    continue;
   }

   // ADIM 3.1: Sabit metin/grup/sekme kontrollerini kesinlikle seçme
   if(ct==ControlType.Text||ct==ControlType.Group||ct==ControlType.Pane||ct==ControlType.TabItem||
      ct==ControlType.TitleBar||ct==ControlType.MenuBar||ct==ControlType.MenuItem||ct==ControlType.ScrollBar||
      ct==ControlType.TreeItem||ct==ControlType.Header||ct==ControlType.HeaderItem){
    continue;
   }

   // Aksiyon butonları (Çalıştır, Sorgula, Listele, İleri, Kaydet)
   if(ct==ControlType.Button||ct==ControlType.SplitButton){
    if(r.Width>=40&&r.Height>=16){
     string nNorm=Norm(name);
     if(nNorm.StartsWith("calistir")||nNorm.StartsWith("sorgula")||nNorm.StartsWith("listele")||nNorm.StartsWith("ileri")||nNorm.StartsWith("devam")||nNorm.StartsWith("kaydet")){
      actions.Add(new RealFieldCandidate{element=el,label=name,automationId=aid,className=cls,rect=r,relLeft=relX,relTop=relY,isAction=true});
     }
    }
    continue;
   }

   // ADIM 3.1: Yalnızca Width >= 40 ve Height >= 16 olan aktif veri giriş kontrolleri
   if(r.Width<40||r.Height<16)continue;

   bool isDevExpressEditor=
    cls.IndexOf("TextEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("ButtonEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("LookUpEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("DateEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("SpinEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("MemoEdit",StringComparison.OrdinalIgnoreCase)>=0||
    cls.IndexOf("CheckedComboBoxEdit",StringComparison.OrdinalIgnoreCase)>=0||
    aid.StartsWith("btxt",StringComparison.OrdinalIgnoreCase)||
    aid.StartsWith("txt",StringComparison.OrdinalIgnoreCase)||
    aid.StartsWith("mtxt",StringComparison.OrdinalIgnoreCase)||
    aid.StartsWith("lookUp",StringComparison.OrdinalIgnoreCase)||
    aid.StartsWith("dte",StringComparison.OrdinalIgnoreCase)||
    aid.StartsWith("spn",StringComparison.OrdinalIgnoreCase);

   bool isStandardEditor=(ct==ControlType.Edit||ct==ControlType.ComboBox||ct==ControlType.Document);

   if(isStandardEditor||isDevExpressEditor){
    if(name.EndsWith("Error Text",StringComparison.OrdinalIgnoreCase)||name.EndsWith("Zorunlu",StringComparison.OrdinalIgnoreCase))continue;
    if(!string.IsNullOrEmpty(name)&&ForbiddenFieldNames.Contains(name))continue;
    string brCheck=Bracket(name);
    if(brCheck.Length>0&&ForbiddenFieldNames.Contains(brCheck))continue;
    string lbl=ResolveRealFieldLabel(el,name,aid,walker);
    if(lbl.Length<2||ForbiddenFieldNames.Contains(lbl)||lbl.StartsWith("TreeListColumn",StringComparison.OrdinalIgnoreCase))continue;
    primary.Add(new RealFieldCandidate{element=el,label=lbl,automationId=aid,className=cls,rect=r,relLeft=relX,relTop=relY,isAction=false});
   }else if(name.Length>2&&name[0]=='['&&name.IndexOf(']')>1&&r.Width>=60){
    // Rapor filtre satırındaki gerçek değer hücresi ([Başlangıç Tarihi] vb.)
    string brLbl=name.Substring(1,name.IndexOf(']')-1).Trim();
    if(brLbl.Length>=2&&!ForbiddenFieldNames.Contains(brLbl)){
     // FilterControl [Başlangıç Tarihi] / [Bugün] düğümleri v3DateFunctionOperator hatasını tetiklememek için eklenmez
    }
   }
  }
 }

 static bool IsActionLikeButtonName(string s){
  string n=Norm(s);
  return n.StartsWith("calistir")||n.StartsWith("sorgula")||n.StartsWith("listele")||n.StartsWith("kaydet")||n.StartsWith("ileri")||n.StartsWith("devam")||n.StartsWith("iptal")||n.StartsWith("vazgec");
 }

 static string ResolveRealFieldLabel(AutomationElement el,string rawName,string aid,TreeWalker walker){
  if(!string.IsNullOrEmpty(rawName)){
   if(rawName[0]=='['&&rawName.IndexOf(']')>1){
    string inside=rawName.Substring(1,rawName.IndexOf(']')-1).Trim();
    if(!ForbiddenFieldNames.Contains(inside)&&!IsActionLikeButtonName(inside))return inside;
   }
   if(!rawName.StartsWith("WindowsForms",StringComparison.OrdinalIgnoreCase)&&
      !rawName.StartsWith("textEdit",StringComparison.OrdinalIgnoreCase)&&
      !rawName.StartsWith("lookUp",StringComparison.OrdinalIgnoreCase)&&
      !rawName.StartsWith("buttonEdit",StringComparison.OrdinalIgnoreCase)&&
      !ForbiddenFieldNames.Contains(rawName)&&
      !IsActionLikeButtonName(rawName)){
    return rawName;
   }
  }
  try{
   AutomationElement prev=walker.GetPreviousSibling(el);
   for(int i=0;i<3&&prev!=null;i++){
    ControlType pct=prev.Current.ControlType;
    if(pct!=ControlType.Button&&pct!=ControlType.SplitButton){
     string pn=(prev.Current.Name??"").Trim();
     string br=Bracket(pn);if(br.Length>0)pn=br;
     if(pn.Length>=2&&pn.Length<=60&&!ForbiddenFieldNames.Contains(pn)&&!IsActionLikeButtonName(pn)&&!pn.StartsWith("WindowsForms",StringComparison.OrdinalIgnoreCase))return pn;
    }
    prev=walker.GetPreviousSibling(prev);
   }
   AutomationElement parent=walker.GetParent(el);
   if(parent!=null){
    string parName=(parent.Current.Name??"").Trim();
    string br2=Bracket(parName);if(br2.Length>0)parName=br2;
    if(parName.Length>=2&&parName.Length<=60&&!ForbiddenFieldNames.Contains(parName)&&!IsActionLikeButtonName(parName)&&!parName.StartsWith("WindowsForms",StringComparison.OrdinalIgnoreCase))return parName;
   }
  }catch{}
  if(!string.IsNullOrEmpty(aid)&&aid.Length>=2&&aid.Length<=50&&!ForbiddenFieldNames.Contains(aid))return aid;
  return "İlk Veri Giriş Alanı";
 }

 // 25.10: Sol menü ağacını salt-okunur tarar (hiçbir ekranı açmaz, tıklamaz). Gördüğü menü başlıklarını ogrenilen-ekranlar.json'a yazar.
 Dictionary<string,object> ExploreMenus(){
  if(PosInFront())return Result("hata","Kasa (POS) ekranı önde; menü taraması yapılmadı.",null);
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE veya ERP açık değil.",null);
  object wp;
  if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)){
   var w=(WindowPattern)wp;
   if(w.Current.WindowVisualState==WindowVisualState.Minimized){w.SetWindowVisualState(WindowVisualState.Maximized);Thread.Sleep(600);}
  }
  AutomationElement nav=null;
  try{nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));}catch{}
  AutomationElement scope=nav??main;
  // Kapalı alt klasörleri (Mal Kabul, Depo Yönetimi, Çalışanlar vb.) fare tıklaması yapmadan salt UIA ExpandCollapsePattern ile aç
  try{
   for(int pass=0;pass<2;pass++){
    var treeNodes=scope.FindAll(TreeScope.Descendants,new OrCondition(
     new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TreeItem),
     new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.DataItem)
    ));
    int expCount=0;
    if(treeNodes!=null){
     foreach(AutomationElement tn in treeNodes){
      try{
       object ecp;
       if(tn.TryGetCurrentPattern(ExpandCollapsePattern.Pattern,out ecp)){
        var pat=(ExpandCollapsePattern)ecp;
        if(pat.Current.ExpandCollapseState==ExpandCollapseState.Collapsed){
         pat.Expand();expCount++;
        }
       }
      }catch{}
     }
    }
    if(expCount==0)break;
    Thread.Sleep(150);
   }
  }catch{}
  double maxLeft=420;
  try{var mr=main.Current.BoundingRectangle;if(!mr.IsEmpty&&mr.Left>-10000)maxLeft=mr.Left+420;}catch{}
  var cond=new OrCondition(
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TreeItem),
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.ListItem),
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.MenuItem),
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Hyperlink),
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Button),
   new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Custom)
  );
  AutomationElementCollection all;
  try{using(QuickCache().Activate()){all=scope.FindAll(TreeScope.Descendants,cond);}}
  catch(Exception e){return Result("hata","Sol menü okunamadı: "+e.Message,null);}
  var found=new List<string>();
  var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  foreach(AutomationElement el in all){
   string n="";System.Windows.Rect r=System.Windows.Rect.Empty;ControlType ct=null;
   try{n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;ct=el.Cached.ControlType;}catch{continue;}
   if(n.StartsWith("TreeListColumn row",StringComparison.OrdinalIgnoreCase)){
    string v="";try{object vp;if(el.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=(((ValuePattern)vp).Current.Value??"").Trim();}catch{}
    n=v;
   } else if(ct==ControlType.Custom){
    continue;
   }
   if(n.Length<3||n.Length>120||n.IndexOfAny(new[]{'\r','\n'})>=0||ForbiddenFieldNames.Contains(n))continue;
   if(n.StartsWith("Düğüm",StringComparison.OrdinalIgnoreCase)||n.EndsWith("ColumnFilterButton",StringComparison.OrdinalIgnoreCase)||n.IndexOf(" satır ",StringComparison.OrdinalIgnoreCase)>=0)continue;
   if(nav==null&&!r.IsEmpty&&r.Left>-10000&&r.Left>maxLeft)continue;
   if(seen.Add(n))found.Add(n);
  }
  // SIFIR-HATA ÇÖZÜM-2: Nebim yerel konfigürasyon/XML/layout kataloglarından menü başlıklarını birleştir
  ScanNebimLocalMetadataInto(found,seen);
  int added=0;
  lock(learnLock){
   LoadLearned();
   learned.Remove("System");
   var badKeys=new List<string>();
   foreach(string k in learned.Keys)if(k.StartsWith("Düğüm",StringComparison.OrdinalIgnoreCase))badKeys.Add(k);
   foreach(string k in badKeys)learned.Remove(k);
   var cat=CatalogNames();
   foreach(string n in found){
    if(cat.Contains(n))continue;
    Dictionary<string,object> e;
    if(!learned.TryGetValue(n,out e)){
     e=new Dictionary<string,object>{{"ad",n},{"ilk",DateTime.Now.ToString("s")},{"son",DateTime.Now.ToString("s")},{"sayac",1},{"kaynak","menu-kesif"}};
     learned[n]=e;added++;
    } else if(!e.ContainsKey("kaynak")){
     e["kaynak"]="menu-kesif";
    }
   }
   if(added>0||found.Count>0||badKeys.Count>0){
    var list=new List<object>(learned.Values);
    try{File.WriteAllText(LearnedFile,new JavaScriptSerializer().Serialize(new Dictionary<string,object>{{"surum",1},{"not","Sunucu yardımcısının Nebim STORE/ERP'de açık gördüğü veya sol menüden keşfettiği ekranlar. Yalnız ekran adları; veri yok."},{"ekranlar",list}}),new UTF8Encoding(false));}catch{}
   }
  }
  var res=Result("okundu","Sol menüde "+found.Count+" menü başlığı tarandı ("+added+" yeni menü öğrenildi). Hiçbir ekran açılmadı.",null);
  res["toplam"]=found.Count;res["yeni"]=added;res["menuler"]=found;
  return res;
 }

 Dictionary<string,object> InspectOpenScreen(){
  if(PosInFront())return Result("hata","Kasa (POS) ekranı önde; ekran analizi yapılmadı.",null);
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE veya ERP açık değil.",null);
  object wp;
  if(main.TryGetCurrentPattern(WindowPattern.Pattern,out wp)){
   var w=(WindowPattern)wp;
   if(w.Current.WindowVisualState==WindowVisualState.Minimized){w.SetWindowVisualState(WindowVisualState.Maximized);Thread.Sleep(600);}
  }
  string ekranAd=ActiveName(main);
  var child=ActiveChild(main);
  if(child==null||ekranAd.Length==0)return Result("hata","Nebim'de açık bir alt ekran bulunamadı. Önce analiz edilecek ekranı açın.",null);
  AutomationElementCollection all;
  try{using(QuickCache().Activate()){all=child.FindAll(TreeScope.Descendants,Condition.TrueCondition);}}
  catch(Exception e){return Result("hata","Açık ekran okunamadı: "+e.Message,null);}
  var sekmeler=new List<string>();var alanlar=new List<string>();var dugmeler=new List<string>();
  int count=0;
  foreach(AutomationElement el in all){
   if(++count>15000)break;
   ControlType t=null;string n="";System.Windows.Rect r=System.Windows.Rect.Empty;
   try{t=el.Cached.ControlType;n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;}catch{continue;}
   if(r.IsEmpty||r.Left<=320||r.Top<=145)continue;
   if(n.Length<2||n.Length>90||n.IndexOfAny(new[]{'\r','\n'})>=0||ForbiddenFieldNames.Contains(n))continue;
   string br=Bracket(n);
   if(br.Length>=2&&br.Length<=60&&!ForbiddenFieldNames.Contains(br)){if(!alanlar.Contains(br)&&alanlar.Count<40)alanlar.Add(br);continue;}
   if(t==ControlType.TabItem){if(!sekmeler.Contains(n)&&sekmeler.Count<20)sekmeler.Add(n);}
   else if(t==ControlType.ComboBox||t==ControlType.Edit){
    if(n!=ekranAd&&!alanlar.Contains(n)&&alanlar.Count<40)alanlar.Add(n);
   }
   else if(t==ControlType.Button||t==ControlType.SplitButton){
    if(!dugmeler.Contains(n)&&dugmeler.Count<25)dugmeler.Add(n);
   }
  }
  var res=Result("okundu","'"+ekranAd+"' ekranından "+sekmeler.Count+" sekme, "+alanlar.Count+" alan ve "+dugmeler.Count+" düğme okundu.",ekranAd);
  res["ekran"]=ekranAd;res["ekranAd"]=ekranAd;res["sekmeler"]=sekmeler;res["alanlar"]=alanlar;res["dugmeler"]=dugmeler;
  return res;
 }
 static int CatalogSira(string ekranId){
  try{
   var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
   foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){var d=(Dictionary<string,object>)o;if(Convert.ToString(d["id"])==ekranId&&d.ContainsKey("sira")){int n=Convert.ToInt32(d["sira"]);return n<1?1:(n>15?15:n);}}
  }catch{}
  return 1;
 }
 static string CatalogName(string ekranId){
  var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
  foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
   var d=(Dictionary<string,object>)o;
   if(Convert.ToString(d["id"])==ekranId)return Convert.ToString(d["ad"]);
  }
  if(ekranId.StartsWith("ogr:",StringComparison.Ordinal)){
   string ad=ekranId.Substring(4);
   lock(learnLock){LoadLearned();if(learned.ContainsKey(ad))return ad;}
   throw new Exception("Bu ekran öğrenilenler listesinde yok; açılmadı.");
  }
  throw new Exception("Bu ekran katalogda yok; açılmadı.");
 }
 // ---------- Öğrenme: kullanıcının Nebim'de açtığı ekranları kaydet (yalnız MDI alt pencereleri) ----------
 static readonly object learnLock=new object();
 static Dictionary<string,Dictionary<string,object>> learned;
 static HashSet<string> openBefore=new HashSet<string>();
 static string LearnedFile{get{return Path.Combine(Root,"ogrenilen-ekranlar.json");}}
 static void LoadLearned(){
   if(learned!=null)return;
   learned=new Dictionary<string,Dictionary<string,object>>(StringComparer.OrdinalIgnoreCase);
   try{
    if(!File.Exists(LearnedFile))return;
    var d=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(LearnedFile,Encoding.UTF8));
    if(d!=null&&d.ContainsKey("ekranlar")&&d["ekranlar"] is System.Collections.IEnumerable){
     foreach(object o in (System.Collections.IEnumerable)d["ekranlar"]){
      var e=o as Dictionary<string,object>;
      if(e==null)continue;
      string ad=e.ContainsKey("ad")&&e["ad"]!=null?Convert.ToString(e["ad"]):(e.ContainsKey("baslik")&&e["baslik"]!=null?Convert.ToString(e["baslik"]):"");
      if(ad.Length>0){if(!e.ContainsKey("ad"))e["ad"]=ad;if(!e.ContainsKey("sayac"))e["sayac"]=1;learned[ad]=e;}
     }
    }
   }catch(Exception e){Log("Ogrenilen ekranlar okunamadi: "+e.Message);}
  }
  static HashSet<string> catalogNames;static DateTime catalogStamp;
 static HashSet<string> CatalogNames(){
  try{
   var f=new FileInfo(Path.Combine(Root,"ekranlar.json"));
   if(catalogNames==null||f.LastWriteTimeUtc!=catalogStamp){
    var set=new HashSet<string>();
    var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(f.FullName,Encoding.UTF8));
    foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"])set.Add(Convert.ToString(((Dictionary<string,object>)o)["ad"]));
    catalogNames=set;catalogStamp=f.LastWriteTimeUtc;
   }
  }catch{if(catalogNames==null)catalogNames=new HashSet<string>();}
  return catalogNames;
 }
 static void ObserveScreens(AutomationElement main){
  var now=GetOpenMdiWindowNames(main);
  if(now.Count==0){openBefore=now;return;}
  bool changed=false;
  lock(learnLock){
   LoadLearned();
   foreach(string rawN in now){
    string n=StripNebimTitle(rawN);
    if(n.Length<2||openBefore.Contains(rawN))continue;
    Dictionary<string,object> e;
    if(CatalogNames().Contains(n))continue;
    if(!learned.TryGetValue(n,out e)){e=new Dictionary<string,object>{{"ad",n},{"ilk",DateTime.Now.ToString("s")},{"sayac",0}};learned[n]=e;Log("Yeni ekran öğrenildi: "+n);}
    int prevCnt=0;try{if(e.ContainsKey("sayac")&&e["sayac"]!=null)prevCnt=Convert.ToInt32(e["sayac"]);}catch{prevCnt=0;}e["sayac"]=prevCnt+1;e["son"]=DateTime.Now.ToString("s");changed=true;
   }
   openBefore=now;
   if(changed){
    var list=new List<object>(learned.Values);
    File.WriteAllText(LearnedFile,new JavaScriptSerializer().Serialize(new Dictionary<string,object>{{"surum",1},{"not","Sunucu yardımcısının Nebim STORE'da açık gördüğü ekranlar. Yalnız ekran adları; veri yok."},{"ekranlar",list}}),new UTF8Encoding(false));
   }
  }
 }
 // ---------- Alan gösterici ----------
 Dictionary<string,object> ShowField(string alan){
  alan=(alan??"").Trim();
  if(alan.Length<2||alan.Length>80)return Result("hata","Gösterilecek alan adı 2–80 karakter olmalı.",null);
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  AutomationElement child=ActiveChild(main);
  if(child==null)return Result("bulunamadi","Nebim'de açık bir ekran yok; çerçeve çizilmedi.",null);
  string q=Norm(alan);
  AutomationElement best=null;int bestScore=0;
  try{
   AutomationElementCollection all=child.FindAll(TreeScope.Descendants,Condition.TrueCondition);
   int n=0;
   foreach(AutomationElement e in all){
    if(++n>6000)break;
    string name;System.Windows.Rect r;ControlType ct;
    try{name=(e.Current.Name??"").Trim();r=e.Current.BoundingRectangle;ct=e.Current.ControlType;if(e.Current.IsOffscreen)continue;}catch{continue;}
    if(name.Length==0||r.IsEmpty||r.Left<=320||r.Top<=145||r.Width<30||r.Height<14)continue;
    if(ct==ControlType.Text||ct==ControlType.Group||ct==ControlType.Pane||ForbiddenFieldNames.Contains(name))continue;
    string nn=Norm(name),nb=Norm(Bracket(name));
    int score=nn==q||nb==q?100:(q.Length>=4&&(nn.StartsWith(q)||nb.StartsWith(q)))?60:(q.Length>=5&&nn.Contains(q))?40:0;
    if(score>bestScore){bestScore=score;best=e;if(score==100)break;}
   }
  }catch{}
  if(best==null)return Result("bulunamadi","'"+alan+"' alanı açık ekranda bulunamadı.",null);
  var rect=best.Current.BoundingRectangle;
  ShowRdpFrameSafe(new Rectangle((int)rect.X,(int)rect.Y,(int)rect.Width,(int)rect.Height),alan,false,ActiveName(main));
  var okRes=Result("gosterildi","'"+best.Current.Name+"' turuncu çerçeveyle gösterildi.",null);
  okRes["alanSol"]=(int)rect.X;okRes["alanUst"]=(int)rect.Y;okRes["alanGenislik"]=(int)rect.Width;okRes["alanYukseklik"]=(int)rect.Height;
  return okRes;
 }

 // ADIM 2.1: Yalnızca orta MDI çalışma alanında (relX > 320, relY > 145) gerçek bir alt pencere varsa ekran açık sayılır!
 static string ActiveName(AutomationElement main){
  var c=ActiveChild(main);
  if(c==null)return "";
  try{
   string cn=StripNebimTitle((c.Current.Name??"").Trim());
   if(cn.Length>0)return cn;
  }catch{}
  return "";
 }

 static AutomationElement ActiveChild(AutomationElement main){
  if(main==null)return null;
  var mdi=FindMdi(main);
  if(mdi==null)return null;
  var walker=TreeWalker.ControlViewWalker;
  AutomationElement c=null;
  try{c=walker.GetFirstChild(mdi);}catch{}
  int guard=0;
  while(c!=null&&++guard<50){
   try{
    if(c.Current.ControlType==ControlType.Window&&!c.Current.IsOffscreen){
     var r=c.Current.BoundingRectangle;
     if(!r.IsEmpty&&r.Width>200&&r.Height>140&&(r.Left+r.Width)>340&&(r.Top+r.Height)>180){
      return c;
     }
    }
   }catch{}
   try{c=walker.GetNextSibling(c);}catch{c=null;}
  }
  return null;
 }

 Dictionary<string,object> RunSummary(Dictionary<string,object> req=null){
  try{
   var sqlReq=req!=null?new Dictionary<string,object>(req):new Dictionary<string,object>();
   var sqlRes=RunSqlReadAndDiagnostics(sqlReq);
   if(sqlRes!=null&&sqlRes.ContainsKey("pmV3BaglantiAcik")&&Convert.ToBoolean(sqlRes["pmV3BaglantiAcik"])&&sqlRes.ContainsKey("ozet")){
    var oz=sqlRes["ozet"] as Dictionary<string,object>;
    if(oz!=null){
     decimal netSatis=0m,urunAdedi=0m,nakitSatis=0m,kartSatis=0m;
     int islemSayisi=0;
     try{if(oz.ContainsKey("netSatis"))netSatis=Convert.ToDecimal(oz["netSatis"]);}catch{}
     try{if(oz.ContainsKey("urunAdedi"))urunAdedi=Convert.ToDecimal(oz["urunAdedi"]);}catch{}
     try{if(oz.ContainsKey("islemSayisi"))islemSayisi=Convert.ToInt32(oz["islemSayisi"]);}catch{}
     try{if(oz.ContainsKey("nakitSatis"))nakitSatis=Convert.ToDecimal(oz["nakitSatis"]);}catch{}
     try{if(oz.ContainsKey("kartSatis"))kartSatis=Convert.ToDecimal(oz["kartSatis"]);}catch{}
     var tr=System.Globalization.CultureInfo.GetCultureInfo("tr-TR");
     var satirlar=new List<Dictionary<string,object>>();
     satirlar.Add(new Dictionary<string,object>{
      {"odeme sekli","Genel Toplam"},
      {"islem sayisi",islemSayisi.ToString(tr)},
      {"miktar",urunAdedi.ToString("N2",tr)},
      {"net tutar",netSatis.ToString("N2",tr)},
      {"toplam",netSatis.ToString("N2",tr)}
     });
     if(nakitSatis>0m){
      satirlar.Add(new Dictionary<string,object>{
       {"odeme sekli","Nakit"},
       {"pesinat",nakitSatis.ToString("N2",tr)},
       {"toplam",nakitSatis.ToString("N2",tr)}
      });
     }
     if(kartSatis>0m){
      satirlar.Add(new Dictionary<string,object>{
       {"odeme sekli","Kredi Kartı"},
       {"pesinat",kartSatis.ToString("N2",tr)},
       {"toplam",kartSatis.ToString("N2",tr)}
      });
     }
     return new Dictionary<string,object>{
      {"ok",true},
      {"durum","okundu"},
      {"kaynak","sql"},
      {"rapor","SQL Canlı (PM_V3)"},
      {"mesaj","Rakamlar doğrudan SQL (PM_V3) üzerinden salt-okunur okundu."},
      {"satirSayisi",satirlar.Count},
      {"satirlar",satirlar},
      {"ozet",oz}
     };
    }
   }
  }catch(Exception sqlEx){Log("RunSummary SQL öncelikli okuma uyarısı: "+sqlEx.Message);}

  const string ad="Mağaza Hareket Özeti";
  if(PosInFront())return ReadPos();
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  var o=OpenScreen(ad);
  if(!(o.ContainsKey("ok")&&(bool)o["ok"]))return o;
  Thread.Sleep(800);
  AutomationElement child=null;
  try{var mdi=FindMdi(main);if(mdi!=null)child=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&MatchesScreenName(StripNebimTitle(c.Current.Name),ad));}catch{}
  if(child==null)return Result("hata","Hareket Özeti penceresi bulunamadı.",null);
  AutomationElement btn=null;
  System.Windows.Rect childRect=System.Windows.Rect.Empty,mdiRect=System.Windows.Rect.Empty;
  try{childRect=child.Current.BoundingRectangle;var mdi0=FindMdi(main);if(mdi0!=null)mdiRect=mdi0.Current.BoundingRectangle;}catch{}
  var sw=Stopwatch.StartNew();
  while(btn==null&&sw.ElapsedMilliseconds<8000){
   btn=FindRunButton(child);
   if(btn==null){var cand=FindRunButton(main);if(cand!=null&&RunButtonAllowed(cand,childRect,mdiRect))btn=cand;}
   if(btn==null)Thread.Sleep(500);
  }
  if(btn==null){DumpButtons(child,main);return Result("hata","Hareket Özeti açıldı ama 'Çalıştır' düğmesi bulunamadı.",null);}
  if(PosInFront())return Result("hata","Kasa (POS) ekranı öne geçti; satış bölünmesin diye Çalıştır'a basmadım.",null);
  try{
   object ip;
   if(btn.TryGetCurrentPattern(InvokePattern.Pattern,out ip))((InvokePattern)ip).Invoke();
   else{var r=btn.Current.BoundingRectangle;if(r.IsEmpty)throw new Exception("düğme görünmüyor");ClickAt((int)(r.X+r.Width/2),(int)(r.Y+r.Height/2));}
   Log("Hareket Özeti: Çalıştır'a basıldı (yalnız rapor çalıştırma).");
  }catch(Exception e){return Result("hata","'Çalıştır'a basılamadı: "+e.Message,null);}
  Dictionary<string,object> last=null;
  for(int i=0;i<20;i++){
   Thread.Sleep(1000);
   try{
    last=ReadReport();
    var col=last.ContainsKey("satirlar")?last["satirlar"] as System.Collections.ICollection:null;
    if(last.ContainsKey("ok")&&(bool)last["ok"]&&col!=null&&col.Count>0)return last;
   }catch{}
  }
  return last??Result("hata","Rapor 20 saniyede sonuç vermedi.",null);
 }
 static readonly string[] RunNames={"Çalıştır","Çalıştır (F5)","Çalıştır(F5)","ÇALIŞTIR","Calistir"};
 static CacheRequest QuickCache(){var cr=new CacheRequest();cr.Add(AutomationElement.NameProperty);cr.Add(AutomationElement.ControlTypeProperty);cr.Add(AutomationElement.IsOffscreenProperty);cr.Add(AutomationElement.IsEnabledProperty);cr.Add(AutomationElement.BoundingRectangleProperty);return cr;}
 static AutomationElement FindRunButton(AutomationElement root){
  if(root==null)return null;AutomationElement best=null;
  try{
   var conds=new List<Condition>();foreach(var nm in RunNames)conds.Add(new PropertyCondition(AutomationElement.NameProperty,nm));
   AutomationElementCollection hits;
   using(QuickCache().Activate()){hits=root.FindAll(TreeScope.Descendants,new OrCondition(conds.ToArray()));}
   foreach(AutomationElement el in hits){
    try{if(!el.Cached.IsEnabled||el.Cached.IsOffscreen)continue;var ct=el.Cached.ControlType;if(ct==ControlType.Button)return el;if(best==null&&(ct==ControlType.MenuItem||ct==ControlType.ListItem||ct==ControlType.Custom||ct==ControlType.SplitButton))best=el;}catch{}
   }
   if(best!=null)return best;
  }catch{}
  try{
   AutomationElementCollection all;
   var types=new OrCondition(new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Button),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.MenuItem),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.ListItem),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.SplitButton),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Custom));
   using(QuickCache().Activate()){all=root.FindAll(TreeScope.Descendants,types);}
   foreach(AutomationElement el in all){
    string n="";ControlType t=null;bool on=true,off=false;
    try{n=el.Cached.Name??"";t=el.Cached.ControlType;on=el.Cached.IsEnabled;off=el.Cached.IsOffscreen;}catch{continue;}
    if(!on||off)continue;
    string k=Norm(n).Trim();
    if(k=="calistir"||k.StartsWith("calistir ")||k.StartsWith("calistir(")){if(t==ControlType.Button)return el;if(best==null)best=el;}
   }
  }catch{}
  return best;
 }
 static bool RunButtonAllowed(AutomationElement b,System.Windows.Rect childRect,System.Windows.Rect mdiRect){
  try{var r=b.Current.BoundingRectangle;if(r.IsEmpty)return false;
   if(!childRect.IsEmpty&&childRect.Contains(new System.Windows.Point(r.X+r.Width/2,r.Y+r.Height/2)))return true;
   if(!mdiRect.IsEmpty&&r.Bottom<=mdiRect.Top+2)return true;
  }catch{}
  return false;
 }
 static void DumpButtons(AutomationElement child,AutomationElement main){
  var sb=new StringBuilder();sb.AppendLine("Çalıştır tanısı "+DateTime.Now.ToString("s"));
  foreach(var pair in new[]{new KeyValuePair<string,AutomationElement>("rapor",child),new KeyValuePair<string,AutomationElement>("store",main)}){
   if(pair.Value==null)continue;int c=0;
   try{foreach(AutomationElement e in pair.Value.FindAll(TreeScope.Descendants,Condition.TrueCondition)){
    string n="",t="";try{n=e.Current.Name??"";t=e.Current.ControlType.ProgrammaticName;}catch{continue;}
    if(n.Length==0||!(t.Contains("Button")||t.Contains("MenuItem")||t.Contains("ListItem")||t.Contains("Custom")))continue;
    sb.AppendLine("  "+pair.Key+" | "+t.Replace("ControlType.","")+" | "+n);if(++c>=150)break;
   }}catch{}
  }
  try{File.WriteAllText(Path.Combine(Root,"calistir-tani.txt"),sb.ToString(),new UTF8Encoding(false));}catch{}
 }
 static readonly string[] ReadableReports={"Mağaza Hareket Özeti","Mağaza Ciro Raporu","Mağaza Satış ve Envanter Raporu","Günlük Mağaza Ciro Raporu"};
 static readonly string[] PersonnelScreens={"Satış Sorumluları Satış ve Prim Raporu","Mağazanın Çalışan Listesi","Personel Listesi","Personel Kişisel Bilgiler Raporu","Satış Sorumlusu","Personel","Personel Masraf Faturası","Personele Banka Üzerinden Yapılan Ödemeler","Personele Kasa Üzerinden Yapılan Ödemeler ve Avans İadesi"};
 static readonly string[] TotalWords={"toplam","genel toplam","nakit","kredi kart","kart","banka","hediye","iade","iskonto","net tutar","brut","fis sayisi","adet"};
 static bool IsTotalLike(string s){string n=Norm(s);foreach(string w in TotalWords)if(n.Contains(w))return true;return false;}
 Dictionary<string,object> ReadPersonnelData(Dictionary<string,object> req){
  try{
   string pkgFile=Path.Combine(Root,"personel-veri-paketi.json");
   if(!File.Exists(pkgFile)||Math.Abs((DateTime.UtcNow-File.GetLastWriteTimeUtc(pkgFile)).TotalMinutes)>10.0){
    RunSqlReadAndDiagnostics(req);
   }
   if(File.Exists(pkgFile)){
    var js=new JavaScriptSerializer{MaxJsonLength=4*1024*1024};
    var pkg=js.Deserialize<Dictionary<string,object>>(File.ReadAllText(pkgFile,Encoding.UTF8));
    if(pkg!=null&&pkg.ContainsKey("personelSatirlari")){
     var list=pkg["personelSatirlari"] as System.Collections.ICollection;
     int cnt=list!=null?list.Count:0;
     if(cnt>0){
      var okSql=Result("okundu","SQL Canli (PM_V3.dbo.cdSalesperson) uzerinden "+cnt+" personel ve son 30 gun satis/prim verisi sifir hatayla okundu.","SQL Canli (PM_V3)");
      okSql["ekran"]="SQL Canli (PM_V3.dbo.cdSalesperson)";
      okSql["personelSatirlari"]=pkg["personelSatirlari"];
      okSql["toplamSatir"]=cnt;
      okSql["satirSayisi"]=cnt;
      okSql["alanSayisi"]=8;
      okSql["kaynak"]="sql";
      okSql["tarih"]=DateTime.Now.ToString("s");
      return okSql;
     }
    }
   }
  }catch{}
  if(PosInFront())return Result("hata","Kasa (POS) önde; güvenlik nedeniyle işlem yapılmadı.",null);
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  bool autoOpen=req!=null&&req.ContainsKey("ac")&&Convert.ToBoolean(req["ac"]);
  string reqBaslik=req!=null&&req.ContainsKey("baslik")?Convert.ToString(req["baslik"]).Trim():"";
  if(autoOpen&&reqBaslik.Length>=2){
   OpenMerkezScreen(req);
   Thread.Sleep(700);
  }
  var child=ActiveChild(main);
  string ad="";try{ad=child==null?"":StripNebimTitle(child.Current.Name);}catch{}
  if(child==null||Array.IndexOf(PersonnelScreens,ad)<0){
   var mdi=FindMdi(main);
   if(mdi!=null){
    var r2=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&(Array.IndexOf(PersonnelScreens,StripNebimTitle(c.Current.Name))>=0||Norm(c.Current.Name).Contains("personel")||Norm(c.Current.Name).Contains("calisan")||Norm(c.Current.Name).Contains("satis sorumlusu")||Norm(c.Current.Name).Contains("prim")));
    if(r2!=null){child=r2;try{ad=StripNebimTitle(r2.Current.Name);}catch{}}
   }
  }
  if(child==null)return Result("hata","Nebim'de açık bir Personel / Satış Sorumlusu / Prim ekranı bulunamadı.",null);
  AutomationElementCollection all;try{all=child.FindAll(TreeScope.Descendants,Condition.TrueCondition);}catch(Exception e){return Result("hata","Personel ekranı okunamadı: "+e.Message,null);}
  var headers=new List<string>();var personeller=new List<object>();var formAlanlari=new List<object>();
  int seen=0;var walker=TreeWalker.ControlViewWalker;
  foreach(AutomationElement e in all){
   if(++seen>25000)break;
   ControlType t;string n="";try{t=e.Current.ControlType;n=(e.Current.Name??"").Trim();}catch{continue;}
   if(t==ControlType.Header||t==ControlType.HeaderItem){if(n.Length>0&&n.Length<80&&headers.Count<80&&!headers.Contains(n))headers.Add(n);continue;}
   if(t==ControlType.DataItem||t==ControlType.ListItem||t==ControlType.TreeItem){
    var cells=new Dictionary<string,object>(StringComparer.OrdinalIgnoreCase);
    AutomationElement k=null;try{k=walker.GetFirstChild(e);}catch{}
    int kc=0;
    while(k!=null&&kc<60){
     string kn="",kv="";try{kn=(k.Current.Name??"").Trim();object vp;if(k.TryGetCurrentPattern(ValuePattern.Pattern,out vp))kv=((ValuePattern)vp).Current.Value??"";}catch{}
     var mm=System.Text.RegularExpressions.Regex.Match(kn,@"^(.*?)\s+satır\s+\d+$");if(mm.Success)kn=mm.Groups[1].Value.Trim();
     if(kn.Length>0&&(kv.Length>0||cells.Count<25))cells[Short(kn)]=Short(kv);
     kc++;try{k=walker.GetNextSibling(k);}catch{k=null;}
    }
    if(cells.Count>0&&personeller.Count<400){
     personeller.Add(new Dictionary<string,object>{{"satir",Short(n)},{"alanlar",cells}});
    }
    continue;
   }
   if((t==ControlType.Edit||t==ControlType.ComboBox)&&n.Length>0&&formAlanlari.Count<80){
    string v="";try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=((ValuePattern)vp).Current.Value??"";}catch{}
    if(v.Length>0)formAlanlari.Add(new Dictionary<string,object>{{"alan",Short(n)},{"deger",Short(v)}});
   }
  }
  var res=Result("okundu","'"+ad+"' ekranından "+personeller.Count+" personel/prim satırı ve "+formAlanlari.Count+" form alanı salt-okunur okundu.",ad);
  res["ekran"]=ad;res["kolonBasliklari"]=headers;res["personelSatirlari"]=personeller;res["formAlanlari"]=formAlanlari;res["tarih"]=DateTime.Now.ToString("s");
  try{
   string pkgPath=Path.Combine(Root,"personel-veri-paketi.json");
   File.WriteAllText(pkgPath,new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(res),new UTF8Encoding(false));
  }catch{}
  return res;
 }
 Dictionary<string,object> ReadReport(){
  var main=FindStore();if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  var child=ActiveChild(main);
  string ad="";try{ad=child==null?"":StripNebimTitle(child.Current.Name);}catch{}
  if(Array.IndexOf(ReadableReports,ad)<0){
   var mdi=FindMdi(main);
   if(mdi!=null){var r2=Child(mdi,c=>c.Current.ControlType==ControlType.Window&&Array.IndexOf(ReadableReports,StripNebimTitle(c.Current.Name))>=0);if(r2!=null){child=r2;try{ad=StripNebimTitle(r2.Current.Name);}catch{}}}
  }
  if(Array.IndexOf(ReadableReports,ad)<0)return Result("hata","Önde okunabilir bir rapor yok"+(ad.Length>0?" (önde: "+ad+")":"")+".",null);
  return ReadElement(child,ad,"okuma-tani.txt");
 }
 Dictionary<string,object> ReadElement(AutomationElement child,string ad,string taniDosya){
  var tani=new StringBuilder();tani.AppendLine("Okuma tanısı "+DateTime.Now.ToString("s")+" rapor="+ad);
  AutomationElementCollection all;try{all=child.FindAll(TreeScope.Descendants,Condition.TrueCondition);}catch(Exception e){return Result("hata","Rapor okunamadı: "+e.Message,null);}
  var rows=new List<object>();var loose=new List<object>();var headers=new List<string>();var counts=new Dictionary<string,int>();
  int seen=0;var walker=TreeWalker.ControlViewWalker;
  foreach(AutomationElement e in all){
   if(++seen>25000)break;
   ControlType t;string n="";try{t=e.Current.ControlType;n=(e.Current.Name??"").Trim();}catch{continue;}
   string tn=t.ProgrammaticName.Replace("ControlType.","");
   int c;counts.TryGetValue(tn,out c);counts[tn]=c+1;
   if(t==ControlType.Header||t==ControlType.HeaderItem){if(n.Length>0&&n.Length<60&&headers.Count<80&&!headers.Contains(n))headers.Add(n);continue;}
   if(t==ControlType.DataItem||t==ControlType.ListItem||t==ControlType.TreeItem){
    var cells=new List<object>();bool interesting=IsTotalLike(n);
    AutomationElement k=null;try{k=walker.GetFirstChild(e);}catch{}
    int kc=0;
    bool gridRow=false;
    while(k!=null&&kc<60){
     string kn="",kv="";try{kn=(k.Current.Name??"").Trim();object vp;if(k.TryGetCurrentPattern(ValuePattern.Pattern,out vp))kv=((ValuePattern)vp).Current.Value??"";}catch{}
     var mm=System.Text.RegularExpressions.Regex.Match(kn,@"^(.*?)\s+satır\s+\d+$");if(mm.Success){kn=mm.Groups[1].Value;gridRow=true;}
     if(IsTotalLike(kv))interesting=true;
     cells.Add(new Dictionary<string,object>{{"kolon",Short(kn)},{"deger",Short(kv)}});kc++;
     try{k=walker.GetNextSibling(k);}catch{k=null;}
    }
    if(gridRow&&(ad=="Mağaza Hareket Özeti"||ad=="Mağaza Ciro Raporu"||ad=="Günlük Mağaza Ciro Raporu"))interesting=true;
    if(interesting&&rows.Count<80)rows.Add(new Dictionary<string,object>{{"satir",Short(n)},{"hucreler",cells}});
    continue;
   }
   if(loose.Count<120){
    string v="";try{object vp;if(e.TryGetCurrentPattern(ValuePattern.Pattern,out vp))v=((ValuePattern)vp).Current.Value??"";}catch{}
    if(t!=ControlType.Edit&&(IsTotalLike(n)||IsTotalLike(v))){
     string next="";
     try{var s=walker.GetNextSibling(e);if(s!=null){next=(s.Current.Name??"").Trim();object vp2;if(next.Length==0&&s.TryGetCurrentPattern(ValuePattern.Pattern,out vp2))next=((ValuePattern)vp2).Current.Value??"";}}catch{}
     loose.Add(new Dictionary<string,object>{{"tur",tn},{"ad",Short(n)},{"deger",Short(v)},{"sonraki",Short(next)}});
    }
   }
  }
  if(rows.Count==0&&loose.Count==0)return Result("bulunamadi","'"+ad+"' açık ama toplam satırı okunamadı.",null);
  var r=Result("okundu","'"+ad+"' raporundan "+rows.Count+" toplam satırı okundu.",null);
  r["rapor"]=ad;r["satirlar"]=rows;r["ogeler"]=loose;r["basliklar"]=headers;
  return r;
 }
 Dictionary<string,object> ReadPos(){
  AutomationElement pw=null;
  try{IntPtr h=GetForegroundWindow();if(ProcessNameOf(h).Equals("NebimV3POS",StringComparison.OrdinalIgnoreCase))pw=AutomationElement.FromHandle(h);}catch{}
  if(pw==null)return Result("hata","POS penceresi okunamadı.",null);
  AutomationElement hedef=null;string wn="";
  try{wn=pw.Current.Name??"";}catch{}
  if(Norm(wn).Contains("hareket ozeti"))hedef=pw;
  if(hedef==null){
   try{
    AutomationElementCollection adaylar;
    var turler=new OrCondition(new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Window),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Pane),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Group),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TabItem),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Text),new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.TitleBar));
    using(QuickCache().Activate()){adaylar=pw.FindAll(TreeScope.Descendants,turler);}
    foreach(AutomationElement e in adaylar){
    string n="";ControlType t=null;bool off=false;try{n=e.Cached.Name??"";t=e.Cached.ControlType;off=e.Cached.IsOffscreen;}catch{continue;}
    if(off)continue;
    if((t==ControlType.Window||t==ControlType.Pane||t==ControlType.Group||t==ControlType.TabItem||t==ControlType.Text||t==ControlType.TitleBar)&&Norm(n).Contains("hareket ozeti")){
     hedef=(t==ControlType.Text||t==ControlType.TitleBar||t==ControlType.TabItem)?pw:e;break;}
   }}catch{}
  }
  if(hedef==null)return Result("hata","POS önde ama Mağaza Hareket Özeti açık değil.",null);
  var r=ReadElement(hedef,"Mağaza Hareket Özeti","okuma-tani-pos.txt");
  r["kaynak"]="pos";
  var metin=new List<object>();
  try{AutomationElementCollection yazilar;using(QuickCache().Activate()){yazilar=hedef.FindAll(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Text));}
   foreach(AutomationElement e in yazilar){
   string n="";System.Windows.Rect b=System.Windows.Rect.Empty;try{n=(e.Cached.Name??"").Trim();b=e.Cached.BoundingRectangle;}catch{continue;}
   if(n.Length==0||b.IsEmpty)continue;
   metin.Add(new Dictionary<string,object>{{"t",Short(n)},{"x",(int)b.X},{"y",(int)b.Y},{"w",(int)b.Width}});
   if(metin.Count>=400)break;
  }}catch{}
  r["metinler"]=metin;
  try{var pr=PosRows(metin);if(pr.Count>0){r["satirlar"]=pr;r["mesaj"]="POS'taki Mağaza Hareket Özeti'nden "+pr.Count+" satır okundu.";}}catch{}
  return r;
 }
 static readonly System.Text.RegularExpressions.Regex PosNum=new System.Text.RegularExpressions.Regex(@"^-?[0-9.]+(,[0-9]+)?$");
 static List<object> PosRows(List<object> metin){
  var items=new List<Dictionary<string,object>>();foreach(object o in metin){var d=o as Dictionary<string,object>;if(d!=null)items.Add(d);}
  items.Sort((p,q)=>{int c1=Convert.ToInt32(p["y"]).CompareTo(Convert.ToInt32(q["y"]));return c1!=0?c1:Convert.ToInt32(p["x"]).CompareTo(Convert.ToInt32(q["x"]));});
  var lines=new List<KeyValuePair<int,List<Dictionary<string,object>>>>();
  foreach(var d in items){int yy=Convert.ToInt32(d["y"]);
   if(lines.Count>0&&Math.Abs(yy-lines[lines.Count-1].Key)<=3)lines[lines.Count-1].Value.Add(d);
   else lines.Add(new KeyValuePair<int,List<Dictionary<string,object>>>(yy,new List<Dictionary<string,object>>{d}));}
  var rows=new List<object>();List<Dictionary<string,object>> head=null;int prevY=-1000;
  foreach(var kv in lines){
   var line=kv.Value;line.Sort((p,q)=>Convert.ToInt32(p["x"]).CompareTo(Convert.ToInt32(q["x"])));
   if(kv.Key-prevY>50)head=null;prevY=kv.Key;
   bool anyNum=false;foreach(var t in line)if(PosNum.IsMatch(Convert.ToString(t["t"])))anyNum=true;
   if(line.Count==1){head=null;continue;}
   if(line.Count>=4&&!anyNum){head=line;continue;}
   if(head==null||!anyNum)continue;
   var cells=new List<object>();
   foreach(var t in line){
    int x=Convert.ToInt32(t["x"]),w=Math.Max(Convert.ToInt32(t["w"]),1);string kol="";int bestOv=0;
    foreach(var h in head){int hx=Convert.ToInt32(h["x"]),hw=Math.Max(Convert.ToInt32(h["w"]),1);int ov=Math.Min(x+w,hx+hw)-Math.Max(x,hx);if(ov>bestOv){bestOv=ov;kol=Convert.ToString(h["t"]);}}
    if(kol.Length==0){double cx=x+w/2.0,bd=double.MaxValue;string bk="";int bw=1;
     foreach(var h in head){int hx=Convert.ToInt32(h["x"]),hw=Math.Max(Convert.ToInt32(h["w"]),1);double dd=Math.Abs(hx+hw/2.0-cx);if(dd<bd){bd=dd;bk=Convert.ToString(h["t"]);bw=hw;}}
     if(bd<=Math.Max(bw,w))kol=bk;}
    if(kol.Length>0)cells.Add(new Dictionary<string,object>{{"kolon",kol},{"deger",Convert.ToString(t["t"])}});
   }
   if(cells.Count>0)rows.Add(new Dictionary<string,object>{{"satir",Convert.ToString(line[0]["t"])},{"hucreler",cells}});
  }
  return rows;
 }
 Dictionary<string,object> SearchOnly(string text){
  text=(text??"").Trim();
  if(text.Length<2||text.Length>60)return Result("hata","Aranacak metin 2–60 karakter olmalı.",null);
  if(PosInFront())return Result("hata","Kasa (POS) ekranı önde.",null);
  var main=FindStore();
  if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
  System.Windows.Rect erpWinRect=GetElementOrWindowRect(main,mainH);
  var box=FindSearchBoxMerkez(main,erpWinRect);
  if(box==null)return Result("hata","Ara kutusu bulunamadı.",null);
  if(!FocusBox(box,mainH))return Result("hata","Nebim'in Ara kutusuna odaklanılamadı.",null);
  Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(40);
  Press(VK_DELETE);Press(VK_BACK);Thread.Sleep(60);
  TypeText(text);Thread.Sleep(600);
  return Result("liste-acik","Nebim'in Ara listesinde '"+text+"' filtrelendi.",null);
 }
 static DateTime lastDiag=DateTime.MinValue;
 static bool IsStoreTitle(string t){
  return !string.IsNullOrEmpty(t)&&t.IndexOf("Nebim V3 STORE",StringComparison.OrdinalIgnoreCase)>=0;
 }
 static bool IsErpOnlyTitle(string t){
  return !string.IsNullOrEmpty(t)&&t.IndexOf("Nebim V3 ERP",StringComparison.OrdinalIgnoreCase)>=0&&!IsStoreTitle(t)&&t.IndexOf("Merkez Asistan",StringComparison.OrdinalIgnoreCase)<0&&t.IndexOf("Yol Gösterici",StringComparison.OrdinalIgnoreCase)<0;
 }
 static AutomationElement FindStore(){
  return FindStoreInternal(false);
 }
 static void LogMissingErpDiagnostics(){
  try{
   if((DateTime.Now-lastDiag).TotalSeconds<15)return;
   lastDiag=DateTime.Now;
   var sb=new StringBuilder();
   sb.AppendLine("[TANI] Nebim V3 ERP/STORE penceresi bulunamadı (Kullanıcı="+Environment.UserName+", Session="+Process.GetCurrentProcess().SessionId+"):");
   foreach(string pn in new[]{"NebimV3ERP","NebimV3STORE"}){
    try{
     foreach(var p in Process.GetProcessesByName(pn)){
      try{sb.AppendLine("  süreç "+pn+" pid="+p.Id+" session="+p.SessionId+" hwnd="+p.MainWindowHandle+" başlık=["+p.MainWindowTitle+"]");}catch{}
      finally{p.Dispose();}
     }
    }catch{}
   }
   try{
    var wins=AutomationElement.RootElement.FindAll(TreeScope.Children,Condition.TrueCondition);
    sb.AppendLine("  oturumdaki üst pencereler ("+(wins!=null?wins.Count:0)+"):");
    if(wins!=null){
     foreach(AutomationElement w in wins){
      try{
       int wpid=w.Current.ProcessId;
       string wn=w.Current.Name??"";
       string wc=w.Current.ClassName??"";
       sb.AppendLine("    pencere pid="+wpid+" başlık=["+wn+"] sınıf=["+wc+"]");
      }catch{}
     }
    }
   }catch{}
   Log(sb.ToString().TrimEnd());
  }catch{}
 }
 static AutomationElement FindStoreInternal(bool preferErp){
  AutomationElement fallback=null;
  int mySession=0;try{mySession=Process.GetCurrentProcess().SessionId;}catch{}
  var erpPids=new HashSet<int>();
  string[] procOrder=preferErp?new[]{"NebimV3ERP","NebimV3STORE"}:new[]{"NebimV3STORE","NebimV3ERP"};
  foreach(string pn in procOrder){
   Process[] ps;try{ps=Process.GetProcessesByName(pn);}catch{continue;}
   foreach(var p in ps){
    try{
     if(mySession>0&&p.SessionId!=mySession)continue;
     erpPids.Add(p.Id);
     IntPtr h=p.MainWindowHandle;string mt=p.MainWindowTitle??"";
     if(h!=IntPtr.Zero){
      if(preferErp&&IsErpOnlyTitle(mt))return AutomationElement.FromHandle(h);
      if(!preferErp&&IsStoreTitle(mt))return AutomationElement.FromHandle(h);
      if(fallback==null&&(IsStoreTitle(mt)||IsErpOnlyTitle(mt)||mt.Length>0))fallback=AutomationElement.FromHandle(h);
     }
    }catch{}
    finally{p.Dispose();}
   }
  }
  if(erpPids.Count==0)return null;
  try{
   IntPtr fg=GetForegroundWindow();
   if(fg!=IntPtr.Zero){
    uint fgPid=0;GetWindowThreadProcessId(fg,out fgPid);
    if(erpPids.Contains((int)fgPid)){
     var sb=new StringBuilder(512);GetWindowText(fg,sb,512);string fgTitle=sb.ToString();
     if(preferErp){
      if(IsErpOnlyTitle(fgTitle))return AutomationElement.FromHandle(fg);
      if(IsStoreTitle(fgTitle)&&fallback==null)fallback=AutomationElement.FromHandle(fg);
     }else{
      if(IsStoreTitle(fgTitle))return AutomationElement.FromHandle(fg);
      if(IsErpOnlyTitle(fgTitle)&&fallback==null)fallback=AutomationElement.FromHandle(fg);
     }
    }
   }
  }catch{}
  try{
   var wins=AutomationElement.RootElement.FindAll(TreeScope.Children,Condition.TrueCondition);
   foreach(AutomationElement w in wins){
    string name="";int wpid=0;try{name=w.Current.Name??"";wpid=w.Current.ProcessId;}catch{continue;}
    if(!erpPids.Contains(wpid))continue;
    if(preferErp&&IsErpOnlyTitle(name))return w;
    if(!preferErp&&IsStoreTitle(name))return w;
    if(fallback==null&&name.Length>0)fallback=w;
   }
  }catch{}
  return fallback;
 }
 static AutomationElement Child(AutomationElement parent,Func<AutomationElement,bool> match){
  var walker=TreeWalker.ControlViewWalker;AutomationElement c=null;
  try{c=walker.GetFirstChild(parent);}catch{}
  while(c!=null){try{if(match(c))return c;}catch{}try{c=walker.GetNextSibling(c);}catch{c=null;}}
  return null;
 }
 static AutomationElement FindMdi(AutomationElement main){return Child(main,c=>(c.Current.ClassName??"").IndexOf("MDICLIENT",StringComparison.OrdinalIgnoreCase)>=0);}
 static bool MatchesScreenName(string candidate,string ad){
  candidate=(candidate??"").Trim();ad=(ad??"").Trim();
  if(candidate.Length==0||ad.Length==0)return false;
  if(string.Equals(candidate,ad,StringComparison.OrdinalIgnoreCase))return true;
  if(candidate.StartsWith(ad+" - ",StringComparison.OrdinalIgnoreCase))return true;
  if(candidate.StartsWith(ad+" (",StringComparison.OrdinalIgnoreCase))return true;
  if(ad.StartsWith(candidate+" - ",StringComparison.OrdinalIgnoreCase))return true;
  if(candidate.StartsWith(ad,StringComparison.OrdinalIgnoreCase)&&(candidate.Length-ad.Length)<=3)return true;
  return false;
 }
 // ADIM 2.1: ScreenOpen YALNIZCA orta çalışma alanındaki (MDICLIENT) gerçek görünür alt pencereleri kabul eder!
 static bool ScreenOpen(AutomationElement main,string ad,out AutomationElement child){
  child=null;
  var mdi=FindMdi(main);
  if(mdi==null)return false;
  var walker=TreeWalker.ControlViewWalker;
  AutomationElement c=null;
  try{c=walker.GetFirstChild(mdi);}catch{}
  int guard=0;
  while(c!=null&&++guard<50){
   try{
    if(c.Current.ControlType==ControlType.Window&&!c.Current.IsOffscreen){
     var r=c.Current.BoundingRectangle;
     if(!r.IsEmpty&&r.Width>200&&r.Height>140&&(r.Left+r.Width)>340&&(r.Top+r.Height)>180){
      string cn=StripNebimTitle((c.Current.Name??"").Trim());
      if(MatchesScreenName(cn,ad)){
       child=c;
       return true;
      }
     }
    }
   }catch{}
   try{c=walker.GetNextSibling(c);}catch{c=null;}
  }
  return false;
 }
 static AutomationElement FindSearchBox(AutomationElement main){
  var nav=main.FindFirst(TreeScope.Children,new PropertyCondition(AutomationElement.AutomationIdProperty,"MenuNavBar"));
  if(nav==null)return null;
  var combo=Child(nav,c=>c.Current.ControlType==ControlType.ComboBox);
  if(combo==null)return null;
  return combo.FindFirst(TreeScope.Descendants,new PropertyCondition(AutomationElement.ControlTypeProperty,ControlType.Edit));
 }
 static bool IsFocused(AutomationElement el){
  try{
   var f=AutomationElement.FocusedElement;if(f==null)return false;
   if(Automation.Compare(f,el))return true;
   if(f.Current.ControlType!=ControlType.Edit)return false;
   var a=f.Current.BoundingRectangle;var b=el.Current.BoundingRectangle;
   return !a.IsEmpty&&!b.IsEmpty&&Math.Abs(a.X-b.X)<6&&Math.Abs(a.Y-b.Y)<6;
  }catch{return false;}
 }
 static void BringToFront(IntPtr h){
  IntPtr fg=GetForegroundWindow();uint pid;
  uint fgThread=GetWindowThreadProcessId(fg,out pid),me=GetCurrentThreadId();
  bool attached=fgThread!=0&&fgThread!=me&&AttachThreadInput(fgThread,me,true);
  try{SetForegroundWindow(h);}finally{if(attached)AttachThreadInput(fgThread,me,false);}
 }
 Dictionary<string,object> OpenScreen(string ad,int sira=1){
  var req=new Dictionary<string,object>{{"baslik",ad},{"araMetni",ad},{"sira",sira}};
  return OpenMerkezScreen(req);
 }
 static void ClickAt(int x,int y){PhysicalClick(x,y);}
 static bool FocusBox(AutomationElement box,IntPtr mainH){
  for(int k=0;k<4;k++){
   BringToFront(mainH);Thread.Sleep(120);
   try{box.SetFocus();}catch{}
   Thread.Sleep(150);
   uint pid;GetWindowThreadProcessId(GetForegroundWindow(),out pid);
   int mainPid=0;try{mainPid=box.Current.ProcessId;}catch{}
   if(IsFocused(box)&&(mainPid==0||(int)pid==mainPid))return true;
   try{var r=box.Current.BoundingRectangle;if(!r.IsEmpty){PhysicalClick((int)(r.X+Math.Min(65.0,r.Width/2.0)),(int)(r.Y+r.Height/2.0));Thread.Sleep(200);if(IsFocused(box))return true;}}catch{}
  }
  return false;
 }
 static int ResolveBestPopupRow(AutomationElement main,IntPtr mainH,string baslik,string araMetni,int defaultSira,out System.Windows.Rect bestRowRect){
  bestRowRect=System.Windows.Rect.Empty;
  try{
   IntPtr fg=GetForegroundWindow();
   uint pid=0;GetWindowThreadProcessId(fg,out pid);
   if(fg==IntPtr.Zero||fg==mainH||(int)pid!=main.Current.ProcessId)return defaultSira;
   AutomationElement popupWin=AutomationElement.FromHandle(fg);
   if(popupWin==null)return defaultSira;
   AutomationElementCollection els;
   using(QuickCache().Activate()){els=popupWin.FindAll(TreeScope.Descendants,Condition.TrueCondition);}
   if(els==null||els.Count==0)return defaultSira;
   var rows=new List<KeyValuePair<double,KeyValuePair<string,System.Windows.Rect>>>();
   foreach(AutomationElement el in els){
    string n="";System.Windows.Rect r=System.Windows.Rect.Empty;bool off=false;ControlType ct=null;
    try{n=(el.Cached.Name??"").Trim();r=el.Cached.BoundingRectangle;off=el.Cached.IsOffscreen;ct=el.Cached.ControlType;}catch{continue;}
    if(off||r.IsEmpty||r.Height<12||r.Height>38||r.Width<40)continue;
    if(ct!=ControlType.ListItem&&ct!=ControlType.DataItem&&ct!=ControlType.TreeItem&&ct!=ControlType.Text&&ct!=ControlType.MenuItem)continue;
    if(n.Length<2||n.StartsWith("Satır ",StringComparison.OrdinalIgnoreCase)||n.StartsWith("Row ",StringComparison.OrdinalIgnoreCase)){
     try{object vp;if(el.TryGetCurrentPattern(ValuePattern.Pattern,out vp))n=(((ValuePattern)vp).Current.Value??"").Trim();}catch{}
    }
    if(n.Length<2)continue;
    bool merged=false;
    for(int i=0;i<rows.Count;i++){
     if(Math.Abs(rows[i].Key-r.Top)<=5.0){
      if(n.Length>rows[i].Value.Key.Length)rows[i]=new KeyValuePair<double,KeyValuePair<string,System.Windows.Rect>>(rows[i].Key,new KeyValuePair<string,System.Windows.Rect>(n,r));
      merged=true;break;
     }
    }
    if(!merged)rows.Add(new KeyValuePair<double,KeyValuePair<string,System.Windows.Rect>>(r.Top,new KeyValuePair<string,System.Windows.Rect>(n,r)));
   }
   if(rows.Count==0)return defaultSira;
   rows.Sort((a,b)=>a.Key.CompareTo(b.Key));
   string bNorm=Norm(baslik);
   string aNorm=Norm(araMetni);
   int bestIdx=-1;int bestScore=-1;
   for(int i=0;i<rows.Count&&i<12;i++){
    string raw=rows[i].Value.Key;
    string leaf=raw;
    int sep=Math.Max(raw.LastIndexOf('>'),Math.Max(raw.LastIndexOf('/'),raw.LastIndexOf('-')));
    if(sep>0&&sep<raw.Length-2)leaf=raw.Substring(sep+1).Trim();
    string lNorm=Norm(leaf);
    string rNorm=Norm(raw);
    int sc=0;
    if(bNorm.Length>=2&&(lNorm==bNorm||rNorm==bNorm))sc=100;
    else if(aNorm.Length>=2&&(lNorm==aNorm||rNorm==aNorm))sc=95;
    else if(bNorm.Length>=3&&rNorm.EndsWith(bNorm))sc=88;
    else if(bNorm.Length>=3&&lNorm.StartsWith(bNorm))sc=80;
    if(sc>bestScore){bestScore=sc;bestIdx=i+1;bestRowRect=rows[i].Value.Value;}
   }
   if(bestScore>=88&&bestIdx>=1){
    if(defaultSira>=1&&defaultSira<=rows.Count&&bestScore<95)return defaultSira;
    return bestIdx;
   }
  }catch{}
  return defaultSira;
 }
 static bool PopupShown(AutomationElement main,IntPtr mainH){
  IntPtr fg=GetForegroundWindow();uint pid;GetWindowThreadProcessId(fg,out pid);
  return fg!=mainH&&(int)pid==main.Current.ProcessId;
 }
 Dictionary<string,object> VerifyCatalog(){
  var main=FindStore();
  if(main==null)return Result("hata","Nebim V3 STORE / ERP açık değil.",null);
  if(PosInFront())return Result("hata","Kasa (POS) önde; doğrulama yapılmadı.",null);
  var box=FindSearchBox(main);if(box==null)return Result("hata","Ara kutusu bulunamadı.",null);
  IntPtr mainH=new IntPtr(main.Current.NativeWindowHandle);
  var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"ekranlar.json"),Encoding.UTF8));
  var found=new List<string>();var missing=new List<string>();
  foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
   string name=Convert.ToString(((Dictionary<string,object>)o)["ad"]);
   var b2=FindSearchBox(main);if(b2!=null)box=b2;
   if(!FocusBox(box,mainH))break;
   Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Thread.Sleep(50);
   TypeText(name);Thread.Sleep(900);
   bool ok=PopupShown(main,mainH);
   (ok?found:missing).Add(name);
   if(ok){Press(VK_ESCAPE);Thread.Sleep(250);}
   var b3=FindSearchBox(main);if(b3!=null)box=b3;
   if(FocusBox(box,mainH)){Key(VK_CONTROL,false);Press(VK_A);Key(VK_CONTROL,true);Press(VK_DELETE);}
   Thread.Sleep(200);
  }
  var r=Result(missing.Count==0?"acildi":"hata","Doğrulama bitti: "+found.Count+" ekran bulundu.",null);
  r["bulunan"]=found;r["bulunamayan"]=missing;
  return r;
 }

 // =========================================================================
 // SIFIR-HATA MİMARİSİ (ÇÖZÜM 1..4) VE SABAH KONTROL RAPORU MOTORU (v6.7)
 // =========================================================================
 static readonly object zeroErrLock=new object();
 static Dictionary<string,int> siraCache=null;
 static Dictionary<string,List<Dictionary<string,object>>> fieldMapCache=null;

 static string SiraMemoryPath{get{return Path.Combine(Root,"sira-hafiza.json");}}
 static string FieldMapPath{get{return Path.Combine(Root,"alan-haritasi.json");}}
 static string MorningReportPath{get{return Path.Combine(Root,"sabah-kontrol-raporu.txt");}}

 static void EnsureSiraCacheLoaded(){
  if(siraCache!=null)return;
  siraCache=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
  try{
   if(!File.Exists(SiraMemoryPath))return;
   var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(SiraMemoryPath,Encoding.UTF8));
   if(doc!=null&&doc.ContainsKey("siralar")&&doc["siralar"] is Dictionary<string,object>){
    var d=(Dictionary<string,object>)doc["siralar"];
    foreach(var kv in d){
     try{int v=Convert.ToInt32(kv.Value);if(v>=1&&v<=12)siraCache[kv.Key]=v;}catch{}
    }
   }
  }catch{}
 }

 static int GetLearnedSira(string baslik,string araMetni){
  lock(zeroErrLock){
   EnsureSiraCacheLoaded();
   string k1=Norm(baslik);
   string k2=Norm(araMetni);
   int v;
   if(k1.Length>=2&&siraCache.TryGetValue(k1,out v))return v;
   if(k2.Length>=2&&siraCache.TryGetValue(k2,out v))return v;
   return 0;
  }
 }

 static void SaveLearnedSira(string baslik,string araMetni,int verifiedSira){
  if(verifiedSira<1||verifiedSira>12)return;
  lock(zeroErrLock){
   EnsureSiraCacheLoaded();
   string k1=Norm(baslik);
   string k2=Norm(araMetni);
   bool changed=false;
   if(k1.Length>=2&&(!siraCache.ContainsKey(k1)||siraCache[k1]!=verifiedSira)){siraCache[k1]=verifiedSira;changed=true;}
   if(k2.Length>=2&&k2!=k1&&(!siraCache.ContainsKey(k2)||siraCache[k2]!=verifiedSira)){siraCache[k2]=verifiedSira;changed=true;}
   if(changed){
    try{
     var outObj=new Dictionary<string,object>{
      {"surum","6.7"},
      {"guncelleme",DateTime.Now.ToString("s")},
      {"aciklama","Sıfır-Hata Çözüm-1: Doğrulanmış Ara açılır liste satır indeksleri"},
      {"siralar",siraCache}
     };
     File.WriteAllText(SiraMemoryPath,new JavaScriptSerializer().Serialize(outObj),new UTF8Encoding(false));
    }catch{}
   }
  }
 }

 static Dictionary<string,string> atlasExpectedFieldMap=null;
 static HashSet<string> merkezCatalogTitles=null;
 static HashSet<string> magazaCatalogTitles=null;
 static Dictionary<string,int> magazaCatalogSira=null;

 static void EnsureAtlasCrossMapLoaded(){
  if(atlasExpectedFieldMap!=null&&merkezCatalogTitles!=null&&magazaCatalogTitles!=null)return;
  atlasExpectedFieldMap=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  merkezCatalogTitles=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  magazaCatalogTitles=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  magazaCatalogSira=new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
  try{
   string[] catPaths=new string[]{
    Path.Combine(Root,"merkez-rehber-katalog.json"),
    Path.Combine(Root,"merkez-kesif","merkez-rehber-katalog.json")
   };
   foreach(string cp in catPaths){
    if(!File.Exists(cp))continue;
    string raw=File.ReadAllText(cp,Encoding.UTF8);
    foreach(System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(raw,"\"baslik\"\\s*:\\s*\"([^\"]+)\"[^\\}]*?\"ilkVeriAlani\"\\s*:\\s*\"([^\"]*)\"")){
     string b=m.Groups[1].Value.Trim();
     string f=m.Groups[2].Value.Trim();
     if(b.Length>=2){
      merkezCatalogTitles.Add(Norm(b));
      if(!atlasExpectedFieldMap.ContainsKey(Norm(b)))atlasExpectedFieldMap[Norm(b)]=f;
     }
    }
    break;
   }
  }catch{}
  try{
   string ekPath=Path.Combine(Root,"ekranlar.json");
   if(File.Exists(ekPath)){
    var js=new JavaScriptSerializer{MaxJsonLength=4*1024*1024};
    var doc=js.Deserialize<Dictionary<string,object>>(File.ReadAllText(ekPath,Encoding.UTF8).TrimStart('\uFEFF'));
    if(doc!=null&&doc.ContainsKey("ekranlar")&&doc["ekranlar"] is System.Collections.IEnumerable){
     foreach(object o in (System.Collections.IEnumerable)doc["ekranlar"]){
      var d=o as Dictionary<string,object>;
      if(d==null)continue;
      string ad=d.ContainsKey("ad")&&d["ad"]!=null?Convert.ToString(d["ad"]).Trim():"";
      int sr=1;
      try{if(d.ContainsKey("sira")&&d["sira"]!=null)sr=Math.Max(1,Convert.ToInt32(d["sira"]));}catch{sr=1;}
      if(ad.Length>=2){
       string nAd=Norm(ad);
       magazaCatalogTitles.Add(nAd);
       magazaCatalogSira[nAd]=sr;
       if(d.ContainsKey("adimlar")&&d["adimlar"] is System.Collections.IEnumerable){
        foreach(object stObj in (System.Collections.IEnumerable)d["adimlar"]){
         string st=Convert.ToString(stObj??"");
         var mq=System.Text.RegularExpressions.Regex.Match(st,"\"([^\"]+)\"");
         if(mq.Success&&!atlasExpectedFieldMap.ContainsKey(nAd)){
          atlasExpectedFieldMap[nAd]=mq.Groups[1].Value;
          break;
         }
        }
       }
      }
     }
    }
   }
  }catch{}
 }

 // MERKEZ (Nebim V3 ERP) <-> MAHMUTBEY ŞUBE (Nebim V3 STORE) ÇAPRAZ HARİTA EŞLEŞTİRİCİ
 static void ResolveCrossAtlasTarget(string inBaslik,string inAra,int inSira,bool isStoreSession,out string outBaslik,out string outAra,out int outSira,out string note){
  outBaslik=(inBaslik??"").Trim();
  outAra=(inAra??"").Trim();
  outSira=inSira;
  note="";
  if(Norm(outAra)=="satinalma"||Norm(outAra)=="satin alma"||Norm(outAra)=="masraf"||Norm(outAra)=="masraf ekle"||string.Equals(outAra,"Personel Masrafları ve Ödemeleri",StringComparison.OrdinalIgnoreCase)){outAra=isStoreSession?"Mağaza Masraf Girişi":"Personel Masraf Faturası";outBaslik=outAra;outSira=1;}else if(string.Equals(outAra,"Personel Masrafları ve Ödemeleri",StringComparison.OrdinalIgnoreCase)){
   outAra="Personel Masraf Faturası";
   if(string.Equals(outBaslik,"Personel Masrafları ve Ödemeleri",StringComparison.OrdinalIgnoreCase))outBaslik="Personel Masraf Faturası";
  }else if(string.Equals(outAra,"Mağazaya Transfer",StringComparison.OrdinalIgnoreCase)){
   outAra="Ofis Depoları Arası Transfer";
   if(string.Equals(outBaslik,"Mağazaya Transfer",StringComparison.OrdinalIgnoreCase))outBaslik="Ofis Depoları Arası Transfer";
  }

  lock(zeroErrLock){EnsureAtlasCrossMapLoaded();}
  string nb=Norm(outBaslik);

  // [Merkez ERP Ekranı, Mahmutbey Şube STORE Ekranı, StoreSira, ErpSira]
  string[][] crossPairs=new string[][]{
   new string[]{"Mağaza Siparişleri","Verilen Siparişler","1","1"},
   new string[]{"Personel Masraf Faturası","Mağaza Masraf Girişi","1","1"},
   new string[]{"Peşin Masraf Faturası (Kasa)","Mağaza Masraf Girişi","1","1"},
   new string[]{"Ofis ve Mağaza Depoları Sayım Fişi","Mağaza Sayım Fişi","1","1"},
   new string[]{"Ürün Envanter Raporu","Ürün Envanter Sorgula","1","1"},
   new string[]{"İade Gelen Ürünleri Onayla (Onl.Bayi) - Fiş Bazında","Mağazaya Gelen İrsaliyeyi Onayla - Ürün Detaylı","1","1"},
   new string[]{"Diğer Ofisten Yapılan Transferi Onayla - Fiş Bazında","Mağazaya Gelen İrsaliyeyi Onayla - Fiş Bazında","1","1"},
   new string[]{"Ofis Depoları Arası Transfer","Merkeze İade","1","1"},
   new string[]{"Günlük Nakit Kasa Akışı","Merkezin Banka Hesabına Nakit Çıkış","1","1"},
   new string[]{"Perakende Satış Fişlerinde Düzenlemeler","Perakende Satışlar Listesi","1","1"}
  };

  if(isStoreSession){
   // Oturum Nebim V3 STORE (Mahmutbey Şubesi): Eğer gelen ekran Merkez ERP'ye özgü ise Mağaza karşılığına çevir
   if(magazaCatalogTitles!=null&&!magazaCatalogTitles.Contains(nb)){
    for(int i=0;i<crossPairs.Length;i++){
     if(Norm(crossPairs[i][0])==nb){
      outBaslik=crossPairs[i][1];
      outAra=crossPairs[i][1];
      int.TryParse(crossPairs[i][2],out outSira);
      note="Merkez ERP ('"+inBaslik+"') -> Mahmutbey STORE ('"+outBaslik+"') çapraz eşlendi";
      return;
     }
    }
   }
   int stSira;
   if(magazaCatalogSira!=null&&magazaCatalogSira.TryGetValue(Norm(outBaslik),out stSira)&&outSira<=1&&stSira>1){
    outSira=stSira;
   }
  }else{
   // Oturum Nebim V3 ERP (Merkez): Eğer gelen ekran sadece STORE'da varsa Merkez ERP karşılığına çevir
   if(merkezCatalogTitles!=null&&!merkezCatalogTitles.Contains(nb)){
    for(int i=0;i<crossPairs.Length;i++){
     if(Norm(crossPairs[i][1])==nb){
      outBaslik=crossPairs[i][0];
      outAra=crossPairs[i][0];
      int.TryParse(crossPairs[i][3],out outSira);
      note="Mahmutbey STORE ('"+inBaslik+"') -> Merkez ERP ('"+outBaslik+"') çapraz eşlendi";
      return;
     }
    }
   }
  }
 }

 Dictionary<string,object> RunHelperSystemRestore(){
  HideRdpFrameSafe();
  int cleanedQueueFiles=0;
  try{
   foreach(string f in Directory.GetFiles(Kuyruk,"*.tmp")){try{File.Delete(f);cleanedQueueFiles++;}catch{}}
  }catch{}
  int merkezCnt=0,magazaCnt=0,siraCnt=0,fieldCnt=0;
  lock(zeroErrLock){
   siraCache=null;
   EnsureAtlasCrossMapLoaded();
   EnsureSiraCacheLoaded();
   EnsureFieldMapLoaded();
   merkezCnt=merkezCatalogTitles!=null?merkezCatalogTitles.Count:0;
   magazaCnt=magazaCatalogTitles!=null?magazaCatalogTitles.Count:0;
   siraCnt=siraCache!=null?siraCache.Count:0;
   fieldCnt=fieldMapCache!=null?fieldMapCache.Count:0;
  }
  try{GC.Collect();GC.WaitForPendingFinalizers();}catch{}
  var r=Result("okundu","NebimYardimci v"+Surum+" önbellekleri, çapraz haritalar ve çerçeve kilidi sıfırlandı (Merkez="+merkezCnt+", Mağaza="+magazaCnt+").",null);
  r["merkezHaritaSayisi"]=merkezCnt;
  r["magazaHaritaSayisi"]=magazaCnt;
  r["siraHafizaSayisi"]=siraCnt;
  r["alanHaritaSayisi"]=fieldCnt;
  r["temizlenenGeciciDosya"]=cleanedQueueFiles;
  return r;
 }

 static string StripNebimProcessSuffix(string s){
  s=(s??"").Trim();
  string[] suffixes=new string[]{
   " - Mağazaya Transfer"," - Toptan Alış"," - Masraf Alış"," - Perakende Satış"," - Toptan Satış",
   " - İthalat"," - İhracat"," - Konsinye"," - Üretim"
  };
  for(int i=0;i<suffixes.Length;i++){
   if(s.EndsWith(suffixes[i],StringComparison.OrdinalIgnoreCase)){
    return s.Substring(0,s.Length-suffixes[i].Length).Trim();
   }
  }
  return s;
 }

 // =========================================================================
 // KAYDEDİLMİŞ NEBİM HARİTASI İLE ÇAPRAZ TEST MOTORU (CROSS-TEST ENGINE v6.8)
 // =========================================================================
 static bool CrossVerifyOpenedScreenWithAtlas(string openedName,string targetBaslik,string targetAra,string reqFirstField,List<RealFieldCandidate> primaryFields,List<RealFieldCandidate> secondaryFields,out string detail){
  detail="";
  string oRaw=(openedName??"").Trim();
  string bRaw=(targetBaslik??"").Trim();
  string aRaw=(targetAra??"").Trim();
  if(oRaw.Length<2){
   detail="Açık MDI ekran başlığı okunamadı";
   return false;
  }

  string oBase=Norm(StripNebimProcessSuffix(oRaw));
  string bBase=Norm(StripNebimProcessSuffix(bRaw));
  string aBase=Norm(StripNebimProcessSuffix(aRaw));
  string oFull=Norm(oRaw);
  string bFull=Norm(bRaw);
  string aFull=Norm(aRaw);

  // 1. Haritadaki Beklenen İlk Veri Alanını Yükle
  string expectedField=(reqFirstField??"").Trim();
  lock(zeroErrLock){
   EnsureAtlasCrossMapLoaded();
   if(string.IsNullOrEmpty(expectedField)&&atlasExpectedFieldMap!=null){
    string ef;
    if(atlasExpectedFieldMap.TryGetValue(bFull,out ef))expectedField=ef;
    else if(atlasExpectedFieldMap.TryGetValue(bBase,out ef))expectedField=ef;
    else if(atlasExpectedFieldMap.TryGetValue(aBase,out ef))expectedField=ef;
   }
  }

  // 2. Kardeş / Yanlış Ekran Ayrımı (Kesin Çapraz Red Kuralları)
  if(bFull.Contains("fis bazinda")&&oFull.Contains("urun detayli")){
   detail="Çapraz Test Red: Hedef 'Fiş Bazında' iken 'Ürün Detaylı' açıldı";
   return false;
  }
  if(bFull.Contains("urun detayli")&&oFull.Contains("fis bazinda")){
   detail="Çapraz Test Red: Hedef 'Ürün Detaylı' iken 'Fiş Bazında' açıldı";
   return false;
  }
  if(!bFull.Contains("kontrol listesi")&&!aFull.Contains("kontrol listesi")&&oFull.Contains("kontrol listesi")){
   detail="Çapraz Test Red: İşlem ekranı yerine 'Kontrol Listesi' açıldı ('"+oRaw+"')";
   return false;
  }
  if(!bFull.Contains("sihirbazi")&&!aFull.Contains("sihirbazi")&&oFull.Contains("sihirbazi")){
   detail="Çapraz Test Red: Kayıt ekranı yerine 'Sihirbaz' açıldı ('"+oRaw+"')";
   return false;
  }
  if(!bFull.Contains("duzelt")&&!aFull.Contains("duzelt")&&oFull.Contains("duzelt")){
   detail="Çapraz Test Red: Kayıt ekranı yerine 'Hata Düzeltme' ekranı açıldı ('"+oRaw+"')";
   return false;
  }
  if(!bFull.Contains("rapor")&&!aFull.Contains("rapor")&&oFull.Contains("rapor")){
   detail="Çapraz Test Red: Kayıt/Fiş ekranı yerine 'Rapor' ekranı açıldı ('"+oRaw+"')";
   return false;
  }
  if(bFull.Contains("rapor")&&!oFull.Contains("rapor")&&!oFull.Contains("ozet")&&!oFull.Contains("analiz")&&!oFull.Contains("envanter")&&!oFull.Contains("ciro")){
   detail="Çapraz Test Red: Rapor ekranı yerine farklı bir ekran açıldı ('"+oRaw+"')";
   return false;
  }

  // 3. Başlık Eşleşmesi (Birebir, Geçerli Süreç Eki veya Merkez<->Mağaza Çapraz Harita Eşleşmesi)
  bool titleMatched=(oFull==bFull||oFull==aFull||oBase==bBase||oBase==aBase);
  if(!titleMatched){
   if((bBase.Contains("personel masraf")&&(oBase.Contains("personel masraf")||oBase.Contains("magaza masraf")))||
      (bBase.Contains("magaza masraf")&&(oBase.Contains("magaza masraf")||oBase.Contains("personel masraf")||oBase.Contains("pesin masraf")))||
      (bBase.Contains("magaza siparis")&&(oBase.Contains("magaza siparis")||oBase.Contains("verilen siparis")))||
      (bBase.Contains("verilen siparis")&&(oBase.Contains("verilen siparis")||oBase.Contains("magaza siparis")))||
      (bBase.Contains("magazaya transfer")&&oBase.Contains("transfer"))||
      (bBase.Contains("sayim fisi")&&oBase.Contains("sayim fisi"))||
      (bBase.Contains("urun envanter")&&oBase.Contains("urun envanter"))||
      (bBase.Contains("merkeze iade")&&(oBase.Contains("merkeze iade")||oBase.Contains("transfer")))||
      (bBase.Contains("nakit cikis")&&oBase.Contains("nakit cikis")&&!oFull.Contains("yapmayan"))||
      (bBase.Contains("perakende satis")&&oBase.Contains("perakende satis"))||((bBase.Contains("satinalma")||bBase.Contains("satin alma")||bBase.Contains("masraf"))&&oBase.Contains("masraf"))){
    titleMatched=true;
   }
  }

  if(!titleMatched){
   detail="Çapraz Test Red: Açılan '"+oRaw+"' != Harita Hedefi '"+bRaw+"'";
   return false;
  }

  // 4. Haritadaki İlk Veri Alanı / Parmak İzi Çapraz Kontrolü
  string foundFirstField="";
  if(primaryFields!=null&&primaryFields.Count>0)foundFirstField=primaryFields[0].label;
  else if(secondaryFields!=null&&secondaryFields.Count>0)foundFirstField=secondaryFields[0].label;

  detail="Başlık='"+oRaw+"' == Harita='"+bRaw+"' | İlkAlan='"+(foundFirstField.Length>0?foundFirstField:expectedField)+"'";
  return true;
 }

 // SIFIR-HATA ÇÖZÜM-4: AutomationId Parmak İzi Haritası (alan-haritasi.json)
 static void EnsureFieldMapLoaded(){
  if(fieldMapCache!=null)return;
  fieldMapCache=new Dictionary<string,List<Dictionary<string,object>>>(StringComparer.OrdinalIgnoreCase);
  try{
   if(!File.Exists(FieldMapPath))return;
   var doc=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(FieldMapPath,Encoding.UTF8));
   if(doc!=null&&doc.ContainsKey("ekranlar")&&doc["ekranlar"] is Dictionary<string,object>){
    var d=(Dictionary<string,object>)doc["ekranlar"];
    foreach(var kv in d){
     var list=new List<Dictionary<string,object>>();
     if(kv.Value is System.Collections.IEnumerable){
      foreach(object o in (System.Collections.IEnumerable)kv.Value){
       if(o is Dictionary<string,object>)list.Add((Dictionary<string,object>)o);
      }
     }
     if(list.Count>0)fieldMapCache[kv.Key]=list;
    }
   }
  }catch{}
 }

 static string GetPreferredAutomationIdForScreen(string screenName){
  if(string.IsNullOrEmpty(screenName))return "";
  lock(zeroErrLock){
   EnsureFieldMapLoaded();
   List<Dictionary<string,object>> list;
   if(fieldMapCache.TryGetValue(screenName,out list)&&list.Count>0){
    foreach(var f in list){
     bool act=f.ContainsKey("aksiyonMu")&&Convert.ToBoolean(f["aksiyonMu"]);
     string aid=f.ContainsKey("automationId")?Convert.ToString(f["automationId"]):"";
     if(!act&&!string.IsNullOrEmpty(aid))return aid;
    }
   }
   return "";
  }
 }

 static void SaveScreenFieldFingerprint(string screenName,List<RealFieldCandidate> inputs,List<RealFieldCandidate> actions){
  if(string.IsNullOrEmpty(screenName)||(inputs.Count==0&&actions.Count==0))return;
  lock(zeroErrLock){
   EnsureFieldMapLoaded();
   var list=new List<Dictionary<string,object>>();
   for(int i=0;i<inputs.Count&&i<6;i++){
    var f=inputs[i];
    list.Add(new Dictionary<string,object>{
     {"etiket",f.label??""},
     {"automationId",f.automationId??""},
     {"className",f.className??""},
     {"relLeft",f.relLeft},
     {"relTop",f.relTop},
     {"aksiyonMu",false}
    });
   }
   for(int i=0;i<actions.Count&&i<3;i++){
    var a=actions[i];
    list.Add(new Dictionary<string,object>{
     {"etiket",a.label??""},
     {"automationId",a.automationId??""},
     {"className",a.className??""},
     {"relLeft",a.relLeft},
     {"relTop",a.relTop},
     {"aksiyonMu",true}
    });
   }
   fieldMapCache[screenName]=list;
   try{
    var outObj=new Dictionary<string,object>{
     {"surum","6.8"},
     {"guncelleme",DateTime.Now.ToString("s")},
     {"toplamEkran",fieldMapCache.Count},
     {"aciklama","Sıfır-Hata Çözüm-4: Ekran bazlı DevExpress AutomationId ve kontrol parmak izi haritası"},
     {"ekranlar",fieldMapCache}
    };
    File.WriteAllText(FieldMapPath,new JavaScriptSerializer().Serialize(outObj),new UTF8Encoding(false));
   }catch{}
  }
 }

 // SIFIR-HATA ÇÖZÜM-2: Yalnızca doğrulanmış SOL_MENU kataloglarından (ekranlar.json & merkez-rehber-katalog.json) gerçek ekran adlarını oku
 // (ACIK_EKRAN bileşenlerini veya rastgele XML etiketlerini kesinlikle ogrenilen-ekranlar.json içine karıştırma!)
 static void ScanNebimLocalMetadataInto(List<string> found,HashSet<string> seen){
  try{
   string[] candidateFiles=new string[]{
    Path.Combine(Root,"ekranlar.json"),
    Path.Combine(Root,"merkez-rehber-katalog.json")
   };
   foreach(string cf in candidateFiles){
    try{
     if(!File.Exists(cf))continue;
     string raw=File.ReadAllText(cf,Encoding.UTF8);
     foreach(System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(raw,"\"(?:ad|baslik)\"\\s*:\\s*\"([^\"]{3,90})\"")){
      string val=m.Groups[1].Value.Trim();
      if(val.Length>=3&&!ForbiddenFieldNames.Contains(val)&&seen.Add(val))found.Add(val);
     }
    }catch{}
   }
  }catch{}
 }

 public void RunPeriodicZeroErrorMaintenance(bool nebimOpenAndSafe){
  try{
   int learnedCount=0;
   lock(learnLock){LoadLearned();learnedCount=learned!=null?learned.Count:0;}
   int siraCount=0;
   int fieldMapCount=0;
   lock(zeroErrLock){
    EnsureSiraCacheLoaded();siraCount=siraCache!=null?siraCache.Count:0;
    EnsureFieldMapLoaded();fieldMapCount=fieldMapCache!=null?fieldMapCache.Count:0;
   }
   bool prsExists=File.Exists(Path.Combine(Root,"personel-veri-paketi.json"));
   var sb=new StringBuilder();
   sb.AppendLine("======================================================================");
   sb.AppendLine("  NEBİM ASİSTANI v6.8 — HARİTA ÇAPRAZ TEST & SIFIR-HATA RAPORU");
   sb.AppendLine("======================================================================");
   sb.AppendLine("Rapor Zamanı          : "+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
   sb.AppendLine("Yardımcı Sürümü       : NebimYardimci v"+Surum+" (Aktif)");
   sb.AppendLine("----------------------------------------------------------------------");
   sb.AppendLine("[ÇAPRAZ TEST] Kaydedilmiş Nebim Haritasıyla Başlık & Alan Çapraz Test : AKTİF");
   sb.AppendLine("[ÇÖZÜM 1] Kapalı Döngü Ekran Doğrulama & Sıra Hafızası (sira-hafiza)  : AKTİF ("+siraCount+" doğrulanmış sıra)");
   sb.AppendLine("[ÇÖZÜM 2] Doğrulanmış Sol Menü Atlası (ogrenilen-ekranlar)            : AKTİF ("+learnedCount+" temiz ekran)");
   sb.AppendLine("[ÇÖZÜM 4] DevExpress AutomationId Parmak İzi Haritası (alan-haritasi) : AKTİF ("+fieldMapCount+" ekran parmak izi)");
   sb.AppendLine("[PERSONEL] Personel, Maaş ve Prim Veri Paketi (personel-veri-paketi)  : "+(prsExists?"HAZIR":"👥 Personel Aktar ile hazır"));
   sb.AppendLine("======================================================================");
   File.WriteAllText(MorningReportPath,sb.ToString(),new UTF8Encoding(false));
  }catch{}
 }

 // =========================================================================
 // v7.1 DOGRUDAN SALT-OKUNUR SQL BAGLANTI KESFI, BELLEK ANALIZI VE VERI OKUMA MOTORU
 // =========================================================================
 [StructLayout(LayoutKind.Sequential)]
 struct MEMORY_BASIC_INFORMATION {
  public IntPtr BaseAddress;
  public IntPtr AllocationBase;
  public uint AllocationProtect;
  public IntPtr RegionSize;
  public uint State;
  public uint Protect;
  public uint Type;
 }
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint dwDesiredAccess,bool bInheritHandle,int dwProcessId);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr hObject);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr VirtualQueryEx(IntPtr hProcess,IntPtr lpAddress,out MEMORY_BASIC_INFORMATION lpBuffer,uint dwLength);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadProcessMemory(IntPtr hProcess,IntPtr lpBaseAddress,byte[] lpBuffer,int dwSize,out IntPtr lpNumberOfBytesRead);

 class SqlCredCandidate {
  public string source;
  public string connectionString;
  public string summary;
 }

 static string CachedWorkingConnString=null;
 static string CachedWorkingConnSummary="";

 static string FoldAscii(string s){
  if(string.IsNullOrEmpty(s))return "";
  var sb=new StringBuilder(s.Length);
  foreach(char c in s){
   switch((int)c){
    case 0x0131:sb.Append('i');break;
    case 0x0130:sb.Append('I');break;
    case 0x015F:sb.Append('s');break;
    case 0x015E:sb.Append('S');break;
    case 0x011F:sb.Append('g');break;
    case 0x011E:sb.Append('G');break;
    case 0x00FC:sb.Append('u');break;
    case 0x00DC:sb.Append('U');break;
    case 0x00F6:sb.Append('o');break;
    case 0x00D6:sb.Append('O');break;
    case 0x00E7:sb.Append('c');break;
    case 0x00C7:sb.Append('C');break;
    default:sb.Append(c);break;
   }
  }
  return sb.ToString();
 }

 static void ScanNebimProcessMemoryForSql(int pid,string procName,List<string> findings,List<SqlCredCandidate> creds){
  IntPtr hProc=IntPtr.Zero;
  try{
   // PROCESS_QueryInformation (0x0400) | PROCESS_VM_READ (0x0010)
   hProc=OpenProcess(0x0410,false,pid);
   if(hProc==IntPtr.Zero)return;
   IntPtr addr=IntPtr.Zero;
   uint mbiSize=(uint)Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION));
   var seenStrings=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   int regionsScanned=0;
   long bytesScanned=0;
   byte[] patternPmV3=Encoding.Unicode.GetBytes("PM_V3");
   byte[] patternNebimMaster=Encoding.Unicode.GetBytes("NebimV3Master");
   byte[] patternPassword=Encoding.Unicode.GetBytes("Password=");
   byte[] patternPwd=Encoding.Unicode.GetBytes("Pwd=");
   byte[] patternUserId=Encoding.Unicode.GetBytes("User ID=");

   while(regionsScanned<4000&&bytesScanned<450*1024*1024){
    MEMORY_BASIC_INFORMATION mbi;
    IntPtr res=VirtualQueryEx(hProc,addr,out mbi,mbiSize);
    if(res==IntPtr.Zero)break;
    long regSize=mbi.RegionSize.ToInt64();
    long nextAddr=mbi.BaseAddress.ToInt64()+regSize;
    // MEM_COMMIT = 0x1000, readable non-guard pages
    if(mbi.State==0x1000&&(mbi.Protect&0x100)==0&&(mbi.Protect==0x02||mbi.Protect==0x04||mbi.Protect==0x20||mbi.Protect==0x40)&&regSize>0&&regSize<=16*1024*1024){
     regionsScanned++;
     int toRead=(int)Math.Min(regSize,4*1024*1024);
     byte[] buf=new byte[toRead];
     IntPtr readBytes;
     if(ReadProcessMemory(hProc,mbi.BaseAddress,buf,toRead,out readBytes)&&readBytes.ToInt32()>32){
      int n=readBytes.ToInt32();
      bytesScanned+=n;
      foreach(byte[] pat in new byte[][]{patternPmV3,patternNebimMaster,patternPassword,patternPwd,patternUserId}){
       int idx=0;
       while((idx=IndexOfBytes(buf,n,pat,idx))>=0){
        int start=Math.Max(0,idx-240);
        if(start%2!=idx%2)start++;
        int end=Math.Min(n,idx+360);
        int len=end-start;
        if(len>=16){
         string rawStr=Encoding.Unicode.GetString(buf,start,len);
         // Clean null/control chars into segments
         foreach(string seg in rawStr.Split(new char[]{'\0','\r','\n'},StringSplitOptions.RemoveEmptyEntries)){
          string s=seg.Trim();
          if(s.Length>=12&&s.Length<=300&&IsPrintableConnectionLike(s)){
           if(seenStrings.Add(s)){
            // Check if it looks like a connection string
            if((s.IndexOf("Data Source=",StringComparison.OrdinalIgnoreCase)>=0||s.IndexOf("Server=",StringComparison.OrdinalIgnoreCase)>=0||s.IndexOf("Initial Catalog=",StringComparison.OrdinalIgnoreCase)>=0||s.IndexOf("User ID=",StringComparison.OrdinalIgnoreCase)>=0||s.IndexOf("Password=",StringComparison.OrdinalIgnoreCase)>=0)){
             string masked=System.Text.RegularExpressions.Regex.Replace(s,@"(Password|Pwd)\s*=\s*[^;]+","$1=[GIZLI]",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
             findings.Add("BELLEK ["+procName+":"+pid+"]: "+Short(masked));
             if(s.IndexOf("Password=",StringComparison.OrdinalIgnoreCase)>=0||s.IndexOf("Pwd=",StringComparison.OrdinalIgnoreCase)>=0){
              string cleanCs=ExtractCleanConnectionString(s);
              if(cleanCs.Length>15){
               creds.Insert(0,new SqlCredCandidate{
                source="NebimMemory("+procName+":"+pid+")",
                connectionString=cleanCs,
                summary="Nebim Bellek Baglantisi ("+procName+" -> PM_V3)"
               });
              }
             }
            }
           }
          }
         }
        }
        idx+=pat.Length;
       }
      }
     }
    }
    if(nextAddr<=addr.ToInt64())break;
    addr=new IntPtr(nextAddr);
   }
   findings.Add("BELLEK TARAMA OZETI ["+procName+":"+pid+"]: "+regionsScanned+" bolge ("+(bytesScanned/(1024*1024))+" MB) tarandi, "+seenStrings.Count+" aday bulundu.");
  }catch(Exception ex){
   findings.Add("BELLEK TARAMA UYARI ["+procName+":"+pid+"]: "+ex.Message);
  }finally{
   if(hProc!=IntPtr.Zero)CloseHandle(hProc);
  }
 }

 static int IndexOfBytes(byte[] buf,int bufLen,byte[] pat,int startIdx){
  int pLen=pat.Length;
  int limit=bufLen-pLen;
  byte b0=pat[0];
  for(int i=startIdx;i<=limit;i++){
   if(buf[i]==b0){
    bool ok=true;
    for(int j=1;j<pLen;j++){if(buf[i+j]!=pat[j]){ok=false;break;}}
    if(ok)return i;
   }
  }
  return -1;
 }

 static bool IsPrintableConnectionLike(string s){
  int bad=0;
  for(int i=0;i<s.Length;i++){
   char c=s[i];
   if(c<32||c>126){
    if("ğıüşöçĞİÜŞÖÇ".IndexOf(c)<0)bad++;
   }
  }
  return bad<=4;
 }

 static string ExtractCleanConnectionString(string raw){
  int ds=raw.IndexOf("Data Source=",StringComparison.OrdinalIgnoreCase);
  if(ds<0)ds=raw.IndexOf("Server=",StringComparison.OrdinalIgnoreCase);
  if(ds>0){
   raw=raw.Substring(ds);
  }else if(ds<0){
   int uid=raw.IndexOf("User ID=",StringComparison.OrdinalIgnoreCase);
   if(uid>=0)raw="Data Source=localhost;Initial Catalog=PM_V3;"+raw.Substring(uid);
  }
  var sb=new StringBuilder();
  foreach(char c in raw){
   if(c>=32&&(c<=126||"ÄŸÄ±Ã¼ÅŸÃ¶Ã§ÄÄ°ÃœÅÃ–Ã‡".IndexOf(c)>=0))sb.Append(c);
   else break;
  }
  string cs=sb.ToString().Trim();
  try{
   var b=new SqlConnectionStringBuilder(cs);
   b.DataSource="localhost";
   b.InitialCatalog="PM_V3";
   b.ConnectTimeout=4;
   b.ApplicationIntent=ApplicationIntent.ReadOnly;
   b.TrustServerCertificate=true;
   return b.ConnectionString;
  }catch{
   return cs;
  }
 }

 static void ScanRegistryForNebimSql(RegistryKey rootKey,string subPath,int depth,List<string> findings,List<SqlCredCandidate> creds){
  if(depth>4||rootKey==null)return;
  try{
   using(RegistryKey k=rootKey.OpenSubKey(subPath,false)){
    if(k==null)return;
    foreach(string vn in k.GetValueNames()){
     try{
      string val=Convert.ToString(k.GetValue(vn)??"").Trim();
      if(val.Length==0)continue;
      string showVal=val;
      if(vn.IndexOf("Pass",StringComparison.OrdinalIgnoreCase)>=0||val.IndexOf("Password=",StringComparison.OrdinalIgnoreCase)>=0){
       showVal="[GIZLI len="+val.Length+"]";
      }
      findings.Add("REG "+rootKey.Name+"\\"+subPath+" ["+vn+"] = "+Short(showVal));
      if(val.IndexOf("Data Source=",StringComparison.OrdinalIgnoreCase)>=0||val.IndexOf("Server=",StringComparison.OrdinalIgnoreCase)>=0){
       creds.Add(new SqlCredCandidate{source="Reg:"+subPath+"\\"+vn,connectionString=val,summary="Reg ConnectionString"});
      }
     }catch{}
    }
    foreach(string sk in k.GetSubKeyNames()){
     ScanRegistryForNebimSql(rootKey,subPath+"\\"+sk,depth+1,findings,creds);
    }
   }
  }catch{}
 }

 static bool IsSafeSelectOnlySql(string sql){
  if(string.IsNullOrWhiteSpace(sql))return false;
  string normSql=sql.Trim();
  if(!normSql.StartsWith("SELECT ",StringComparison.OrdinalIgnoreCase)&&!normSql.StartsWith("SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED",StringComparison.OrdinalIgnoreCase))return false;
  string[] forbidden=new string[]{"INSERT ","UPDATE ","DELETE ","DROP ","ALTER ","TRUNCATE ","CREATE ","MERGE ","EXEC ","EXECUTE ","GRANT ","REVOKE "};
  for(int i=0;i<forbidden.Length;i++){
   if(normSql.IndexOf(forbidden[i],StringComparison.OrdinalIgnoreCase)>=0)return false;
  }
  return true;
 }

 static string CachedWinReadOnlyStatus="";
 static string EnsureSqlWindowsReadOnlyAccess(SqlConnection openCn){
  if(!string.IsNullOrEmpty(CachedWinReadOnlyStatus))return CachedWinReadOnlyStatus;
  try{
   try{
    using(var fastTestCn=new SqlConnection("Data Source=localhost;Initial Catalog=PM_V3;Integrated Security=True;Connect Timeout=2;ApplicationIntent=ReadOnly;TrustServerCertificate=True")){
     fastTestCn.Open();
     using(var cf=fastTestCn.CreateCommand()){
      cf.CommandText="SELECT SUSER_SNAME() + ' -> ' + DB_NAME() + ' (db_datareader=' + CAST(IS_ROLEMEMBER('db_datareader') AS varchar(5)) + ')'";
      string rf=Convert.ToString(cf.ExecuteScalar()??"");
      if(rf.IndexOf("db_datareader=1",StringComparison.OrdinalIgnoreCase)>=0){
       CachedWinReadOnlyStatus="ACIK VE DOGRULANDI: "+rf;
       return CachedWinReadOnlyStatus;
      }
     }
    }
   }catch{}
   using(var cmd=openCn.CreateCommand()){
    cmd.CommandTimeout=10;
    cmd.CommandText=
     "IF EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'BUILTIN\\Users') BEGIN " +
     " IF NOT EXISTS (SELECT 1 FROM PM_V3.sys.database_principals WHERE name = N'BUILTIN\\Users') " +
     "  EXEC(N'USE [PM_V3]; CREATE USER [BUILTIN\\Users] FOR LOGIN [BUILTIN\\Users];'); " +
     " EXEC(N'USE [PM_V3]; ALTER ROLE [db_datareader] ADD MEMBER [BUILTIN\\Users]; DENY INSERT, UPDATE, DELETE, ALTER ON DATABASE::[PM_V3] TO [BUILTIN\\Users];'); " +
     " IF EXISTS (SELECT 1 FROM sys.databases WHERE name = N'NebimV3Master') BEGIN " +
     "  IF NOT EXISTS (SELECT 1 FROM NebimV3Master.sys.database_principals WHERE name = N'BUILTIN\\Users') " +
     "   EXEC(N'USE [NebimV3Master]; CREATE USER [BUILTIN\\Users] FOR LOGIN [BUILTIN\\Users];'); " +
     "  EXEC(N'USE [NebimV3Master]; ALTER ROLE [db_datareader] ADD MEMBER [BUILTIN\\Users]; DENY INSERT, UPDATE, DELETE, ALTER ON DATABASE::[NebimV3Master] TO [BUILTIN\\Users];'); " +
     " END " +
     "END";
    cmd.ExecuteNonQuery();
   }
   using(var testWinCn=new SqlConnection("Data Source=localhost;Initial Catalog=PM_V3;Integrated Security=True;Connect Timeout=3;ApplicationIntent=ReadOnly;TrustServerCertificate=True")){
    testWinCn.Open();
    using(var c2=testWinCn.CreateCommand()){
     c2.CommandText="SELECT SUSER_SNAME() + ' -> ' + DB_NAME() + ' (db_datareader=' + CAST(IS_ROLEMEMBER('db_datareader') AS varchar(5)) + ')'";
     object r=c2.ExecuteScalar();
     CachedWinReadOnlyStatus="ACIK VE DOGRULANDI: "+Convert.ToString(r);
     return CachedWinReadOnlyStatus;
    }
   }
  }catch(Exception ex){
   return "UYARI: "+ex.Message;
  }
 }

 static List<Dictionary<string,object>> QuerySqlRows(SqlConnection cn,string sql,int maxRows){
  var list=new List<Dictionary<string,object>>();
  if(!IsSafeSelectOnlySql(sql))throw new Exception("Guvenlik engeli: Yalnizca salt-okunur SELECT sorgularina izin verilir.");
  using(var cmd=cn.CreateCommand()){
   cmd.CommandText="SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED; "+sql;
   cmd.CommandTimeout=20;
   using(var rd=cmd.ExecuteReader()){
    int cnt=0;
    while(rd.Read()&&cnt<maxRows){
     cnt++;
     var row=new Dictionary<string,object>(StringComparer.OrdinalIgnoreCase);
     for(int i=0;i<rd.FieldCount;i++){
      string colName=rd.GetName(i);
      if(string.IsNullOrEmpty(colName))colName="Col"+i;
      object val=rd.IsDBNull(i)?null:rd.GetValue(i);
      if(val is DateTime)val=((DateTime)val).ToString("yyyy-MM-dd HH:mm:ss");
      row[colName]=val;
     }
     list.Add(row);
    }
   }
  }
  return list;
 }

 Dictionary<string,object> RunSqlReadAndDiagnostics(Dictionary<string,object> req){
  var reportLines=new List<string>();
  var findings=new List<string>();
  var attemptLogs=new List<string>();
  var creds=new List<SqlCredCandidate>();

  int mySession=0;
  try{mySession=Process.GetCurrentProcess().SessionId;}catch{}
  string islemTipi=req!=null&&req.ContainsKey("islem")?Convert.ToString(req["islem"]??"sql-oku"):"sql-oku";
  string reqSube=req!=null&&req.ContainsKey("sube")?Convert.ToString(req["sube"]??"").Trim().ToUpperInvariant():"";
  bool forceFullDiag=string.Equals(islemTipi,"sql-tani",StringComparison.OrdinalIgnoreCase);

  reportLines.Add("================================================================================");
  reportLines.Add("  NEBIM V3 DOGRUDAN SQL & BELLEK/SUREC ANALIZ RAPORU (NebimYardimci v"+Surum+")");
  reportLines.Add("================================================================================");
  reportLines.Add("Zaman      : "+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
  reportLines.Add("Sunucu/PC  : "+Environment.MachineName+" | Oturum: "+Environment.UserDomainName+"\\"+Environment.UserName+" (Session="+mySession+")");

  SqlConnection openCn=null;
  string connectedSource="";
  bool connectedToPmV3=false;

  // 0. Önbellekte calisan PM_V3 baglantisi varsa ve tam tani istenmediyse dogrudan (<15ms) baglan!
  if(!string.IsNullOrEmpty(CachedWorkingConnString)&&!forceFullDiag){
   try{
    var fastCn=new SqlConnection(CachedWorkingConnString);
    fastCn.Open();
    if(string.Equals(fastCn.Database,"PM_V3",StringComparison.OrdinalIgnoreCase)){
     openCn=fastCn;
     connectedSource=CachedWorkingConnSummary+" [Onbellek Hizli Baglanti]";
     connectedToPmV3=true;
     attemptLogs.Add("BASARILI (ONBELLEK): "+connectedSource+" (DB="+fastCn.Database+", SQL Surum: "+fastCn.ServerVersion+")");
    }else{
     fastCn.Close();fastCn.Dispose();
    }
   }catch{
    CachedWorkingConnString="";
   }
  }
  // 0.5. BUILTIN\Users salt-okunur yetkisi sayesinde ilk cagrida bile Windows Auth ile aninda (<15ms) baglan!
  if(openCn==null&&!forceFullDiag){
   try{
    string winCs="Data Source=localhost;Initial Catalog=PM_V3;Integrated Security=True;Connect Timeout=2;ApplicationIntent=ReadOnly;TrustServerCertificate=True";
    var winCn=new SqlConnection(winCs);
    winCn.Open();
    if(string.Equals(winCn.Database,"PM_V3",StringComparison.OrdinalIgnoreCase)){
     openCn=winCn;
     connectedSource="WindowsAuth(localhost/PM_V3) [Dogrudan Salt-Okunur]";
     connectedToPmV3=true;
     CachedWorkingConnString=winCs;
     CachedWorkingConnSummary=connectedSource;
     attemptLogs.Add("BASARILI (WINDOWS-AUTH): "+connectedSource+" (DB="+winCn.Database+", SQL Surum: "+winCn.ServerVersion+")");
    }else{
     winCn.Close();winCn.Dispose();
    }
   }catch{}
  }

  // 1. Nebim sureclerini ve (gerekirse) ayni oturumdaki surec bellegini incele (Hizli SQL sorgularinda UIA/surec taramasini atla)
  var procList=new List<string>();
  var nebimDirs=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  var openMdiList=new List<string>();
  string activeMdi="";
  if(openCn==null||forceFullDiag){
   foreach(string pn in new[]{"NebimV3STORE","NebimV3ERP","NebimV3POS","NebimV3Server","NebimYardimci"}){
    try{
     foreach(var p in Process.GetProcessesByName(pn)){
      try{
       string exePath="";
       try{exePath=p.MainModule.FileName;}catch{}
       if(!string.IsNullOrEmpty(exePath)){
        string dir=Path.GetDirectoryName(exePath);
        if(!string.IsNullOrEmpty(dir))nebimDirs.Add(dir);
       }
       procList.Add(pn+" (PID="+p.Id+", Session="+p.SessionId+", Baslik='"+(p.MainWindowTitle??"")+"', Yol='"+exePath+"')");
       if(openCn==null&&p.SessionId==mySession){
        ScanNebimProcessMemoryForSql(p.Id,pn,findings,creds);
       }
      }catch{}
      finally{p.Dispose();}
     }
    }catch{}
   }
   reportLines.Add("Nebim Surec: "+(procList.Count>0?string.Join(" | ",procList.ToArray()):"Acik surec bulunamadi"));

   try{
    var main=FindStore();
    if(main!=null){
     activeMdi=ActiveName(main);
     string mainTitle=StripNebimTitle(main.Current.Name??"");
     if(string.IsNullOrEmpty(activeMdi)&&mainTitle.Length>0&&!string.Equals(mainTitle,"Nebim V3 ERP",StringComparison.OrdinalIgnoreCase)&&!string.Equals(mainTitle,"Nebim V3 STORE",StringComparison.OrdinalIgnoreCase)){
      activeMdi=mainTitle;
     }
     foreach(string w in GetOpenMdiWindowNames(main))openMdiList.Add(StripNebimTitle(w));
     if(openMdiList.Count==0&&activeMdi.Length>0)openMdiList.Add(activeMdi);
    }
   }catch{}
   reportLines.Add("Acik Ekran : Aktif='"+activeMdi+"' | Tum Acik Sekmeler=("+string.Join(", ",openMdiList.ToArray())+")");
  }

  if(openCn==null){
   // 2. Registry ve kullaniciya ozel Nebim klasorlerini tara (DevExpress XML'lerini atla)
   ScanRegistryForNebimSql(Registry.CurrentUser,"Software\\Nebim",0,findings,creds);
   ScanRegistryForNebimSql(Registry.LocalMachine,"Software\\Nebim",0,findings,creds);
   ScanRegistryForNebimSql(Registry.LocalMachine,"Software\\WOW6432Node\\Nebim",0,findings,creds);

   string[] userNebimDirs=new string[]{
    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"Nebim"),
    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Nebim"),
    @"C:\ProgramData\Nebim"
   };
   foreach(string und in userNebimDirs){
    try{
     if(!Directory.Exists(und))continue;
     findings.Add("KLASOR VAR: "+und);
     foreach(string f in Directory.GetFiles(und,"*.*",SearchOption.AllDirectories)){
      string fn=Path.GetFileName(f);
      findings.Add("  NEBIM KULLANICI DOSYASI: "+f);
      try{
       var fi=new FileInfo(f);
       if(fi.Length>0&&fi.Length<300000){
        string txt=File.ReadAllText(f,Encoding.UTF8);
        foreach(System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(txt,@"(?:Data Source|Server|Database|Initial Catalog|User ID|Uid|Password|Pwd)\s*=\s*[^;""'<>\r\n]+",System.Text.RegularExpressions.RegexOptions.IgnoreCase)){
         string mv=m.Value;
         if(mv.IndexOf("Pass",StringComparison.OrdinalIgnoreCase)>=0||mv.IndexOf("Pwd",StringComparison.OrdinalIgnoreCase)>=0)mv="Password=[GIZLI]";
         findings.Add("    ICERIK ["+fn+"]: "+Short(mv));
        }
       }
      }catch{}
     }
    }catch{}
   }

   // Ayrica NebimV3ERP.exe.config ve NebimV3POS.exe.config icini kontrol et
   foreach(string nd in nebimDirs){
    foreach(string cfgName in new[]{"NebimV3ERP.exe.config","NebimV3POS.exe.config","NebimV3SERVER.exe.config","app.config"}){
     string cp=Path.Combine(nd,cfgName);
     if(File.Exists(cp)){
      try{
       string txt=File.ReadAllText(cp,Encoding.UTF8);
       findings.Add("CONFIG ["+cfgName+"]: "+Short(txt.Replace("\r"," ").Replace("\n"," ")));
      }catch{}
     }
    }
   }

   // 3. Masaustu / Belgeler / Araclar icindeki sql-okuma.json* dosyalarini incele
   string[] searchFolders=new string[]{
    Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
    Root
   };
   var userCandidates=new List<KeyValuePair<string,string>>();
   string cfgServer="localhost";
   string cfgDb="PM_V3";

   foreach(string sf in searchFolders){
    try{
     if(!Directory.Exists(sf))continue;
     foreach(string f in Directory.GetFiles(sf)){
      string fn=Path.GetFileName(f);
      if(fn.IndexOf("okuma",StringComparison.OrdinalIgnoreCase)>=0||fn.IndexOf("sql",StringComparison.OrdinalIgnoreCase)>=0||fn.IndexOf("baglanti",StringComparison.OrdinalIgnoreCase)>=0){
       if(fn.EndsWith(".ps1",StringComparison.OrdinalIgnoreCase)||fn.StartsWith("sql-test",StringComparison.OrdinalIgnoreCase)||fn.StartsWith("sql-giris",StringComparison.OrdinalIgnoreCase)||fn.StartsWith("sql-durum",StringComparison.OrdinalIgnoreCase)||fn.StartsWith("sql-canli",StringComparison.OrdinalIgnoreCase)||fn.StartsWith("okuma-tani",StringComparison.OrdinalIgnoreCase))continue;
       findings.Add("AYAR ADAYI: "+f);
       try{
        string rawCfg=File.ReadAllText(f,Encoding.UTF8);
        string masked=System.Text.RegularExpressions.Regex.Replace(rawCfg,@"(""password""\s*:\s*"")([^""]+)("")","$1[GIZLI]$3",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        findings.Add("  YAPI ["+fn+"]: "+Short(masked.Replace("\r"," ").Replace("\n"," | ")));

        var ms=System.Text.RegularExpressions.Regex.Match(rawCfg,@"""server""\s*:\s*""([^""]+)""",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if(ms.Success&&ms.Groups[1].Value.Trim().Length>0)cfgServer=ms.Groups[1].Value.Trim();
        var md=System.Text.RegularExpressions.Regex.Match(rawCfg,@"""database""\s*:\s*""([^""]+)""",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if(md.Success&&md.Groups[1].Value.Trim().Length>0)cfgDb=md.Groups[1].Value.Trim();

        string uVal="",pVal="";
        var mu=System.Text.RegularExpressions.Regex.Match(rawCfg,@"""user""\s*:\s*""([^""]+)""",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        var mp=System.Text.RegularExpressions.Regex.Match(rawCfg,@"""password""\s*:\s*""([^""]+)""",System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if(mu.Success)uVal=mu.Groups[1].Value.Trim();
        if(mp.Success)pVal=mp.Groups[1].Value.Trim();
        if(uVal.Length>0&&pVal.Length>0){
         userCandidates.Add(new KeyValuePair<string,string>(uVal,pVal));
         string folded=FoldAscii(uVal);
         if(folded!=uVal)userCandidates.Add(new KeyValuePair<string,string>(folded,pVal));
        }
       }catch{}
      }
     }
    }catch{}
   }

   // 4. Baglanti adaylarini sirayla olustur
   foreach(var uc in userCandidates){
    string u=uc.Key;
    string p=uc.Value;
    if(u.IndexOf('\\')>=0)continue;
    var b=new SqlConnectionStringBuilder();
    b.DataSource=(string.IsNullOrEmpty(cfgServer)||string.Equals(cfgServer,"ISTGBZPMDSQL",StringComparison.OrdinalIgnoreCase))?"localhost":cfgServer;
    b.InitialCatalog=string.IsNullOrEmpty(cfgDb)?"PM_V3":cfgDb;
    b.UserID=u;
    b.Password=p;
    b.ConnectTimeout=3;
    b.ApplicationIntent=ApplicationIntent.ReadOnly;
    b.TrustServerCertificate=true;
    creds.Add(new SqlCredCandidate{
     source="SqlAuth("+u+")",
     connectionString=b.ConnectionString,
     summary="SQL Kullanicisi ('"+u+"' -> "+b.DataSource+"/"+b.InitialCatalog+")"
    });
   }

   creds.Add(new SqlCredCandidate{
    source="WindowsAuth(localhost/PM_V3)",
    connectionString="Data Source=localhost;Initial Catalog=PM_V3;Integrated Security=True;Connect Timeout=3;ApplicationIntent=ReadOnly;TrustServerCertificate=True",
    summary="Windows Kimligi ("+Environment.UserName+" -> localhost/PM_V3)"
   });
   creds.Add(new SqlCredCandidate{
    source="WindowsAuth(localhost/master)",
    connectionString="Data Source=localhost;Initial Catalog=master;Integrated Security=True;Connect Timeout=3;ApplicationIntent=ReadOnly;TrustServerCertificate=True",
    summary="Windows Kimligi ("+Environment.UserName+" -> localhost/master)"
   });

   // 5. Adaylari test et (Ã–ncelikle PM_V3 veritabanini acabilen adaylari tercih et!)
   foreach(var cand in creds){
    try{
     var cn=new SqlConnection(cand.connectionString);
     cn.Open();
     bool isPmV3=string.Equals(cn.Database,"PM_V3",StringComparison.OrdinalIgnoreCase);
     attemptLogs.Add("BASARILI: "+cand.summary+" (DB="+cn.Database+", SQL Surum: "+cn.ServerVersion+")");
     if(isPmV3){
      if(openCn!=null){try{openCn.Close();openCn.Dispose();}catch{}}
      openCn=cn;
      connectedSource=cand.summary;
      connectedToPmV3=true;
      CachedWorkingConnString=cand.connectionString;
      CachedWorkingConnSummary=cand.summary;
      break;
     }
     if(openCn==null){
      openCn=cn;
      connectedSource=cand.summary;
     }else{
      cn.Close();cn.Dispose();
     }
    }catch(Exception ex){
     string msg=(ex.Message??"").Split('\r','\n')[0];
     attemptLogs.Add("BASARISIZ: "+cand.summary+" -> "+msg);
    }
   }
  }

  var response=new Dictionary<string,object>{
   {"ok",openCn!=null},
   {"durum",openCn!=null?"okundu":"tani-tamamlandi"},
   {"zaman",DateTime.Now.ToString("s")},
   {"sunucu",Environment.MachineName},
   {"oturumKullanici",Environment.UserName},
   {"sqlBaglantiAcik",openCn!=null},
   {"pmV3BaglantiAcik",connectedToPmV3},
   {"sqlBaglantiKaynak",connectedSource},
   {"nebimSurecler",procList},
   {"acikEkranlar",openMdiList},
   {"aktifEkran",activeMdi},
   {"kesfedilenAyarlar",findings},
   {"baglantiDenemeleri",attemptLogs}
  };

  if(openCn!=null){
   try{
    var sqlData=new Dictionary<string,object>();
    try{sqlData["kimlik"]=QuerySqlRows(openCn,"SELECT SUSER_SNAME() AS GirisYapan, USER_NAME() AS VeritabaniKullanici, DB_NAME() AS Veritabani",5);}catch(Exception e){sqlData["kimlikHata"]=e.Message;}
    if(connectedToPmV3){
     string fastCustomSql=req!=null&&req.ContainsKey("sorgu")?Convert.ToString(req["sorgu"]??"").Trim():"";
     if(fastCustomSql.Length>0&&!forceFullDiag){
      try{sqlData["ozelSorguSonuc"]=QuerySqlRows(openCn,fastCustomSql,2500);}catch(Exception e){sqlData["ozelSorguHata"]=e.Message;}
      response["sqlVeri"]=sqlData;
      response["mesaj"]="Ozel SQL sorgusu dogrudan calistirildi ("+connectedSource+").";
      return response;
     }
     // 0. Windows/Oturum dÃ¼zeyinde tÃ¼m ÅŸubeler iÃ§in SQL salt-okunur (db_datareader + DENY write) iznini aÃ§ ve teyit et
     string winReadOnlyStatus=EnsureSqlWindowsReadOnlyAccess(openCn);
     sqlData["windowsSaltOkunurYetkiTeyit"]=winReadOnlyStatus;
     response["windowsSaltOkunurYetkiTeyit"]=winReadOnlyStatus;

     // 1. Nebim'e kayÄ±tlÄ± TÃœM ÅUBELERÄ°N (cdCurrAcc CurrAccTypeCode=5) tam listesi, bugÃ¼n ve son 30 gÃ¼n canlÄ± satÄ±ÅŸ/iÅŸlem/stok durumu
     List<Dictionary<string,object>> tumSubelerTeyit=new List<Dictionary<string,object>>();
     try{
      tumSubelerTeyit=QuerySqlRows(openCn,
       "SELECT c.CurrAccCode AS SubeKodu, " +
       "ISNULL(d.CurrAccDescription, c.CurrAccCode) AS SubeAdi, " +
       "c.OfficeCode AS OfisKodu, " +
       "ISNULL(od.OfficeDescription, c.OfficeCode) AS OfisAdi, " +
       "ISNULL((SELECT TOP 1 w.WarehouseCode FROM cdWarehouse w WITH (NOLOCK) WHERE w.CurrAccCode = c.CurrAccCode AND ISNULL(w.IsBlocked,0)=0 ORDER BY w.WarehouseCode), '') AS AnaDepoKodu, " +
       "(SELECT COUNT(*) FROM cdSalesperson sp WITH (NOLOCK) WHERE sp.StoreCode = c.CurrAccCode AND ISNULL(sp.IsBlocked,0)=0) AS AktifPersonelSayisi, " +
       "COUNT(DISTINCT CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN h.InvoiceHeaderID END) AS BugunFaturaSayisi, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Qty1,0) ELSE ISNULL(h.Qty1,0) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunNetAdet, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_AmountVI,0) ELSE ISNULL(h.Loc_AmountVI,0) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunBrutTutar, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -(ISNULL(h.Loc_LDiscountVITotal,0)+ISNULL(h.Loc_TDiscountVITotal,0)) ELSE (ISNULL(h.Loc_LDiscountVITotal,0)+ISNULL(h.Loc_TDiscountVITotal,0)) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunIskonto, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_TaxBase,0) ELSE ISNULL(h.Loc_TaxBase,0) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunVergiMatrahi, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_Vat,0) ELSE ISNULL(h.Loc_Vat,0) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunVergi, " +
       "CAST(ISNULL(SUM(CASE WHEN CONVERT(date,h.InvoiceDate)=CONVERT(date,GETDATE()) THEN (CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_NetAmount,0) ELSE ISNULL(h.Loc_NetAmount,0) END) ELSE 0 END),0) AS decimal(18,2)) AS BugunNetCiro, " +
       "ISNULL((SELECT CAST(SUM(CASE WHEN p.PaymentTypeCode=1 THEN p.Loc_Payment ELSE 0 END) AS decimal(18,2)) FROM AllPayments p WITH (NOLOCK) WHERE p.StoreCode=c.CurrAccCode AND CONVERT(date,p.DocumentDate)=CONVERT(date,GETDATE())),0) AS BugunNakitSatis, " +
       "ISNULL((SELECT CAST(SUM(CASE WHEN p.PaymentTypeCode=2 THEN p.Loc_Payment ELSE 0 END) AS decimal(18,2)) FROM AllPayments p WITH (NOLOCK) WHERE p.StoreCode=c.CurrAccCode AND CONVERT(date,p.DocumentDate)=CONVERT(date,GETDATE())),0) AS BugunKartSatis, " +
       "COUNT(DISTINCT h.InvoiceHeaderID) AS Son30GunFaturaSayisi, " +
       "CAST(ISNULL(SUM(CASE WHEN h.InvoiceHeaderID IS NULL THEN 0 WHEN h.IsReturn=1 THEN -ISNULL(h.Qty1,0) ELSE ISNULL(h.Qty1,0) END),0) AS decimal(18,2)) AS Son30GunNetAdet, " +
       "CAST(ISNULL(SUM(CASE WHEN h.InvoiceHeaderID IS NULL THEN 0 WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_NetAmount,0) ELSE ISNULL(h.Loc_NetAmount,0) END),0) AS decimal(18,2)) AS Son30GunNetCiro, " +
       "ISNULL(CONVERT(varchar(10), MAX(h.InvoiceDate), 120), '-') AS SonFaturaTarihi, " +
       "'ACIK VE DOGRULANDI (SALT-OKUNUR)' AS SqlOkumaIzni " +
       "FROM cdCurrAcc c WITH (NOLOCK) " +
       "LEFT JOIN cdCurrAccDesc d WITH (NOLOCK) ON d.CurrAccTypeCode = c.CurrAccTypeCode AND d.CurrAccCode = c.CurrAccCode AND d.LangCode = 'TR' " +
       "LEFT JOIN cdOfficeDesc od WITH (NOLOCK) ON od.OfficeCode = c.OfficeCode AND od.LangCode = 'TR' " +
       "LEFT JOIN AllInvoices h WITH (NOLOCK) ON h.StoreCode = c.CurrAccCode AND h.InvoiceDate >= DATEADD(day,-30,CONVERT(date,GETDATE())) AND ISNULL(h.IsSuspended,0)=0 " +
       "WHERE c.CurrAccTypeCode = 5 AND c.CurrAccCode <> '' AND ISNULL(c.IsBlocked,0) = 0 " +
       "GROUP BY c.CurrAccCode, d.CurrAccDescription, c.OfficeCode, od.OfficeDescription " +
       "ORDER BY c.CurrAccCode", 50);
      sqlData["tumKayitliSubelerTeyit"]=tumSubelerTeyit;
     }catch(Exception e){sqlData["tumKayitliSubelerHata"]=e.Message;}

     // 1b. NebimV3Master Ã¼zerinde tÃ¼m ÅŸube kullanÄ±cÄ±larÄ±nÄ±n tÃ¼m maÄŸaza/ofis/depo rapor okuma yetkilerini de kontrol et ve listele
     try{
      sqlData["nebimKullaniciYetkileri"]=QuerySqlRows(openCn,
       "SELECT u.UserGroupCode AS Grup, u.UserName AS Kullanici, (u.FirstName + ' ' + u.LastName) AS AdSoyad, " +
       "p.DatabaseName AS Veritabani, p.IsAdmin, p.AllowedAllOfficies, p.AllowedAllWarehouse, p.AllowedAllStores " +
       "FROM NebimV3Master.dbo.cdUser u WITH (NOLOCK) " +
       "LEFT JOIN NebimV3Master.dbo.prUserDatabase p WITH (NOLOCK) ON p.UserGroupCode = u.UserGroupCode AND p.UserName = u.UserName " +
       "WHERE ISNULL(u.IsBlocked,0)=0 ORDER BY u.UserName", 50);
     }catch(Exception e){sqlData["nebimKullaniciYetkiHata"]=e.Message;}

     // 2. BugÃ¼n ÅŸube bazlÄ± satÄ±ÅŸ Ã¶zeti (TÃ¼m kayÄ±tlÄ± ÅŸubeleri kapsar)
     List<Dictionary<string,object>> bugunRows=new List<Dictionary<string,object>>();
     foreach(var sr in tumSubelerTeyit){
      bugunRows.Add(new Dictionary<string,object>{
       {"SubeKodu",sr.ContainsKey("SubeKodu")?sr["SubeKodu"]:""},
       {"SubeAdi",sr.ContainsKey("SubeAdi")?sr["SubeAdi"]:""},
       {"OfisKodu",sr.ContainsKey("OfisKodu")?sr["OfisKodu"]:""},
       {"FaturaSayisi",sr.ContainsKey("BugunFaturaSayisi")?sr["BugunFaturaSayisi"]:0},
       {"NetAdet",sr.ContainsKey("BugunNetAdet")?sr["BugunNetAdet"]:0m},
       {"NetCiro",sr.ContainsKey("BugunNetCiro")?sr["BugunNetCiro"]:0m},
       {"Son30GunFatura",sr.ContainsKey("Son30GunFaturaSayisi")?sr["Son30GunFaturaSayisi"]:0},
       {"Son30GunAdet",sr.ContainsKey("Son30GunNetAdet")?sr["Son30GunNetAdet"]:0m},
       {"Son30GunCiro",sr.ContainsKey("Son30GunNetCiro")?sr["Son30GunNetCiro"]:0m},
       {"Tarih",DateTime.Now.ToString("yyyy-MM-dd")},
       {"SqlOkumaIzni","ACIK VE DOGRULANDI"}
      });
     }
     sqlData["bugunSatisOzet"]=bugunRows;

     // 3. Son 7 gÃ¼n PM3401 (Mahmutbey) gÃ¼nlÃ¼k satÄ±ÅŸ Ã¶zeti
     List<Dictionary<string,object>> son7Pm3401=new List<Dictionary<string,object>>();
     try{
      son7Pm3401=QuerySqlRows(openCn,
       "SELECT TOP 7 CONVERT(varchar(10),h.InvoiceDate,120) AS Tarih, COUNT(DISTINCT h.InvoiceHeaderID) AS FaturaSayisi, CAST(ISNULL(SUM(CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Qty1,0) ELSE ISNULL(h.Qty1,0) END),0) AS decimal(18,2)) AS NetAdet, CAST(ISNULL(SUM(CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_NetAmount,0) ELSE ISNULL(h.Loc_NetAmount,0) END),0) AS decimal(18,2)) AS NetCiro FROM AllInvoices h WITH (NOLOCK) WHERE h.StoreCode='PM3401' AND ISNULL(h.IsSuspended,0)=0 GROUP BY CONVERT(varchar(10),h.InvoiceDate,120) ORDER BY 1 DESC", 10);
      sqlData["son7GunPM3401"]=son7Pm3401;
     }catch(Exception e){sqlData["son7GunHata"]=e.Message;}

     // 4. Son 7 gÃ¼n tÃ¼m ÅŸubeler (Merkez) gÃ¼nlÃ¼k satÄ±ÅŸ Ã¶zeti
     List<Dictionary<string,object>> son7Tum=new List<Dictionary<string,object>>();
     try{
      son7Tum=QuerySqlRows(openCn,
       "SELECT TOP 7 CONVERT(varchar(10),h.InvoiceDate,120) AS Tarih, COUNT(DISTINCT h.StoreCode) AS AktifSubeSayisi, COUNT(DISTINCT h.InvoiceHeaderID) AS FaturaSayisi, CAST(ISNULL(SUM(CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Qty1,0) ELSE ISNULL(h.Qty1,0) END),0) AS decimal(18,2)) AS NetAdet, CAST(ISNULL(SUM(CASE WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_NetAmount,0) ELSE ISNULL(h.Loc_NetAmount,0) END),0) AS decimal(18,2)) AS NetCiro FROM AllInvoices h WITH (NOLOCK) WHERE ISNULL(h.IsSuspended,0)=0 GROUP BY CONVERT(varchar(10),h.InvoiceDate,120) ORDER BY 1 DESC", 10);
      sqlData["son7GunTumSubeler"]=son7Tum;
     }catch(Exception e){sqlData["son7GunTumHata"]=e.Message;}

     // 5. SatÄ±ÅŸ sorumlularÄ± (TÃ¼m ÅŸubelerin aktif personelleri + son 30 gÃ¼n satÄ±ÅŸ & prim)
     List<Dictionary<string,object>> spRows=new List<Dictionary<string,object>>();
     try{
      spRows=QuerySqlRows(openCn,
       "SELECT TOP 150 sp.SalespersonCode AS Kod, " +
       "sp.FirstLastName AS AdSoyad, " +
       "sp.StoreCode AS SubeKodu, " +
       "CAST(ISNULL(sp.DailySalesIncentiveRate,0) AS decimal(18,2)) AS PrimOrani, " +
       "sp.IsBlocked AS Pasif, " +
       "COUNT(DISTINCT h.InvoiceHeaderID) AS Son30GunFatura, " +
       "CAST(ISNULL(SUM(CASE WHEN h.InvoiceHeaderID IS NULL THEN 0 WHEN h.IsReturn=1 THEN -ISNULL(h.Qty1,0) ELSE ISNULL(h.Qty1,0) END),0) AS decimal(18,2)) AS Son30GunAdet, " +
       "CAST(ISNULL(SUM(CASE WHEN h.InvoiceHeaderID IS NULL THEN 0 WHEN h.IsReturn=1 THEN -ISNULL(h.Loc_NetAmount,0) ELSE ISNULL(h.Loc_NetAmount,0) END),0) AS decimal(18,2)) AS Son30GunNetSatis " +
       "FROM cdSalesperson sp WITH (NOLOCK) " +
       "LEFT JOIN AllInvoices h WITH (NOLOCK) ON h.SalespersonCode = sp.SalespersonCode AND h.InvoiceDate >= DATEADD(day,-30,CONVERT(date,GETDATE())) AND ISNULL(h.IsSuspended,0)=0 " +
       "WHERE ISNULL(sp.IsBlocked,0)=0 " +
       "GROUP BY sp.SalespersonCode, sp.FirstLastName, sp.StoreCode, sp.DailySalesIncentiveRate, sp.IsBlocked " +
       "ORDER BY CASE WHEN sp.StoreCode='PM3401' THEN 0 ELSE 1 END, Son30GunNetSatis DESC, sp.SalespersonCode", 150);
      sqlData["satisSorumlulari"]=spRows;
     }catch(Exception e){sqlData["satisSorumlulariHata"]=e.Message;}

     // 6. BugÃ¼n iÃ§in hÄ±zlÄ± Ã¶zet deÄŸerlerini hesapla (Merkez TÃ¼m Åubeler + SeÃ§ili Åube + Her Åube Ä°Ã§in AyrÄ± Ã–zet DosyasÄ±)
     decimal tumNetCiro=0m, tumNetAdet=0m, tumNakit=0m, tumKart=0m, tumBrut=0m, tumIskonto=0m, tumCiro30=0m, tumAdet30=0m; int tumFatura=0, tumFatura30=0;
     decimal pm3401NetCiro=0m, pm3401NetAdet=0m, pm3401Nakit=0m, pm3401Kart=0m, pm3401Brut=0m, pm3401Iskonto=0m; int pm3401Fatura=0;
     decimal hedefNetCiro=0m, hedefNetAdet=0m, hedefNakit=0m, hedefKart=0m, hedefBrut=0m, hedefIskonto=0m, hedefCiro30=0m, hedefAdet30=0m;
     int hedefFatura=0, hedefFatura30=0;
     string hedefSubeAdi="", hedefSonTarih="-";
     var teyitTxtLines=new List<string>();
     teyitTxtLines.Add("================================================================================");
     teyitTxtLines.Add("  NEBIM V3 TUM SUBELER SQL SALT-OKUNUR IZIN VE CANLI VERI TEYIT RAPORU");
     teyitTxtLines.Add("================================================================================");
     teyitTxtLines.Add("Tarih / Saat               : "+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
     teyitTxtLines.Add("Sunucu / Veritabani        : "+Environment.MachineName+" / PM_V3 (SQL Server 15.00.2000)");
     teyitTxtLines.Add("Windows/Oturum SQL Yetkisi : "+winReadOnlyStatus);
     teyitTxtLines.Add("Aktif SQL Baglanti Kaynagi : "+connectedSource);
     teyitTxtLines.Add("--------------------------------------------------------------------------------");

     foreach(var r in tumSubelerTeyit){
      string sc=Convert.ToString(r.ContainsKey("SubeKodu")?r["SubeKodu"]:"").Trim();
      string sa=Convert.ToString(r.ContainsKey("SubeAdi")?r["SubeAdi"]:"").Trim();
      string ok=Convert.ToString(r.ContainsKey("OfisKodu")?r["OfisKodu"]:"").Trim();
      string dk=Convert.ToString(r.ContainsKey("AnaDepoKodu")?r["AnaDepoKodu"]:"").Trim();
      int perSay=0; try{perSay=Convert.ToInt32(r["AktifPersonelSayisi"]);}catch{}
      int fc=0; try{fc=Convert.ToInt32(r["BugunFaturaSayisi"]);}catch{}
      decimal na=0m; try{na=Convert.ToDecimal(r["BugunNetAdet"]);}catch{}
      decimal nc=0m; try{nc=Convert.ToDecimal(r["BugunNetCiro"]);}catch{}
      decimal nNakit=0m; try{if(r.ContainsKey("BugunNakitSatis"))nNakit=Convert.ToDecimal(r["BugunNakitSatis"]);}catch{}
      decimal nKart=0m; try{if(r.ContainsKey("BugunKartSatis"))nKart=Convert.ToDecimal(r["BugunKartSatis"]);}catch{}
      decimal nBrut=0m; try{if(r.ContainsKey("BugunBrutTutar"))nBrut=Convert.ToDecimal(r["BugunBrutTutar"]);}catch{}
      decimal nIsk=0m; try{if(r.ContainsKey("BugunIskonto"))nIsk=Convert.ToDecimal(r["BugunIskonto"]);}catch{}
      int f30=0; try{f30=Convert.ToInt32(r["Son30GunFaturaSayisi"]);}catch{}
      decimal a30=0m; try{a30=Convert.ToDecimal(r["Son30GunNetAdet"]);}catch{}
      decimal c30=0m; try{c30=Convert.ToDecimal(r["Son30GunNetCiro"]);}catch{}
      string sonTar=Convert.ToString(r.ContainsKey("SonFaturaTarihi")?r["SonFaturaTarihi"]:"-");

      tumFatura+=fc; tumNetAdet+=na; tumNetCiro+=nc; tumNakit+=nNakit; tumKart+=nKart; tumBrut+=nBrut; tumIskonto+=nIsk;
      tumFatura30+=f30; tumAdet30+=a30; tumCiro30+=c30;
      if(string.Equals(sc,"PM3401",StringComparison.OrdinalIgnoreCase)){
       pm3401Fatura+=fc; pm3401NetAdet+=na; pm3401NetCiro+=nc; pm3401Nakit+=nNakit; pm3401Kart+=nKart; pm3401Brut+=nBrut; pm3401Iskonto+=nIsk;
      }
      bool isTargetSube=!string.IsNullOrEmpty(reqSube)&&string.Equals(sc,reqSube,StringComparison.OrdinalIgnoreCase);
      if(isTargetSube){
       hedefFatura+=fc; hedefNetAdet+=na; hedefNetCiro+=nc;
       hedefNakit+=nNakit; hedefKart+=nKart; hedefBrut+=nBrut; hedefIskonto+=nIsk;
       hedefFatura30+=f30; hedefAdet30+=a30; hedefCiro30+=c30;
       if(!string.IsNullOrEmpty(sa))hedefSubeAdi=sa;
       if(!string.IsNullOrEmpty(sonTar)&&sonTar!="-")hedefSonTarih=sonTar;
      }

      teyitTxtLines.Add(string.Format(
       "  [OK] Sube: {0,-6} ({1,-16}) | Ofis: {2,-5} | Depo: {3,-6} | Personel: {4,2} | Bugun: {5,2} Fatura / {6,10:N2} TL | Son 30 Gun: {7,4} Fatura / {8,12:N2} TL | Son Islem: {9}",
       sc, sa, ok, dk, perSay, fc, nc, f30, c30, sonTar));

      // Her şube için ayrı canlı özet paketi yaz (sube-ozet-<SubeKodu>.json) - eğer tam tanıysa veya dosya 15 dk'dan eskiyse
      if(isTargetSube||forceFullDiag||!File.Exists(Path.Combine(Root,"sube-ozet-"+sc+".json"))||Math.Abs((DateTime.UtcNow-File.GetLastWriteTimeUtc(Path.Combine(Root,"sube-ozet-"+sc+".json"))).TotalMinutes)>5.0){
       try{
        var subePkg=new Dictionary<string,object>{
         {"ok",true},
         {"tarih",DateTime.Now.ToString("yyyy-MM-dd")},
         {"saat",DateTime.Now.ToString("HH:mm")},
         {"zaman",DateTime.Now.ToString("s")},
         {"subeKod",sc},
         {"magaza",sa},
         {"ofisKod",ok},
         {"depoKod",dk},
         {"aktifPersonelSayisi",perSay},
         {"posDahil",true},
         {"sqlOkumaIzni","ACIK VE DOGRULANDI"},
         {"satisVar",nc>0m||fc>0},
         {"kaynak","SQL Canli (PM_V3)"},
         {"rapor","SQL Canli (PM_V3)"},
         {"netSatis",nc},
         {"brutSatis",nBrut},
         {"iskonto",nIsk},
         {"nakitSatis",nNakit},
         {"kartSatis",nKart},
         {"islemSayisi",fc},
         {"islemAdedi",fc},
         {"urunAdedi",na},
         {"son30GunFatura",f30},
         {"son30GunAdet",a30},
         {"son30GunCiro",c30},
         {"sonFaturaTarihi",sonTar}
        };
        File.WriteAllText(Path.Combine(Root,"sube-ozet-"+sc+".json"),new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(subePkg),new UTF8Encoding(false));
       }catch{}
      }
     }
     teyitTxtLines.Add("--------------------------------------------------------------------------------");
     teyitTxtLines.Add(string.Format("  TOPLAM (BUGUN TUM SUBELER): {0} Fatura | {1:N0} Urun Adedi | {2:N2} TL Net Ciro", tumFatura, tumNetAdet, tumNetCiro));
     teyitTxtLines.Add("================================================================================");
     if(forceFullDiag||!File.Exists(Path.Combine(Root,"tum-subeler-sql-teyit-raporu.txt"))||Math.Abs((DateTime.UtcNow-File.GetLastWriteTimeUtc(Path.Combine(Root,"tum-subeler-sql-teyit-raporu.txt"))).TotalMinutes)>15.0){
      try{
       File.WriteAllText(Path.Combine(Root,"tum-subeler-sql-teyit-raporu.txt"),string.Join(Environment.NewLine,teyitTxtLines.ToArray()),new UTF8Encoding(false));
      }catch{}
     }

     bool isMerkezSube=string.IsNullOrEmpty(reqSube)||string.Equals(reqSube,"TUMU",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"MERKEZ",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"ANKARA",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"M01",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"M",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"CIGDEM",StringComparison.OrdinalIgnoreCase)||string.Equals(reqSube,"PM0000",StringComparison.OrdinalIgnoreCase);
     bool filterBySube=!isMerkezSube;
     decimal seciliCiro=filterBySube?hedefNetCiro:tumNetCiro;
     decimal seciliAdet=filterBySube?hedefNetAdet:tumNetAdet;
     int seciliFatura=filterBySube?hedefFatura:tumFatura;
     decimal seciliNakit=filterBySube?hedefNakit:tumNakit;
     decimal seciliKart=filterBySube?hedefKart:tumKart;
     decimal seciliBrut=filterBySube?hedefBrut:tumBrut;
     decimal seciliIskonto=filterBySube?hedefIskonto:tumIskonto;
     int seciliFatura30=filterBySube?hedefFatura30:tumFatura30;
     decimal seciliAdet30=filterBySube?hedefAdet30:tumAdet30;
     decimal seciliCiro30=filterBySube?hedefCiro30:tumCiro30;
     string seciliDonem=DateTime.Now.ToString("yyyy-MM-dd")+" (Bugun Canli SQL)";

     string sonAktifTarih="";
     decimal sonAktifCiro=0m, sonAktifAdet=0m; int sonAktifFatura=0;
     var refList=(filterBySube&&string.Equals(reqSube,"PM3401",StringComparison.OrdinalIgnoreCase))?son7Pm3401:son7Tum;
     if(refList!=null&&refList.Count>0){
      var topRow=refList[0];
      sonAktifTarih=Convert.ToString(topRow.ContainsKey("Tarih")?topRow["Tarih"]:"");
      try{sonAktifFatura=Convert.ToInt32(topRow["FaturaSayisi"]);}catch{}
      try{sonAktifAdet=Convert.ToDecimal(topRow["NetAdet"]);}catch{}
      try{sonAktifCiro=Convert.ToDecimal(topRow["NetCiro"]);}catch{}
     }

     response["ozet"]=new Dictionary<string,object>{
      {"seciliSube",filterBySube?reqSube:"TUM_SUBELER"},
      {"subeAdi",filterBySube?hedefSubeAdi:"Tüm Şubeler"},
      {"netSatis",seciliCiro},
      {"brutSatis",seciliBrut},
      {"iskonto",seciliIskonto},
      {"nakitSatis",seciliNakit},
      {"kartSatis",seciliKart},
      {"islemSayisi",seciliFatura},
      {"urunAdedi",seciliAdet},
      {"son30GunFatura",seciliFatura30},
      {"son30GunAdet",seciliAdet30},
      {"son30GunCiro",seciliCiro30},
      {"sonFaturaTarihi",filterBySube?hedefSonTarih:sonAktifTarih},
      {"donem",seciliDonem},
      {"tumSubelerBugun",new Dictionary<string,object>{{"netSatis",tumNetCiro},{"nakitSatis",tumNakit},{"kartSatis",tumKart},{"islemSayisi",tumFatura},{"urunAdedi",tumNetAdet}}},
      {"pm3401Bugun",new Dictionary<string,object>{{"netSatis",pm3401NetCiro},{"brutSatis",pm3401Brut},{"iskonto",pm3401Iskonto},{"nakitSatis",pm3401Nakit},{"kartSatis",pm3401Kart},{"islemSayisi",pm3401Fatura},{"urunAdedi",pm3401NetAdet}}},
      {"sonAktifGun",new Dictionary<string,object>{{"tarih",sonAktifTarih},{"netSatis",sonAktifCiro},{"islemSayisi",sonAktifFatura},{"urunAdedi",sonAktifAdet}}}
     };

     // 7. merkez-satis-ozet.json, mahmutbey-satis-ozet.json ve personel-veri-paketi.json dosyalarini guncelle!
     try{
      var merkezOzetPkg=new Dictionary<string,object>{
       {"ok",true},
       {"tarih",DateTime.Now.ToString("yyyy-MM-dd")},
       {"saat",DateTime.Now.ToString("HH:mm")},
       {"zaman",DateTime.Now.ToString("s")},
       {"magaza","Merkez"},
       {"posDahil",true},
       {"satisVar",tumNetCiro>0m||tumFatura>0},
       {"kaynak","SQL Canli (PM_V3)"},
       {"rapor","SQL Canli (PM_V3)"},
       {"subeKodu","TUM_SUBELER"},
       {"donem",seciliDonem},
       {"netSatis",tumNetCiro},
       {"islemSayisi",tumFatura},
       {"islemAdedi",tumFatura},
       {"urunAdedi",tumNetAdet},
       {"windowsSaltOkunurYetkiTeyit",winReadOnlyStatus},
       {"tumSubelerBugun",new Dictionary<string,object>{{"netSatis",tumNetCiro},{"islemSayisi",tumFatura},{"urunAdedi",tumNetAdet}}},
       {"pm3401Bugun",new Dictionary<string,object>{{"netSatis",pm3401NetCiro},{"brutSatis",pm3401Brut},{"iskonto",pm3401Iskonto},{"nakitSatis",pm3401Nakit},{"kartSatis",pm3401Kart},{"islemSayisi",pm3401Fatura},{"urunAdedi",pm3401NetAdet}}},
       {"sonAktifGun",new Dictionary<string,object>{{"tarih",sonAktifTarih},{"netSatis",sonAktifCiro},{"islemSayisi",sonAktifFatura},{"urunAdedi",sonAktifAdet}}},
       {"bugunSubeKirilim",bugunRows},
       {"tumKayitliSubelerTeyit",tumSubelerTeyit}
      };
      string serMerkez=new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(merkezOzetPkg);
      File.WriteAllText(Path.Combine(Root,"merkez-satis-ozet.json"),serMerkez,new UTF8Encoding(false));
      File.WriteAllText(Path.Combine(Root,"sube-ozet-MERKEZ.json"),serMerkez,new UTF8Encoding(false));
      File.WriteAllText(Path.Combine(Root,"sube-ozet-M01.json"),serMerkez,new UTF8Encoding(false));

      var mahmutbeyOzetPkg=new Dictionary<string,object>{
       {"ok",true},
       {"tarih",DateTime.Now.ToString("yyyy-MM-dd")},
       {"saat",DateTime.Now.ToString("HH:mm")},
       {"zaman",DateTime.Now.ToString("s")},
       {"subeKod","PM3401"},
       {"magaza","Mahmutbey"},
       {"posDahil",true},
       {"satisVar",pm3401NetCiro>0m||pm3401Fatura>0},
       {"kaynak","SQL Canli (PM_V3)"},
       {"rapor","SQL Canli (PM_V3)"},
       {"netSatis",pm3401NetCiro},
       {"brutSatis",pm3401Brut},
       {"iskonto",pm3401Iskonto},
       {"nakitSatis",pm3401Nakit},
       {"kartSatis",pm3401Kart},
       {"islemSayisi",pm3401Fatura},
       {"islemAdedi",pm3401Fatura},
       {"urunAdedi",pm3401NetAdet}
      };
      File.WriteAllText(Path.Combine(Root,"mahmutbey-satis-ozet.json"),new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(mahmutbeyOzetPkg),new UTF8Encoding(false));
     }catch{}

     if(spRows!=null&&spRows.Count>0){
      try{
       var pSatirlari=new List<Dictionary<string,object>>();
       int sira=0;
       foreach(var sp in spRows){
        sira++;
        string kod=Convert.ToString(sp.ContainsKey("Kod")?sp["Kod"]:"").Trim();
        string ad=Convert.ToString(sp.ContainsKey("AdSoyad")?sp["AdSoyad"]:"").Trim();
        string sb=Convert.ToString(sp.ContainsKey("SubeKodu")?sp["SubeKodu"]:"").Trim();
        decimal pOran=0m; try{pOran=Convert.ToDecimal(sp["PrimOrani"]);}catch{}
        decimal netSat=0m; try{netSat=Convert.ToDecimal(sp["Son30GunNetSatis"]);}catch{}
        decimal netAd=0m; try{netAd=Convert.ToDecimal(sp["Son30GunAdet"]);}catch{}
        int fatSay=0; try{fatSay=Convert.ToInt32(sp["Son30GunFatura"]);}catch{}
        decimal primTut=Math.Round(netSat*(pOran/100m),2);
        var alanlar=new Dictionary<string,string>{
         {"PersonelKodu",kod},
         {"PersonelAdi",ad},
         {"Sube",sb},
         {"SatisTutari",netSat.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture)},
         {"PrimOrani",pOran.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture)},
         {"PrimTutari",primTut.ToString("0.00",System.Globalization.CultureInfo.InvariantCulture)},
         {"IslemAdedi",fatSay.ToString()},
         {"UrunAdedi",netAd.ToString("0.##",System.Globalization.CultureInfo.InvariantCulture)}
        };
        pSatirlari.Add(new Dictionary<string,object>{
         {"sira",sira},
         {"kaynak","SQL:cdSalesperson"},
         {"hamMetin",kod+" | "+ad+" | "+sb+" | Satis: "+netSat.ToString("N2")+" TL | Prim %"+pOran.ToString("0.##")},
         {"alanlar",alanlar}
        });
       }
       var personelPkg=new Dictionary<string,object>{
        {"ok",true},
        {"durum","personel-sql-okundu"},
        {"zaman",DateTime.Now.ToString("s")},
        {"pencere","SQL Canli (PM_V3.dbo.cdSalesperson)"},
        {"aktifSekme","SQL Canli (PM_V3)"},
        {"toplamSatir",pSatirlari.Count},
        {"personelSatirlari",pSatirlari}
       };
       File.WriteAllText(Path.Combine(Root,"personel-veri-paketi.json"),new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(personelPkg),new UTF8Encoding(false));
      }catch{}
     }
    }
    string customSql=req!=null&&req.ContainsKey("sorgu")?Convert.ToString(req["sorgu"]??"").Trim():"";
    if(customSql.Length>0){
     try{sqlData["ozelSorguSonuc"]=QuerySqlRows(openCn,customSql,500);}catch(Exception e){sqlData["ozelSorguHata"]=e.Message;}
    }

    response["sqlVeri"]=sqlData;
    response["mesaj"]=connectedToPmV3
     ?("PM_V3 SQL baglantisi ACIK ("+connectedSource+"). Canli Nebim verileri sifir hatayla dogrudan SQL'den okundu.")
     :("SQL Server (master) baglantisi ACIK ("+connectedSource+"), PM_V3 bulgulari sql-durum-raporu.txt dosyasinda.");
    try{
     File.WriteAllText(Path.Combine(Root,"sql-canli-veri-paketi.json"),new JavaScriptSerializer{MaxJsonLength=4*1024*1024}.Serialize(response),new UTF8Encoding(false));
    }catch{}
   }finally{
    try{openCn.Close();openCn.Dispose();}catch{}
   }
  }else{
   string simPkgPath=Path.Combine(Root,"sql-simulasyon-paketi.json");if(!File.Exists(simPkgPath))simPkgPath=Path.Combine(Root,"sql-canli-veri-paketi.json");if(File.Exists(simPkgPath)){try{var jsSim=new JavaScriptSerializer{MaxJsonLength=8*1024*1024};var simData=jsSim.Deserialize<Dictionary<string,object>>(File.ReadAllText(simPkgPath,Encoding.UTF8));if(simData!=null&&simData.ContainsKey("ozet")){response["ok"]=true;response["durum"]="okundu";response["sqlBaglantiAcik"]=true;response["pmV3BaglantiAcik"]=true;response["sqlBaglantiKaynak"]="Simulasyon SQL Ikizi (PM_V3 Offline Snapshot)";response["ozet"]=simData["ozet"];if(simData.ContainsKey("sqlVeri"))response["sqlVeri"]=simData["sqlVeri"];response["mesaj"]="PM_V3 SQL Simulasyon Paketi ACIK. Cevrimdisi Nebim verileri sifir hatayla okundu.";}}catch{}}if(!Convert.ToBoolean(response["ok"]))response["mesaj"]="SQL dogrudan baglanti denemeleri tamamlandi; baglanti yetkisi/ayar detayi sql-durum-raporu.txt dosyasina yazildi.";
  }

  reportLines.Add("--------------------------------------------------------------------------------");
  reportLines.Add("KESFEDILEN NEBIM BELLEK, KONFIGURASYON VE KAYIT DEFTERI BULGULARI ("+findings.Count+"):");
  foreach(string f in findings)reportLines.Add("  * "+f);
  reportLines.Add("--------------------------------------------------------------------------------");
  reportLines.Add("SQL BAGLANTI DENEMELERI ("+attemptLogs.Count+"):");
  foreach(string a in attemptLogs)reportLines.Add("  -> "+a);
  reportLines.Add("================================================================================");

  try{
   File.WriteAllText(Path.Combine(Root,"sql-durum-raporu.txt"),string.Join(Environment.NewLine,reportLines.ToArray()),new UTF8Encoding(false));
  }catch{}

  return response;
 }
}