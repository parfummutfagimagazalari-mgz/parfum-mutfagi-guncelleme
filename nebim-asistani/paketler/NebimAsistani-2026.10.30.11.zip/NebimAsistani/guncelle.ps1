# Copyright (c) 2026 Ahmet Aksoy. Tum haklari saklidir. Izinsiz degistirilemez, kopyalanamaz, ticari kullanilamaz (LISANS.txt).
# Nebim Asistani - GUNCELLEYICI (30.10.2026)
# Yeni surumu GitHub'daki surum bildiriminden bulur, zip'i indirir, SHA-256 ile dogrular ve kurar.
# Sube ayarlari (sube.json: kod, ad, sunucu, merkez) ve karo ayarlari korunur. Nebim'e HICBIR SEY yazmaz.
#   -Kontrol : yalniz yeni surum var mi bakar, state\guncelleme.json'a yazar (asistan haber verir). Hicbir sey kurmaz.
param([switch]$Kontrol)

$ErrorActionPreference = 'Stop'
$BILDIRIM = 'https://raw.githubusercontent.com/parfummutfagimagazalari-mgz/parfum-mutfagi-guncelleme/main/nebim-asistani/surum.json'
$IZINLI = 'https://raw.githubusercontent.com/parfummutfagimagazalari-mgz/parfum-mutfagi-guncelleme/main/nebim-asistani/paketler/'
$kok = $PSScriptRoot
$durumDosyasi = Join-Path $kok 'state\guncelleme.json'

function Yaz([string]$m) { Write-Host ('{0:HH:mm:ss} {1}' -f (Get-Date), $m) }
function Durum($veri) {
  try {
    New-Item -ItemType Directory -Force (Split-Path $durumDosyasi) | Out-Null
    [IO.File]::WriteAllText($durumDosyasi, ($veri | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
  } catch {}
}

try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

  $mevcutDosya = Join-Path $kok 'surum.json'
  $mevcut = '0.0.0.0'
  if (Test-Path $mevcutDosya) { $mevcut = [string](Get-Content -LiteralPath $mevcutDosya -Raw -Encoding UTF8 | ConvertFrom-Json).surum }

  $b = Invoke-RestMethod -Uri ($BILDIRIM + '?t=' + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 20
  if (-not $b.surum -or -not $b.zip -or -not $b.sha256) { throw 'Surum bildirimi eksik (surum/zip/sha256).' }
  if (-not ([string]$b.zip).StartsWith($IZINLI)) { throw ('Surum bildirimindeki indirme adresi izinli depoda degil: ' + $b.zip) }
  if ([string]$b.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'Surum bildirimindeki SHA-256 gecersiz.' }
  $yeniVar = ([version]$b.surum) -gt ([version]$mevcut)

  if ($Kontrol) {
    Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = $mevcut; yeni = [string]$b.surum; var = $yeniVar; notlar = [string]$b.notlar })
    exit 0
  }

  Yaz ('Kurulu surum: ' + $mevcut + ' | GitHub yayindaki surum: ' + $b.surum)
  $mahmutbeyKurulumu = Test-Path (Join-Path $kok 'desktop\asistan-9karo-kur.ps1')

  if (-not $yeniVar) {
    Yaz 'GitHub uzerindeki en son surum zaten kurulu.'
    if ($mahmutbeyKurulumu) {
      Yaz 'Mahmutbey yerel derleme ve servis yenilemesi calistiriliyor...'
      & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $kok 'desktop\asistan-9karo-kur.ps1')
    }
    Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = $mevcut; yeni = [string]$b.surum; var = $false; notlar = '' })
    Yaz 'Asistan guncel ve aktif.'
    exit 0
  }
  if ($b.notlar) { Yaz ('Yenilikler: ' + $b.notlar) }

  $is = Join-Path $env:TEMP ('NebimAsistani-guncelleme-' + $b.surum)
  if (Test-Path $is) { Remove-Item $is -Recurse -Force }
  New-Item -ItemType Directory -Force $is | Out-Null
  $zip = Join-Path $is 'NebimAsistani.zip'
  Yaz 'GitHub deposundan indiriliyor...'
  Invoke-WebRequest -Uri $b.zip -OutFile $zip -UseBasicParsing -TimeoutSec 300
  $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
  if ($hash -ne ([string]$b.sha256).ToUpperInvariant()) { throw ('Indirilen dosya dogrulanamadi (SHA-256 farkli). Kurulum yapilmadi. Beklenen ' + $b.sha256 + ', gelen ' + $hash) }
  Yaz 'Dosya dogrulandi (SHA-256)'

  $acik = Join-Path $is 'acik'
  Expand-Archive -LiteralPath $zip -DestinationPath $acik -Force

  if ($mahmutbeyKurulumu) {
    Yaz 'Mahmutbey ve Ankara Merkez kurulumu guncelleniyor (sube ve karo ayarlari korunuyor)...'
    $paketKok = Join-Path $acik 'NebimAsistani'
    if (-not (Test-Path $paketKok)) { $paketKok = $acik }
    $araclar = Join-Path $env:APPDATA 'Parfum Mutfagi\veri\nebim-gelen\araclar'
    $merkezKesif = Join-Path $araclar 'merkez-kesif'
    New-Item -ItemType Directory -Force $araclar | Out-Null
    New-Item -ItemType Directory -Force $merkezKesif | Out-Null
    if (Test-Path (Join-Path $paketKok 'sunucu-yardimci\NebimYardimci.exe')) {
      Copy-Item (Join-Path $paketKok 'sunucu-yardimci\NebimYardimci.exe') (Join-Path $araclar 'NebimYardimci.exe') -Force
      Copy-Item (Join-Path $paketKok 'sunucu-yardimci\NebimYardimci.exe') (Join-Path $kok 'sunucu-yardimci\NebimYardimci.exe') -Force
    }
    foreach ($jsonFile in @('nebim-bilgi-cozum-kutuphanesi.json', 'hata-sozlugu.json')) {
      if (Test-Path (Join-Path $paketKok ('sunucu-yardimci\' + $jsonFile))) {
        Copy-Item (Join-Path $paketKok ('sunucu-yardimci\' + $jsonFile)) (Join-Path $araclar $jsonFile) -Force
        Copy-Item (Join-Path $paketKok ('sunucu-yardimci\' + $jsonFile)) (Join-Path $kok ('desktop\' + $jsonFile)) -Force
      }
    }
    if (Test-Path (Join-Path $paketKok 'desktop\MerkezAtlasKesif.exe')) {
      Get-Process MerkezAtlasKesif* -ErrorAction SilentlyContinue | Stop-Process -Force
      Copy-Item (Join-Path $paketKok 'desktop\MerkezAtlasKesif.exe') (Join-Path $merkezKesif 'MerkezAtlasKesif.exe') -Force
      Copy-Item (Join-Path $paketKok 'desktop\MerkezAtlasKesif.exe') (Join-Path $merkezKesif 'MerkezAtlasKesif_Live.exe') -Force
    }
    if (Test-Path (Join-Path $paketKok 'desktop\NebimAssistant.exe')) {
      Get-Process NebimAssistant -ErrorAction SilentlyContinue | Stop-Process -Force
      Start-Sleep -Seconds 1
      Copy-Item (Join-Path $paketKok 'desktop\NebimAssistant.exe') (Join-Path $kok 'desktop\NebimAssistant.exe') -Force
      Copy-Item (Join-Path $paketKok 'desktop\NebimAssistant.exe') (Join-Path $araclar 'NebimAssistant.exe') -Force
      if (Test-Path (Join-Path $paketKok 'surum.json')) {
        Copy-Item (Join-Path $paketKok 'surum.json') (Join-Path $kok 'surum.json') -Force
      }
      Start-Process -FilePath (Join-Path $kok 'desktop\NebimAssistant.exe') -WorkingDirectory (Join-Path $kok 'desktop')
    }
  } else {
    $kur = Get-ChildItem -Path $acik -Filter 'kur.ps1' -Recurse | Select-Object -First 1
    if (-not $kur) { throw 'Paketin icinde kur.ps1 bulunamadi.' }
    Yaz 'Kuruluyor (sube ayarlari korunuyor)...'
    & powershell -NoProfile -ExecutionPolicy Bypass -File $kur.FullName -Zorla
    if ($LASTEXITCODE -ne 0) { throw 'Kurulum tamamlanamadi; ayrinti masaustundeki NEBIM-ASISTAN-KURULUM-SONUC.txt dosyasinda. Eski surum calismaya devam ediyor.' }
  }

  Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); mevcut = [string]$b.surum; yeni = [string]$b.surum; var = $false; notlar = '' })
  Remove-Item $is -Recurse -Force -ErrorAction SilentlyContinue
  Yaz ('GUNCELLEME TAMAM: surum ' + $b.surum)
} catch {
  if ($Kontrol) { Durum ([ordered]@{ kontrol = (Get-Date -Format 's'); var = $false; hata = $_.Exception.Message }); exit 0 }
  Yaz ('GUNCELLEME YAPILAMADI: ' + $_.Exception.Message)
  Yaz 'Mevcut asistan calismaya devam ediyor; Nebim''e hicbir sey yazilmadi.'
  exit 1
}
